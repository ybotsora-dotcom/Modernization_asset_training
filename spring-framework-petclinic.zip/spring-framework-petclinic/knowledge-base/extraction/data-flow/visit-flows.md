---
tags:
  - extraction
  - data-flow
---
# Data Flow Analysis — Visit flows

## Flow: Add visit to a pet

**Confidence**: HIGH

### Source
- **Type**: HTTP request (POST /owners/{ownerId}/pets/{petId}/visits/new)
- **Location**: [VisitController.processNewVisitForm()](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)
- **Format**: form fields (date, description)

### Transformations
1. **Pre-load** - `@ModelAttribute loadPetWithVisit(petId)`: `findPetById`, new `Visit`, `pet.addVisit(visit)`; runs before both GET and POST handlers.
2. **Binding** - `date` via `@DateTimeFormat(pattern="yyyy/MM/dd")`; `id` disallowed.
3. **Validation** - `@Valid`: `@NotEmpty` description ([Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)).
4. **Service** - `saveVisit` (`@Transactional`).
5. **Persist** - JPA persist/merge into `visits`; JDBC `SimpleJdbcInsert` on `visits` with visit_date, description, pet_id (JDBC update path throws `UnsupportedOperationException`).
6. **Response** - `redirect:/owners/{ownerId}`.

### Destination
- **Type**: Database table `visits` (FK pet_id -> pets)
- **Format**: Relational

### Involved Modules
- `web.VisitController`, `model.Visit`, `model.Pet`, `service.ClinicServiceImpl`, `repository.VisitRepository` implementations

### Evidence
- [VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java); [JdbcVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java) `save`; [JpaVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVisitRepositoryImpl.java) `save`

## Flow: Show visit history of a pet

**Confidence**: HIGH

### Source
- **Type**: HTTP request (GET /owners/*/pets/{petId}/visits)
- **Location**: [VisitController.showVisits()](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)
- **Format**: path variable

### Transformations
1. `findPetById(petId).getVisits()`; visits come from the loaded `Pet` (eager `@OneToMany` under JPA, owner-wide join in the JDBC path). Model key `visits`, view `visitList`.
2. Note: `ClinicService.findVisitsByPetId` -> `VisitRepository.findByPetId` exists (JPA JPQL `v.pet.id = :id`; JDBC pet row + visit rows, `visit.setPet`). `ClinicServiceImpl.findVisitsByPetId` has no `@Transactional`, and the four controllers read do not call it.

### Destination
- **Type**: HTML response (JSP `visitList`)
- **Format**: HTML

### Involved Modules
- `web.VisitController`, `service.ClinicServiceImpl`, `repository.PetRepository`

### Evidence
- [VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java) `showVisits`; [ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) `findVisitsByPetId`

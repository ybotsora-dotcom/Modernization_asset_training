---
tags:
  - extraction
  - data-flow
---
# Data Flow Analysis — Pet flows

## Flow: Pet form preparation (reference data and owner load)

**Confidence**: HIGH

### Source
- **Type**: HTTP request (any route under /owners/{ownerId} handled by `PetController`)
- **Location**: [PetController.populatePetTypes(), findOwner()](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java) (`@ModelAttribute`, run before every handler)
- **Format**: path variable

### Transformations
1. **Pet types** - `clinicService.findPetTypes()` -> `PetRepository.findPetTypes()`: JPQL `SELECT ptype FROM PetType ptype ORDER BY ptype.name` (jpa, spring-data-jpa) or `SELECT id, name FROM types ORDER BY name` (jdbc). Model key `types`.
2. **Owner** - `findOwnerById(ownerId)`, model key `owner` (see [owner-flows.md](./owner-flows.md)).
3. **Create form** - `initCreationForm`: new `Pet`, `owner.addPet(pet)` (sets pet.owner), model `pet`.
4. **Edit form** - `initUpdateForm`: `findPetById`; JPA `em.find(Pet.class,id)`; JDBC reads `owner_id` from `pets`, loads the whole owner via `OwnerRepository.findById`, then picks the pet with `EntityUtils.getById`.

### Destination
- **Type**: HTML response (JSP `pets/createOrUpdatePetForm`)
- **Format**: HTML

### Involved Modules
- `web.PetController`, `service.ClinicServiceImpl`, `repository.PetRepository` implementations, `repository.jdbc.JdbcPetRepositoryImpl` (depends on `OwnerRepository`)

### Evidence
- [PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java); [JpaPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaPetRepositoryImpl.java); [JdbcPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java)

## Flow: Create or update pet (form POST)

**Confidence**: HIGH

### Source
- **Type**: HTTP request (POST /owners/{ownerId}/pets/new and /pets/{petId}/edit)
- **Location**: [PetController.processCreationForm(), processUpdateForm()](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
- **Format**: form fields (name, birthDate, type)

### Transformations
1. **Type conversion** - `type` text -> `PetType` by `PetTypeFormatter.parse()`, which loads all types via `findPetTypes()` and matches by name; unknown -> `ParseException` ([PetTypeFormatter.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java), registered in [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml)).
2. **Date conversion** - `birthDate` parsed with `@DateTimeFormat(pattern="yyyy/MM/dd")` ([Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)).
3. **Validation** - `PetValidator` (name required; type required if new; birthDate required), set by `@InitBinder("pet")` ([PetValidator.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java)).
4. **Duplicate check (create only)** - `owner.getPet(name, true)` non-null -> field error `duplicate`.
5. **Association** - `owner.addPet(pet)` sets `pet.owner`.
6. **Service/persist** - `savePet`: JPA persist/merge; JDBC `SimpleJdbcInsert` into `pets` (new) or `UPDATE pets SET name, birth_date, type_id, owner_id` using `createPetParameterSource` (flattens type and owner to ids).
7. **Response** - `redirect:/owners/{ownerId}`.

### Destination
- **Type**: Database table `pets` (FKs to `owners`, `types`)
- **Format**: Relational

### Involved Modules
- `web.PetController`, `web.PetValidator`, `web.PetTypeFormatter`, `model.Pet`, `service.ClinicServiceImpl`, `repository.PetRepository` implementations

### Evidence
- [PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java) `processCreationForm`, `processUpdateForm`; [JdbcPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java) `save`, `createPetParameterSource`
- Observation: only the `owner` binder disallows `id`; no `id` restriction was found for the `pet` binder. Runtime effect not verified.

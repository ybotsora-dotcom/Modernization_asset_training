---
tags:
  - extraction
  - data-flow
---
# Data Flow Analysis — Infrastructure and cross-cutting flows

## Flow: Startup database initialization

**Confidence**: HIGH

### Source
- **Type**: File (classpath `db/${db.script}/schema.sql` and `data.sql`)
- **Location**: [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml) `jdbc:initialize-database`; paths from [data-access.properties](../../../src/main/resources/spring/data-access.properties) (`jdbc.initLocation`, `jdbc.dataLocation`; `db.script` is a Maven placeholder)
- **Format**: SQL scripts

### Transformations
1. Placeholders resolved by `context:property-placeholder` with `system-properties-mode="OVERRIDE"`.
2. Scripts run in order on the `dataSource` (tomcat-jdbc pool). H2 schema drops and recreates 7 tables (vets, specialties, vet_specialties, types, owners, pets, visits) with FKs; the data script has 47 INSERT lines. Variants exist under `db/hsqldb`, `mysql`, `postgresql` (not read).
3. A `javaee` profile replaces the DataSource with JNDI lookup `java:comp/env/jdbc/petclinic`.

### Destination
- **Type**: Database (all tables)
- **Format**: Relational

### Involved Modules
- `datasource-config.xml`, `data-access.properties`, `pom.xml` (profile property values, not re-read here)

### Evidence
- [schema.sql](../../../src/main/resources/db/h2/schema.sql), [data.sql](../../../src/main/resources/db/h2/data.sql). No procedures, functions, views or triggers found in any db script (grep).

## Flow: Persistence profile switching

**Confidence**: HIGH

### Source
- **Type**: Configuration (`PetclinicInitializer.SPRING_PROFILE = "jpa"` default, or `spring.profiles.active`)
- **Location**: [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)

### Transformations
1. `jpa` / `spring-data-jpa`: `LocalContainerEntityManagerFactoryBean` (Hibernate, packagesToScan `org.springframework.samples.petclinic`), `JpaTransactionManager`, `PersistenceExceptionTranslationPostProcessor`.
2. `jdbc`: `DataSourceTransactionManager`, `JdbcClient`, `NamedParameterJdbcTemplate`, component scan of `repository.jdbc`.
3. `jpa`: component scan `repository.jpa`; `spring-data-jpa`: `<jpa:repositories>` on `repository.springdatajpa`.

### Destination
- **Type**: Bean wiring that decides which repository implementation serves every flow

### Involved Modules
- `business-config.xml`, `ClinicServiceImpl`

### Evidence
- [business-config.xml](../../../src/main/resources/spring/business-config.xml); [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) lines 52-58

## Flow: Repository call monitoring (JMX)

**Confidence**: HIGH

### Source
- **Type**: Every method call on a `@Repository` bean (Spring AOP, pointcut `within(@org.springframework.stereotype.Repository *)`)
- **Location**: [CallMonitoringAspect.invoke()](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java)

### Transformations
1. `invoke()` times the call with `StopWatch`, increments `callCount` and `accumulatedCallTime` (synchronized) when `enabled` (default true).
2. Exposed as MBean `petclinic:type=CallMonitor` via `context:mbean-export` ([tools-config.xml](../../../src/main/resources/spring/tools-config.xml)).

### Destination
- **Type**: In-memory counters read via JMX (not persisted)

### Involved Modules
- `util.CallMonitoringAspect`, JPA/JDBC repository implementations

### Evidence
- [CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java) lines 77-96
- Inferred, not verified: Spring Data interfaces are not annotated `@Repository`, so the pointcut likely does not cover them.

## Flow: Error handling

**Confidence**: MEDIUM

### Source
- **Type**: Any unhandled controller exception (`CrashController` /oups not read in this pass)

### Transformations
1. `SimpleMappingExceptionResolver` with `defaultErrorView="exception"` -> `WEB-INF/jsp/exception.jsp` ([mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) lines 60-65).

### Destination
- **Type**: HTML error page

### Involved Modules
- `mvc-core-config.xml`, `mvc-view-config.xml`

### Evidence
- [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml)

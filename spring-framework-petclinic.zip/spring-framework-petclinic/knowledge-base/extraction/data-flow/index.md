---
tags:
  - extraction
  - data-flow
---
# Data Flow Overview

Single-module Spring Framework XML-configured web app (web -> service -> repository -> relational DB). Static analysis only; nothing was built or run. Total documented flows: 13.

## Module files
- [owner-flows.md](./owner-flows.md) — create, update, search, show owner (4 flows)
- [pet-flows.md](./pet-flows.md) — form preparation, create/update pet (2 flows)
- [visit-flows.md](./visit-flows.md) — add visit, show visit history (2 flows)
- [vet-flows.md](./vet-flows.md) — vet list as HTML/JSON/XML with Caffeine cache (1 flow)
- [infrastructure-flows.md](./infrastructure-flows.md) — DB initialization, profile switching, JMX call monitoring, error handling (4 flows)

## Critical paths
1. Owner write: `OwnerController` -> `@Valid` -> `ClinicServiceImpl.saveOwner` -> repository (persist/merge, or SimpleJdbcInsert/UPDATE) -> `owners`.
2. Owner read with pets and visits: JPA uses one left-join-fetch query; JDBC loads pets and visits per owner (N+1 on searches).
3. Pet write: `PetTypeFormatter` + `PetValidator` + duplicate-name check -> `savePet` -> `pets`.
4. Visit write: `@ModelAttribute` pet/visit linking -> `saveVisit` -> `visits`.
5. Vet list: the only cached flow (`@Cacheable("vets")`, Caffeine); no eviction found in code.

## Facts worth knowing
- Three interchangeable repository implementations sit behind every flow; differences are documented per flow.
- No stored procedures, views or triggers exist, so the DB tier has no SQL-resident transformation steps.
- All flows are synchronous HTTP -> DB; no messaging, async or external API flows; no AI product code.

## Open gaps
- JSP view bodies and `CrashController` not read; JSON/XML converter registration not traced; `JdbcPetVisitExtractor` body not read.
- Spring Data variants of `save` and `findAll` are inferred from interface inheritance.

## Related
- [repository/index.md](../repository/index.md)

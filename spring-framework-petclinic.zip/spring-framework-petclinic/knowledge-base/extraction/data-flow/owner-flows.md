---
tags:
  - extraction
  - data-flow
---
# Data Flow Analysis — Owner flows

Common persistence tier for all flows: controller -> `ClinicServiceImpl` (`@Transactional`) -> `OwnerRepository` implementation selected by Spring profile (jpa default, jdbc, spring-data-jpa; see [infrastructure-flows.md](./infrastructure-flows.md)). No stored procedures, views or triggers exist in `db/*/schema.sql` or `data.sql` (grep), so there are no SQL-resident steps.

## Flow: Create owner (form POST)

**Confidence**: HIGH

### Source
- **Type**: HTTP request (POST /owners/new, form-encoded)
- **Location**: [OwnerController.processCreationForm()](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- **Format**: form fields bound to `Owner`

### Transformations
1. **Binding** - `@InitBinder setAllowedFields` disallows field `id`; form -> `Owner`.
2. **Validation** - `@Valid`: `@NotEmpty` on firstName/lastName/address/city/telephone, `@Digits(integer=10)` on telephone ([Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [Person.java](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java)). On errors the form view `owners/createOrUpdateOwnerForm` is returned with no write.
3. **Service** - `ClinicServiceImpl.saveOwner()` (`@Transactional`) -> `ownerRepository.save()` ([ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)).
4. **Persist (jpa)** - `JpaOwnerRepositoryImpl.save()`: `persist` if id null else `merge` ([JpaOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java)).
5. **Persist (jdbc)** - `JdbcOwnerRepositoryImpl.save()`: `SimpleJdbcInsert` on `owners` with generated key; key written back via `owner.setId()` ([JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java)).
6. **Persist (spring-data-jpa)** - [SpringDataOwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java) declares no `save`; it is inherited from the `OwnerRepository` interface and served by `<jpa:repositories>` (inferred, MEDIUM for this variant).
7. **Response** - `redirect:/owners/{id}` using the generated id.

### Destination
- **Type**: Database table `owners` ([schema.sql](../../../src/main/resources/db/h2/schema.sql))
- **Format**: Relational

### Involved Modules
- `web.OwnerController`, `service.ClinicServiceImpl`, `repository.OwnerRepository` + 3 implementations, `model.Owner`

### Evidence
- [OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) `processCreationForm`; [ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) `saveOwner`

## Flow: Update owner (form POST)

**Confidence**: HIGH

### Source
- **Type**: HTTP request (POST /owners/{ownerId}/edit)
- **Location**: [OwnerController.processUpdateOwnerForm()](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- **Format**: form fields + path variable

### Transformations
1. **Binding/validation** - as in the create flow.
2. **Id enrichment** - `owner.setId(ownerId)` from the path variable (id is a disallowed bound field).
3. **Service/persist** - `saveOwner` -> JPA `merge`; JDBC `UPDATE owners SET first_name, last_name, address, city, telephone WHERE id`.
4. **Response** - `redirect:/owners/{ownerId}`.

### Destination
- **Type**: Database table `owners`
- **Format**: Relational

### Involved Modules
- as create flow

### Evidence
- [JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) `save`; [JpaOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java) `save`
- Inferred, not verified: under JPA, `merge` of a form-built detached `Owner` (pets not bound) interacts with `cascade = ALL` on pets; runtime effect not determined.

## Flow: Find owners by last name

**Confidence**: HIGH

### Source
- **Type**: HTTP request (GET /owners?lastName=...)
- **Location**: [OwnerController.processFindForm()](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- **Format**: query parameter bound to `Owner`

### Transformations
1. **Defaulting** - null lastName -> "" (returns all owners).
2. **Service** - `findOwnerByLastName` (`@Transactional(readOnly=true)`).
3. **Query (jpa)** - JPQL `SELECT DISTINCT owner FROM Owner owner left join fetch owner.pets WHERE owner.lastName LIKE :lastName`, parameter `lastName + "%"` (prefix match).
4. **Query (jdbc)** - `SELECT ... FROM owners WHERE last_name like :lastName` via `BeanPropertyRowMapper`, then per owner `loadPetsAndVisits()`: `pets LEFT OUTER JOIN visits` through `JdbcPetVisitExtractor`, type resolved from `SELECT id, name FROM types` with `EntityUtils.getById`, pets attached via `owner.addPet`. Two extra queries per owner (N+1).
5. **Query (spring-data-jpa)** - `@Query` with `LIKE :lastName%` and left join fetch ([SpringDataOwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java)).
6. **Routing by result size** - 0: `rejectValue("lastName","notFound")`, view `owners/findOwners`; 1: `redirect:/owners/{id}`; more: model `selections`, view `owners/ownersList`.

### Destination
- **Type**: HTML response (JSP; prefix `/WEB-INF/jsp/`, suffix `.jsp` in [mvc-view-config.xml](../../../src/main/resources/spring/mvc-view-config.xml)) or redirect
- **Format**: HTML

### Involved Modules
- `web.OwnerController`, `service.ClinicServiceImpl`, owner repositories, `repository.jdbc.JdbcPetVisitExtractor`, `util.EntityUtils`

### Evidence
- [OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) `processFindForm`; [JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) `findByLastName`, `loadPetsAndVisits`
- Gap: `JdbcPetVisitExtractor` body not read; its grouping behaviour is inferred from its use.

## Flow: Show / load owner by id

**Confidence**: HIGH

### Source
- **Type**: HTTP request (GET /owners/{ownerId}, GET /owners/{ownerId}/edit)
- **Location**: [OwnerController.showOwner(), initUpdateOwnerForm()](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- **Format**: path variable

### Transformations
1. **Service** - `findOwnerById` (readOnly).
2. **Query (jpa)** - JPQL `left join fetch owner.pets WHERE owner.id = :id`, `getSingleResult()`.
3. **Query (jdbc)** - owner row via `BeanPropertyRowMapper`; `EmptyResultDataAccessException` -> `ObjectRetrievalFailureException`; then `loadPetsAndVisits`.
4. **View model** - `ModelAndView("owners/ownerDetails")` carrying the owner; the edit variant returns the form view.

### Destination
- **Type**: HTML response (JSP)
- **Format**: HTML

### Involved Modules
- as above

### Evidence
- [JpaOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java) `findById`; [JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) `findById`
- Gap: JSP bodies under `WEB-INF/jsp/owners/` not read; field rendering not traced.

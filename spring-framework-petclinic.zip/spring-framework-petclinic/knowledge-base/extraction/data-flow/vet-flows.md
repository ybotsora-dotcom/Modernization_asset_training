---
tags:
  - extraction
  - data-flow
---
# Data Flow Analysis — Vet flows

## Flow: Vet list (HTML, JSON, XML) with cache

**Confidence**: HIGH

### Source
- **Type**: HTTP request (GET /vets, /vets.json, /vets.xml)
- **Location**: [VetController.showVetList(), showJsonVetList(), showXmlVetList()](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java)
- **Format**: none (no parameters)

### Transformations
1. **Cache check** - `ClinicServiceImpl.findVets()` is `@Cacheable("vets")`; `CaffeineCacheManager` with names `default`, `vets` ([tools-config.xml](../../../src/main/resources/spring/tools-config.xml)). First call reaches the repository; later calls return the cached collection. No eviction found in code.
2. **Query (jpa)** - JPQL `SELECT distinct vet FROM Vet vet left join fetch vet.specialties ORDER BY vet.lastName, vet.firstName`.
3. **Query (jdbc)** - ordered `vets`; all `specialties`; per vet `SELECT specialty_id FROM vet_specialties WHERE vet_id=?` (N+1); specialties resolved with `EntityUtils.getById` and `vet.addSpecialty`.
4. **Query (spring-data-jpa)** - [SpringDataVetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataVetRepository.java) declares no query; `findAll` is inherited from `VetRepository` (inferred, MEDIUM for this variant).
5. **Wrapping** - `getVets()` copies into the `Vets` wrapper (`@XmlRootElement`, list element `vet`).
6. **Serialization** - HTML: model `vets` -> JSP `vets/vetList`; JSON/XML: `@ResponseBody` with `produces`. `Vet.getSpecialties()` (`@XmlElement`) returns a name-sorted (case-insensitive) unmodifiable list ([Vet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java)).

### Destination
- **Type**: API response / HTML response (Cache `vets` as intermediate)
- **Format**: HTML, JSON, XML

### Involved Modules
- `web.VetController`, `service.ClinicServiceImpl`, `repository.VetRepository` implementations, `model.Vets`, `model.Vet`, `model.Specialty`

### Evidence
- [VetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java); [ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) `findVets`; [JdbcVetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVetRepositoryImpl.java) `findAll`
- Gap: JSON/XML message converter registration not traced.

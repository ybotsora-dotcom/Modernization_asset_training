---
tags:
  - extraction
  - ui-ux
---

# Navigation flows

Back to [index.md](./index.md). Screen detail: [owners.md](./owners.md), [pets-visits.md](./pets-visits.md), [shell-and-vets.md](./shell-and-vets.md). Single-page-per-request server-rendered app; no modals/dialogs, no client-side routing, no role-based menu conditions found.

## Menu tree (menu.tag)
- Home -> `/` (Welcome)
- Find owners -> `/owners/find` (Find Owners)
- Veterinarians -> `/vets` (Veterinarians List)
- Error -> `/oups` (Error)
- Dispatcher servlet mapped to `/` (PetclinicInitializer.getServletMappings); static: `/resources/**`, `/webjars/**`.

## Route table
| Method | Path | Handler | View / result |
|---|---|---|---|
| GET | / | view-controller | welcome |
| GET | /owners/find | OwnerController.initFindForm | owners/findOwners |
| GET | /owners | processFindForm | findOwners (none) / redirect (1) / owners/ownersList (many) |
| GET/POST | /owners/new | initCreationForm / processCreationForm | owners/createOrUpdateOwnerForm; redirect /owners/{id} |
| GET | /owners/{ownerId} | showOwner | owners/ownerDetails |
| GET/POST | /owners/{ownerId}/edit | initUpdateOwnerForm / processUpdateOwnerForm | form; redirect /owners/{ownerId} |
| GET/POST | /owners/{ownerId}/pets/new | PetController | pets/createOrUpdatePetForm; redirect /owners/{ownerId} |
| GET/POST | /owners/{ownerId}/pets/{petId}/edit | PetController | same form; redirect |
| GET | /owners/*/pets/{petId}/visits/new | VisitController.initNewVisitForm | pets/createOrUpdateVisitForm |
| POST | /owners/{ownerId}/pets/{petId}/visits/new | processNewVisitForm | redirect /owners/{ownerId} |
| GET | /owners/*/pets/{petId}/visits | showVisits | `visitList` (no JSP found) |
| GET | /vets | VetController.showVetList | vets/vetList |
| GET | /vets.json, /vets.xml | showJsonVetList, showXmlVetList | @ResponseBody |
| GET | /oups | CrashController | throws -> exception view |

## Navigation Flow: Find with single match
- **Entry Point**: Find Owner button. **Source**: Find Owners. **Target**: Owner Details. **Trigger**: submit. **Parameters**: ownerId. **Condition**: exactly one owner matches (`results.size()==1`).
- Evidence: OwnerController.processFindForm. Confidence: HIGH

## Navigation Flow: Find with multiple matches / none
- Many -> Owners List (model `selections`); name link -> Owner Details. None -> same Find page with "not found" error. Evidence: OwnerController.processFindForm; ownersList.jsp:25-28. Confidence: HIGH

## Navigation Flow: Create owner
- Find Owners "Add Owner" -> `/owners/new`; valid POST -> redirect to Owner Details of the new id; invalid -> same form with field errors. Confidence: HIGH

## Navigation Flow: Edit owner / pets / visits (from Owner Details)
- "Edit Owner" -> `{ownerId}/edit` (relative URL); "Add New Pet" -> `{ownerId}/pets/new`; "Edit Pet" -> `/owners/{o}/pets/{p}/edit`; "Add Visit" -> `/owners/{o}/pets/{p}/visits/new`. Each successful POST redirects back to Owner Details (`redirect:/owners/{ownerId}`); validation failure re-renders the form. Confidence: HIGH

## Back / context navigation
- No explicit back or cancel buttons exist on any form; users rely on the browser or menu. Context (owner id, pet id) is carried only in URL path variables; no session (`<%@ page session="false" %>` on all JSPs).
- Any unhandled exception from any route renders the Error screen (SimpleMappingExceptionResolver).

---
tags:
  - extraction
  - ui-ux
---

# Shell, Welcome, Vets and Error screens

See [index.md](./index.md), [navigation.md](./navigation.md), [owners.md](./owners.md).

## Shared Shell (layout tag library)
- **Source File**: [layout.tag](../../../src/main/webapp/WEB-INF/tags/layout.tag) composing [htmlHeader.tag](../../../src/main/webapp/WEB-INF/tags/htmlHeader.tag), [bodyHeader.tag](../../../src/main/webapp/WEB-INF/tags/bodyHeader.tag) -> [menu.tag](../../../src/main/webapp/WEB-INF/tags/menu.tag) -> [menuItem.tag](../../../src/main/webapp/WEB-INF/tags/menuItem.tag), [pivotal.tag](../../../src/main/webapp/WEB-INF/tags/pivotal.tag), [footer.tag](../../../src/main/webapp/WEB-INF/tags/footer.tag)
- Every JSP wraps content in `<petclinic:layout pageName="...">` (optional `customScript` fragment invoked after footer). `pageName` values: `home`, `owners`, `vets`, `error`; the menu marks the matching item `active`.
- Field helpers: [inputField.tag](../../../src/main/webapp/WEB-INF/tags/inputField.tag) (label + `form:input` + success/error icon + `status.errorMessage`), [selectField.tag](../../../src/main/webapp/WEB-INF/tags/selectField.tag) (`form:select` from a List), [localDate.tag](../../../src/main/webapp/WEB-INF/tags/localDate.tag) (formats LocalDate with a pattern).

```
┌──────────────────────────────────────────────────┐
│ navbar (dark, expand-lg, burger toggler)         │
│ [brand] [Home][Find owners][Veterinarians][Error]│
├──────────────────────────────────────────────────┤
│ container-fluid > container.xd-container         │
│   <page body>                                    │
│   [Sponsored by Pivotal logo]                    │
├──────────────────────────────────────────────────┤
│ bootstrap.bundle.js (footer.tag) + customScript  │
└──────────────────────────────────────────────────┘
```
- Menu items (menu.tag:16-34): Home `/` (fa-home), Find owners `/owners/find` (fa-search), Veterinarians `/vets` (fa-th-list), Error `/oups` (glyph `exclamation-triangle`, no `fa-` prefix; likely renders no icon, inferred).
- Evidence: layout.tag:1-27; menu.tag:7-39. Confidence: HIGH.

## Screen: Welcome
- **Source File**: [welcome.jsp](../../../src/main/webapp/WEB-INF/jsp/welcome.jsp)
- **Handler**: `<mvc:view-controller path="/" view-name="welcome"/>` in [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml); no controller class, no backend call.
- **Purpose**: Landing page: heading from message key `welcome` (en/de/es bundles) and pets.png image.
- **Layout Model**: one full-width Bootstrap row
```
┌──────────────────────────────────────────────────┐
│ [menu bar: Home active]                          │
│ Welcome  (fmt:message key="welcome")             │
│ [ pets.png: A cat and a dog ]                    │
└──────────────────────────────────────────────────┘
```
- Navigation: entry screen; menu leads elsewhere. No interactive controls beyond the menu.
- **Evidence**: welcome.jsp:6-14; mvc-core-config.xml (view-controller). **Confidence**: HIGH (locale-resolution mechanism not verified; no LocaleResolver bean seen in the web config, so default Accept-Language handling is inferred).

## Screen: Veterinarians List
- **Source File**: [vetList.jsp](../../../src/main/webapp/WEB-INF/jsp/vets/vetList.jsp)
- **Handler**: [VetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java) `showVetList` (GET /vets)
- **Purpose**: Read-only list of vets with specialties, plus links to machine-readable feeds.
- **Domain**: Vets
```
┌──────────────────────────────────────────────────┐
│ [menu bar: Veterinarians active]                 │
│ Veterinarians                                    │
│ ┌──────────────────┬───────────────────────────┐ │
│ │ Name             │ Specialties               │ │
│ ├──────────────────┼───────────────────────────┤ │
│ │ First Last       │ names, or "none"          │ │
│ └──────────────────┴───────────────────────────┘ │
│ [View as XML]  [View as JSON]                    │
└──────────────────────────────────────────────────┘
```
### Key Controls
| Control | Type | Label | Bound To | Purpose |
|---|---|---|---|---|
| vetsTable | table | "Veterinarians" | `vets.vetList` | Rows (firstName lastName, specialties, "none" when nrOfSpecialties==0) |
| View as XML | link | "View as XML" | - | GET /vets.xml |
| View as JSON | link | "View as JSON" | - | GET /vets.json |
### Interactions
| Trigger | Handler | Backend Call | Business Rule |
|---|---|---|---|
| Page load | `showVetList` | `ClinicService.findVets()` (wrapped in `Vets`) | No paging/filter |
| XML link | `showXmlVetList` (produces application/xml) | `ClinicService.findVets()` | JAXB `Vets` |
| JSON link | `showJsonVetList` (produces application/json) | `ClinicService.findVets()` | - |
- Note: mvc-view-config.xml also declares a bean view `vets/vetList.xml` (MarshallingView); whether it is used given the `@ResponseBody` endpoints is not verified.
- **Evidence**: vetList.jsp:7-44; VetController.java. **Confidence**: HIGH

## Screen: Error (Exception view)
- **Source File**: [exception.jsp](../../../src/main/webapp/WEB-INF/jsp/exception.jsp)
- **Handler**: [CrashController.java](../../../src/main/java/org/springframework/samples/petclinic/web/CrashController.java) `triggerException` (GET /oups) throws RuntimeException; `SimpleMappingExceptionResolver` (defaultErrorView `exception`) in mvc-core-config.xml renders it for any unhandled controller exception.
- **Purpose**: Demonstrates error handling; shows pets.png, "Something happened..." and `${exception.message}`.
```
┌──────────────────────────────────────────────────┐
│ [menu bar: Error active]                         │
│ [ pets.png ]                                     │
│ Something happened...                            │
│ <exception message>                              │
└──────────────────────────────────────────────────┘
```
- No backend call; no controls. **Evidence**: exception.jsp:5-14; CrashController.java. **Confidence**: HIGH

## Styling Patterns
- Bootstrap 5.3.8 via WebJar (`bootstrap.bundle.min.js` in footer.tag); Font Awesome 4.7.0 CSS via WebJar; app CSS `/resources/css/petclinic.css` compiled from `resources/scss/{petclinic,header,typography,responsive}.scss`; fonts Montserrat and Varela Round in `resources/fonts`.
- Forms use Bootstrap 3-style classes (`form-horizontal`, `form-group`, `col-sm-2/10`, `has-error`, `help-inline`) on a Bootstrap 5 base; a modernization should normalize these. Validation icons use `fa-ok`/`fa-remove`, which are not Font Awesome 4.7 icon names (inferred: icons may not render).
- Responsive: viewport meta, navbar collapse, `responsive.scss`. Legacy IE shim comments in htmlHeader.tag.
- Only one client target exists; no separate mobile or native client found.
- **Evidence**: htmlHeader.tag:7-29; footer.tag:3-5. **Confidence**: HIGH (rendering of icons MEDIUM).

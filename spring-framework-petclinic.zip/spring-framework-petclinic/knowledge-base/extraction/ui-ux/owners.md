---
tags:
  - extraction
  - ui-ux
---

# Owners domain screens

Shared layout/tags: see [shell-and-vets.md](./shell-and-vets.md). Navigation: [navigation.md](./navigation.md). Index: [index.md](./index.md).
All controller logic is in [OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) and delegates to `ClinicService` (`service/ClinicService.java`), whose persistence is profile-switched (jpa/jdbc/spring-data-jpa). Menu highlight for all of these: `pageName="owners"` ("Find owners").

## Screen: Find Owners
- **Source File**: [findOwners.jsp](../../../src/main/webapp/WEB-INF/jsp/owners/findOwners.jsp)
- **Handler/Code-Behind**: `OwnerController.initFindForm` (GET /owners/find), `OwnerController.processFindForm` (GET /owners)
- **Purpose**: Search owners by last name or jump to creating an owner.
- **Domain**: Owners
- **Client Targets**: Only target (Web browser)
- **Layout Model**: Bootstrap `form-horizontal` rows inside `container`

### Wireframe
```
┌──────────────────────────────────────────────────┐
│ [logo] [Home] [Find owners]* [Veterinarians] [Error]│
├──────────────────────────────────────────────────┤
│  Find Owners                                     │
│  Last name  [ lastName (max 80)            ]     │
│             (error text: "not found")            │
│             [Find Owner]                         │
│                                                  │
│  [Add Owner]                                     │
│              (Pivotal logo)                      │
└──────────────────────────────────────────────────┘
```

### Key Controls
| Control Name | Type | Label | Bound To | Purpose |
|---|---|---|---|---|
| search-owner-form | form GET /owners | - | `owner` (new Owner) | Submits search |
| lastName | form:input size 30 maxlength 80 | "Last name" | owner.lastName | Search term |
| (errors) | form:errors path="*" | - | BindingResult | Shows "not found" |
| Find Owner | submit button | "Find Owner" | - | Search |
| Add Owner | link btn | "Add Owner" | - | -> /owners/new |

### Interactions
| Trigger | Handler | Backend Call | Business Rule |
|---|---|---|---|
| Page load | `initFindForm` | none (new `Owner`) | - |
| Find Owner submit | `processFindForm` | `ClinicService.findOwnerByLastName(lastName)` | null lastName becomes "" (all owners); 0 results -> rejectValue("lastName","notFound") re-renders this page; 1 result -> redirect to details; >1 -> Owners list |

### Data Bindings
- **Displayed Entity**: Owner - lastName
- **Editable Fields**: lastName (text, max 80 client-side, no server validation)

### Navigation
- **Navigates To**: Owners List, Owner Details (single match), Owner Form (Add Owner)
- **Navigated From**: Main menu "Find owners"
- **Opens Dialogs**: none

### Styling Notes
- Uses raw markup rather than `petclinic:inputField` (own label/`control-group`).
- **Evidence**: findOwners.jsp:8-34; OwnerController.java (initFindForm, processFindForm)
- **Confidence**: HIGH

## Screen: Owners List
- **Source File**: [ownersList.jsp](../../../src/main/webapp/WEB-INF/jsp/owners/ownersList.jsp)
- **Handler/Code-Behind**: `OwnerController.processFindForm` (multiple-match branch)
- **Purpose**: Show search results when more than one owner matches.
- **Domain**: Owners
- **Client Targets**: Only target (Web browser)
- **Layout Model**: Single striped table

### Wireframe
```
┌──────────────────────────────────────────────────┐
│ [menu bar]                                       │
├──────────────────────────────────────────────────┤
│ Owners                                           │
│ ┌─────────┬─────────┬──────┬──────────┬───────┐  │
│ │ Name    │ Address │ City │Telephone │ Pets  │  │
│ ├─────────┼─────────┼──────┼──────────┼───────┤  │
│ │ <link>  │ addr    │ city │ tel      │ names │  │
│ └─────────┴─────────┴──────┴──────────┴───────┘  │
└──────────────────────────────────────────────────┘
```

### Key Controls
| Control Name | Type | Label | Bound To | Purpose |
|---|---|---|---|---|
| ownersTable | table | "Owners" | model `selections` (Collection<Owner>) | Result rows |
| name link | anchor | firstName lastName | owner.id | -> /owners/{id} |

### Interactions
| Trigger | Handler | Backend Call | Business Rule |
|---|---|---|---|
| Name link click | `OwnerController.showOwner` | `ClinicService.findOwnerById(id)` | - |

### Data Bindings
- **Displayed Entity**: Owner - firstName, lastName, address, city, telephone, pets[].name (read-only)

### Navigation
- **Navigates To**: Owner Details. **Navigated From**: Find Owners.
- **Evidence**: ownersList.jsp:8-48; OwnerController.java (processFindForm)
- **Confidence**: HIGH
- Note: no sorting or paging controls exist; pet names are plain text.

## Screen: Owner Details
- **Source File**: [ownerDetails.jsp](../../../src/main/webapp/WEB-INF/jsp/owners/ownerDetails.jsp)
- **Handler/Code-Behind**: `OwnerController.showOwner` (GET /owners/{ownerId})
- **Purpose**: Read-only owner profile with pets and their visit history; hub for edit owner, add pet, edit pet, add visit.
- **Domain**: Owners
- **Client Targets**: Only target (Web browser)
- **Layout Model**: Two stacked striped tables; pets table nests a visits table per row

### Wireframe
```
┌──────────────────────────────────────────────────┐
│ [menu bar]                                       │
├──────────────────────────────────────────────────┤
│ Owner Information                                │
│ Name       │ First Last                          │
│ Address    │ ...                                 │
│ City       │ ...                                 │
│ Telephone  │ ...                                 │
│ [Edit Owner] [Add New Pet]                       │
│                                                  │
│ Pets and Visits                                  │
│ ┌────────────────────┬─────────────────────────┐ │
│ │ Name:  <pet>       │ Visit Date │ Description│ │
│ │ Birth Date: yyyy-MM-dd│ <date>  │ <text>     │ │
│ │ Type:  <type>      │ Edit Pet   │ Add Visit  │ │
│ └────────────────────┴─────────────────────────┘ │
└──────────────────────────────────────────────────┘
```

### Key Controls
| Control Name | Type | Label | Bound To | Purpose |
|---|---|---|---|---|
| Edit Owner | link btn | "Edit Owner" | owner.id | -> {id}/edit |
| Add New Pet | link btn | "Add New Pet" | owner.id | -> {id}/pets/new |
| Edit Pet | link | "Edit Pet" | owner.id, pet.id | -> /owners/{o}/pets/{p}/edit |
| Add Visit | link | "Add Visit" | owner.id, pet.id | -> /owners/{o}/pets/{p}/visits/new |
| localDate tag | custom tag | - | pet.birthDate, visit.date | Formats LocalDate yyyy-MM-dd |

### Interactions
| Trigger | Handler | Backend Call | Business Rule |
|---|---|---|---|
| Page load | `showOwner` | `ClinicService.findOwnerById(ownerId)` | Model carries owner with pets and visits |
| Redirects after create/update owner/pet/visit land here | redirect:/owners/{id} | - | Post/Redirect/Get |

### Data Bindings
- **Displayed Entity**: Owner (firstName, lastName, address, city, telephone); Pet (name, birthDate, type.name); Visit (date, description). All read-only, output via `c:out`.

### Navigation
- **Navigates To**: Owner Form (edit), Pet Form (new/edit), Visit Form. **Navigated From**: Owners List, Find Owners (single match), create/update redirects from Owner, Pet and Visit forms.
- **Evidence**: ownerDetails.jsp:7-96; OwnerController.java (showOwner)
- **Confidence**: HIGH

## Screen: Owner Form (New / Edit)
- **Source File**: [createOrUpdateOwnerForm.jsp](../../../src/main/webapp/WEB-INF/jsp/owners/createOrUpdateOwnerForm.jsp)
- **Handler/Code-Behind**: `OwnerController.initCreationForm`/`processCreationForm` (/owners/new), `initUpdateOwnerForm`/`processUpdateOwnerForm` (/owners/{id}/edit)
- **Purpose**: Create or update an owner.
- **Domain**: Owners
- **Client Targets**: Only target (Web browser)
- **Layout Model**: `form-horizontal`; five `petclinic:inputField` rows

### Wireframe
```
┌──────────────────────────────────────────────────┐
│ [menu bar]                                       │
├──────────────────────────────────────────────────┤
│ New Owner   (heading omits "New " when editing)  │
│ First Name [ firstName          ] (✓/✗ + msg)    │
│ Last Name  [ lastName           ]                │
│ Address    [ address            ]                │
│ City       [ city               ]                │
│ Telephone  [ telephone          ]                │
│            [Add Owner | Update Owner]            │
└──────────────────────────────────────────────────┘
```

### Key Controls
| Control Name | Type | Label | Bound To | Purpose |
|---|---|---|---|---|
| add-owner-form | form POST (same URL) | - | `owner` | Submit |
| firstName, lastName | inputField | "First Name","Last Name" | Person.firstName/lastName | @NotEmpty |
| address, city | inputField | "Address","City" | Owner.address/city | @NotEmpty |
| telephone | inputField | "Telephone" | Owner.telephone | @NotEmpty, @Digits(integer=10, fraction=0) |
| submit | button | "Add Owner" if new else "Update Owner" | `owner['new']` | Save |

### Interactions
| Trigger | Handler | Backend Call | Business Rule |
|---|---|---|---|
| GET /owners/new | `initCreationForm` | none | - |
| GET /owners/{id}/edit | `initUpdateOwnerForm` | `ClinicService.findOwnerById` | - |
| POST /owners/new | `processCreationForm` (@Valid) | `ClinicService.saveOwner` | Errors re-render the form; success redirects to /owners/{newId}; `id` binding disallowed |
| POST /owners/{id}/edit | `processUpdateOwnerForm` (@Valid) | `ClinicService.saveOwner` | id taken from path; redirect to /owners/{id} |

### Data Bindings
- **Displayed Entity**: Owner. **Editable**: firstName, lastName, address, city, telephone (validation from Bean Validation annotations in model/Person.java and Owner.java; messages from messages.properties)

### Navigation
- **Navigated From**: Find Owners ("Add Owner"), Owner Details ("Edit Owner"). **Navigates To**: Owner Details.
- **Evidence**: createOrUpdateOwnerForm.jsp:9-34; OwnerController.java; model/Owner.java:47-57
- **Confidence**: HIGH

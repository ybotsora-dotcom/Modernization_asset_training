---
tags:
  - extraction
  - ui-ux
---

# Pets and Visits domain screens

See also [owners.md](./owners.md), [shell-and-vets.md](./shell-and-vets.md), [navigation.md](./navigation.md), [index.md](./index.md). Both screens load the Flatpickr date picker (CSS+JS from `/webjars/flatpickr/4.6.13/`) via the layout `customScript` fragment. Menu highlight: `owners`.

## Screen: Pet Form (New / Edit)
- **Source File**: [createOrUpdatePetForm.jsp](../../../src/main/webapp/WEB-INF/jsp/pets/createOrUpdatePetForm.jsp)
- **Handler/Code-Behind**: [PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java) (class mapping `/owners/{ownerId}`), [PetValidator.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java), [PetTypeFormatter.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java)
- **Purpose**: Add a pet to an owner or edit an existing pet.
- **Domain**: Pets
- **Client Targets**: Only target (Web browser)
- **Layout Model**: `form-horizontal`

### Wireframe
```
┌──────────────────────────────────────────────────┐
│ [menu bar]                                       │
├──────────────────────────────────────────────────┤
│ New Pet                                          │
│ Owner       First Last (read-only text)          │
│ Name        [ name                 ]             │
│ Birth Date  [ birthDate (flatpickr)]             │
│ Type        ┌ select (size 5) ┐ pet types        │
│             └─────────────────┘                  │
│             [Add Pet | Update Pet]               │
└──────────────────────────────────────────────────┘
```

### Key Controls
| Control Name | Type | Label | Bound To | Purpose |
|---|---|---|---|---|
| (form) | form:form POST same URL | - | `pet` | Submit |
| hidden id | input hidden | - | pet.id | Carries id |
| name | inputField | "Name" | Pet.name | Required (PetValidator) |
| birthDate | inputField + flatpickr("#birthDate") | "Birth Date" | Pet.birthDate (`@DateTimeFormat yyyy/MM/dd`) | Required; bad format -> typeMismatch.birthDate "invalid date" |
| type | selectField size 5 | "Type " | Pet.type, options `types` | Required only when pet is new |
| submit | button | "Add Pet"/"Update Pet" | `pet['new']` | Save |

### Interactions
| Trigger | Handler | Backend Call | Business Rule |
|---|---|---|---|
| Any request in controller | `@ModelAttribute populatePetTypes`, `findOwner` | `ClinicService.findPetTypes()`, `findOwnerById` | Owner and type list always loaded |
| GET .../pets/new | `initCreationForm` | none (owner.addPet(new Pet)) | - |
| POST .../pets/new | `processCreationForm` | `ClinicService.savePet` | Duplicate name for same owner -> rejectValue("name","duplicate"); validator errors re-render; redirect to owner details |
| GET .../pets/{petId}/edit | `initUpdateForm` | `ClinicService.findPetById` | - |
| POST .../pets/{petId}/edit | `processUpdateForm` | `ClinicService.savePet` | Same validator; redirect to owner details |

### Data Bindings
- **Displayed Entity**: Pet (name, birthDate, type), Owner (names, read-only). Type options are `PetType` names converted by `PetTypeFormatter`.
- **Editable**: name (required), birthDate (LocalDate, required), type (required when new)

### Navigation
- **Navigated From**: Owner Details ("Add New Pet", "Edit Pet"). **Navigates To**: Owner Details.
- **Styling Notes**: the Flatpickr assets use absolute `/webjars/...` paths without context path (inferred risk if deployed under a context path).
- **Evidence**: createOrUpdatePetForm.jsp:7-49; PetController.java; PetValidator.java
- **Confidence**: HIGH

## Screen: Visit Form (New Visit + Previous Visits)
- **Source File**: [createOrUpdateVisitForm.jsp](../../../src/main/webapp/WEB-INF/jsp/pets/createOrUpdateVisitForm.jsp)
- **Handler/Code-Behind**: [VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)
- **Purpose**: Record a visit for a pet and list the pet's earlier visits.
- **Domain**: Visits
- **Client Targets**: Only target (Web browser)
- **Layout Model**: pet summary table, form, history table

### Wireframe
```
┌──────────────────────────────────────────────────┐
│ [menu bar]                                       │
├──────────────────────────────────────────────────┤
│ New Visit                                        │
│ Pet                                              │
│ │ Name │ Birth Date │ Type │ Owner │             │
│ │ ...  │ yyyy/MM/dd │ ...  │ ...   │             │
│ Date        [ date (flatpickr)  ]                │
│ Description [ description       ]                │
│             [Add Visit]                          │
│ Previous Visits                                  │
│ │ Date │ Description │                           │
│ │ ...  │ ...         │                           │
└──────────────────────────────────────────────────┘
```

### Key Controls
| Control Name | Type | Label | Bound To | Purpose |
|---|---|---|---|---|
| date | inputField + flatpickr("#date") | "Date" | Visit.date (`@DateTimeFormat yyyy/MM/dd`) | Visit date |
| description | inputField | "Description" | Visit.description (`@NotEmpty`) | Text |
| hidden petId | input hidden | - | visit.pet.id | Carried in form |
| Add Visit | submit | "Add Visit" | - | Save |
| history table | table | "Previous Visits" | visit.pet.visits (non-new only) | Read-only |

### Interactions
| Trigger | Handler | Backend Call | Business Rule |
|---|---|---|---|
| Any request | `@ModelAttribute loadPetWithVisit` | `ClinicService.findPetById(petId)` | Creates fresh Visit attached to pet (pet.addVisit) |
| GET /owners/*/pets/{petId}/visits/new | `initNewVisitForm` | (model attribute above) | - |
| POST /owners/{ownerId}/pets/{petId}/visits/new | `processNewVisitForm` (@Valid) | `ClinicService.saveVisit` | Errors re-render; redirect to owner details |

### Data Bindings
- **Displayed**: Pet (name, birthDate, type.name), Owner name, Visit (date, description). **Editable**: date, description.

### Navigation
- **Navigated From**: Owner Details ("Add Visit"). **Navigates To**: Owner Details.
- **Evidence**: createOrUpdateVisitForm.jsp:8-69; VisitController.java
- **Confidence**: HIGH

## Unreachable / dangling endpoint
- `GET /owners/*/pets/{petId}/visits` (`VisitController.showVisits`) returns view name `visitList` and calls `ClinicService.findPetById(...).getVisits()`. No `visitList.jsp` exists under `WEB-INF/jsp` (verified by file listing), and no UI link targets it. Confidence: HIGH that no view exists; runtime result is inferred (would error via the exception view).

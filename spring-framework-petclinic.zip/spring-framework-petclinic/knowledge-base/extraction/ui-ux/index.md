---
tags:
  - extraction
  - ui-ux
---

# UI/UX Discovery - Spring Petclinic

Paradigm: server-rendered Spring MVC with JSP views and JSP tag files (no SPA, no JS controller framework; only Bootstrap bundle JS and Flatpickr on two forms). Single client target: Web browser (no target matrix needed).

## Screen inventory
| # | Screen | Route | Purpose | Detail |
|---|---|---|---|---|
| 1 | Welcome | GET / | Landing page | [shell-and-vets.md](./shell-and-vets.md) |
| 2 | Find Owners | GET /owners/find | Search by last name | [owners.md](./owners.md) |
| 3 | Owners List | GET /owners (many matches) | Search results | [owners.md](./owners.md) |
| 4 | Owner Details | GET /owners/{id} | Owner, pets, visits hub | [owners.md](./owners.md) |
| 5 | Owner Form (new/edit) | /owners/new, /owners/{id}/edit | Create/update owner | [owners.md](./owners.md) |
| 6 | Pet Form (new/edit) | /owners/{id}/pets/new, .../{petId}/edit | Create/update pet | [pets-visits.md](./pets-visits.md) |
| 7 | Visit Form | /owners/{id}/pets/{petId}/visits/new | Add visit, see history | [pets-visits.md](./pets-visits.md) |
| 8 | Veterinarians List | GET /vets | Vets and specialties (+ XML/JSON feeds) | [shell-and-vets.md](./shell-and-vets.md) |
| 9 | Error | GET /oups, any exception | Exception view | [shell-and-vets.md](./shell-and-vets.md) |

Not a screen: `GET /owners/*/pets/{petId}/visits` maps to missing view `visitList` (see pets-visits.md). Navigation detail: [navigation.md](./navigation.md).

## Navigation diagram
```mermaid
graph TD
    Menu["Main Menu"]
    Welcome["Welcome"]
    Err["Error"]
    subgraph Owners["Owners"]
        Find["Find Owners"]
        List["Owners List"]
        Details["Owner Details"]
        OwnerForm["Owner Form"]
    end
    subgraph Pets["Pets and Visits"]
        PetForm["Pet Form"]
        VisitForm["Visit Form"]
    end
    Vets["Veterinarians List"]
    Menu -->|"Home"| Welcome
    Menu -->|"Find owners"| Find
    Menu -->|"Veterinarians"| Vets
    Menu -->|"Error"| Err
    Find -->|"many matches"| List
    Find -->|"one match"| Details
    Find -->|"Add Owner"| OwnerForm
    List -->|"name link"| Details
    Details -->|"Edit Owner"| OwnerForm
    Details -->|"Add New Pet / Edit Pet"| PetForm
    Details -->|"Add Visit"| VisitForm
    OwnerForm -->|"save"| Details
    PetForm -->|"save"| Details
    VisitForm -->|"save"| Details
```
Validation note: this diagram was rendered successfully with `mermaid_check.py` (Mermaid CLI with chrome-headless-shell 157.0.8103.50) on 2026-11-11.

## Statistics
- Screens: 9 (plus shared layout). Interactions cataloged: 22 (form loads/submits, searches, feeds, error trigger). Client targets: 1 (Web browser).

## Cross-cutting
- Backend seam: controllers (`web/`) -> `ClinicService` -> repositories (profile-switched jpa/jdbc/spring-data-jpa).
- Styling and shared tags: Bootstrap 5.3.8, Font Awesome 4.7.0, SCSS-compiled petclinic.css, Flatpickr 4.6.13; see [shell-and-vets.md](./shell-and-vets.md).
- i18n: messages bundles en/de/es exist but JSPs hard-code English labels except the Welcome heading (`welcome` key) - verified in JSP sources.
- Pivotal sponsor logo rendered on every page (pivotal.tag).

Files: [owners.md](./owners.md), [pets-visits.md](./pets-visits.md), [shell-and-vets.md](./shell-and-vets.md), [navigation.md](./navigation.md).

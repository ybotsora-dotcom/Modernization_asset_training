---
tags:
  - extraction
  - quality
---

# Extraction Quality Report

**Generated**: 2026-11-13
**Overall Score**: 99 / Grade: A

> Caveat: coverage was **not measured** for repository, architecture, functional, data-model, data-flow, integrations, ui-ux, business-intent, business-logic-rules, security, runtime-operations, risk-gap and knowledge-graph (no completeness report exists). Their scores reflect structure only and do not show the output is complete. A score of 99 means few structural defects were found, not that the extraction is exhaustive.

All 15 checks were run. CHECK-11 passes by design (no rule engine). CHECK-12 had nothing to resolve (every AI list is empty). CHECK-13 ran and reported ok with 0 sweep locations (nothing to cover). CHECK-07 ran the Mermaid CLI on all 9 diagrams: all OK.

## Summary

| Folder | Score | Grade | Coverage | Critical | Warnings | Infos |
|--------|-------|-------|----------|----------|----------|-------|
| repository/ | 98 | A | not measured | 0 | 0 | 1 |
| architecture/ | 100 | A | not measured | 0 | 0 | 0 |
| functional/ | 100 | A | not measured | 0 | 0 | 0 |
| data-model/ | 100 | A | not measured | 0 | 0 | 0 |
| data-flow/ | 100 | A | not measured | 0 | 0 | 0 |
| integrations/ | 98 | A | not measured | 0 | 0 | 1 |
| ui-ux/ | 100 | A | not measured | 0 | 0 | 0 |
| business-intent/ | 100 | A | not measured | 0 | 0 | 0 |
| business-logic-rules/ | 100 | A | not measured | 0 | 0 | 0 |
| security/ | 100 | A | not measured | 0 | 0 | 0 |
| runtime-operations/ | 100 | A | not measured | 0 | 0 | 0 |
| risk-gap/ | 96 | A | not measured | 0 | 0 | 2 |
| knowledge-graph/ | 100 | A | not measured | 0 | 0 | 0 |
| ai/ | 100 | A | n/a (0 AI locations, measured) | 0 | 0 | 0 |
| **TOTAL** | **99** | **A** | - | **0** | **0** | **4** |

## Critical Issues (must fix before downstream agents run)

None.

## Warnings (should fix for quality modernization output)

None. The previous run's single Warning (CHECK-06, thin EOL table) is resolved; see below.

## Infos

- **[CHECK-05] risk-gap/operations.md RISK-018**: still says vulnerability/currency status "was not checked (no network)" and that `mysql-connector-java` 8.1.0 availability was not verified, while the rewritten table reports support dates retrieved on 2026-11-13. The table also says the repository versions are "a few patch releases behind", but the table's own figures show Hibernate 7.4.0 vs 7.4.15 and Tomcat 11.0.18 vs 11.0.29.
- **[CHECK-06] risk-gap/operations.md RISK-021**: the follow-up "verify with a container deployment test" is execution-based; the claim is already documented from source and marked inferred, so it is not a gap.
- **[CHECK-06/CHECK-05] integrations/**: CI/tooling services (GitHub Actions, SonarCloud, Dependabot) are not mentioned (carried over).
- **[CHECK-05] repository/ (project-profile.json)**: a gap note says `ai-sweep.py` was not run, but `ai/sweep.json` exists (carried over).

## CHECK-06 re-evaluation: resolved

I read the current `risk-gap/operations.md` rather than relying on the note.

- The table now has 10 rows, a migration-urgency ranking (five tiers), a per-row support position, status and confidence. It covers Java 17, Spring Framework 7.0.8, Hibernate ORM 7.4.0, Tomcat 11.0.18, Jetty 11.0.26, MySQL 5.7.8 and PostgreSQL 9.6.0. H2 and the `mysql-connector-java` coordinates are marked Not assessed / Inferred (LOW), and Caffeine and Logback are stated as not assessed.
- Repository-side evidence checked and correct: `java.version` 17 (pom.xml:17), Spring 7.0.8 (:31), Tomcat 11.0.18 (:39), Hibernate 7.4.0.Final (:50), H2 2.4.240 (:53), driver 8.1.0 (:68), Jetty plugin 11.0.26 (:76), `jetty:11.0-jdk17` (:478), `mysql-connector-java` (:575), EhCache comment (:182), readme.md lines 69 and 92 (mysql:5.7.8, postgres:9.6.0).
- The provenance is disclosed honestly: dates came from a third-party tracker through a page-fetch tool, not from vendor pages, and rows are MEDIUM, not HIGH. I did not re-fetch the dates, so they are not independently verified here.
- Not fully complete, by design of the source: H2, the driver, Caffeine and Logback have no dates. These gaps are labelled, so they are not a Warning. They are the reason the table is rated resolved rather than exhaustive.
- Net: the signal "obsolete / EOL technology flags that drive migration urgency" is now present and usable. The downgrade from Warning to the Infos above is only about wording inconsistencies.

## Other regression checks

- CHECK-01/03/09: all required folders and files present; all `.md` files have frontmatter; the largest file is 323 lines (limit 500).
- CHECK-02: all `summary.json` files parse. `project-profile.json` is VALID against `project-profile.v2`. Empty arrays are legitimate (single-module app, no product AI).
- CHECK-07: 9 Mermaid diagrams, 0 failed.
- CHECK-08: 0 broken relative links.
- CHECK-10: 207 entities, 511 relationships, 453 high-confidence, `unresolvedGaps` present.
- CHECK-11: no rule engine by design; passes.
- CHECK-14: no `confirmed`/`HIGH` claim found citing only documentation (scripted line scan).
- CHECK-15: no repeated-description tables or broken quoting found (scripted scan).
- CHECK-04/05: name-presence checks plus sampling found no new unresolved references.

## Modernization Readiness Assessment

### What Is Well-Documented
- Technology stack with versions; EOL flags with urgency ranking and dated support positions.
- Layered architecture, profile-switched persistence, coupling areas.
- Entity/schema model for four dialects; 19 HTTP routes; 9 screens with interaction linkage and navigation diagram.
- No-authentication security posture, runtime topology, 40 business rules, capabilities.
- Knowledge graph with 207 entities and 511 relationships.

### What Is Missing or Too Thin
- No signal is missing at Warning level. Coverage of the extraction against the codebase is not measured for 13 folders; no completeness report exists.

### Recommended Improvements

1. [MEDIUM] Run the completeness report so coverage can be measured for the 13 folders.
2. [LOW] Align RISK-018 wording with the new EOL table, correct the "few patch releases" phrase, and make the RISK-021 follow-up source-based.
3. [LOW] Mention CI/tooling services in integrations or state they are out of scope.
4. [LOW] Refresh the stale gap note in project-profile.json.

---
tags:
  - extraction
  - data-model
---
# Data Model Documentation

## Overview
- Project: spring-framework-petclinic. This file documents the SQL scripts under `src/main/resources/db/`: folders `h2`, `hsqldb`, `mysql`, `postgresql`. Each holds `schema.sql` and `data.sql`; `mysql` and `postgresql` also hold a setup text file (instructions only).
- Folder selection: Maven profile property `db.script` (H2 default, HSQLDB, MySQL, PostgreSQL in [pom.xml](../../../pom.xml)) fills `jdbc.initLocation=classpath:db/${db.script}/schema.sql` and `jdbc.dataLocation=classpath:db/${db.script}/data.sql` in [data-access.properties](../../../src/main/resources/spring/data-access.properties).
- Entity mapping: see [model-entities.md](./model-entities.md).

## Core Entities
Tables (same seven in all four dialects). Evidence: [h2/schema.sql](../../../src/main/resources/db/h2/schema.sql), [hsqldb/schema.sql](../../../src/main/resources/db/hsqldb/schema.sql), [mysql/schema.sql](../../../src/main/resources/db/mysql/schema.sql), [postgresql/schema.sql](../../../src/main/resources/db/postgresql/schema.sql).

### owners
- **Location**: all four `schema.sql`; entity [Owner](./model-entities.md)
- **Table**: `owners`
- **Persistence Ownership**: parent of pets.
- **Schema**:
  | Column | Type | Constraints | Purpose |
  |---|---|---|---|
  | id | INTEGER identity (MySQL `INT(4) UNSIGNED AUTO_INCREMENT`, PG `SERIAL`) | PK | id |
  | first_name | VARCHAR(30) | nullable | |
  | last_name | VARCHAR_IGNORECASE(30) in h2/hsqldb; VARCHAR(30) in mysql/postgresql | nullable, indexed | case-insensitive search in embedded DBs |
  | address | VARCHAR(255) | nullable | |
  | city | VARCHAR(80) | nullable | |
  | telephone | VARCHAR(20) | nullable | |
- **Relationships**: referenced by pets.owner_id.
- **Evidence**: indexes `owners_last_name` (h2, hsqldb), `INDEX(last_name)` (mysql), `idx_owners_last_name` (postgresql).
- **Confidence**: HIGH

### pets
- **Location**: all four `schema.sql`; entity [Pet](./model-entities.md)
- **Table**: `pets`
- **Persistence Ownership**: child of owners and types; parent of visits.
- **Schema**:
  | Column | Type | Constraints | Purpose |
  |---|---|---|---|
  | id | identity / SERIAL | PK | id |
  | name | VARCHAR(30) | nullable, indexed | |
  | birth_date | DATE | nullable | |
  | type_id | INTEGER | NOT NULL, FK types(id) | |
  | owner_id | INTEGER | NOT NULL, FK owners(id) | |
- **Relationships**: FK `fk_pets_owners`, `fk_pets_types` (named in h2/hsqldb; unnamed in mysql/postgresql). No ON DELETE rule in any dialect.
- **Evidence**: index `pets_name` / `INDEX(name)` / `idx_pets_name`.
- **Confidence**: HIGH

### types
- **Table**: `types` (entity PetType). Columns: id (PK identity), name VARCHAR(80), indexed (`types_name` / `INDEX(name)` / `idx_types_name`).
- **Persistence Ownership**: lookup, parent of pets.
- **Relationships**: referenced by pets.type_id.
- **Evidence**: the four `schema.sql` files.
- **Confidence**: HIGH

### visits
- **Table**: `visits` (entity Visit).
- **Schema**:
  | Column | Type | Constraints | Purpose |
  |---|---|---|---|
  | id | identity / SERIAL | PK | |
  | pet_id | INTEGER | NOT NULL, FK pets(id) | |
  | visit_date | DATE | nullable | |
  | description | VARCHAR(255) | nullable | |
- **Persistence Ownership**: child of pets.
- **Relationships**: FK `fk_visits_pets` (h2/hsqldb). Index `visits_pet_id` exists in h2 and hsqldb only; mysql has no explicit index (InnoDB creates one for the FK); postgresql has none.
- **Evidence**: the four `schema.sql` files.
- **Confidence**: HIGH

### vets
- **Table**: `vets` (entity Vet). Columns: id (PK identity), first_name VARCHAR(30), last_name VARCHAR(30), index on last_name (`vets_last_name` / `INDEX(last_name)` / `idx_vets_last_name`).
- **Persistence Ownership**: parent of vet_specialties.
- **Relationships**: many-to-many to specialties.
- **Evidence**: the four `schema.sql` files.
- **Confidence**: HIGH

### specialties
- **Table**: `specialties` (entity Specialty). Columns: id (PK identity), name VARCHAR(80), indexed (`specialties_name` / `INDEX(name)` / `idx_specialties_name`).
- **Persistence Ownership**: lookup.
- **Relationships**: referenced by vet_specialties.specialty_id.
- **Evidence**: the four `schema.sql` files.
- **Confidence**: HIGH

### vet_specialties
- **Table**: `vet_specialties` (join table, no entity class; mapped by `Vet.specialties`).
- **Schema**: `vet_id` INTEGER NOT NULL FK vets(id); `specialty_id` INTEGER NOT NULL FK specialties(id). No primary key in any dialect. UNIQUE (vet_id, specialty_id) exists in mysql and postgresql (`unique_ids`) but not in h2/hsqldb.
- **Persistence Ownership**: owned by Vet side of the many-to-many.
- **Evidence**: the four `schema.sql` files.
- **Confidence**: HIGH

## Relationship Map
```
owners 1-* pets (owner_id)    types 1-* pets (type_id)
pets 1-* visits (pet_id)
vets *-* specialties via vet_specialties(vet_id, specialty_id)
```
All FKs are plain `REFERENCES` without cascade rules.

## Inheritance Hierarchies
None at schema level (the `@MappedSuperclass` bases have no tables); see [model-entities.md](./model-entities.md).

## Cross-Module References
None; the scripts are consumed by `jdbc:initialize-database` in [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml).

## Persistence Configuration
- Dialect differences:
  | Aspect | h2 | hsqldb | mysql | postgresql |
  |---|---|---|---|---|
  | Drop existing tables first | yes (`DROP TABLE ... IF EXISTS`) | yes | no | no |
  | Create database | no | no | `CREATE DATABASE IF NOT EXISTS petclinic`, utf8 / utf8_general_ci | no |
  | Create tables | `CREATE TABLE` | `CREATE TABLE` | `CREATE TABLE IF NOT EXISTS`, InnoDB | `CREATE TABLE IF NOT EXISTS` |
  | Id generation | `GENERATED BY DEFAULT AS IDENTITY` | `IDENTITY` | `AUTO_INCREMENT` | `SERIAL` plus `ALTER SEQUENCE ..._id_seq RESTART WITH 100` per table |
  | Case-insensitive last_name | VARCHAR_IGNORECASE | VARCHAR_IGNORECASE | no | no |
  | Seed id values | `default` | explicit 1..n | explicit, `INSERT IGNORE` | explicit, `ON CONFLICT DO NOTHING` |
- Re-runnable: mysql and postgresql scripts are idempotent by design (IF NOT EXISTS and ignore-duplicate inserts); h2/hsqldb rebuild the schema each run. Inferred from statement forms.
- PostgreSQL sequences restart at 100 while seed rows use explicit ids 1..n, so new rows will not collide with seeds (inferred from statements).

## Database Initialization
- Initialization Scripts: `db/h2`, `db/hsqldb`, `db/mysql`, `db/postgresql` each with `schema.sql` then `data.sql`, run in that order by `<jdbc:initialize-database>` ("If any of the script fails, the initialization stops").
- Setup notes (not executable): [mysql/petclinic_db_setup_mysql.txt](../../../src/main/resources/db/mysql/petclinic_db_setup_mysql.txt), [postgresql/petclinic_db_setup_postgresql.txt](../../../src/main/resources/db/postgresql/petclinic_db_setup_postgresql.txt). Their postgresql text mentions `tomcat7:run`, which differs from the jetty goal in CLAUDE.md (documentation drift).
- Seed Data: every dialect has 47 INSERT statements: 6 vets, 3 specialties (radiology, surgery, dentistry), 5 vet_specialties rows, 6 types (cat, dog, lizard, snake, bird, hamster), 10 owners, 13 pets, 4 visits (counts from the h2 file; the other three have the same statement count). Owner and pet names are sample data; no credentials.
- Data divergence: h2 and hsqldb seed pet birth dates and visit dates (e.g. Leo born 2010-09-07, first visit 2013-01-01) differ from mysql and postgresql (Leo born 2000-09-07, first visit 2010-03-04), so the sample content is not identical across databases.
- Migration Strategy: none; no Flyway or Liquibase found.

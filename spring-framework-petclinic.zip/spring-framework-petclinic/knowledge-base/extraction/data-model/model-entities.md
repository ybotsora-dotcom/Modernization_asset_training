---
tags:
  - extraction
  - data-model
---
# Data Model Documentation

## Overview
- Project: spring-framework-petclinic; Java, Spring Framework (XML config), JPA annotations on entities in package `org.springframework.samples.petclinic.model`, Hibernate as vendor.
- Databases: H2 (default), HSQLDB, MySQL, PostgreSQL; see [database-schemas.md](./database-schemas.md).
- Pattern: layered (web, service, repository). Repositories have three implementations (jpa, jdbc, spring-data-jpa) that share the same entities and schema, so they are documented as one module. Evidence: [business-config.xml](../../../src/main/resources/spring/business-config.xml).
- Aggregate roots (inferred from cascade settings): Owner (cascades to Pet, which cascades to Visit); Vet. PetType and Specialty are lookup entities.

## Core Entities

### Owner
- **Location**: [Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)
- **Table**: `owners`
- **Persistence Ownership**: Inverse side of Owner-Pet (`mappedBy = "owner"`); Pet holds the FK. Aggregate root.
- **Schema**:
  | Column | Type | Constraints | Purpose |
  |---|---|---|---|
  | id | Integer | PK, IDENTITY (BaseEntity) | identifier |
  | first_name | String | @NotEmpty (Person) | first name |
  | last_name | String | @NotEmpty (Person) | last name |
  | address | String | @NotEmpty | address |
  | city | String | @NotEmpty | city |
  | telephone | String | @NotEmpty, @Digits(integer=10, fraction=0) | phone |
- **Relationships**:
  - One-to-Many to Pet (field `pets`), bidirectional, inverse side. Cascade: ALL. Fetch: not set (JPA default LAZY). No orphanRemoval.
- **Evidence**: `@Entity @Table(name = "owners")`, `@OneToMany(cascade = CascadeType.ALL, mappedBy = "owner")`
- **Confidence**: HIGH

### Pet
- **Location**: [Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)
- **Table**: `pets`
- **Persistence Ownership**: Owns FKs `owner_id` and `type_id`; inverse side of Pet-Visit.
- **Schema**:
  | Column | Type | Constraints | Purpose |
  |---|---|---|---|
  | id | Integer | PK, IDENTITY | identifier |
  | name | String | none in class (NamedEntity) | pet name |
  | birth_date | LocalDate | @DateTimeFormat yyyy/MM/dd | birth date |
  | type_id | Integer | FK to types.id; NOT NULL in DDL | pet type |
  | owner_id | Integer | FK to owners.id; NOT NULL in DDL | owner |
- **Relationships**:
  - Many-to-One to PetType (`@JoinColumn(name = "type_id")`), no cascade, fetch not set.
  - Many-to-One to Owner (`@JoinColumn(name = "owner_id")`), no cascade, fetch not set.
  - One-to-Many to Visit (`mappedBy = "pet"`), cascade ALL, fetch EAGER.
- **Evidence**: `@Entity @Table(name = "pets")` and the annotations above
- **Confidence**: HIGH

### PetType
- **Location**: [PetType.java](../../../src/main/java/org/springframework/samples/petclinic/model/PetType.java)
- **Table**: `types`
- **Persistence Ownership**: Referenced by pets.type_id; no back-reference in the class (one-way from Pet).
- **Schema**: `id` (PK, IDENTITY), `name` (from NamedEntity).
- **Relationships**: none declared.
- **Evidence**: `@Entity @Table(name = "types")`
- **Confidence**: HIGH

### Visit
- **Location**: [Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)
- **Table**: `visits`
- **Persistence Ownership**: Owns FK `pet_id`.
- **Schema**:
  | Column | Type | Constraints | Purpose |
  |---|---|---|---|
  | id | Integer | PK, IDENTITY | identifier |
  | visit_date | LocalDate | constructor defaults to LocalDate.now() | visit date |
  | description | String | @NotEmpty | description |
  | pet_id | Integer | FK to pets.id; NOT NULL in DDL | pet |
- **Relationships**: Many-to-One to Pet (`@JoinColumn(name = "pet_id")`), no cascade, bidirectional with Pet.visits.
- **Evidence**: `@Entity @Table(name = "visits")`
- **Confidence**: HIGH

### Vet
- **Location**: [Vet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java)
- **Table**: `vets`
- **Persistence Ownership**: Owning side of join table `vet_specialties`.
- **Schema**: `id` (PK, IDENTITY), `first_name`, `last_name` (both @NotEmpty, from Person).
- **Relationships**:
  - Many-to-Many to Specialty via `@JoinTable(name = "vet_specialties", joinColumns vet_id, inverseJoinColumns specialty_id)`, fetch EAGER, no cascade. Unidirectional.
- **Evidence**: `@ManyToMany(fetch = FetchType.EAGER) @JoinTable(...)`
- **Confidence**: HIGH

### Specialty
- **Location**: [Specialty.java](../../../src/main/java/org/springframework/samples/petclinic/model/Specialty.java)
- **Table**: `specialties`
- **Persistence Ownership**: Target of the Vet join table; no back-reference.
- **Schema**: `id` (PK, IDENTITY), `name` (from NamedEntity).
- **Relationships**: none declared.
- **Evidence**: `@Entity @Table(name = "specialties")`
- **Confidence**: HIGH

### Vets (non-persistent)
- **Location**: [Vets.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vets.java)
- **Table**: none. JAXB `@XmlRootElement` wrapper holding a `List<Vet>`; not an `@Entity`.
- **Confidence**: HIGH

## Relationship Map
```
Owner 1 --(cascade ALL, mappedBy owner)--> * Pet        [FK pets.owner_id]
Pet   * --> 1 PetType                                    [FK pets.type_id, one-way]
Pet   1 --(cascade ALL, EAGER, mappedBy pet)--> * Visit  [FK visits.pet_id]
Vet   * <--(EAGER, vet_specialties)--> * Specialty       [Vet owns join table, one-way]
```

## Inheritance Hierarchies
All bases are `@MappedSuperclass` (no table, no discriminator; columns are copied into each concrete table).
- [BaseEntity.java](../../../src/main/java/org/springframework/samples/petclinic/model/BaseEntity.java): `id` Integer, `@GeneratedValue(strategy = IDENTITY)`, `isNew()` is `id == null`. Children: NamedEntity, Person, Visit.
- [NamedEntity.java](../../../src/main/java/org/springframework/samples/petclinic/model/NamedEntity.java): `name`. Children: Pet, PetType, Specialty.
- [Person.java](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java): `first_name`, `last_name`. Children: Owner, Vet.

## Cross-Module References
- Entities live only in the `model` package. The `repository` interfaces and their jpa, jdbc and springdatajpa implementations, plus `service` and `web`, reference them; see [repository intake](../repository/index.md). Detail of those usages was not traced here.

## Persistence Configuration
- ORM/Persistence Framework: Hibernate via `HibernateJpaVendorAdapter` in profiles `jpa` and `spring-data-jpa`; profile `jdbc` uses `DataSourceTransactionManager` without an ORM. Evidence: [business-config.xml](../../../src/main/resources/spring/business-config.xml).
- Entity discovery: `packagesToScan = org.springframework.samples.petclinic` and `persistenceUnitName = petclinic` are both set. No `persistence.xml` was found in the repository (find), and a comment in the XML says the persistence unit wins when both are set. Effective behaviour is inferred, not verified.
- DDL Strategy: no `hbm2ddl` / `generate-ddl` setting found in main XML or properties; the schema comes from SQL scripts (see [database-schemas.md](./database-schemas.md)).
- Dialect: `jpa.database` from [data-access.properties](../../../src/main/resources/spring/data-access.properties); `jpa.showSql=true`.
- Caching: Spring cache with Caffeine (names `default`, `vets`) in [tools-config.xml](../../../src/main/resources/spring/tools-config.xml); `@Cacheable(value = "vets")` in ClinicServiceImpl. No Hibernate second-level cache configuration found.
- Batch Fetching: none configured.
- Naming Convention: explicit `@Table` / `@Column` names, snake_case.
- Datasource: Tomcat JDBC pool in [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml); values come from Maven-profile placeholders (keys `jdbc.url`, `jdbc.username`, `jdbc.password`; values not recorded). A JNDI datasource exists in profile `javaee`.

## Database Initialization
- Scripts, seed data and per-database differences: [database-schemas.md](./database-schemas.md).
- Migration Strategy: none (no Flyway or Liquibase configuration found in main resources).

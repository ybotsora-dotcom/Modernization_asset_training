---
tags:
  - extraction
  - data-model
---
# Data Model Index

Project: spring-framework-petclinic (Spring Framework XML config, JPA/Hibernate entities, with JDBC and Spring Data JPA alternatives). Four SQL script sets (H2, HSQLDB, MySQL, PostgreSQL). Analysis is static; nothing was run.

## Module files
- [model-entities.md](./model-entities.md) - 6 JPA `@Entity` classes, 3 `@MappedSuperclass` bases, 1 non-persistent JAXB wrapper (`Vets`), relationships, persistence config.
- [database-schemas.md](./database-schemas.md) - `schema.sql` / `data.sql` for every folder under `src/main/resources/db/` (h2, hsqldb, mysql, postgresql), per-dialect differences, initialization.

## Entity summary
| Entity | Table |
|---|---|
| Owner | owners |
| Pet | pets |
| PetType | types |
| Visit | visits |
| Vet | vets |
| Specialty | specialties |
| (join, no class) | vet_specialties |

All entities live in the `model` package. The join table `vet_specialties` has no class; it is mapped from `Vet.specialties`.

Entity count: 6 entities plus 1 join table.

## ER diagram
```
owners 1 --- * pets * --- 1 types
                 1
                 |
                 *
              visits

vets * --- * specialties   (via vet_specialties)
```

## Related extraction
- [Repository intake](../repository/index.md)

Gaps: none blocking; the missing `persistence.xml` and effective entity discovery are marked inferred in model-entities.md.

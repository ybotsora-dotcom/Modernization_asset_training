---
tags:
  - extraction
  - integrations
---
# petclinic - data, file and internal contracts

## Multi-backend relational data contract
- **Provider**: H2 (default), HSQLDB, MySQL (`localhost:3306/petclinic`), PostgreSQL (`localhost:5432/petclinic`); selected by Maven `-P` profile properties `jdbc.url`, `jdbc.driverClassName`, `jpa.database`, `db.script` injected into [data-access.properties](../../../src/main/resources/spring/data-access.properties)
- **Consumer**: petclinic repositories (`OwnerRepository`, `PetRepository`, `VetRepository`, `VisitRepository`), each with three implementations picked by Spring profile: `jpa` (default, `PetclinicInitializer.SPRING_PROFILE`; `@PersistenceContext`), `jdbc` (`JdbcClient`/`NamedParameterJdbcTemplate`), `spring-data-jpa` (`<jpa:repositories>`, `@Query` JPQL)
- **Protocol**: JDBC (Tomcat JDBC pool `org.apache.tomcat.jdbc.pool.DataSource`; Hibernate JPA vendor adapter)
- **Payload Format**: SQL
- **Evidence**: [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml), [business-config.xml](../../../src/main/resources/spring/business-config.xml), [repository/](../../../src/main/java/org/springframework/samples/petclinic/repository), [pom.xml](../../../pom.xml) profiles
- **Modernization Relevance**: High - triple parallel implementations triple maintenance; DB credentials come from Maven properties; `jpa.showSql=true` is set.
- **Confidence**: HIGH

## JNDI datasource contract (javaee profile)
- **Provider**: Container-supplied `java:comp/env/jdbc/petclinic`
- **Consumer**: petclinic `dataSource` bean when Spring profile `javaee` is active
- **Protocol**: JDBC
- **Payload Format**: SQL
- **Evidence**: [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml)
- **Modernization Relevance**: Low
- **Confidence**: HIGH (definition); whether any deployment uses it is not verifiable from code.

## Schema and seed SQL file contract
- **Provider**: `src/main/resources/db/{h2,hsqldb,mysql,postgresql}/schema.sql` and `data.sql`; plus manual setup notes `petclinic_db_setup_mysql.txt`, `petclinic_db_setup_postgresql.txt`
- **Consumer**: `<jdbc:initialize-database>` at startup, which runs `jdbc.initLocation` then `jdbc.dataLocation`
- **Protocol**: File I/O (classpath) executed over JDBC
- **Payload Format**: SQL
- **Evidence**: [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml), [db/](../../../src/main/resources/db)
- **Modernization Relevance**: High - scripts run on every start; no versioned migration tool (Flyway/Liquibase) found.
- **Confidence**: HIGH

## Vets cache contract (internal)
- **Provider**: `CaffeineCacheManager` with caches `default`, `vets`
- **Consumer**: `ClinicServiceImpl` `@Cacheable("vets")` (find vets)
- **Protocol**: Other (in-process)
- **Payload Format**: Other (Java objects)
- **Evidence**: [tools-config.xml](../../../src/main/resources/spring/tools-config.xml), [ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)
- **Modernization Relevance**: Low - no eviction/TTL config found in XML.
- **Confidence**: HIGH

## JMX call-monitor contract
- **Provider**: `CallMonitoringAspect` exposed as MBean `petclinic:type=CallMonitor` via `<context:mbean-export/>`
- **Consumer**: JMX clients (operators); aspect intercepts repository/service calls
- **Protocol**: Other (JMX)
- **Payload Format**: Other (MBean attributes/operations)
- **Evidence**: [CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java), [tools-config.xml](../../../src/main/resources/spring/tools-config.xml)
- **Modernization Relevance**: Medium - candidate for Micrometer-style metrics.
- **Confidence**: HIGH

## Findings and gaps
- No outbound HTTP clients, messaging, event systems, SOAP or gRPC found in sources or pom (searched RestTemplate/WebClient/RestClient/jms/kafka/amqp/security).
- No authentication or authorization layer; no health/metrics HTTP endpoints.
- No AI provider, embedding, vector DB or MCP integrations found in application code.

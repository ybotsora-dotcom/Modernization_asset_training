---
tags:
  - extraction
  - integrations
---
# petclinic - HTTP/REST and view contracts

Single-module WAR. DispatcherServlet mapped to `/` ([PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)). No authentication/authorization mechanism found in code or pom (no Spring Security), so no route requires authentication (this holds for all 19 routes, which is why the tables below have no Auth column). Most routes are server-rendered JSP form views (browser consumer); only `/vets.json` and `/vets.xml` return data payloads.

## Owners web contract
- **Provider**: petclinic `OwnerController`
- **Consumer**: Web browser (JSP forms)
- **Protocol**: HTTP/REST (form-based, HTML)
- **Payload Format**: HTML (JSP) / form-urlencoded; Owner bound with Bean Validation
- **Evidence**: [OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- **Modernization Relevance**: Medium - form-post MVC; no JSON API for owners.
- **Confidence**: HIGH

| Method | Path | Action |
|--------|------|--------|
| GET | /owners/new | initCreationForm |
| POST | /owners/new | processCreationForm |
| GET | /owners/find | initFindForm |
| GET | /owners | processFindForm |
| GET | /owners/{ownerId}/edit | initUpdateOwnerForm |
| POST | /owners/{ownerId}/edit | processUpdateOwnerForm |
| GET | /owners/{ownerId} | showOwner |

## Pets web contract
- **Provider**: petclinic `PetController` (class prefix `/owners/{ownerId}`); uses `PetTypeFormatter` and `PetValidator`
- **Consumer**: Web browser
- **Protocol**: HTTP/REST (form-based, HTML)
- **Payload Format**: HTML / form-urlencoded
- **Evidence**: [PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
- **Modernization Relevance**: Medium
- **Confidence**: HIGH

| Method | Path | Action |
|--------|------|--------|
| GET | /owners/{ownerId}/pets/new | initCreationForm |
| POST | /owners/{ownerId}/pets/new | processCreationForm |
| GET | /owners/{ownerId}/pets/{petId}/edit | initUpdateForm |
| POST | /owners/{ownerId}/pets/{petId}/edit | processUpdateForm |

## Visits web contract
- **Provider**: petclinic `VisitController`
- **Consumer**: Web browser
- **Protocol**: HTTP/REST (form-based, HTML)
- **Payload Format**: HTML / form-urlencoded
- **Evidence**: [VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)
- **Modernization Relevance**: Medium
- **Confidence**: HIGH

| Method | Path | Action |
|--------|------|--------|
| GET | /owners/*/pets/{petId}/visits/new | initNewVisitForm |
| POST | /owners/{ownerId}/pets/{petId}/visits/new | processNewVisitForm |
| GET | /owners/*/pets/{petId}/visits | showVisits |

## Vets web and data contract
- **Provider**: petclinic `VetController`
- **Consumer**: Web browser (HTML); any HTTP client (JSON/XML)
- **Protocol**: HTTP/REST
- **Payload Format**: JSON (`/vets.json`), XML (`/vets.xml`, `Vets` model), HTML (`/vets`). A `vets/vetList.xml` MarshallingView is declared in [mvc-view-config.xml](../../../src/main/resources/spring/mvc-view-config.xml).
- **Evidence**: [VetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java), [Vets.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vets.java)
- **Modernization Relevance**: Medium - the only machine-readable API; unversioned, read-only, backed by the `vets` cache.
- **Confidence**: HIGH

| Method | Path | Action |
|--------|------|--------|
| GET | /vets | showVetList |
| GET | /vets.json | showJsonVetList |
| GET | /vets.xml | showXmlVetList |

## Welcome and error-demo contract
- **Provider**: `mvc:view-controller` in [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) (path `/` -> view `welcome`); `CrashController`
- **Consumer**: Web browser
- **Protocol**: HTTP/REST
- **Payload Format**: HTML. `/oups` deliberately throws; `SimpleMappingExceptionResolver` renders the `exception` view.
- **Evidence**: [CrashController.java](../../../src/main/java/org/springframework/samples/petclinic/web/CrashController.java), mvc-core-config.xml
- **Modernization Relevance**: Low - demo endpoint should not ship to production.
- **Confidence**: HIGH

| Method | Path | Action |
|--------|------|--------|
| GET | / | view-controller (welcome) |
| GET | /oups | triggerException |

## Static resources contract
- **Provider**: petclinic (`mvc:resources` `/resources/**` from `/resources/`; `/webjars/**` from classpath `META-INF/resources/webjars/`; default servlet handler)
- **Consumer**: Web browser
- **Protocol**: HTTP/REST (static GET)
- **Payload Format**: Other (CSS/JS/images; SCSS compiled at build time via Maven `css` profile)
- **Evidence**: [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml), [pom.xml](../../../pom.xml)
- **Modernization Relevance**: Low
- **Confidence**: HIGH

---
tags:
  - extraction
  - integrations
---
# Integrations overview

Single module (`petclinic`, WAR, Spring Framework XML config). 11 contracts, 19 HTTP routes.

- [petclinic-api.md](./petclinic-api.md) - 6 contracts: HTTP/REST and view contracts (owners, pets, visits, vets, welcome/error-demo, static resources) with endpoint tables
- [petclinic-data.md](./petclinic-data.md) - 5 contracts: multi-backend JDBC, JNDI datasource, SQL schema/seed files, Caffeine cache, JMX monitor

## Contracts
In [petclinic-api.md](./petclinic-api.md): Owners web contract, Pets web contract, Visits web contract, Vets web and data contract, Welcome and error-demo contract, Static resources contract.

In [petclinic-data.md](./petclinic-data.md): Multi-backend relational data contract, JNDI datasource contract (javaee profile), Schema and seed SQL file contract, Vets cache contract, JMX call-monitor contract.

Status COMPLETE, confidence HIGH.

## Authentication
No authentication or authorization mechanism was found for any of the 19 routes (no Spring Security in the pom, no security filter), so the endpoint tables in petclinic-api.md carry no Auth column.

## External dependency summary
Databases only (H2, HSQLDB, MySQL, PostgreSQL). No outbound service calls, messaging or auth provider found.

## Related
- [repository/index.md](../repository/index.md)

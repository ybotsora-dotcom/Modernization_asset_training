---
tags:
  - extraction
  - ai
---
# AI Components

**There is no product AI in this application.** Spring Petclinic (Spring Framework, XML config, JPA/JDBC/Spring Data repositories, JSP views) contains no model-provider SDK calls, agents, flows, tools, prompts, RAG pipelines, evals, guardrails or AI observability. The sweep (`sweep.json`) found zero hits in sdk_import, call_site, inline_prompt, prompt_file, vector_store, chunker_tokenizer, fusion_rerank, ai_config and mcp. The scope is `product: false`.

## Engineering AI
One developer harness: Claude Code, configured only through the root instruction file `CLAUDE.md` (81 lines: build/run commands, test commands, the three-persistence-profile architecture, web layer notes). Item: `ai:harness:claude-code` (see [engineering-harness.md](./engineering-harness.md)).
- No `.claude/settings.json`, `settings.local.json`, `.mcp.json`, agents, commands, skills or hooks exist in the repo; no permission rules, so nothing is flagged.
- Other harnesses (Copilot, Cursor, Windsurf, Codex, Aider, Continue) were checked: no config files found.

## Inventory
Providers 0, models 0, frameworks 0, agents 0, flows 0, tools 0, MCP servers 0, prompts 0, RAG pipelines 0, evaluation 0, guardrails 0, observability 0, harness 1.
Each empty area: none found, searched all sweep classes above.

## Risks and doc findings
No AI risks. No doc-vs-code AI claims to check.

## Area files
- [engineering-harness.md](./engineering-harness.md): 1 item (`ai:harness:claude-code`).

Every other area is empty and has no file, because the harness is the only area with findings.

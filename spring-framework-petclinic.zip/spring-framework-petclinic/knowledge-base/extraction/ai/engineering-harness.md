---
tags:
  - extraction
  - ai
---
# Engineering Harness

Developer AI harnesses configured in the repository. There is one item: Claude Code, configured through a single instruction file. The application itself has no product AI (see [index.md](./index.md)).

### ai:harness:claude-code
- **Harness**: claude-code
- **Instruction files**: `CLAUDE.md` (81 lines, repository root)
- **Config files**: none. The repository has no `.claude/settings.json`, `.claude/settings.local.json` or `.mcp.json`
- **Agents, skills, commands, hooks, MCP servers**: none defined by the repository
- **Permissions**: no permission rules are configured in the repository, so nothing is flagged as permissive
- **Confidence**: confirmed

A local `.claude/` folder exists on the analysis machine. It was created by the modernization toolkit and its agents (operator docs copy, host-check marker, traceability ledger, agent memory), it is untracked in git, and it is not harness configuration of the repository.

#### What the instruction file tells the assistant
`CLAUDE.md` is guidance text only and carries no executable configuration. It covers:
- Project overview: a plain Spring Framework application (XML configuration, not Spring Boot) with three layers (web, service, repository), packaged as a WAR and run in Jetty or Tomcat.
- Build and run commands: Maven wrapper, database profile switches, CSS recompilation and the Docker image build.
- Test commands and the shared service-layer test design: one abstract test class with three subclasses, one per persistence profile.
- The three interchangeable persistence implementations, how a Spring profile selects one, and the separate Maven profile axis that selects the database.
- The web layer: XML-configured Spring MVC, JSP views and localized messages.

Evidence: [CLAUDE.md:1](../../../CLAUDE.md); section headings at lines 5, 11, 26, 43, 65 and 77.

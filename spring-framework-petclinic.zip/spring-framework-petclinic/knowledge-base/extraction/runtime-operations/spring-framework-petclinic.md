---
tags:
  - extraction
  - runtime-operations
---
# Runtime Operations: spring-framework-petclinic

## Deployment Model

### Type
WAR deployed to a Servlet container (Jetty via Maven plugin for local run; Jetty-based container image via Jib). Confidence: HIGH.
Evidence: [pom.xml](../../../pom.xml) (`<packaging>war</packaging>`, jetty-maven-plugin 11.0.26, jib-maven-plugin 3.5.1).

### Artifact
- `target/petclinic.war` (`<finalName>petclinic</finalName>`). Confidence: HIGH. Evidence: [pom.xml](../../../pom.xml).
- Docker image `docker.io/springcommunity/spring-framework-petclinic`, tags `${project.version}` (7.0.3) and `latest`, built with `mvn jib:build` from base `jetty:11.0-jdk17`, entrypoint `java -jar /usr/local/jetty/start.jar`. Confidence: HIGH. Evidence: [pom.xml](../../../pom.xml) jib plugin block. No Dockerfile exists.
- Web app bootstrap is programmatic (no web.xml): [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) registers a root context (`business-config.xml`, `tools-config.xml`), a DispatcherServlet mapped to `/` (`mvc-core-config.xml`) and a `CharacterEncodingFilter` (UTF-8, forced). Confidence: HIGH.

### Execution Environment
- Java 17 (`java.version`, enforcer rule). Spring Framework 7.0.8, Jakarta namespace (`jakarta.servlet`). Confidence: HIGH. Evidence: [pom.xml](../../../pom.xml).
- Local run: `./mvnw jetty:run-war` on port 8080 (per [CLAUDE.md](../../../CLAUDE.md) and [readme.md](../../../readme.md); the port is the plugin default, not set in the pom). Confidence: MEDIUM.
- [jetty-web.xml](../../../src/main/webapp/WEB-INF/jetty-web.xml) sets `parentLoaderPriority=true` (classloader workaround for tomcat-jdbc under Jetty). Confidence: HIGH.
- CI: GitHub Actions matrix JDK 17 and 21, `./mvnw -B verify` plus Sonar scan on push to main. Evidence: [maven-build-main.yml](../../../.github/workflows/maven-build-main.yml), [maven-build-pull-request.yml](../../../.github/workflows/maven-build-pull-request.yml). Confidence: HIGH.

### Resource Constraints
None declared (no JVM flags, memory limits or container resource settings in the repo). Confidence: HIGH (absence verified).

## Runtime Dependencies

### External Services
None (no HTTP clients, brokers or third-party APIs found). Confidence: MEDIUM (absence based on config and dependency review).

### System Dependencies
- Servlet 6 / JSP / JSTL container (jakarta.servlet-api, tomcat-jasper-el, glassfish JSTL) - [pom.xml](../../../pom.xml).
- Tomcat JDBC pool (`org.apache.tomcat.jdbc.pool.DataSource`) - [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml).
- Build time only, `-P css`: libsass Maven plugin to compile SCSS.

### Data Stores
Selected by Maven profile (values filtered into `data-access.properties`). Evidence: [pom.xml](../../../pom.xml) profiles; [data-access.properties](../../../src/main/resources/spring/data-access.properties). Confidence: HIGH.

| Maven profile | URL | Driver | User / password | `db.script` / `jpa.database` |
|---|---|---|---|---|
| H2 (default, activeByDefault) | `jdbc:h2:mem:petclinic` | `org.h2.Driver` | sa / empty | h2 / H2 |
| HSQLDB | `jdbc:hsqldb:mem:petclinic` | `org.hsqldb.jdbcDriver` | sa / empty | hsqldb / HSQL |
| MySQL | `jdbc:mysql://localhost:3306/petclinic?useUnicode=true` | `com.mysql.cj.jdbc.Driver` (8.1.0) | petclinic / petclinic | mysql / MYSQL |
| PostgreSQL | `jdbc:postgresql://localhost:5432/petclinic` | `org.postgresql.Driver` (42.7.13) | postgres / petclinic | postgresql / POSTGRESQL |

- Schema and seed data are loaded at every startup by `<jdbc:initialize-database>` from `classpath:db/${db.script}/schema.sql` and `data.sql` (stops on script failure). Evidence: [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml); scripts under `src/main/resources/db/`.
- A `javaee` Spring profile declares a JNDI DataSource `java:comp/env/jdbc/petclinic` in the same file. Confidence: HIGH (declared). Whether it cleanly replaces the non-profile `dataSource` bean was not verified (inferred: bean override decides).
- Hibernate dialect via `jpa.database`; `jpa.showSql=true` (SQL printed to stdout).

## Configuration Management

### Configuration Sources
1. JVM system properties, highest priority: `<context:property-placeholder ... system-properties-mode="OVERRIDE"/>` in [business-config.xml](../../../src/main/resources/spring/business-config.xml) and datasource-config.xml. Confidence: HIGH.
2. [data-access.properties](../../../src/main/resources/spring/data-access.properties) on the classpath; its `${...}` values are substituted at build time by Maven resource filtering (`<filtering>true</filtering>`, [pom.xml](../../../pom.xml)) from the active Maven profile. The DB choice is therefore fixed at package time unless overridden by system properties. Confidence: HIGH.
3. Spring XML under `src/main/resources/spring/` (business, datasource, tools, mvc-core, mvc-view). Confidence: HIGH.
4. Environment variables: not referenced by any config. Whether the placeholder configurer falls back to them was not verified at runtime (inferred). Confidence: MEDIUM.

Spring profiles (evidence [business-config.xml](../../../src/main/resources/spring/business-config.xml), [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)): `jpa` (default via `setDefaultProfiles`), `jdbc`, `spring-data-jpa`, `javaee`. Override with `-Dspring.profiles.active=...`. Confidence: HIGH.

### Key Properties
| Property | Purpose | Default/Required | Environment Variable |
|---|---|---|---|
| `spring.profiles.active` | pick persistence implementation | default profile `jpa` | none |
| `jdbc.driverClassName`, `jdbc.url`, `jdbc.username`, `jdbc.password` | datasource | from Maven profile (H2) | none |
| `jdbc.initLocation`, `jdbc.dataLocation` | schema/data scripts | `classpath:db/${db.script}/{schema,data}.sql` | none |
| `jpa.database` | Hibernate dialect | from Maven profile | none |
| `jpa.showSql` | log SQL | `true` | none |
| `db.script` | script folder name | from Maven profile | none |

Confidence: HIGH for all rows.

### Secrets Management
No secrets manager. MySQL/PostgreSQL credentials are hardcoded in the [pom.xml](../../../pom.xml) profiles and baked into the packaged properties file. CI uses GitHub secrets `GITHUB_TOKEN` and `SONAR_TOKEN` ([workflow](../../../.github/workflows/maven-build-main.yml)). Confidence: HIGH.

## Scheduling & Background Tasks

### Scheduled Jobs
None. No `@Scheduled`, `@Async`, Quartz, `task:` namespace or `@Enable*` annotations found in `src/main`. Confidence: HIGH (grep verified).

### Async Processing
None.

### Caching (operational)
Caffeine `CaffeineCacheManager` with caches `default` and `vets`, no size or TTL configured. `ClinicServiceImpl` vets lookup is `@Cacheable("vets")`. Evidence: [tools-config.xml](../../../src/main/resources/spring/tools-config.xml), [ClinicServiceImpl.java:100](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java). Confidence: HIGH.

## Observability

### Logging
- Framework: SLF4J + Logback ([logback.xml](../../../src/main/resources/logback.xml)). Confidence: HIGH.
- Destination: console only, pattern `%-5level %logger{0} - %msg%n`; no file appender. Confidence: HIGH.
- Levels: root `info`; `org.springframework.samples.petclinic` `debug`; hibernate debug is commented out. Config rescanned every 30 seconds (`scan="true"`); JUL bridged via `LevelChangePropagator`. Confidence: HIGH.
- MVC exceptions are logged under category `warn` (`warnLogCategory` in [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml)); error view `exception.jsp`. Confidence: HIGH.

### Metrics
JMX only: `CallMonitoringAspect` exported via `<context:mbean-export/>` as MBean `petclinic:type=CallMonitor` with attributes `enabled`, `callCount`, `callTime` (average ms) and operation `reset`. It advises beans within `@Repository` classes. Evidence: [CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java), [tools-config.xml](../../../src/main/resources/spring/tools-config.xml). Its Javadoc says it is not effective with spring-data-jpa. No Prometheus or Micrometer. Confidence: HIGH.

### Health Checks
None: no Actuator or health endpoint exists. A probe would have to use `GET /` (welcome view via `mvc:view-controller`), which is inferred, not declared. Confidence: HIGH (absence), LOW (suggested probe).

### Tracing
Disabled; no tracing dependency. Confidence: HIGH.

### Alert-worthy events (inferred)
Startup failure of `initialize-database` scripts; DB connection failures; exceptions routed to the `warn` category. Confidence: LOW.

## Evidence

### Configuration Files
- [pom.xml](../../../pom.xml): profiles, filtering, jetty, jib, enforcer.
- [business-config.xml](../../../src/main/resources/spring/business-config.xml), [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml), [tools-config.xml](../../../src/main/resources/spring/tools-config.xml), [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml), [data-access.properties](../../../src/main/resources/spring/data-access.properties)
- [logback.xml](../../../src/main/resources/logback.xml), [jetty-web.xml](../../../src/main/webapp/WEB-INF/jetty-web.xml)

### Source Code References
- [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java), [CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java)

### Build Configuration
- [pom.xml](../../../pom.xml); CI: [maven-build-main.yml](../../../.github/workflows/maven-build-main.yml)

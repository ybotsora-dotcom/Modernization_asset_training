---
tags:
  - extraction
  - runtime-operations
---
# Runtime Operations: Index

Single-module Maven project (WAR). No Dockerfile, docker-compose, Kubernetes or Helm manifests exist in the repository; the container image is produced by the Jib Maven plugin.

## Service files
- [spring-framework-petclinic.md](./spring-framework-petclinic.md) - the only module: WAR deployment, DB profiles, Spring profiles, JMX call monitor, Caffeine cache, logging.

## Deployment model summary
- WAR (`petclinic.war`) run on Jetty (`jetty:run-war`) or any Servlet 6 container; optional Jib-built image from `jetty:11.0-jdk17` (HIGH).
- Java 17 (enforced by maven-enforcer); CI builds on JDK 17 and 21.
- No scheduled jobs, no async processing, no message brokers, no external APIs. Only external dependency is the relational database (H2/HSQLDB in-memory by default; MySQL/PostgreSQL optional).
- No tracing, no metrics endpoint, no health endpoint (no Actuator, no Spring Boot).

## Related extraction folders
- [../repository/index.md](../repository/index.md)

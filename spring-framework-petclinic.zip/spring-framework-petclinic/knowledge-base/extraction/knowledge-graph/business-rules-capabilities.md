---
tags:
  - extraction
  - knowledge-graph
---

# Knowledge Graph: Business Rules and Capabilities

Back to [knowledge-graph/index.md](./index.md). 40 business rules, 15 capabilities, domains and personas.

**Counts**: 63 entities, 181 relationships (source in this domain). Confidence: high 146, medium 35, low 0.

Rule ids are the ids in [business-logic-rules/index.md](../business-logic-rules/index.md). No rule engine exists, so no rule-engine mapping is linked. Rule confidence is carried through from the rules summary (HIGH or MEDIUM). Visit does not require a vet (VIS-002).

## Diagram

**Legend.** Node label = `Type: Name`. Solid arrow = HIGH confidence (explicit code or config evidence). Dashed arrow = MEDIUM (inferred or not run-time verified). Dotted line (no arrowhead, label ends `low`) = LOW (speculative).

```mermaid
graph LR
    n0["BusinessDomain: Owners domain"]
    n1["BusinessDomain: Pets domain"]
    n2["BusinessDomain: Visits domain"]
    n3["BusinessDomain: Vets domain"]
    n4["Entity: Owner"]
    n5["Entity: Pet"]
    n6["Entity: Visit"]
    n7["Entity: Vet"]
    n8["BusinessRule: VIS-002"]
    n9["BusinessRule: VET-005"]
    n10["BusinessRule: OWN-008"]
    n11["BusinessRule: PLT-001"]
    n12["BusinessRule: PLT-002"]
    n13["BusinessRule: OWN-009"]
    n14["BusinessRule: VIS-007"]
    n15["BusinessRule: VET-001"]
    n16["BusinessRule: VIS-009"]
    n17["BusinessCapability: Record a visit for a pet"]
    n18["Persona: Clinic front-desk staff"]
    n0 -->|"MANAGES"| n4
    n1 -->|"MANAGES"| n5
    n2 -->|"MANAGES"| n6
    n3 -->|"MANAGES"| n7
    n8 -->|"AFFECTS"| n6
    n8 -->|"AFFECTS"| n7
    n9 -->|"AFFECTS"| n7
    n8 -->|"INDEPENDENT_OF"| n9
    n10 -.->|"AFFECTS"| n4
    n11 -->|"CHANGES_BEHAVIOUR_OF"| n14
    n11 -->|"CHANGES_BEHAVIOUR_OF"| n15
    n12 -->|"CHANGES_BEHAVIOUR_OF"| n13
    n14 -->|"AFFECTS"| n6
    n15 -.->|"AFFECTS"| n7
    n13 -.->|"AFFECTS"| n4
    n16 -.->|"AFFECTS"| n6
    n17 -->|"BELONGS_TO"| n2
    n17 -->|"BELONGS_TO"| n2
    n18 -.->|"USES"| n17
```

## Entities

| Entity | Type | Primary location | Role |
|---|---|---|---|
| OWN-001 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Owner mandatory fields (Validation) |
| OWN-002 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Telephone digits only, at most 10 integer digits (Validation) |
| OWN-003 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Last-name prefix search (Workflow) |
| OWN-004 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Search result routing (Workflow) |
| OWN-005 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Owner id cannot be bound from a request (Constraint) |
| OWN-006 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Owner create versus update (Workflow) |
| OWN-007 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Owner pets ordered by name (Calculation) |
| OWN-008 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Owner-to-pet cascade; no delete capability (Constraint) |
| OWN-009 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Search case sensitivity depends on database (Configuration) |
| OWN-010 | BusinessRule | [business-logic-rules/owners.md](../business-logic-rules/owners.md) | Missing owner lookup fails (Constraint) |
| PET-001 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Pet name required (Validation) |
| PET-002 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Pet type required only for new pets (Validation) |
| PET-003 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Pet birth date required (Validation) |
| PET-004 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Duplicate pet name per owner (Validation) |
| PET-005 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Birth date input format yyyy/MM/dd (Validation) |
| PET-006 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Pet type resolved by exact name (Validation) |
| PET-007 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Pet attached to owner and saved (Workflow) |
| PET-008 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Pet types listed alphabetically (Calculation) |
| PET-009 | BusinessRule | [business-logic-rules/pets.md](../business-logic-rules/pets.md) | Pet must reference an existing type and owner (Constraint) |
| VIS-001 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Visit description required (Validation) |
| VIS-002 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | A visit does not require or record a vet (Constraint) |
| VIS-003 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Pet visits shown newest first (Calculation) |
| VIS-004 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Visit date defaults to today (Calculation) |
| VIS-005 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Visit date format yyyy/MM/dd, not validated further (Validation) |
| VIS-006 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Visit must belong to an existing pet (Constraint) |
| VIS-007 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Visits are insert-only in JDBC mode (Constraint) |
| VIS-008 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Add-visit workflow (Workflow) |
| VIS-009 | BusinessRule | [business-logic-rules/visits.md](../business-logic-rules/visits.md) | Visit list endpoint targets a view that is not in the repo (Workflow) |
| VET-001 | BusinessRule | [business-logic-rules/vets.md](../business-logic-rules/vets.md) | Vets ordered by last then first name (Calculation) |
| VET-002 | BusinessRule | [business-logic-rules/vets.md](../business-logic-rules/vets.md) | Specialties sorted by name (Calculation) |
| VET-003 | BusinessRule | [business-logic-rules/vets.md](../business-logic-rules/vets.md) | Specialty count and none display (Calculation) |
| VET-004 | BusinessRule | [business-logic-rules/vets.md](../business-logic-rules/vets.md) | Vet list is cached (Configuration) |
| VET-005 | BusinessRule | [business-logic-rules/vets.md](../business-logic-rules/vets.md) | Vets are read-only and unrelated to visits (Constraint) |
| VET-006 | BusinessRule | [business-logic-rules/vets.md](../business-logic-rules/vets.md) | Vet-specialty link integrity (Constraint) |
| VET-007 | BusinessRule | [business-logic-rules/vets.md](../business-logic-rules/vets.md) | Vet list published in three formats (Workflow) |
| PLT-001 | BusinessRule | [business-logic-rules/platform.md](../business-logic-rules/platform.md) | Persistence implementation chosen by Spring profile (Configuration) |
| PLT-002 | BusinessRule | [business-logic-rules/platform.md](../business-logic-rules/platform.md) | Database chosen by Maven profile (Configuration) |
| PLT-003 | BusinessRule | [business-logic-rules/platform.md](../business-logic-rules/platform.md) | Repository call monitoring (Configuration) |
| PLT-004 | BusinessRule | [business-logic-rules/platform.md](../business-logic-rules/platform.md) | Unhandled errors show a generic error page (Workflow) |
| PLT-005 | BusinessRule | [business-logic-rules/platform.md](../business-logic-rules/platform.md) | Transaction boundaries on the service (Constraint) |
| Owners domain | BusinessDomain | [business-intent/owners.md](../business-intent/owners.md) | Client register, search, edit |
| Pets domain | BusinessDomain | [business-intent/pets.md](../business-intent/pets.md) | Pet registration and edit, type list |
| Visits domain | BusinessDomain | [business-intent/visits.md](../business-intent/visits.md) | Visit recording and history; no vet link |
| Vets domain | BusinessDomain | [business-intent/vets.md](../business-intent/vets.md) | Read-only vet and specialty directory |
| Platform domain | BusinessDomain | [business-intent/platform.md](../business-intent/platform.md) | Database and persistence selection, monitoring, errors |
| Clinic front-desk staff | Persona | [business-intent/index.md](../business-intent/index.md) | Finds owners, registers owners and pets, records visits (inferred; no login) |
| Vet directory viewer | Persona | [business-intent/index.md](../business-intent/index.md) | Anonymous reader of the vet list |
| Developer or operator | Persona | [business-intent/index.md](../business-intent/index.md) | Chooses DB and persistence profile, reads JMX |
| Find owners by surname | BusinessCapability | [business-intent/owners.md](../business-intent/owners.md) | Capability in Owners domain |
| Register a new owner | BusinessCapability | [business-intent/owners.md](../business-intent/owners.md) | Capability in Owners domain |
| Edit owner details | BusinessCapability | [business-intent/owners.md](../business-intent/owners.md) | Capability in Owners domain |
| View owner record | BusinessCapability | [business-intent/owners.md](../business-intent/owners.md) | Capability in Owners domain |
| Add a pet to an owner | BusinessCapability | [business-intent/pets.md](../business-intent/pets.md) | Capability in Pets domain |
| Edit a pet | BusinessCapability | [business-intent/pets.md](../business-intent/pets.md) | Capability in Pets domain |
| Pet type selection list | BusinessCapability | [business-intent/pets.md](../business-intent/pets.md) | Capability in Pets domain |
| Record a visit for a pet | BusinessCapability | [business-intent/visits.md](../business-intent/visits.md) | Capability in Visits domain |
| Visit history per pet | BusinessCapability | [business-intent/visits.md](../business-intent/visits.md) | Capability in Visits domain |
| Visit list endpoint (not usable) | BusinessCapability | [business-intent/visits.md](../business-intent/visits.md) | Capability in Visits domain |
| View veterinarians and specialties | BusinessCapability | [business-intent/vets.md](../business-intent/vets.md) | Capability in Vets domain |
| Publish vet list as JSON and XML | BusinessCapability | [business-intent/vets.md](../business-intent/vets.md) | Capability in Vets domain |
| Select database and persistence implementation | BusinessCapability | [business-intent/platform.md](../business-intent/platform.md) | Capability in Platform domain |
| Monitor repository activity | BusinessCapability | [business-intent/platform.md](../business-intent/platform.md) | Capability in Platform domain |
| Generic error handling | BusinessCapability | [business-intent/platform.md](../business-intent/platform.md) | Capability in Platform domain |

## Relationships

| Source | Relationship | Target | Confidence | Evidence |
|---|---|---|---|---|
| OWN-001 | AFFECTS | Owner | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-002 | AFFECTS | Owner | medium | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-003 | AFFECTS | Owner | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-003 | AFFECTS | Pet | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-003 | AFFECTS | Visit | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-004 | AFFECTS | Owner | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-005 | AFFECTS | Owner | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-006 | AFFECTS | Owner | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-007 | AFFECTS | Owner | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-007 | AFFECTS | Pet | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-008 | AFFECTS | Owner | medium | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-008 | AFFECTS | Pet | medium | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-008 | AFFECTS | Visit | medium | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-009 | AFFECTS | Owner | medium | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-010 | AFFECTS | Owner | medium | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| PET-001 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-002 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-002 | AFFECTS | PetType | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-003 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-004 | AFFECTS | Owner | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-004 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-005 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-006 | AFFECTS | PetType | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-006 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-007 | AFFECTS | Owner | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-007 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-008 | AFFECTS | PetType | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-009 | AFFECTS | Pet | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-009 | AFFECTS | PetType | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-009 | AFFECTS | Owner | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| VIS-001 | AFFECTS | Visit | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-002 | AFFECTS | Visit | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-002 | AFFECTS | Pet | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-002 | AFFECTS | Vet | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-003 | AFFECTS | Pet | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-003 | AFFECTS | Visit | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-004 | AFFECTS | Visit | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-005 | AFFECTS | Visit | medium | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-006 | AFFECTS | Visit | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-006 | AFFECTS | Pet | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-007 | AFFECTS | Visit | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-008 | AFFECTS | Pet | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-008 | AFFECTS | Visit | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-009 | AFFECTS | Pet | medium | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-009 | AFFECTS | Visit | medium | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VET-001 | AFFECTS | Vet | medium | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-002 | AFFECTS | Vet | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-002 | AFFECTS | Specialty | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-003 | AFFECTS | Vet | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-004 | AFFECTS | Vet | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-005 | AFFECTS | Vet | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-005 | AFFECTS | Specialty | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-005 | AFFECTS | Visit | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-006 | AFFECTS | Vet | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-006 | AFFECTS | Specialty | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-007 | AFFECTS | Vet | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| PLT-001 | AFFECTS | Owner | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-001 | AFFECTS | Pet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-001 | AFFECTS | Visit | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-001 | AFFECTS | Vet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | AFFECTS | Owner | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | AFFECTS | Pet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | AFFECTS | Visit | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | AFFECTS | Vet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | AFFECTS | Specialty | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | AFFECTS | PetType | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-003 | AFFECTS | Owner | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-003 | AFFECTS | Pet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-003 | AFFECTS | Visit | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-003 | AFFECTS | Vet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-004 | AFFECTS | Owner | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-004 | AFFECTS | Pet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-004 | AFFECTS | Visit | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-004 | AFFECTS | Vet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-005 | AFFECTS | Owner | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-005 | AFFECTS | Pet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-005 | AFFECTS | Visit | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-005 | AFFECTS | Vet | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| OWN-003 | ENFORCED_IN | OwnerController | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-004 | ENFORCED_IN | OwnerController | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-005 | ENFORCED_IN | OwnerController | high | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| OWN-009 | ENFORCED_IN | Maven database profiles | medium | [business-logic-rules/owners.md](../business-logic-rules/owners.md) |
| PET-001 | ENFORCED_IN | PetValidator | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-002 | ENFORCED_IN | PetValidator | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-003 | ENFORCED_IN | PetValidator | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-004 | ENFORCED_IN | PetController | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-006 | ENFORCED_IN | PetTypeFormatter | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| PET-009 | ENFORCED_IN | db scripts (schema.sql, data.sql) | high | [business-logic-rules/pets.md](../business-logic-rules/pets.md) |
| VIS-006 | ENFORCED_IN | db scripts (schema.sql, data.sql) | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VET-006 | ENFORCED_IN | db scripts (schema.sql, data.sql) | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VIS-007 | ENFORCED_IN | JdbcVisitRepositoryImpl | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-007 | ENFORCED_IN | JpaVisitRepositoryImpl | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-008 | ENFORCED_IN | VisitController | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VIS-009 | ENFORCED_IN | VisitController | high | [business-logic-rules/visits.md](../business-logic-rules/visits.md) |
| VET-001 | ENFORCED_IN | JpaVetRepositoryImpl | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-001 | ENFORCED_IN | JdbcVetRepositoryImpl | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-004 | ENFORCED_IN | ClinicServiceImpl | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-004 | ENFORCED_IN | cacheManager | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| VET-007 | ENFORCED_IN | VetController | high | [business-logic-rules/vets.md](../business-logic-rules/vets.md) |
| PLT-001 | ENFORCED_IN | PetclinicInitializer | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-001 | ENFORCED_IN | business-config.xml | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | ENFORCED_IN | Maven database profiles | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-002 | ENFORCED_IN | data-access.properties | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-003 | ENFORCED_IN | CallMonitoringAspect | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-003 | ENFORCED_IN | tools-config.xml | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-004 | ENFORCED_IN | SimpleMappingExceptionResolver | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| PLT-005 | ENFORCED_IN | ClinicServiceImpl | high | [business-logic-rules/platform.md](../business-logic-rules/platform.md) |
| VIS-002 | INDEPENDENT_OF | VET-005 | high | [business-logic-rules/index.md](../business-logic-rules/index.md) |
| PLT-001 | CHANGES_BEHAVIOUR_OF | VIS-007 | high | [business-logic-rules/index.md](../business-logic-rules/index.md) |
| PLT-001 | CHANGES_BEHAVIOUR_OF | VET-001 | high | [business-logic-rules/index.md](../business-logic-rules/index.md) |
| PLT-002 | CHANGES_BEHAVIOUR_OF | OWN-009 | high | [business-logic-rules/index.md](../business-logic-rules/index.md) |
| OWN-007 | SHARES_LOGIC_WITH | PET-004 | high | [business-logic-rules/index.md](../business-logic-rules/index.md) |
| Owners domain | MANAGES | Owner | high | [business-intent/index.md](../business-intent/index.md) |
| Owners domain | MANAGES | Person | high | [business-intent/index.md](../business-intent/index.md) |
| Pets domain | MANAGES | Pet | high | [business-intent/index.md](../business-intent/index.md) |
| Pets domain | MANAGES | PetType | high | [business-intent/index.md](../business-intent/index.md) |
| Visits domain | MANAGES | Visit | high | [business-intent/index.md](../business-intent/index.md) |
| Vets domain | MANAGES | Vet | high | [business-intent/index.md](../business-intent/index.md) |
| Vets domain | MANAGES | Specialty | high | [business-intent/index.md](../business-intent/index.md) |
| Find owners by surname | BELONGS_TO | Owners domain | medium | [business-intent/index.md](../business-intent/index.md) |
| Find owners by surname | IMPLEMENTED_BY | OwnerController | medium | [business-intent/owners.md](../business-intent/owners.md); [functional/index.md](../functional/index.md) |
| Find owners by surname | GOVERNED_BY | OWN-003 | medium | [business-intent/owners.md](../business-intent/owners.md) |
| Find owners by surname | GOVERNED_BY | OWN-004 | medium | [business-intent/owners.md](../business-intent/owners.md) |
| Register a new owner | BELONGS_TO | Owners domain | high | [business-intent/index.md](../business-intent/index.md) |
| Register a new owner | IMPLEMENTED_BY | OwnerController | high | [business-intent/owners.md](../business-intent/owners.md); [functional/index.md](../functional/index.md) |
| Register a new owner | GOVERNED_BY | OWN-001 | high | [business-intent/owners.md](../business-intent/owners.md) |
| Register a new owner | GOVERNED_BY | OWN-006 | high | [business-intent/owners.md](../business-intent/owners.md) |
| Edit owner details | BELONGS_TO | Owners domain | high | [business-intent/index.md](../business-intent/index.md) |
| Edit owner details | IMPLEMENTED_BY | OwnerController | high | [business-intent/owners.md](../business-intent/owners.md); [functional/index.md](../functional/index.md) |
| Edit owner details | GOVERNED_BY | OWN-006 | high | [business-intent/owners.md](../business-intent/owners.md) |
| View owner record | BELONGS_TO | Owners domain | high | [business-intent/index.md](../business-intent/index.md) |
| View owner record | IMPLEMENTED_BY | OwnerController | high | [business-intent/owners.md](../business-intent/owners.md); [functional/index.md](../functional/index.md) |
| View owner record | GOVERNED_BY | OWN-007 | high | [business-intent/owners.md](../business-intent/owners.md) |
| Add a pet to an owner | BELONGS_TO | Pets domain | high | [business-intent/index.md](../business-intent/index.md) |
| Add a pet to an owner | IMPLEMENTED_BY | PetController | high | [business-intent/pets.md](../business-intent/pets.md); [functional/index.md](../functional/index.md) |
| Add a pet to an owner | GOVERNED_BY | PET-007 | high | [business-intent/pets.md](../business-intent/pets.md) |
| Edit a pet | BELONGS_TO | Pets domain | high | [business-intent/index.md](../business-intent/index.md) |
| Edit a pet | IMPLEMENTED_BY | PetController | high | [business-intent/pets.md](../business-intent/pets.md); [functional/index.md](../functional/index.md) |
| Edit a pet | GOVERNED_BY | PET-001 | high | [business-intent/pets.md](../business-intent/pets.md) |
| Pet type selection list | BELONGS_TO | Pets domain | high | [business-intent/index.md](../business-intent/index.md) |
| Pet type selection list | IMPLEMENTED_BY | PetController | high | [business-intent/pets.md](../business-intent/pets.md); [functional/index.md](../functional/index.md) |
| Pet type selection list | GOVERNED_BY | PET-008 | high | [business-intent/pets.md](../business-intent/pets.md) |
| Record a visit for a pet | BELONGS_TO | Visits domain | high | [business-intent/index.md](../business-intent/index.md) |
| Record a visit for a pet | IMPLEMENTED_BY | VisitController | high | [business-intent/visits.md](../business-intent/visits.md); [functional/index.md](../functional/index.md) |
| Record a visit for a pet | GOVERNED_BY | VIS-008 | high | [business-intent/visits.md](../business-intent/visits.md) |
| Visit history per pet | BELONGS_TO | Visits domain | high | [business-intent/index.md](../business-intent/index.md) |
| Visit history per pet | IMPLEMENTED_BY | VisitController | high | [business-intent/visits.md](../business-intent/visits.md); [functional/index.md](../functional/index.md) |
| Visit history per pet | GOVERNED_BY | VIS-003 | high | [business-intent/visits.md](../business-intent/visits.md) |
| Visit list endpoint (not usable) | BELONGS_TO | Visits domain | medium | [business-intent/index.md](../business-intent/index.md) |
| Visit list endpoint (not usable) | IMPLEMENTED_BY | VisitController | medium | [business-intent/visits.md](../business-intent/visits.md); [functional/index.md](../functional/index.md) |
| Visit list endpoint (not usable) | GOVERNED_BY | VIS-009 | medium | [business-intent/visits.md](../business-intent/visits.md) |
| View veterinarians and specialties | BELONGS_TO | Vets domain | medium | [business-intent/index.md](../business-intent/index.md) |
| View veterinarians and specialties | IMPLEMENTED_BY | VetController | medium | [business-intent/vets.md](../business-intent/vets.md); [functional/index.md](../functional/index.md) |
| View veterinarians and specialties | GOVERNED_BY | VET-001 | medium | [business-intent/vets.md](../business-intent/vets.md) |
| Publish vet list as JSON and XML | BELONGS_TO | Vets domain | high | [business-intent/index.md](../business-intent/index.md) |
| Publish vet list as JSON and XML | IMPLEMENTED_BY | VetController | high | [business-intent/vets.md](../business-intent/vets.md); [functional/index.md](../functional/index.md) |
| Publish vet list as JSON and XML | GOVERNED_BY | VET-007 | high | [business-intent/vets.md](../business-intent/vets.md) |
| Select database and persistence implementation | BELONGS_TO | Platform domain | high | [business-intent/index.md](../business-intent/index.md) |
| Select database and persistence implementation | IMPLEMENTED_BY | business-config.xml | high | [business-intent/platform.md](../business-intent/platform.md); [functional/index.md](../functional/index.md) |
| Select database and persistence implementation | GOVERNED_BY | PLT-001 | high | [business-intent/platform.md](../business-intent/platform.md) |
| Select database and persistence implementation | GOVERNED_BY | PLT-002 | high | [business-intent/platform.md](../business-intent/platform.md) |
| Monitor repository activity | BELONGS_TO | Platform domain | high | [business-intent/index.md](../business-intent/index.md) |
| Monitor repository activity | IMPLEMENTED_BY | CallMonitoringAspect | high | [business-intent/platform.md](../business-intent/platform.md); [functional/index.md](../functional/index.md) |
| Monitor repository activity | GOVERNED_BY | PLT-003 | high | [business-intent/platform.md](../business-intent/platform.md) |
| Generic error handling | BELONGS_TO | Platform domain | high | [business-intent/index.md](../business-intent/index.md) |
| Generic error handling | IMPLEMENTED_BY | SimpleMappingExceptionResolver | high | [business-intent/platform.md](../business-intent/platform.md); [functional/index.md](../functional/index.md) |
| Generic error handling | GOVERNED_BY | PLT-004 | high | [business-intent/platform.md](../business-intent/platform.md) |
| Clinic front-desk staff | USES | Find owners by surname | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Register a new owner | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Edit owner details | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | View owner record | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Add a pet to an owner | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Edit a pet | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Pet type selection list | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Record a visit for a pet | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Visit history per pet | medium | [business-intent/index.md](../business-intent/index.md) |
| Clinic front-desk staff | USES | Visit list endpoint (not usable) | medium | [business-intent/index.md](../business-intent/index.md) |
| Vet directory viewer | USES | View veterinarians and specialties | medium | [business-intent/index.md](../business-intent/index.md) |
| Vet directory viewer | USES | Publish vet list as JSON and XML | medium | [business-intent/index.md](../business-intent/index.md) |
| Developer or operator | USES | Select database and persistence implementation | medium | [business-intent/index.md](../business-intent/index.md) |
| Developer or operator | USES | Monitor repository activity | medium | [business-intent/index.md](../business-intent/index.md) |

## Gaps in this domain

- Authorization and StateTransition rule categories have 0 rules; no role entity exists in the graph because the code has none.
- Personas are inferred (no roles or login in code).
- Capability-to-rule links list the principal rules named in the business-intent files, not every rule touching the capability.

## Related

[knowledge-graph/index.md](./index.md), [business-logic-rules/index.md](../business-logic-rules/index.md), [business-intent/index.md](../business-intent/index.md)

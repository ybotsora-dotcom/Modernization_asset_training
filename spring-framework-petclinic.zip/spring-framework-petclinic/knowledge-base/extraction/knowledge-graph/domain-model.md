---
tags:
  - extraction
  - knowledge-graph
---

# Knowledge Graph: Domain Model

Back to [knowledge-graph/index.md](./index.md). Entities, base classes, tables and foreign keys (Owner, Pet, PetType, Visit, Vet, Specialty).

**Counts**: 17 entities, 27 relationships (source in this domain). Confidence: high 27, medium 0, low 0.

Entity names match [data-model/index.md](../data-model/index.md). `Visit` has no relationship to `Vet` in the model, schema or UI (see VIS-002 in the business rules domain).

## Diagram

**Legend.** Node label = `Type: Name`. Solid arrow = HIGH confidence (explicit code or config evidence). Dashed arrow = MEDIUM (inferred or not run-time verified). Dotted line (no arrowhead, label ends `low`) = LOW (speculative).

```mermaid
graph LR
    n0["MappedSuperclass: BaseEntity"]
    n1["MappedSuperclass: NamedEntity"]
    n2["MappedSuperclass: Person"]
    n3["Entity: Owner"]
    n4["Entity: Pet"]
    n5["Entity: PetType"]
    n6["Entity: Visit"]
    n7["Entity: Vet"]
    n8["Entity: Specialty"]
    n9["JAXBWrapper: Vets"]
    n10["Table: owners (table)"]
    n11["Table: pets (table)"]
    n12["Table: visits (table)"]
    n13["Table: vets (table)"]
    n14["Table: vet_specialties (table)"]
    n1 -->|"EXTENDS"| n0
    n2 -->|"EXTENDS"| n0
    n6 -->|"EXTENDS"| n0
    n4 -->|"EXTENDS"| n1
    n5 -->|"EXTENDS"| n1
    n8 -->|"EXTENDS"| n1
    n3 -->|"EXTENDS"| n2
    n7 -->|"EXTENDS"| n2
    n3 -->|"HAS_MANY"| n4
    n4 -->|"REFERENCES"| n5
    n4 -->|"HAS_MANY"| n6
    n7 -->|"ASSOCIATED_WITH"| n8
    n9 -->|"WRAPS"| n7
    n3 -->|"MAPS_TO"| n10
    n4 -->|"MAPS_TO"| n11
    n6 -->|"MAPS_TO"| n12
    n7 -->|"MAPS_TO"| n13
    n11 -->|"FOREIGN_KEY_TO"| n10
    n12 -->|"FOREIGN_KEY_TO"| n11
    n14 -->|"FOREIGN_KEY_TO"| n13
```

## Entities

| Entity | Type | Primary location | Role |
|---|---|---|---|
| BaseEntity | MappedSuperclass | [model/BaseEntity.java](../../../src/main/java/org/springframework/samples/petclinic/model/BaseEntity.java) | Identifier base class |
| NamedEntity | MappedSuperclass | [model/NamedEntity.java](../../../src/main/java/org/springframework/samples/petclinic/model/NamedEntity.java) | Adds name; base of Pet, PetType, Specialty |
| Person | MappedSuperclass | [model/Person.java](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java) | First and last name; base of Owner, Vet |
| Owner | Entity | [model/Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java) | Client; aggregate root of Pet and Visit (cascade ALL) |
| Pet | Entity | [model/Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java) | Animal belonging to an Owner; holds owner_id and type_id |
| PetType | Entity | [model/PetType.java](../../../src/main/java/org/springframework/samples/petclinic/model/PetType.java) | Lookup of pet kinds |
| Visit | Entity | [model/Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java) | Dated visit of a Pet; no Vet reference (VIS-002) |
| Vet | Entity | [model/Vet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java) | Veterinarian; read-only in the application |
| Specialty | Entity | [model/Specialty.java](../../../src/main/java/org/springframework/samples/petclinic/model/Specialty.java) | Lookup of vet specialties |
| Vets | JAXBWrapper | [model/Vets.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vets.java) | Non-persistent list wrapper for XML/JSON vet feeds |
| owners (table) | Table | [data-model/database-schemas.md](../data-model/database-schemas.md) | Owner rows |
| pets (table) | Table | [data-model/database-schemas.md](../data-model/database-schemas.md) | Pet rows; FK owner_id, type_id |
| types (table) | Table | [data-model/database-schemas.md](../data-model/database-schemas.md) | PetType rows |
| visits (table) | Table | [data-model/database-schemas.md](../data-model/database-schemas.md) | Visit rows; FK pet_id, no vet column |
| vets (table) | Table | [data-model/database-schemas.md](../data-model/database-schemas.md) | Vet rows |
| specialties (table) | Table | [data-model/database-schemas.md](../data-model/database-schemas.md) | Specialty rows |
| vet_specialties (table) | Table | [data-model/database-schemas.md](../data-model/database-schemas.md) | Join table Vet-Specialty, no entity class |

## Relationships

| Source | Relationship | Target | Confidence | Evidence |
|---|---|---|---|---|
| NamedEntity | EXTENDS | BaseEntity | high | [model/NamedEntity.java](../../../src/main/java/org/springframework/samples/petclinic/model/NamedEntity.java) |
| Person | EXTENDS | BaseEntity | high | [model/Person.java](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java) |
| Visit | EXTENDS | BaseEntity | high | [model/Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java) |
| Pet | EXTENDS | NamedEntity | high | [model/Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java) |
| PetType | EXTENDS | NamedEntity | high | [model/PetType.java](../../../src/main/java/org/springframework/samples/petclinic/model/PetType.java) |
| Specialty | EXTENDS | NamedEntity | high | [model/Specialty.java](../../../src/main/java/org/springframework/samples/petclinic/model/Specialty.java) |
| Owner | EXTENDS | Person | high | [model/Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java) |
| Vet | EXTENDS | Person | high | [model/Vet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java) |
| Owner | HAS_MANY | Pet | high | [model/Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java); [data-model/model-entities.md](../data-model/model-entities.md) |
| Pet | BELONGS_TO | Owner | high | [model/Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java) |
| Pet | REFERENCES | PetType | high | [model/Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java) |
| Pet | HAS_MANY | Visit | high | [model/Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java); [data-model/model-entities.md](../data-model/model-entities.md) |
| Visit | BELONGS_TO | Pet | high | [model/Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java) |
| Vet | ASSOCIATED_WITH | Specialty | high | [model/Vet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java); [data-model/model-entities.md](../data-model/model-entities.md) |
| Vets | WRAPS | Vet | high | [model/Vets.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vets.java) |
| Owner | MAPS_TO | owners (table) | high | [data-model/model-entities.md](../data-model/model-entities.md) |
| Pet | MAPS_TO | pets (table) | high | [data-model/model-entities.md](../data-model/model-entities.md) |
| PetType | MAPS_TO | types (table) | high | [data-model/model-entities.md](../data-model/model-entities.md) |
| Visit | MAPS_TO | visits (table) | high | [data-model/model-entities.md](../data-model/model-entities.md) |
| Vet | MAPS_TO | vets (table) | high | [data-model/model-entities.md](../data-model/model-entities.md) |
| Specialty | MAPS_TO | specialties (table) | high | [data-model/model-entities.md](../data-model/model-entities.md) |
| Vet | MAPS_TO | vet_specialties (table) | high | [data-model/model-entities.md](../data-model/model-entities.md) |
| pets (table) | FOREIGN_KEY_TO | owners (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| pets (table) | FOREIGN_KEY_TO | types (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| visits (table) | FOREIGN_KEY_TO | pets (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| vet_specialties (table) | FOREIGN_KEY_TO | vets (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| vet_specialties (table) | FOREIGN_KEY_TO | specialties (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |

## Gaps in this domain

- No `persistence.xml` was found; entity discovery relies on `packagesToScan` plus `persistenceUnitName` set together, which the config comment says conflicts (inferred, see [data-model/index.md](../data-model/index.md)).
- Vet-Specialty is unidirectional (`Vet.specialties`); `vet_specialties` has no entity class, so it appears as a table only.

## Related

[knowledge-graph/index.md](./index.md), [data-model/index.md](../data-model/index.md)

---
tags:
  - extraction
  - knowledge-graph
---

# Knowledge Graph: Application Architecture

Back to [knowledge-graph/index.md](./index.md). Layers, repositories in three implementations, Spring configuration, profiles, build and tests.

**Counts**: 52 entities, 110 relationships (source in this domain). Confidence: high 105, medium 1, low 4.

Three repository implementations exist per interface; exactly one set is active, selected by Spring profile (default jpa). `CallMonitoringAspect` pointcut is `within(@Repository *)`: JPA and JDBC implementations carry `@Repository`; the Spring Data interfaces do not, so that coverage is LOW (inferred, per [architecture/petclinic.md](../architecture/petclinic.md)).

## Diagram

**Legend.** Node label = `Type: Name`. Solid arrow = HIGH confidence (explicit code or config evidence). Dashed arrow = MEDIUM (inferred or not run-time verified). Dotted line (no arrowhead, label ends `low`) = LOW (speculative).

```mermaid
graph LR
    n0["Bootstrap: PetclinicInitializer"]
    n1["ServiceInterface: ClinicService"]
    n2["Service: ClinicServiceImpl"]
    n3["RepositoryInterface: OwnerRepository"]
    n4["RepositoryImpl: JpaOwnerRepositoryImpl"]
    n5["RepositoryImpl: JdbcOwnerRepositoryImpl"]
    n6["RepositoryImpl: SpringDataOwnerRepository"]
    n7["SpringProfile: Spring profile jpa"]
    n8["SpringProfile: Spring profile jdbc"]
    n9["SpringProfile: Spring profile spring-data-jpa"]
    n10["SpringConfig: business-config.xml"]
    n11["SpringConfig: tools-config.xml"]
    n12["SpringConfig: datasource-config.xml"]
    n13["Aspect: CallMonitoringAspect"]
    n14["CacheManager: cacheManager"]
    n15["JdbcHelper: JdbcPetVisitExtractor"]
    n16["JdbcHelper: OneToManyResultSetExtractor"]
    n17["Test: AbstractClinicServiceTests"]
    n18["Test: ClinicServiceJpaTests"]
    n0 -->|"LOADS"| n10
    n0 -->|"LOADS"| n11
    n0 -->|"SETS_DEFAULT"| n7
    n10 -->|"IMPORTS"| n12
    n10 -->|"DEFINES"| n8
    n10 -->|"DEFINES"| n7
    n10 -->|"DEFINES"| n9
    n2 -->|"IMPLEMENTS"| n1
    n2 -->|"DEPENDS_ON"| n3
    n4 -->|"IMPLEMENTS"| n3
    n5 -->|"IMPLEMENTS"| n3
    n6 -->|"EXTENDS"| n3
    n7 -->|"ACTIVATES"| n4
    n8 -->|"ACTIVATES"| n5
    n9 -->|"ACTIVATES"| n6
    n5 -->|"USES"| n15
    n15 -->|"EXTENDS"| n16
    n11 -->|"ENABLES"| n13
    n11 -->|"DECLARES"| n14
    n2 -->|"USES"| n14
    n13 -->|"ADVISES"| n4
    n13 -.-|"ADVISES low"| n6
    n18 -->|"EXTENDS"| n17
    n17 -->|"TESTS"| n1
    n18 -->|"PINS_PROFILE"| n7
```

## Entities

| Entity | Type | Primary location | Role |
|---|---|---|---|
| PetclinicInitializer | Bootstrap | [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) | Programmatic servlet initializer; root and servlet contexts; default profile jpa |
| OwnerController | Controller | [web/OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) | Owner search, create, edit, show |
| PetController | Controller | [web/PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java) | Pet create and edit |
| VisitController | Controller | [web/VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java) | Visit create; history endpoint with missing view |
| VetController | Controller | [web/VetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java) | Vet list as HTML, JSON, XML |
| CrashController | Controller | [web/CrashController.java](../../../src/main/java/org/springframework/samples/petclinic/web/CrashController.java) | GET /oups demo exception |
| PetValidator | Validator | [web/PetValidator.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java) | Pet name, type and birth date checks |
| PetTypeFormatter | Formatter | [web/PetTypeFormatter.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java) | Converts PetType by exact name |
| ClinicService | ServiceInterface | [service/ClinicService.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicService.java) | Facade over the four aggregates |
| ClinicServiceImpl | Service | [service/ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) | Transaction boundary and vets cache annotation |
| OwnerRepository | RepositoryInterface | [repository/OwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/OwnerRepository.java) | Persistence contract for Owner |
| PetRepository | RepositoryInterface | [repository/PetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/PetRepository.java) | Persistence contract for Pet |
| VetRepository | RepositoryInterface | [repository/VetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/VetRepository.java) | Persistence contract for Vet |
| VisitRepository | RepositoryInterface | [repository/VisitRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/VisitRepository.java) | Persistence contract for Visit |
| JpaOwnerRepositoryImpl | RepositoryImpl | [repository/jpa/JpaOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java) | Jpa implementation of OwnerRepository |
| JpaPetRepositoryImpl | RepositoryImpl | [repository/jpa/JpaPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaPetRepositoryImpl.java) | Jpa implementation of PetRepository |
| JpaVetRepositoryImpl | RepositoryImpl | [repository/jpa/JpaVetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVetRepositoryImpl.java) | Jpa implementation of VetRepository |
| JpaVisitRepositoryImpl | RepositoryImpl | [repository/jpa/JpaVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVisitRepositoryImpl.java) | Jpa implementation of VisitRepository |
| JdbcOwnerRepositoryImpl | RepositoryImpl | [repository/jdbc/JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) | Jdbc implementation of OwnerRepository |
| JdbcPetRepositoryImpl | RepositoryImpl | [repository/jdbc/JdbcPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java) | Jdbc implementation of PetRepository |
| JdbcVetRepositoryImpl | RepositoryImpl | [repository/jdbc/JdbcVetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVetRepositoryImpl.java) | Jdbc implementation of VetRepository |
| JdbcVisitRepositoryImpl | RepositoryImpl | [repository/jdbc/JdbcVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java) | Jdbc implementation of VisitRepository |
| SpringDataOwnerRepository | RepositoryImpl | [repository/springdatajpa/SpringDataOwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java) | SpringData implementation of OwnerRepository |
| SpringDataPetRepository | RepositoryImpl | [repository/springdatajpa/SpringDataPetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataPetRepository.java) | SpringData implementation of PetRepository |
| SpringDataVetRepository | RepositoryImpl | [repository/springdatajpa/SpringDataVetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataVetRepository.java) | SpringData implementation of VetRepository |
| SpringDataVisitRepository | RepositoryImpl | [repository/springdatajpa/SpringDataVisitRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataVisitRepository.java) | SpringData implementation of VisitRepository |
| JdbcPetVisitExtractor | JdbcHelper | [repository/jdbc/JdbcPetVisitExtractor.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetVisitExtractor.java) | Maps pet-visit join rows (one-to-many) |
| OneToManyResultSetExtractor | JdbcHelper | [repository/jdbc/OneToManyResultSetExtractor.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/OneToManyResultSetExtractor.java) | Generic one-to-many result extractor |
| EntityUtils | Utility | [util/EntityUtils.java](../../../src/main/java/org/springframework/samples/petclinic/util/EntityUtils.java) | Finds entity by id in a list; used by JDBC repositories |
| CallMonitoringAspect | Aspect | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java) | @Around on @Repository classes; JMX managed resource |
| cacheManager | CacheManager | [src/main/resources/spring/tools-config.xml](../../../src/main/resources/spring/tools-config.xml) | CaffeineCacheManager with caches default and vets |
| SimpleMappingExceptionResolver | ExceptionResolver | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) | Maps unhandled exceptions to the exception view |
| business-config.xml | SpringConfig | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) | Imports datasource config; profile blocks for persistence |
| datasource-config.xml | SpringConfig | [src/main/resources/spring/datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml) | DataSource beans, schema initialization, javaee JNDI |
| tools-config.xml | SpringConfig | [src/main/resources/spring/tools-config.xml](../../../src/main/resources/spring/tools-config.xml) | AOP, JMX export, cache config |
| mvc-core-config.xml | SpringConfig | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) | MVC, conversion service, resources, exception resolver |
| mvc-view-config.xml | SpringConfig | [src/main/resources/spring/mvc-view-config.xml](../../../src/main/resources/spring/mvc-view-config.xml) | Content-negotiating view resolvers |
| data-access.properties | Config | [src/main/resources/spring/data-access.properties](../../../src/main/resources/spring/data-access.properties) | JDBC and JPA settings, Maven-filtered |
| logback.xml | Config | [src/main/resources/logback.xml](../../../src/main/resources/logback.xml) | Logback console logging |
| pom.xml | BuildConfig | [pom.xml](../../../pom.xml) | Maven build, WAR packaging, DB profiles, Jib, Jetty plugin |
| db scripts (schema.sql, data.sql) | SqlScripts | [data-model/database-schemas.md](../data-model/database-schemas.md) | Per-dialect DDL and seed data under db/h2, hsqldb, mysql, postgresql |
| Spring profile jpa | SpringProfile | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) | Default persistence profile |
| Spring profile jdbc | SpringProfile | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) | Spring JDBC repositories |
| Spring profile spring-data-jpa | SpringProfile | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) | Spring Data JPA repositories |
| Spring profile javaee | SpringProfile | [src/main/resources/spring/datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml) | JNDI datasource override |
| Maven database profiles | MavenProfile | [pom.xml](../../../pom.xml) | H2 (default), HSQLDB, MySQL, PostgreSQL select driver, URL, db.script; css profile builds SCSS |
| AbstractClinicServiceTests | Test | [src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java) | Shared service-layer test logic |
| ClinicServiceJdbcTests | Test | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJdbcTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJdbcTests.java) | Pins profile via @ActiveProfiles |
| ClinicServiceJpaTests | Test | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJpaTests.java) | Pins profile via @ActiveProfiles |
| ClinicServiceSpringDataJpaTests | Test | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceSpringDataJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceSpringDataJpaTests.java) | Pins profile via @ActiveProfiles |
| Web controller tests | Test | [src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java) | Owner, Pet, Visit, Vet, Crash controller tests with SpringJUnitWebConfig |
| Model unit tests | Test | [src/test/java/org/springframework/samples/petclinic/model/OwnerTests.java](../../../src/test/java/org/springframework/samples/petclinic/model/OwnerTests.java) | OwnerTests, PetTests, VetTests, ValidatorTests |

## Relationships

| Source | Relationship | Target | Confidence | Evidence |
|---|---|---|---|---|
| OwnerController | DELEGATES_TO | ClinicService | high | [web/OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java); [architecture/petclinic.md](../architecture/petclinic.md) |
| PetController | DELEGATES_TO | ClinicService | high | [web/PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java); [architecture/petclinic.md](../architecture/petclinic.md) |
| VisitController | DELEGATES_TO | ClinicService | high | [web/VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java); [architecture/petclinic.md](../architecture/petclinic.md) |
| VetController | DELEGATES_TO | ClinicService | high | [web/VetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java); [architecture/petclinic.md](../architecture/petclinic.md) |
| ClinicServiceImpl | IMPLEMENTS | ClinicService | high | [service/ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) |
| ClinicServiceImpl | DEPENDS_ON | OwnerRepository | high | [service/ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) |
| ClinicServiceImpl | DEPENDS_ON | PetRepository | high | [service/ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) |
| ClinicServiceImpl | DEPENDS_ON | VetRepository | high | [service/ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) |
| ClinicServiceImpl | DEPENDS_ON | VisitRepository | high | [service/ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java) |
| JpaOwnerRepositoryImpl | IMPLEMENTS | OwnerRepository | high | [repository/jpa/JpaOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java) |
| JpaPetRepositoryImpl | IMPLEMENTS | PetRepository | high | [repository/jpa/JpaPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaPetRepositoryImpl.java) |
| JpaVetRepositoryImpl | IMPLEMENTS | VetRepository | high | [repository/jpa/JpaVetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVetRepositoryImpl.java) |
| JpaVisitRepositoryImpl | IMPLEMENTS | VisitRepository | high | [repository/jpa/JpaVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVisitRepositoryImpl.java) |
| JdbcOwnerRepositoryImpl | IMPLEMENTS | OwnerRepository | high | [repository/jdbc/JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) |
| JdbcPetRepositoryImpl | IMPLEMENTS | PetRepository | high | [repository/jdbc/JdbcPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java) |
| JdbcVetRepositoryImpl | IMPLEMENTS | VetRepository | high | [repository/jdbc/JdbcVetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVetRepositoryImpl.java) |
| JdbcVisitRepositoryImpl | IMPLEMENTS | VisitRepository | high | [repository/jdbc/JdbcVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java) |
| SpringDataOwnerRepository | EXTENDS | OwnerRepository | high | [repository/springdatajpa/SpringDataOwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java) |
| SpringDataPetRepository | EXTENDS | PetRepository | high | [repository/springdatajpa/SpringDataPetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataPetRepository.java) |
| SpringDataVetRepository | EXTENDS | VetRepository | high | [repository/springdatajpa/SpringDataVetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataVetRepository.java) |
| SpringDataVisitRepository | EXTENDS | VisitRepository | high | [repository/springdatajpa/SpringDataVisitRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataVisitRepository.java) |
| Spring profile jpa | ACTIVATES | JpaOwnerRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile jpa | ACTIVATES | JpaPetRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile jpa | ACTIVATES | JpaVetRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile jpa | ACTIVATES | JpaVisitRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile jdbc | ACTIVATES | JdbcOwnerRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile jdbc | ACTIVATES | JdbcPetRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile jdbc | ACTIVATES | JdbcVetRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile jdbc | ACTIVATES | JdbcVisitRepositoryImpl | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile spring-data-jpa | ACTIVATES | SpringDataOwnerRepository | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile spring-data-jpa | ACTIVATES | SpringDataPetRepository | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile spring-data-jpa | ACTIVATES | SpringDataVetRepository | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| Spring profile spring-data-jpa | ACTIVATES | SpringDataVisitRepository | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| OwnerRepository | MANAGES | Owner | high | [repository/OwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/OwnerRepository.java) |
| PetRepository | MANAGES | Pet | high | [repository/PetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/PetRepository.java) |
| PetRepository | MANAGES | PetType | high | [repository/PetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/PetRepository.java) |
| VisitRepository | MANAGES | Visit | high | [repository/VisitRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/VisitRepository.java) |
| VetRepository | MANAGES | Vet | high | [repository/VetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/VetRepository.java) |
| JdbcPetRepositoryImpl | DEPENDS_ON | OwnerRepository | high | [repository/jdbc/JdbcPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java); [architecture/petclinic.md](../architecture/petclinic.md) |
| JdbcOwnerRepositoryImpl | USES | JdbcPetVisitExtractor | high | [repository/jdbc/JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) |
| JdbcPetVisitExtractor | EXTENDS | OneToManyResultSetExtractor | high | [repository/jdbc/JdbcPetVisitExtractor.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetVisitExtractor.java) |
| JdbcOwnerRepositoryImpl | USES | EntityUtils | high | [repository/jdbc/JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) |
| JdbcPetRepositoryImpl | USES | EntityUtils | high | [repository/jdbc/JdbcPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JpaOwnerRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jpa/JpaOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JpaPetRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jpa/JpaPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaPetRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JpaVetRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jpa/JpaVetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVetRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JpaVisitRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jpa/JpaVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVisitRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JdbcOwnerRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jdbc/JdbcOwnerRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JdbcPetRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jdbc/JdbcPetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JdbcVetRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jdbc/JdbcVetRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVetRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | JdbcVisitRepositoryImpl | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java); [repository/jdbc/JdbcVisitRepositoryImpl.java](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java) |
| CallMonitoringAspect | ADVISES | SpringDataOwnerRepository | low | [architecture/petclinic.md](../architecture/petclinic.md); [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| CallMonitoringAspect | ADVISES | SpringDataPetRepository | low | [architecture/petclinic.md](../architecture/petclinic.md); [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| CallMonitoringAspect | ADVISES | SpringDataVetRepository | low | [architecture/petclinic.md](../architecture/petclinic.md); [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| CallMonitoringAspect | ADVISES | SpringDataVisitRepository | low | [architecture/petclinic.md](../architecture/petclinic.md); [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| ClinicServiceImpl | USES | cacheManager | high | [service/ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java); [src/main/resources/spring/tools-config.xml](../../../src/main/resources/spring/tools-config.xml) |
| PetController | USES | PetValidator | high | [web/PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java) |
| PetTypeFormatter | DEPENDS_ON | ClinicService | high | [web/PetTypeFormatter.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java) |
| mvc-core-config.xml | REGISTERS | PetTypeFormatter | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| mvc-core-config.xml | REGISTERS | SimpleMappingExceptionResolver | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| mvc-core-config.xml | IMPORTS | mvc-view-config.xml | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| mvc-core-config.xml | SCANS | OwnerController | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| mvc-core-config.xml | SCANS | PetController | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| mvc-core-config.xml | SCANS | VisitController | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| mvc-core-config.xml | SCANS | VetController | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| mvc-core-config.xml | SCANS | CrashController | high | [src/main/resources/spring/mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml) |
| PetclinicInitializer | LOADS | business-config.xml | high | [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) |
| PetclinicInitializer | LOADS | tools-config.xml | high | [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) |
| PetclinicInitializer | LOADS | mvc-core-config.xml | high | [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) |
| PetclinicInitializer | SETS_DEFAULT | Spring profile jpa | high | [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) |
| business-config.xml | IMPORTS | datasource-config.xml | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| tools-config.xml | DECLARES | cacheManager | high | [src/main/resources/spring/tools-config.xml](../../../src/main/resources/spring/tools-config.xml) |
| tools-config.xml | ENABLES | CallMonitoringAspect | high | [src/main/resources/spring/tools-config.xml](../../../src/main/resources/spring/tools-config.xml) |
| datasource-config.xml | INITIALIZES | db scripts (schema.sql, data.sql) | high | [src/main/resources/spring/datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml); [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| datasource-config.xml | READS | data-access.properties | medium | [runtime-operations/spring-framework-petclinic.md](../runtime-operations/spring-framework-petclinic.md) |
| datasource-config.xml | DECLARES | Spring profile javaee | high | [runtime-operations/spring-framework-petclinic.md](../runtime-operations/spring-framework-petclinic.md) |
| pom.xml | FILTERS | data-access.properties | high | [runtime-operations/spring-framework-petclinic.md](../runtime-operations/spring-framework-petclinic.md); [pom.xml](../../../pom.xml) |
| pom.xml | DEFINES | Maven database profiles | high | [pom.xml](../../../pom.xml) |
| Maven database profiles | SELECTS_SCRIPTS | db scripts (schema.sql, data.sql) | high | [pom.xml](../../../pom.xml); [src/main/resources/spring/data-access.properties](../../../src/main/resources/spring/data-access.properties) |
| business-config.xml | DEFINES | Spring profile jpa | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| business-config.xml | DEFINES | Spring profile jdbc | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| business-config.xml | DEFINES | Spring profile spring-data-jpa | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| db scripts (schema.sql, data.sql) | CREATES | owners (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| db scripts (schema.sql, data.sql) | CREATES | pets (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| db scripts (schema.sql, data.sql) | CREATES | visits (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| db scripts (schema.sql, data.sql) | CREATES | vets (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| db scripts (schema.sql, data.sql) | CREATES | types (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| db scripts (schema.sql, data.sql) | CREATES | specialties (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| db scripts (schema.sql, data.sql) | CREATES | vet_specialties (table) | high | [src/main/resources/db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql) |
| ClinicServiceJdbcTests | EXTENDS | AbstractClinicServiceTests | high | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJdbcTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJdbcTests.java) |
| ClinicServiceJpaTests | EXTENDS | AbstractClinicServiceTests | high | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJpaTests.java) |
| ClinicServiceSpringDataJpaTests | EXTENDS | AbstractClinicServiceTests | high | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceSpringDataJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceSpringDataJpaTests.java) |
| AbstractClinicServiceTests | TESTS | ClinicService | high | [src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java) |
| ClinicServiceJdbcTests | PINS_PROFILE | Spring profile jdbc | high | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJdbcTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJdbcTests.java) |
| ClinicServiceJpaTests | PINS_PROFILE | Spring profile jpa | high | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJpaTests.java) |
| ClinicServiceSpringDataJpaTests | PINS_PROFILE | Spring profile spring-data-jpa | high | [src/test/java/org/springframework/samples/petclinic/service/ClinicServiceSpringDataJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceSpringDataJpaTests.java) |
| Web controller tests | TESTS | OwnerController | high | [src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java) |
| Web controller tests | TESTS | PetController | high | [src/test/java/org/springframework/samples/petclinic/web/PetControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/PetControllerTests.java) |
| Web controller tests | TESTS | VisitController | high | [src/test/java/org/springframework/samples/petclinic/web/VisitControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/VisitControllerTests.java) |
| Web controller tests | TESTS | VetController | high | [src/test/java/org/springframework/samples/petclinic/web/VetControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/VetControllerTests.java) |
| Web controller tests | TESTS | CrashController | high | [src/test/java/org/springframework/samples/petclinic/web/CrashControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/CrashControllerTests.java) |
| Web controller tests | LOADS | mvc-core-config.xml | high | [src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java) |
| Model unit tests | TESTS | Owner | high | [src/test/java/org/springframework/samples/petclinic/model/OwnerTests.java](../../../src/test/java/org/springframework/samples/petclinic/model/OwnerTests.java) |
| Model unit tests | TESTS | Pet | high | [src/test/java/org/springframework/samples/petclinic/model/PetTests.java](../../../src/test/java/org/springframework/samples/petclinic/model/PetTests.java) |
| Model unit tests | TESTS | Vet | high | [src/test/java/org/springframework/samples/petclinic/model/VetTests.java](../../../src/test/java/org/springframework/samples/petclinic/model/VetTests.java) |
| Spring profile spring-data-jpa | REUSES_CONFIG_OF | Spring profile jpa | high | [src/main/resources/spring/business-config.xml](../../../src/main/resources/spring/business-config.xml) |
| CallMonitoringAspect | EXPORTS | CallMonitor MBean | high | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java) |
| datasource-config.xml | CONNECTS_TO | Relational database | high | [src/main/resources/spring/datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml) |
| pom.xml | PRODUCES | petclinic.war | high | [pom.xml](../../../pom.xml) |
| pom.xml | PRODUCES | Docker image (Jib) | high | [pom.xml](../../../pom.xml) |

## Gaps in this domain

- `JdbcPetRepositoryImpl` depends on `OwnerRepository` (same-layer sideways dependency noted in [architecture/index.md](../architecture/index.md)); not a cycle.
- `CallMonitoringAspect` coverage of Spring Data repositories is LOW and unverified without running the app.
- `ClinicService` is a single wide facade over four aggregates (coupling note in the architecture extraction).
- The `javaee` profile override of `dataSource` was not verified ([risk-gap/operations.md](../risk-gap/operations.md), RISK-021).

## Related

[knowledge-graph/index.md](./index.md), [architecture/index.md](../architecture/index.md), [repository/index.md](../repository/index.md)

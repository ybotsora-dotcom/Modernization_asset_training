---
tags:
  - extraction
  - knowledge-graph
---

# Knowledge Graph: Experience and Integration

Back to [knowledge-graph/index.md](./index.md). Screens, navigation, integration contracts, external systems and data flows.

**Counts**: 39 entities, 104 relationships (source in this domain). Confidence: high 101, medium 3, low 0.

Relationships whose source is a screen, contract or flow. Flow entities summarise the 13 flows in [data-flow/index.md](../data-flow/index.md); the 11 contracts come from [integrations/index.md](../integrations/index.md). No outbound service calls exist; the relational database is the only external system.

## Diagram

**Legend.** Node label = `Type: Name`. Solid arrow = HIGH confidence (explicit code or config evidence). Dashed arrow = MEDIUM (inferred or not run-time verified). Dotted line (no arrowhead, label ends `low`) = LOW (speculative).

```mermaid
graph LR
    n0["Actor: Web browser"]
    n1["UIComponent: Main Menu"]
    n2["Screen: Find Owners screen"]
    n3["Screen: Owners List screen"]
    n4["Screen: Owner Details screen"]
    n5["Screen: Owner Form screen"]
    n6["Screen: Pet Form screen"]
    n7["Screen: Visit Form screen"]
    n8["Screen: Veterinarians List screen"]
    n9["Screen: Error screen"]
    n10["Controller: OwnerController"]
    n11["Controller: PetController"]
    n12["Controller: VisitController"]
    n13["Controller: VetController"]
    n14["Controller: CrashController"]
    n15["IntegrationContract: Vets web and data contract"]
    n16["IntegrationContract: JMX call-monitor contract"]
    n17["MBean: CallMonitor MBean"]
    n18["Actor: JMX client"]
    n19["DataFlow: Add visit flow"]
    n0 -->|"REQUESTS"| n1
    n1 -->|"NAVIGATES_TO"| n2
    n1 -->|"NAVIGATES_TO"| n8
    n1 -->|"NAVIGATES_TO"| n9
    n2 -->|"NAVIGATES_TO"| n3
    n2 -->|"NAVIGATES_TO"| n4
    n2 -->|"NAVIGATES_TO"| n5
    n3 -->|"NAVIGATES_TO"| n4
    n4 -->|"NAVIGATES_TO"| n6
    n4 -->|"NAVIGATES_TO"| n7
    n4 -->|"NAVIGATES_TO"| n5
    n2 -->|"HANDLED_BY"| n10
    n6 -->|"HANDLED_BY"| n11
    n7 -->|"HANDLED_BY"| n12
    n8 -->|"HANDLED_BY"| n13
    n9 -->|"HANDLED_BY"| n14
    n15 -->|"PROVIDED_BY"| n13
    n16 -->|"PROVIDED_BY"| n17
    n16 -->|"CONSUMED_BY"| n18
    n19 -->|"INVOLVES"| n12
```

## Entities

| Entity | Type | Primary location | Role |
|---|---|---|---|
| Web browser | Actor | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Sole UI client of the server-rendered pages |
| JMX client | Actor | [integrations/petclinic-data.md](../integrations/petclinic-data.md) | Reads the CallMonitor MBean |
| Relational database | ExternalSystem | [integrations/petclinic-data.md](../integrations/petclinic-data.md) | H2, HSQLDB, MySQL or PostgreSQL via JDBC; only external dependency |
| JNDI datasource | ExternalSystem | [integrations/petclinic-data.md](../integrations/petclinic-data.md) | java:comp/env/jdbc/petclinic under the javaee profile |
| CallMonitor MBean | MBean | [util/CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java) | petclinic:type=CallMonitor |
| Main Menu | UIComponent | [ui-ux/navigation.md](../ui-ux/navigation.md) | menu.tag with four entries |
| Welcome screen | Screen | [ui-ux/shell-and-vets.md](../ui-ux/shell-and-vets.md) | Route GET / |
| Find Owners screen | Screen | [ui-ux/owners.md](../ui-ux/owners.md) | Route GET /owners/find |
| Owners List screen | Screen | [ui-ux/owners.md](../ui-ux/owners.md) | Route GET /owners |
| Owner Details screen | Screen | [ui-ux/owners.md](../ui-ux/owners.md) | Route GET /owners/{id} |
| Owner Form screen | Screen | [ui-ux/owners.md](../ui-ux/owners.md) | Route /owners/new, /owners/{id}/edit |
| Pet Form screen | Screen | [ui-ux/pets-visits.md](../ui-ux/pets-visits.md) | Route /owners/{id}/pets/new, .../{petId}/edit |
| Visit Form screen | Screen | [ui-ux/pets-visits.md](../ui-ux/pets-visits.md) | Route .../visits/new |
| Veterinarians List screen | Screen | [ui-ux/shell-and-vets.md](../ui-ux/shell-and-vets.md) | Route GET /vets |
| Error screen | Screen | [ui-ux/shell-and-vets.md](../ui-ux/shell-and-vets.md) | Route GET /oups |
| Owners web contract | IntegrationContract | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Provider OwnerController; consumer Web browser |
| Pets web contract | IntegrationContract | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Provider PetController; consumer Web browser |
| Visits web contract | IntegrationContract | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Provider VisitController; consumer Web browser |
| Vets web and data contract | IntegrationContract | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Provider VetController; consumer Web browser |
| Welcome and error-demo contract | IntegrationContract | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Provider CrashController; consumer Web browser |
| Static resources contract | IntegrationContract | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Provider mvc-core-config.xml; consumer Web browser |
| Multi-backend relational data contract | IntegrationContract | [integrations/petclinic-data.md](../integrations/petclinic-data.md) | Provider Relational database; consumer Spring profile jpa |
| JNDI datasource contract | IntegrationContract | [integrations/petclinic-data.md](../integrations/petclinic-data.md) | Provider JNDI datasource; consumer datasource-config.xml |
| Schema and seed SQL contract | IntegrationContract | [integrations/petclinic-data.md](../integrations/petclinic-data.md) | Provider db scripts (schema.sql, data.sql); consumer datasource-config.xml |
| Vets cache contract | IntegrationContract | [integrations/petclinic-api.md](../integrations/petclinic-api.md) | Provider cacheManager; consumer ClinicServiceImpl |
| JMX call-monitor contract | IntegrationContract | [integrations/petclinic-data.md](../integrations/petclinic-data.md) | Provider CallMonitor MBean; consumer JMX client |
| Create owner flow | DataFlow | [data-flow/owner-flows.md](../data-flow/owner-flows.md) | Synchronous HTTP/config flow; confidence high |
| Update owner flow | DataFlow | [data-flow/owner-flows.md](../data-flow/owner-flows.md) | Synchronous HTTP/config flow; confidence high |
| Find owners flow | DataFlow | [data-flow/owner-flows.md](../data-flow/owner-flows.md) | Synchronous HTTP/config flow; confidence high |
| Show owner flow | DataFlow | [data-flow/owner-flows.md](../data-flow/owner-flows.md) | Synchronous HTTP/config flow; confidence high |
| Pet form preparation flow | DataFlow | [data-flow/pet-flows.md](../data-flow/pet-flows.md) | Synchronous HTTP/config flow; confidence high |
| Create or update pet flow | DataFlow | [data-flow/pet-flows.md](../data-flow/pet-flows.md) | Synchronous HTTP/config flow; confidence high |
| Add visit flow | DataFlow | [data-flow/visit-flows.md](../data-flow/visit-flows.md) | Synchronous HTTP/config flow; confidence high |
| Show visit history flow | DataFlow | [data-flow/visit-flows.md](../data-flow/visit-flows.md) | Synchronous HTTP/config flow; confidence high |
| Vet list flow | DataFlow | [data-flow/vet-flows.md](../data-flow/vet-flows.md) | Synchronous HTTP/config flow; confidence high |
| Startup database initialization flow | DataFlow | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) | Synchronous HTTP/config flow; confidence high |
| Persistence profile switching flow | DataFlow | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) | Synchronous HTTP/config flow; confidence high |
| Repository call monitoring flow | DataFlow | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) | Synchronous HTTP/config flow; confidence high |
| Error handling flow | DataFlow | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) | Synchronous HTTP/config flow; confidence medium |

## Relationships

| Source | Relationship | Target | Confidence | Evidence |
|---|---|---|---|---|
| Main Menu | NAVIGATES_TO | Welcome screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Main Menu | NAVIGATES_TO | Find Owners screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Main Menu | NAVIGATES_TO | Veterinarians List screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Main Menu | NAVIGATES_TO | Error screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Find Owners screen | NAVIGATES_TO | Owners List screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Find Owners screen | NAVIGATES_TO | Owner Details screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Find Owners screen | NAVIGATES_TO | Owner Form screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Owners List screen | NAVIGATES_TO | Owner Details screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Owner Details screen | NAVIGATES_TO | Owner Form screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Owner Details screen | NAVIGATES_TO | Pet Form screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Owner Details screen | NAVIGATES_TO | Visit Form screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Owner Form screen | NAVIGATES_TO | Owner Details screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Pet Form screen | NAVIGATES_TO | Owner Details screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Visit Form screen | NAVIGATES_TO | Owner Details screen | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Find Owners screen | HANDLED_BY | OwnerController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owners List screen | HANDLED_BY | OwnerController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owner Details screen | HANDLED_BY | OwnerController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owner Form screen | HANDLED_BY | OwnerController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Pet Form screen | HANDLED_BY | PetController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Visit Form screen | HANDLED_BY | VisitController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Veterinarians List screen | HANDLED_BY | VetController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Error screen | HANDLED_BY | CrashController | high | [ui-ux/index.md](../ui-ux/index.md) |
| Error screen | HANDLED_BY | SimpleMappingExceptionResolver | high | [ui-ux/index.md](../ui-ux/index.md) |
| Welcome screen | HANDLED_BY | mvc-core-config.xml | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owner Details screen | DISPLAYS | Owner | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owner Details screen | DISPLAYS | Pet | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owner Details screen | DISPLAYS | Visit | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owners List screen | DISPLAYS | Owner | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owner Form screen | EDITS | Owner | high | [ui-ux/index.md](../ui-ux/index.md) |
| Pet Form screen | EDITS | Pet | high | [ui-ux/index.md](../ui-ux/index.md) |
| Pet Form screen | DISPLAYS | PetType | high | [ui-ux/index.md](../ui-ux/index.md) |
| Visit Form screen | EDITS | Visit | high | [ui-ux/index.md](../ui-ux/index.md) |
| Veterinarians List screen | DISPLAYS | Vet | high | [ui-ux/index.md](../ui-ux/index.md) |
| Veterinarians List screen | DISPLAYS | Specialty | high | [ui-ux/index.md](../ui-ux/index.md) |
| Owners web contract | PROVIDED_BY | OwnerController | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Owners web contract | CONSUMED_BY | Web browser | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Pets web contract | PROVIDED_BY | PetController | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Pets web contract | CONSUMED_BY | Web browser | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Visits web contract | PROVIDED_BY | VisitController | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Visits web contract | CONSUMED_BY | Web browser | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Vets web and data contract | PROVIDED_BY | VetController | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Vets web and data contract | CONSUMED_BY | Web browser | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Welcome and error-demo contract | PROVIDED_BY | CrashController | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Welcome and error-demo contract | CONSUMED_BY | Web browser | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Static resources contract | PROVIDED_BY | mvc-core-config.xml | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Static resources contract | CONSUMED_BY | Web browser | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Multi-backend relational data contract | PROVIDED_BY | Relational database | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| Multi-backend relational data contract | CONSUMED_BY | Spring profile jpa | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| JNDI datasource contract | PROVIDED_BY | JNDI datasource | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| JNDI datasource contract | CONSUMED_BY | datasource-config.xml | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| Schema and seed SQL contract | PROVIDED_BY | db scripts (schema.sql, data.sql) | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| Schema and seed SQL contract | CONSUMED_BY | datasource-config.xml | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| Vets cache contract | PROVIDED_BY | cacheManager | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| Vets cache contract | CONSUMED_BY | ClinicServiceImpl | high | [integrations/petclinic-api.md](../integrations/petclinic-api.md) |
| JMX call-monitor contract | PROVIDED_BY | CallMonitor MBean | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| JMX call-monitor contract | CONSUMED_BY | JMX client | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| Multi-backend relational data contract | CONSUMED_BY | Spring profile jdbc | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| Multi-backend relational data contract | CONSUMED_BY | Spring profile spring-data-jpa | high | [integrations/petclinic-data.md](../integrations/petclinic-data.md) |
| Web browser | REQUESTS | Main Menu | high | [ui-ux/navigation.md](../ui-ux/navigation.md) |
| Create owner flow | INVOLVES | OwnerController | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Create owner flow | INVOLVES | ClinicServiceImpl | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Create owner flow | INVOLVES | OwnerRepository | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Create owner flow | WRITES_TO | owners (table) | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Update owner flow | INVOLVES | OwnerController | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Update owner flow | INVOLVES | ClinicServiceImpl | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Update owner flow | INVOLVES | OwnerRepository | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Update owner flow | WRITES_TO | owners (table) | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Find owners flow | INVOLVES | OwnerController | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Find owners flow | INVOLVES | OwnerRepository | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Find owners flow | INVOLVES | JdbcPetVisitExtractor | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Find owners flow | READS_FROM | owners (table) | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Show owner flow | INVOLVES | OwnerController | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Show owner flow | INVOLVES | OwnerRepository | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Show owner flow | READS_FROM | owners (table) | high | [data-flow/owner-flows.md](../data-flow/owner-flows.md) |
| Pet form preparation flow | INVOLVES | PetController | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Pet form preparation flow | INVOLVES | PetRepository | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Pet form preparation flow | READS_FROM | types (table) | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Create or update pet flow | INVOLVES | PetController | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Create or update pet flow | INVOLVES | PetValidator | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Create or update pet flow | INVOLVES | PetTypeFormatter | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Create or update pet flow | INVOLVES | PetRepository | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Create or update pet flow | WRITES_TO | pets (table) | high | [data-flow/pet-flows.md](../data-flow/pet-flows.md) |
| Add visit flow | INVOLVES | VisitController | high | [data-flow/visit-flows.md](../data-flow/visit-flows.md) |
| Add visit flow | INVOLVES | VisitRepository | high | [data-flow/visit-flows.md](../data-flow/visit-flows.md) |
| Add visit flow | INVOLVES | Visit | high | [data-flow/visit-flows.md](../data-flow/visit-flows.md) |
| Add visit flow | WRITES_TO | visits (table) | high | [data-flow/visit-flows.md](../data-flow/visit-flows.md) |
| Show visit history flow | INVOLVES | VisitController | high | [data-flow/visit-flows.md](../data-flow/visit-flows.md) |
| Show visit history flow | INVOLVES | PetRepository | high | [data-flow/visit-flows.md](../data-flow/visit-flows.md) |
| Show visit history flow | READS_FROM | visits (table) | high | [data-flow/visit-flows.md](../data-flow/visit-flows.md) |
| Vet list flow | INVOLVES | VetController | high | [data-flow/vet-flows.md](../data-flow/vet-flows.md) |
| Vet list flow | INVOLVES | VetRepository | high | [data-flow/vet-flows.md](../data-flow/vet-flows.md) |
| Vet list flow | INVOLVES | cacheManager | high | [data-flow/vet-flows.md](../data-flow/vet-flows.md) |
| Vet list flow | INVOLVES | Vets | high | [data-flow/vet-flows.md](../data-flow/vet-flows.md) |
| Vet list flow | READS_FROM | vets (table) | high | [data-flow/vet-flows.md](../data-flow/vet-flows.md) |
| Startup database initialization flow | INVOLVES | datasource-config.xml | high | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Startup database initialization flow | INVOLVES | db scripts (schema.sql, data.sql) | high | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Startup database initialization flow | WRITES_TO | Relational database | high | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Persistence profile switching flow | INVOLVES | business-config.xml | high | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Persistence profile switching flow | INVOLVES | PetclinicInitializer | high | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Repository call monitoring flow | INVOLVES | CallMonitoringAspect | high | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Repository call monitoring flow | INVOLVES | tools-config.xml | high | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Error handling flow | INVOLVES | SimpleMappingExceptionResolver | medium | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Error handling flow | INVOLVES | mvc-core-config.xml | medium | [data-flow/infrastructure-flows.md](../data-flow/infrastructure-flows.md) |
| Vet list flow | READS_FROM | specialties (table) | medium | [data-flow/vet-flows.md](../data-flow/vet-flows.md) |

## Gaps in this domain

- Flow bodies for JSP views, `CrashController` and `JdbcPetVisitExtractor` were not fully read by the data-flow extraction, so those flow edges carry only what its summary states.
- `GET /owners/*/pets/{petId}/visits` maps to view `visitList`, which has no template; not a screen in the graph (RISK-011).
- Screens cite only an "Owner Details" hub for Owner/Pet/Visit display; i18n bundles are not used by the JSPs except the welcome heading.

## Related

[knowledge-graph/index.md](./index.md), [ui-ux/index.md](../ui-ux/index.md), [integrations/index.md](../integrations/index.md), [data-flow/index.md](../data-flow/index.md), [functional/index.md](../functional/index.md)

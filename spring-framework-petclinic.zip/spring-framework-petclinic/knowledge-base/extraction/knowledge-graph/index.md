---
tags:
  - extraction
  - knowledge-graph
---

# Knowledge Graph: Overview

Graph of the single-module Spring Petclinic WAR (Spring Framework 7, XML configuration) built from every extraction folder. Static analysis only; nothing was built or run.

## Summary

- **Entities**: 207. **Relationships**: 511 (every entity has at least one relationship; no isolated nodes).
- **Confidence distribution**: high 453, medium 54, low 4.
- **Domain files** (hard limit 500 lines each): [domain-model.md](./domain-model.md), [application-architecture.md](./application-architecture.md), [experience-integration.md](./experience-integration.md), [business-rules-capabilities.md](./business-rules-capabilities.md), [governance-risk-operations.md](./governance-risk-operations.md).
- **Entity types**: BusinessRule 40, Risk 21, BusinessCapability 15, DataFlow 13, RepositoryImpl 12, IntegrationContract 11, Screen 9, SecurityFinding 9, Table 7, Entity 6, Test 6, Controller 5, SpringConfig 5, BusinessDomain 5, RepositoryInterface 4, SpringProfile 4, MappedSuperclass 3, Persona 3, JdbcHelper 2, Config 2, Actor 2, ExternalSystem 2, Artifact 2, JAXBWrapper 1, Bootstrap 1, Validator 1, Formatter 1, ServiceInterface 1, Service 1, Utility 1, Aspect 1, CacheManager 1, ExceptionResolver 1, BuildConfig 1, SqlScripts 1, MavenProfile 1, MBean 1, UIComponent 1, Application 1, Runtime 1, CI 1, Harness 1.

### Key findings

- Layered monolith: controllers delegate only to `ClinicService`; `ClinicServiceImpl` depends only on the four repository interfaces (HIGH).
- Every repository interface has three implementations (JPA, JDBC, Spring Data JPA); a Spring profile activates one set, default `jpa` set in `PetclinicInitializer` (HIGH). The Maven database profile is an independent axis.
- `Owner` 1..* `Pet` 1..* `Visit`; `Pet` references `PetType`; `Vet` *..* `Specialty` through `vet_specialties`. `Visit` has no link to `Vet` (VIS-002, VET-005).
- No authentication, authorization or CSRF protection (RISK-001, RISK-002); owner personal data is open to anonymous users.
- No rule engine, no messaging, no outbound services and no product AI. The relational database is the only external system; the only AI artifact is the developer harness (CLAUDE.md).
- No circular dependencies were found between components. The only sideways link is `JdbcPetRepositoryImpl` -> `OwnerRepository`.

## System diagram

**Legend.** Node label = `Type: Name`. Solid arrow = HIGH confidence (explicit code or config evidence). Dashed arrow = MEDIUM (inferred or not run-time verified). Dotted line (no arrowhead, label ends `low`) = LOW (speculative).

This overview shows the request path for the owner aggregate only; the Pet, Visit and Vet repositories follow the same three-implementation pattern (see [application-architecture.md](./application-architecture.md)).

```mermaid
graph LR
    n0["Actor: Web browser"]
    n1["UIComponent: Main Menu"]
    n2["Controller: OwnerController"]
    n3["Controller: PetController"]
    n4["Controller: VisitController"]
    n5["Controller: VetController"]
    n6["ServiceInterface: ClinicService"]
    n7["Service: ClinicServiceImpl"]
    n8["RepositoryInterface: OwnerRepository"]
    n9["RepositoryInterface: PetRepository"]
    n10["RepositoryInterface: VisitRepository"]
    n11["RepositoryInterface: VetRepository"]
    n12["SpringProfile: Spring profile jpa"]
    n13["SpringProfile: Spring profile jdbc"]
    n14["SpringProfile: Spring profile spring-data-jpa"]
    n15["RepositoryImpl: JpaOwnerRepositoryImpl"]
    n16["RepositoryImpl: JdbcOwnerRepositoryImpl"]
    n17["RepositoryImpl: SpringDataOwnerRepository"]
    n18["Aspect: CallMonitoringAspect"]
    n19["CacheManager: cacheManager"]
    n20["ExternalSystem: Relational database"]
    n21["SpringConfig: datasource-config.xml"]
    n22["Entity: Owner"]
    n23["Entity: Pet"]
    n24["Entity: Visit"]
    n25["MBean: CallMonitor MBean"]
    n0 -->|"REQUESTS"| n1
    n2 -->|"DELEGATES_TO"| n6
    n3 -->|"DELEGATES_TO"| n6
    n4 -->|"DELEGATES_TO"| n6
    n5 -->|"DELEGATES_TO"| n6
    n7 -->|"IMPLEMENTS"| n6
    n7 -->|"DEPENDS_ON"| n8
    n7 -->|"DEPENDS_ON"| n9
    n7 -->|"DEPENDS_ON"| n10
    n7 -->|"DEPENDS_ON"| n11
    n15 -->|"IMPLEMENTS"| n8
    n16 -->|"IMPLEMENTS"| n8
    n17 -->|"EXTENDS"| n8
    n12 -->|"ACTIVATES"| n15
    n13 -->|"ACTIVATES"| n16
    n14 -->|"ACTIVATES"| n17
    n18 -->|"ADVISES"| n15
    n18 -.-|"ADVISES low"| n17
    n18 -->|"EXPORTS"| n25
    n7 -->|"USES"| n19
    n21 -->|"CONNECTS_TO"| n20
    n22 -->|"HAS_MANY"| n23
    n23 -->|"HAS_MANY"| n24
```

## Counts by domain

| Domain file | Entities | Relationships | High | Medium | Low |
|---|---|---|---|---|---|
| [domain-model.md](./domain-model.md) | 17 | 27 | 27 | 0 | 0 |
| [application-architecture.md](./application-architecture.md) | 52 | 110 | 105 | 1 | 4 |
| [experience-integration.md](./experience-integration.md) | 39 | 104 | 101 | 3 | 0 |
| [business-rules-capabilities.md](./business-rules-capabilities.md) | 63 | 181 | 146 | 35 | 0 |
| [governance-risk-operations.md](./governance-risk-operations.md) | 36 | 89 | 74 | 15 | 0 |
| Total | 207 | 511 | 453 | 54 | 4 |

Relationships are counted in the domain of their source entity. Cross-domain edges (source domain to target domain): application-architecture to domain-model: 15; application-architecture to experience-integration: 2; application-architecture to governance-risk-operations: 2; business-rules-capabilities to application-architecture: 44; business-rules-capabilities to domain-model: 85; experience-integration to application-architecture: 56; experience-integration to domain-model: 22; governance-risk-operations to application-architecture: 54; governance-risk-operations to business-rules-capabilities: 16; governance-risk-operations to domain-model: 4; governance-risk-operations to experience-integration: 2.

## Extraction traceability

Each extraction folder contributes entities that appear in the domain files:

| Extraction folder | Entities contributed | Graph domain file |
|---|---|---|
| [repository/index.md](../repository/index.md) | spring-framework-petclinic, pom.xml, petclinic.war, Docker image (Jib), GitHub Actions workflows, PetclinicInitializer | governance-risk-operations |
| [architecture/index.md](../architecture/index.md) | controllers, ClinicService, repositories (3 implementations), config files, CallMonitoringAspect, cacheManager | application-architecture |
| [functional/index.md](../functional/index.md) | controllers (19 routes), capabilities, Add visit flow routes | application-architecture, business-rules-capabilities |
| [data-model/index.md](../data-model/index.md) | Owner, Pet, PetType, Visit, Vet, Specialty, Vets, tables, foreign keys | domain-model |
| [data-flow/index.md](../data-flow/index.md) | 13 DataFlow entities | experience-integration |
| [integrations/index.md](../integrations/index.md) | 11 IntegrationContract entities, Relational database, JNDI datasource, CallMonitor MBean | experience-integration |
| [ui-ux/index.md](../ui-ux/index.md) | 9 Screen entities, Main Menu, Web browser | experience-integration |
| [business-intent/index.md](../business-intent/index.md) | 5 BusinessDomain, 15 BusinessCapability, 3 Persona | business-rules-capabilities |
| [business-logic-rules/index.md](../business-logic-rules/index.md) | 40 BusinessRule entities (OWN, PET, VIS, VET, PLT) | business-rules-capabilities |
| [security/index.md](../security/index.md) | 9 SecurityFinding entities (SEC-01 to SEC-09) | governance-risk-operations |
| [runtime-operations/index.md](../runtime-operations/index.md) | Servlet container, Spring profiles, Maven database profiles, Docker image, JMX, cacheManager, logback.xml | governance-risk-operations, application-architecture |
| [risk-gap/index.md](../risk-gap/index.md) | 21 Risk entities (RISK-001 to RISK-021) | governance-risk-operations |
| [ai/index.md](../ai/index.md) | ai:harness:claude-code (1 Harness; 0 agents, models, tools, MCP servers, prompts, RAG) | governance-risk-operations |

Also read: [project-profile.json](../project-profile.json) (stack, source layout) for scope. The `.claude/` folder was ignored. No rule-engine mapping file exists by design ([business-logic-rules/index.md](../business-logic-rules/index.md) explains).

## Relationship types

Structural: EXTENDS, IMPLEMENTS, DEPENDS_ON, DELEGATES_TO, USES, MANAGES, HAS_MANY, BELONGS_TO, REFERENCES, ASSOCIATED_WITH, WRAPS, MAPS_TO, FOREIGN_KEY_TO. Wiring: LOADS, IMPORTS, SCANS, REGISTERS, DEFINES, DECLARES, ENABLES, ACTIVATES, SETS_DEFAULT, REUSES_CONFIG_OF, ADVISES, EXPORTS, FILTERS, SELECTS_SCRIPTS, INITIALIZES, CREATES, CONNECTS_TO. Experience: REQUESTS, NAVIGATES_TO, HANDLED_BY, DISPLAYS, EDITS, PROVIDED_BY, CONSUMED_BY, INVOLVES, READS_FROM, WRITES_TO. Business: AFFECTS, ENFORCED_IN, GOVERNED_BY, IMPLEMENTED_BY, INDEPENDENT_OF, CHANGES_BEHAVIOUR_OF, SHARES_LOGIC_WITH, USES. Governance: BUILT_BY, PRODUCES, DEPLOYED_ON, RUNS_ON, BOOTSTRAPS, BUILDS, RAISED_AS, EXPOSES, RELATES_TO, INSTRUCTS, DOCUMENTS, TESTS, PINS_PROFILE, SUPPORTS, CONTAINS.

## Unresolved gaps

- `CallMonitoringAspect` coverage of the Spring Data repositories is LOW: the pointcut matches `@Repository` classes and the Spring Data interfaces are not annotated (inferred, not verified at runtime).
- The `GET /owners/*/pets/{petId}/visits` endpoint targets view `visitList`, which has no template; runtime outcome is unverified (RISK-011, VIS-009).
- Runtime-dependent rules (OWN-009 case sensitivity on MySQL/PostgreSQL, VET-001 Spring Data ordering, OWN-002 `@Digits`) are MEDIUM and unverified; graph edges for them are MEDIUM.
- `entityManagerFactory` sets both `persistenceUnitName` and `packagesToScan`; the effective entity discovery is inferred (no `persistence.xml` found).
- The `javaee` profile JNDI datasource override was not verified (RISK-021).
- Several extraction diagrams or summaries were marked PARTIAL by their authors (data-flow did not read JSP view bodies or CrashController; functional did not read all JSPs); edges derived from them keep the confidence those summaries assign.
- Mermaid syntax validation: all diagrams in this folder were rendered successfully with `mermaid_check.py` (Mermaid CLI with chrome-headless-shell 157.0.8103.50) on 2026-11-11, after the headless browser was installed; they use only plain flowchart syntax and no draw.io-incompatible features.
- AI: `crossRefs` is empty and no sibling item carries an `aiRef`, so there are no AI edges to resolve; the harness node is linked only to the application and the documented profiles.
- Sources disagree on nothing material. Wording differs only in granularity (for example the integrations folder counts 11 contracts, the functional folder 19 routes); both are kept.

## Related extraction

[repository/index.md](../repository/index.md), [architecture/index.md](../architecture/index.md), [functional/index.md](../functional/index.md), [data-model/index.md](../data-model/index.md), [data-flow/index.md](../data-flow/index.md), [integrations/index.md](../integrations/index.md), [ui-ux/index.md](../ui-ux/index.md), [business-intent/index.md](../business-intent/index.md), [business-logic-rules/index.md](../business-logic-rules/index.md), [security/index.md](../security/index.md), [runtime-operations/index.md](../runtime-operations/index.md), [risk-gap/index.md](../risk-gap/index.md), [ai/index.md](../ai/index.md)

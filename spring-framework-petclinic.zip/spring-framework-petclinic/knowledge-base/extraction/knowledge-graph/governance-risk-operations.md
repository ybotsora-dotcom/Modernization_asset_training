---
tags:
  - extraction
  - knowledge-graph
---

# Knowledge Graph: Governance, Risk and Operations

Back to [knowledge-graph/index.md](./index.md). Application, deployment artifacts, security findings, risks and the AI harness.

**Counts**: 36 entities, 89 relationships (source in this domain). Confidence: high 74, medium 15, low 0.

Security findings (SEC-nn) are numbered here for graph traceability, in the order of the security summary's governance risks; each is linked to its risk-gap entry (RISK-nnn). Risks are static-analysis findings, not runtime-verified. The AI extraction found no product AI; only the developer harness exists.

## Diagram

**Legend.** Node label = `Type: Name`. Solid arrow = HIGH confidence (explicit code or config evidence). Dashed arrow = MEDIUM (inferred or not run-time verified). Dotted line (no arrowhead, label ends `low`) = LOW (speculative).

```mermaid
graph LR
    n0["Application: spring-framework-petclinic"]
    n1["BuildConfig: pom.xml"]
    n2["Artifact: petclinic.war"]
    n3["Artifact: Docker image (Jib)"]
    n4["Runtime: Servlet container"]
    n5["CI: GitHub Actions workflows"]
    n6["Harness: ai:harness:claude-code"]
    n7["SecurityFinding: SEC-01"]
    n8["SecurityFinding: SEC-07"]
    n9["SecurityFinding: SEC-09"]
    n10["Risk: RISK-001"]
    n11["Risk: RISK-003"]
    n12["Risk: RISK-011"]
    n13["Risk: RISK-016"]
    n14["Controller: OwnerController"]
    n15["Controller: VisitController"]
    n16["SpringConfig: datasource-config.xml"]
    n17["Entity: Owner"]
    n0 -->|"BUILT_BY"| n1
    n1 -->|"PRODUCES"| n2
    n1 -->|"PRODUCES"| n3
    n2 -->|"DEPLOYED_ON"| n4
    n3 -->|"RUNS_ON"| n4
    n5 -->|"BUILDS"| n1
    n6 -->|"INSTRUCTS"| n0
    n7 -->|"RAISED_AS"| n10
    n8 -->|"RAISED_AS"| n11
    n9 -->|"RAISED_AS"| n13
    n7 -->|"AFFECTS"| n14
    n7 -->|"EXPOSES"| n17
    n7 -->|"AFFECTS"| n1
    n8 -->|"AFFECTS"| n15
    n9 -->|"AFFECTS"| n16
    n10 -->|"AFFECTS"| n14
    n11 -->|"AFFECTS"| n15
    n12 -->|"AFFECTS"| n15
    n13 -->|"AFFECTS"| n16
    n13 -->|"AFFECTS"| n16
```

## Entities

| Entity | Type | Primary location | Role |
|---|---|---|---|
| spring-framework-petclinic | Application | [repository/spring-framework-petclinic.md](../repository/spring-framework-petclinic.md) | Single Maven module, WAR, Spring Framework 7 XML config |
| petclinic.war | Artifact | [pom.xml](../../../pom.xml) | Deployable WAR |
| Docker image (Jib) | Artifact | [pom.xml](../../../pom.xml) | Built by the Jib plugin from base jetty:11.0-jdk17; no Dockerfile |
| Servlet container | Runtime | [runtime-operations/spring-framework-petclinic.md](../runtime-operations/spring-framework-petclinic.md) | Jetty (jetty:run-war) or Tomcat/any Servlet 6 container |
| GitHub Actions workflows | CI | [.github/workflows/maven-build-main.yml](../../../.github/workflows/maven-build-main.yml) | Main and pull-request Maven builds; SonarCloud step on main |
| ai:harness:claude-code | Harness | [ai/index.md](../ai/index.md) | Developer harness configured only by CLAUDE.md; no product AI |
| SEC-01 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | No authentication or authorization; owner PII open to anonymous users |
| SEC-02 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | No CSRF protection on state-changing POSTs (inferred) |
| SEC-03 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | Hardcoded DB credentials in Maven profiles |
| SEC-04 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | No TLS, HSTS, CSP or other security headers |
| SEC-05 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | Unescaped exception message in error view (inferred) |
| SEC-06 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | Pet binder does not disallow id (inferred) |
| SEC-07 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | IDOR: owner/pet relation not verified on pet and visit routes |
| SEC-08 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | jpa.showSql=true and DEBUG logging by default |
| SEC-09 | SecurityFinding | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) | Destructive DB schema re-init at every startup |
| RISK-001 | Risk | [risk-gap/security.md](../risk-gap/security.md) | No authentication or authorization (impact High, likelihood Medium) |
| RISK-002 | Risk | [risk-gap/security.md](../risk-gap/security.md) | No CSRF protection on state-changing POSTs (impact High, likelihood Medium) |
| RISK-003 | Risk | [risk-gap/security.md](../risk-gap/security.md) | Path ids not verified against ownership (IDOR) (impact Medium, likelihood High) |
| RISK-004 | Risk | [risk-gap/security.md](../risk-gap/security.md) | Database credentials committed in pom.xml and readme (impact Medium, likelihood Medium) |
| RISK-005 | Risk | [risk-gap/security.md](../risk-gap/security.md) | No TLS, HSTS, CSP or frame protection (impact Medium, likelihood Medium) |
| RISK-006 | Risk | [risk-gap/security.md](../risk-gap/security.md) | Raw exception.message in error view (impact Medium, likelihood Low) |
| RISK-007 | Risk | [risk-gap/security.md](../risk-gap/security.md) | Pet binder does not disallow id (inferred) (impact Medium, likelihood Medium) |
| RISK-008 | Risk | [risk-gap/security.md](../risk-gap/security.md) | SQL and DEBUG logging on by default (impact Low, likelihood Medium) |
| RISK-009 | Risk | [risk-gap/security.md](../risk-gap/security.md) | Writable JMX MBean (impact Low, likelihood Low) |
| RISK-010 | Risk | [risk-gap/functional-data.md](../risk-gap/functional-data.md) | Unbounded owner list, no rate limiting (impact Low, likelihood Medium) |
| RISK-011 | Risk | [risk-gap/functional-data.md](../risk-gap/functional-data.md) | visitList view missing for visits endpoint (impact Medium, likelihood High) |
| RISK-012 | Risk | [risk-gap/functional-data.md](../risk-gap/functional-data.md) | Pet birth date and visit date not range-checked (impact Medium, likelihood Medium) |
| RISK-013 | Risk | [risk-gap/functional-data.md](../risk-gap/functional-data.md) | Vets cache never evicted, no TTL (impact Low, likelihood Medium) |
| RISK-014 | Risk | [risk-gap/functional-data.md](../risk-gap/functional-data.md) | Behaviour differs silently by Spring and Maven profile (impact Medium, likelihood Medium) |
| RISK-015 | Risk | [risk-gap/functional-data.md](../risk-gap/functional-data.md) | Three parallel persistence implementations (impact Medium, likelihood Medium) |
| RISK-016 | Risk | [risk-gap/operations.md](../risk-gap/operations.md) | Schema scripts DROP tables on every startup (impact High, likelihood Low) |
| RISK-017 | Risk | [risk-gap/operations.md](../risk-gap/operations.md) | No health check, thin metrics, no tracing (impact Low, likelihood Medium) |
| RISK-018 | Risk | [risk-gap/operations.md](../risk-gap/operations.md) | Dependency currency unverified; no audit or SAST in CI (impact Medium, likelihood Medium) |
| RISK-019 | Risk | [risk-gap/security.md](../risk-gap/security.md) | No PII retention, erasure or audit capability (impact Medium, likelihood Low) |
| RISK-020 | Risk | [risk-gap/functional-data.md](../risk-gap/functional-data.md) | Form flow spans several transactions (impact Low, likelihood Low) |
| RISK-021 | Risk | [risk-gap/operations.md](../risk-gap/operations.md) | javaee JNDI datasource override not verified (impact Low, likelihood Low) |

## Relationships

| Source | Relationship | Target | Confidence | Evidence |
|---|---|---|---|---|
| spring-framework-petclinic | CONTAINS | PetclinicInitializer | high | [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java); [repository/index.md](../repository/index.md) |
| spring-framework-petclinic | BUILT_BY | pom.xml | high | [repository/index.md](../repository/index.md) |
| petclinic.war | DEPLOYED_ON | Servlet container | high | [runtime-operations/index.md](../runtime-operations/index.md) |
| Docker image (Jib) | RUNS_ON | Servlet container | high | [pom.xml](../../../pom.xml); [runtime-operations/index.md](../runtime-operations/index.md) |
| Servlet container | BOOTSTRAPS | PetclinicInitializer | medium | [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) |
| GitHub Actions workflows | BUILDS | pom.xml | high | [.github/workflows/maven-build-main.yml](../../../.github/workflows/maven-build-main.yml) |
| ai:harness:claude-code | INSTRUCTS | spring-framework-petclinic | high | [ai/index.md](../ai/index.md); [CLAUDE.md](../../../CLAUDE.md) |
| ai:harness:claude-code | DOCUMENTS | Spring profile jpa | high | [ai/index.md](../ai/index.md); [CLAUDE.md](../../../CLAUDE.md) |
| ai:harness:claude-code | DOCUMENTS | Spring profile jdbc | high | [ai/index.md](../ai/index.md); [CLAUDE.md](../../../CLAUDE.md) |
| ai:harness:claude-code | DOCUMENTS | Spring profile spring-data-jpa | high | [ai/index.md](../ai/index.md); [CLAUDE.md](../../../CLAUDE.md) |
| spring-framework-petclinic | SUPPORTS | Owners domain | high | [business-intent/index.md](../business-intent/index.md) |
| spring-framework-petclinic | SUPPORTS | Pets domain | high | [business-intent/index.md](../business-intent/index.md) |
| spring-framework-petclinic | SUPPORTS | Visits domain | high | [business-intent/index.md](../business-intent/index.md) |
| spring-framework-petclinic | SUPPORTS | Vets domain | high | [business-intent/index.md](../business-intent/index.md) |
| spring-framework-petclinic | SUPPORTS | Platform domain | high | [business-intent/index.md](../business-intent/index.md) |
| SEC-01 | RAISED_AS | RISK-001 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-01 | AFFECTS | OwnerController | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-01 | AFFECTS | pom.xml | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-02 | RAISED_AS | RISK-002 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-02 | AFFECTS | PetclinicInitializer | medium | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-03 | RAISED_AS | RISK-004 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-03 | AFFECTS | pom.xml | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-04 | RAISED_AS | RISK-005 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-04 | AFFECTS | pom.xml | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-05 | RAISED_AS | RISK-006 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-05 | AFFECTS | Error screen | medium | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-06 | RAISED_AS | RISK-007 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-06 | AFFECTS | PetController | medium | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-07 | RAISED_AS | RISK-003 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-07 | AFFECTS | VisitController | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-08 | RAISED_AS | RISK-008 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-08 | AFFECTS | data-access.properties | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-08 | AFFECTS | logback.xml | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-09 | RAISED_AS | RISK-016 | high | [risk-gap/security.md](../risk-gap/security.md); [security/index.md](../security/index.md) |
| SEC-09 | AFFECTS | datasource-config.xml | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-01 | EXPOSES | Owner | high | [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md) |
| SEC-01 | EXPOSES | Visit | medium | [security/index.md](../security/index.md) |
| RISK-001 | AFFECTS | OwnerController | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-001 | AFFECTS | PetController | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-001 | AFFECTS | VisitController | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-001 | AFFECTS | VetController | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-001 | AFFECTS | pom.xml | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-002 | AFFECTS | OwnerController | medium | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-002 | AFFECTS | PetController | medium | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-002 | AFFECTS | VisitController | medium | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-003 | AFFECTS | VisitController | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-003 | AFFECTS | PetController | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-004 | AFFECTS | pom.xml | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-005 | AFFECTS | PetclinicInitializer | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-005 | AFFECTS | pom.xml | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-006 | AFFECTS | Error screen | medium | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-007 | AFFECTS | PetController | medium | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-008 | AFFECTS | data-access.properties | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-008 | AFFECTS | logback.xml | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-009 | AFFECTS | CallMonitoringAspect | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-010 | AFFECTS | OwnerController | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-011 | AFFECTS | VisitController | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-012 | AFFECTS | PetValidator | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-012 | AFFECTS | Visit | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-013 | AFFECTS | ClinicServiceImpl | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-013 | AFFECTS | cacheManager | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-014 | AFFECTS | Spring profile jdbc | medium | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-014 | AFFECTS | Spring profile spring-data-jpa | medium | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-014 | AFFECTS | db scripts (schema.sql, data.sql) | medium | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-015 | AFFECTS | Spring profile jpa | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-015 | AFFECTS | Spring profile jdbc | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-015 | AFFECTS | Spring profile spring-data-jpa | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-016 | AFFECTS | datasource-config.xml | high | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-016 | AFFECTS | db scripts (schema.sql, data.sql) | high | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-017 | AFFECTS | logback.xml | high | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-017 | AFFECTS | CallMonitoringAspect | high | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-018 | AFFECTS | pom.xml | high | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-018 | AFFECTS | GitHub Actions workflows | high | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-019 | AFFECTS | Owner | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-019 | AFFECTS | db scripts (schema.sql, data.sql) | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-020 | AFFECTS | ClinicServiceImpl | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-021 | AFFECTS | datasource-config.xml | medium | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-021 | AFFECTS | Spring profile javaee | medium | [risk-gap/operations.md](../risk-gap/operations.md) |
| RISK-011 | RELATES_TO | VIS-009 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-012 | RELATES_TO | PET-003 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-012 | RELATES_TO | VIS-005 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-013 | RELATES_TO | VET-004 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-014 | RELATES_TO | OWN-009 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-014 | RELATES_TO | PLT-001 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-014 | RELATES_TO | VET-001 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-014 | RELATES_TO | VIS-007 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |
| RISK-003 | RELATES_TO | VIS-008 | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-019 | RELATES_TO | OWN-008 | high | [risk-gap/security.md](../risk-gap/security.md) |
| RISK-020 | RELATES_TO | PLT-005 | high | [risk-gap/functional-data.md](../risk-gap/functional-data.md) |

## Gaps in this domain

- Security findings SEC-02, SEC-05 and SEC-06 are inferred from absence of code or reading only; graph confidence is MEDIUM.
- Dependency vulnerabilities and runtime behaviour were not checked (static analysis only).

## Related

[knowledge-graph/index.md](./index.md), [security/index.md](../security/index.md), [risk-gap/index.md](../risk-gap/index.md), [runtime-operations/index.md](../runtime-operations/index.md), [ai/index.md](../ai/index.md), [repository/index.md](../repository/index.md)

---
tags:
  - extraction
  - security
---
# Security Governance Analysis

**Generated**: 2026-11-11
**Based on**: Repository intake analysis ([repository/index.md](../repository/index.md))
**Scope**: spring-framework-petclinic (single module, WAR)

## Executive Summary

Spring Petclinic is a demo application with **no authentication, no authorization, no CSRF protection, no TLS configuration and no security headers**. There is no Spring Security dependency and no security filter; the only servlet filter is `CharacterEncodingFilter` ([PetclinicInitializer.java:70-74](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)). Every URL, including owner PII create/edit, is open to any anonymous client. This is expected for a sample but is the dominant governance gap if the code is reused. Overall risk: **High** (for any non-demo use).

Positive controls verified: parameterised queries in all three persistence implementations, Bean Validation on owner and visit input, `c:out` output encoding in the owner views, `id` disallow lists on most binders, and a generic exception view. Weak points: default database credentials committed in `pom.xml`, `jpa.showSql=true` and DEBUG app logging, an unescaped `${exception.message}` in the error view, and `id` not disallowed on the Pet binder (inferred).

No password, session, lockout, registration or notification policies exist (no users; the error JSP declares `session="false"`). These policy families are recorded as "not present" in the inventory below.

## Module Analysis

### spring-framework-petclinic

#### Security Mechanisms
- **Authentication**: None. No Spring Security / JAAS / security filter; the dependency list has no security artifact ([pom.xml:95-340](../../../pom.xml)). There is no `web.xml`; configuration is programmatic ([PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)).
- **Authorization**: None. Controllers carry no role checks or method security annotations ([OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)).
- **Encryption**: None configured. No TLS connector, HTTPS redirect, or field/DB encryption. The only external script references are in an IE<9 conditional comment ([htmlHeader.tag:24-27](../../../src/main/webapp/WEB-INF/tags/htmlHeader.tag)).
- **Validation**:
  - Bean Validation: `Person.firstName/lastName` `@NotEmpty` ([Person.java](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java)); `Owner.address/city` `@NotEmpty`, `telephone` `@NotEmpty @Digits(fraction=0, integer=10)` ([Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)); `Visit.description` `@NotEmpty` ([Visit.java:47](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)).
  - `PetValidator`: name required, type required when new, birthDate required ([PetValidator.java:41-58](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java)). No maximum-length checks in Java; only DDL column lengths (e.g. `first_name VARCHAR(30)`, [db/h2/schema.sql](../../../src/main/resources/db/h2/schema.sql)).
  - Mass-assignment guard: `setDisallowedFields("id")` in OwnerController, VisitController and the `owner` binder of PetController ([OwnerController.java:48-51](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [VisitController.java:45-48](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [PetController.java:59-62](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)). The `pet` binder only sets a validator ([PetController.java:64-67](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)) and does not disallow `id` (inferred: a posted `id` may bind to the Pet).
- **SQL injection defence**: queries use bound parameters: JPA `setParameter` ([JpaOwnerRepositoryImpl.java:56-58](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java)), JDBC named params ([JdbcOwnerRepositoryImpl.java:71-78](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java)), Spring Data `@Query` ([SpringDataOwnerRepository.java:35](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java)). The search term is only concatenated with `%` as a bound value.
- **Output encoding**: owner details and list use `<c:out>` ([ownerDetails.jsp:14-26](../../../src/main/webapp/WEB-INF/jsp/owners/ownerDetails.jsp), [ownersList.jsp:28](../../../src/main/webapp/WEB-INF/jsp/owners/ownersList.jsp)); URLs use `fn:escapeXml`. Exception: [exception.jsp:13](../../../src/main/webapp/WEB-INF/jsp/exception.jsp) prints `${exception.message}` raw.
- **Rate limiting / DoS**: none. `/owners` with no parameter returns all owners ([OwnerController.java:67-72](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)).
- **Encoding filter**: `CharacterEncodingFilter("UTF-8", true)` ([PetclinicInitializer.java:70-74](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)).

#### Permissions & Access Control
- **Role Structure**: None defined. No role, permission, grant-restriction or built-in-record constructs exist, so the option/enum/flag enumeration is empty (verified by absence of any security or authority class under `src/main/java`).
- **Default Policy**: Allow-all (no interceptors or filters; `/resources/**`, `/webjars/**` and the default servlet handler mapped openly, [mvc-core-config.xml:30-45](../../../src/main/resources/spring/mvc-core-config.xml)).
- **Object-level access**: none. Owner/Pet/Visit are looked up by path id only; for example [VisitController.java:60-65](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java) loads the pet by `petId` without checking `ownerId` (IDOR by design).
- **Lifecycle & integrity constraints**: no delete endpoints are exposed. `Owner.pets` cascades `CascadeType.ALL` ([Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)); FK constraints on `vet_specialties` ([schema.sql](../../../src/main/resources/db/h2/schema.sql)).
- **Service-to-Service**: none (no external calls per intake).
- **Management exposure (JMX)**: `CallMonitoringAspect` is exported as MBean `petclinic:type=CallMonitor` with writable `enabled` attribute and a `reset` operation ([CallMonitoringAspect.java:37-67](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java)), enabled by `<context:mbean-export/>` ([tools-config.xml:35](../../../src/main/resources/spring/tools-config.xml)). No remote JMX or authentication is configured in the repo; exposure depends on JVM flags (inferred). No Actuator or health endpoints exist.
- **Demo error endpoint**: `GET /oups` always throws ([CrashController.java:36-39](../../../src/main/java/org/springframework/samples/petclinic/web/CrashController.java)).

#### Security Policy & Configuration Inventory

| Setting | Shipped default | Allowed range / options | What it enforces | Enforcement code | Config source |
|---|---|---|---|---|---|
| Password minimum length / expiry / complexity / reset | Not present (no accounts) | n/a | n/a | none | none |
| Session lifetime / idle timeout / autologin | Not present; error JSP `session="false"` | n/a | No HTTP session in error view | [exception.jsp:1](../../../src/main/webapp/WEB-INF/jsp/exception.jsp) | n/a |
| Login required / self-registration / lockout | Not present (anonymous access to all URLs) | n/a | n/a | none | none |
| Notification schemes / privacy defaults | Not present | n/a | n/a | none | none |
| `jdbc.username` (H2 / HSQLDB) | `sa` | any | DB login | [datasource-config.xml:34-36](../../../src/main/resources/spring/datasource-config.xml) | [pom.xml:531, 550](../../../pom.xml) |
| `jdbc.password` (H2 / HSQLDB) | empty | any | DB login | same | [pom.xml:532, 551](../../../pom.xml) |
| `jdbc.username` / `jdbc.password` (MySQL) | `petclinic` / `petclinic` | any | DB login | same | [pom.xml:569-570](../../../pom.xml) |
| `jdbc.username` / `jdbc.password` (PostgreSQL) | `postgres` / `petclinic` | any | DB login | same | [pom.xml:588-589](../../../pom.xml) |
| `jdbc.url` | `jdbc:h2:mem:petclinic` (default profile); MySQL/PostgreSQL URLs carry no TLS parameters | per profile | DB transport | [datasource-config.xml:34](../../../src/main/resources/spring/datasource-config.xml) | [pom.xml:530, 549, 568, 587](../../../pom.xml) |
| `system-properties-mode` | `OVERRIDE` | OVERRIDE/FALLBACK/NEVER | JVM `-D` properties override DB credentials | [datasource-config.xml:28](../../../src/main/resources/spring/datasource-config.xml) | same |
| `jpa.showSql` | `true` | true/false | Logs all SQL | [business-config.xml:41](../../../src/main/resources/spring/business-config.xml) | [data-access.properties:11](../../../src/main/resources/spring/data-access.properties) |
| Log level petclinic package / root | `debug` / `info`; `scan="true"` every 30 s | logback levels | Verbosity; console appender only | [logback.xml](../../../src/main/resources/logback.xml) | same |
| DB initialisation scripts | schema+data run at every startup; schema begins with DROP TABLE | `db.script` h2/hsqldb/mysql/postgresql | Destructive re-init | [datasource-config.xml:38-42](../../../src/main/resources/spring/datasource-config.xml) | [data-access.properties:7-8](../../../src/main/resources/spring/data-access.properties) |
| Active Spring profile | `jpa` | jpa / jdbc / spring-data-jpa (+ `javaee` JNDI datasource) | Persistence implementation; `javaee` moves credentials to JNDI | [PetclinicInitializer.java:55,62](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) | same |
| Character encoding | UTF-8, force=true | n/a | Request encoding | [PetclinicInitializer.java:72](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) | same |
| `Owner.telephone` | `@Digits(integer=10, fraction=0)` | up to 10 digits | Input format | [Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java) | annotation |
| Error view | `defaultErrorView=exception`, `warnLogCategory=warn` | n/a | Generic error page | [mvc-core-config.xml:61-67](../../../src/main/resources/spring/mvc-core-config.xml) | same |

#### Sensitive Data Handling
- **Data Types**: owner PII (first/last name, address, city, telephone: [Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [Person.java](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java)); pet names and birth dates; visit descriptions (possibly health related); DB credentials in configuration.
- **Storage**: plain text columns in H2/HSQLDB (in-memory by default) or MySQL/PostgreSQL; no encryption ([schema.sql](../../../src/main/resources/db/h2/schema.sql)). Sample data is fictitious ([data.sql](../../../src/main/resources/db/h2/data.sql)).
- **Transmission**: plain HTTP unless the container is configured otherwise; DB URLs lack TLS options.
- **Logging of PII**: `Owner.toString()` includes address, city and telephone ([Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)); app DEBUG logging and SQL logging are on. Whether `toString()` reaches logs was not verified.
- **Retention / deletion / audit**: no retention policy, no delete or erasure function, no audit trail. `CallMonitoringAspect` records only call counts and times.
- **Secrets**: DB passwords committed in `pom.xml` Maven profiles and the same defaults in [readme.md:69, 92](../../../readme.md).

#### Governance Risks
| Risk | Severity | Details | Evidence |
|------|----------|---------|----------|
| No authentication or authorization | High | All owner/pet/visit PII can be read and modified anonymously; no object-level checks | [pom.xml:95-340](../../../pom.xml), [OwnerController.java:41-130](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) |
| No CSRF protection on state-changing POSTs | High | No token filter or tag; forms forgeable (inferred from absence of any CSRF code) | [PetclinicInitializer.java:70-74](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java) |
| Hardcoded DB credentials | Medium | Committed passwords for MySQL/PostgreSQL profiles; `postgres` superuser used | [pom.xml:567-589](../../../pom.xml) |
| No transport security / security headers | Medium | No TLS, HSTS, CSP, X-Frame-Options configured; DB connection without TLS | [pom.xml:568, 587](../../../pom.xml) |
| Raw exception message rendered | Medium | `${exception.message}` unescaped; XSS if a message reflects user input (inferred, not exercised) | [exception.jsp:13](../../../src/main/webapp/WEB-INF/jsp/exception.jsp) |
| Pet binder does not disallow `id` | Medium | Possible overwrite of another pet by posting an id (inferred) | [PetController.java:64-67, 92-110](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java) |
| IDOR: owner/pet relation not verified | Medium | Visit and pet routes accept arbitrary ids | [VisitController.java:60-65](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java) |
| Verbose SQL/debug logging | Low | `jpa.showSql=true`, DEBUG level, config reload every 30 s | [data-access.properties:11](../../../src/main/resources/spring/data-access.properties), [logback.xml](../../../src/main/resources/logback.xml) |
| JMX MBean with write operations | Low | Exposure depends on JVM remote JMX flags; none in repo | [CallMonitoringAspect.java:37-67](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java) |
| Unbounded list-all, no rate limiting | Low | `/owners` returns every owner | [OwnerController.java:67-72](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) |
| Aged DB driver / test images | Low | `mysql-driver.version` 8.1.0; readme uses mysql:5.7.8 and postgres:9.6.0. Advisories not checked (no network) | [pom.xml:68](../../../pom.xml), [readme.md:69, 92](../../../readme.md) |
| Destructive DB re-init at startup | Low | Schema scripts DROP tables on every context start; dangerous if pointed at a real DB | [datasource-config.xml:38-42](../../../src/main/resources/spring/datasource-config.xml), [schema.sql:1-7](../../../src/main/resources/db/h2/schema.sql) |
| Limited security testing | Low | Sonar on main build, Dependabot present; no SAST/DAST/dependency-audit job found, no security tests | [maven-build-main.yml:30](../../../.github/workflows/maven-build-main.yml), [dependabot.yml](../../../.github/dependabot.yml) |

#### Dependency notes
Spring Framework 7.0.8, Hibernate 7.4.0.Final, Tomcat 11.0.18 (tomcat-jdbc, jasper-el), H2 2.4.240, Jetty plugin 11.0.26, PostgreSQL driver 42.7.13, MySQL driver 8.1.0 ([pom.xml](../../../pom.xml)). Vulnerability status not checked (static analysis only).

## Cross-Module Patterns
Single module. The three persistence implementations (jpa/jdbc/spring-data-jpa) all use bound parameters, so the SQL injection posture is consistent across profiles. The `javaee` profile supplies the datasource via JNDI ([datasource-config.xml:46-49](../../../src/main/resources/spring/datasource-config.xml)), the only built-in path to remove committed credentials.

## Compliance & Standards
- OWASP Top 10 2021: A01 Broken Access Control (not met), A02 Cryptographic Failures (no TLS or encryption), A05 Security Misconfiguration (headers, logging), A07 Identification and Authentication Failures (none), A03 Injection (SQL mitigated).
- GDPR: owner contact data is personal data; no erasure, retention, consent or audit controls (Art. 5, 17, 32 gaps). Repository data is sample data only.

## Recommendations
1. If the code is reused: add Spring Security (authn, role-based authz, CSRF, HTTPS, security headers).
2. Move DB credentials to environment variables / JNDI (`javaee` profile) / a secret store; remove committed passwords.
3. Escape `${exception.message}` and verify path ids against ownership.
4. Add `setDisallowedFields("id")` to the Pet binder or use DTOs.
5. Set `jpa.showSql=false` and non-DEBUG logging outside development; enable DB TLS.
6. Add dependency audit / SAST to CI; update the MySQL driver and test images.

## Appendix: Evidence Index
- .github/dependabot.yml; .github/workflows/maven-build-main.yml
- pom.xml (profiles lines 520-600)
- readme.md
- src/main/java/.../PetclinicInitializer.java, web/*Controller.java, web/PetValidator.java, model/Owner.java, model/Person.java, model/Visit.java, util/CallMonitoringAspect.java, repository/{jpa,jdbc,springdatajpa}/*
- src/main/resources/logback.xml, spring/*.xml, spring/data-access.properties, db/*/schema.sql
- src/main/webapp/WEB-INF/jsp/exception.jsp, jsp/owners/*.jsp, tags/htmlHeader.tag

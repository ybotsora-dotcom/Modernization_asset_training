---
tags:
  - extraction
  - security
---
# Security Governance Index

**Generated**: 2026-11-11 | **Overall risk**: High (for non-demo use) | **Basis**: [repository/index.md](../repository/index.md)

## Module files
- [spring-framework-petclinic.md](./spring-framework-petclinic.md) - single WAR module: mechanisms, policy inventory, data handling, risks.

## Top risks
1. No authentication/authorization anywhere; all owner PII is open to anonymous users.
2. No CSRF protection, TLS or security headers.
3. Hardcoded DB credentials in `pom.xml` profiles.
4. Raw `${exception.message}` in the error view; Pet binder lacks `id` disallow (inferred).
5. SQL logging and DEBUG logging on by default.

Password, session, lockout, registration and notification policies do not exist (no user accounts).

## Related
[repository/index.md](../repository/index.md)

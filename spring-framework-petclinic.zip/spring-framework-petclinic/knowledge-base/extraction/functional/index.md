---
tags:
  - extraction
  - functional
---
# Functional Discovery: spring-framework-petclinic

Veterinary clinic web app (Spring MVC + JSP). No scheduled jobs, message listeners, stored procedures or CLI commands were found. No authentication configured (inferred from absence in reviewed code).

## Modules
- [owners-pets-visits.md](./owners-pets-visits.md) - owner search/CRUD, pets, visits (8 features)
- [vets-and-platform.md](./vets-and-platform.md) - welcome, vet list (HTML/JSON/XML), error demo, JMX monitoring, persistence switch (5 features)

## Features
Owners, pets and visits ([owners-pets-visits.md](./owners-pets-visits.md)):
- Find Owners by Last Name, Register New Owner, Edit Owner, View Owner Details
- Add Pet to Owner, Edit Pet
- Record Pet Visit, List Pet Visits (the list endpoint has no template, see the open point below)

Vets and platform ([vets-and-platform.md](./vets-and-platform.md)):
- Welcome Page, List Veterinarians (HTML, JSON and XML)
- Error Page Demonstration, Repository Call Monitoring (JMX), Persistence Implementation Switch

## Confidence and gaps
Status PARTIAL, confidence MEDIUM. The JSP templates and the JPA and JDBC repository implementations were not read in full, and no template exists for the visit list view `visitList`.

## Statistics
- 13 features; 19 documented HTTP routes (14 in owners-pets-visits, 5 in vets-and-platform); 0 jobs.
- Open point: `/owners/*/pets/{petId}/visits` targets view `visitList`, which has no template under `src/main`.

Related: [repository/index.md](../repository/index.md)

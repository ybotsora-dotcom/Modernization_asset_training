---
tags:
  - extraction
  - functional
---
# Module: Owners, Pets and Visits

Server-rendered (JSP) workflows for clinic staff. No authentication is configured in the code reviewed (inferred: all routes public). Controllers delegate to `ClinicService` ([ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)).

## Table of Contents
- Owners: find, create, edit, details
- Pets: add, edit
- Visits: add, list
- Flows

---

## Feature: Find Owners by Last Name
- **Module**: Owners, Pets and Visits
- **Type**: UI Flow / API
- **Triggering Mechanism**: User submits the Find Owners form (GET)
- **User Role**: Clinic staff (no role check found)
- **Description**: Staff search owners by last-name prefix. Zero matches re-shows the form with a "not found" error; exactly one match redirects to that owner's details; several matches show a list.
- **Entry Points**: `OwnerController.initFindForm()`, `OwnerController.processFindForm()`
- **Invocation Paths**: `/owners/find` form; `/owners?lastName=X`; parameterless `/owners` lists all owners (lastName defaulted to empty string).
- **Constraints & Limits**: No pagination or result cap found. The Spring Data repository query uses `LIKE :lastName%` (prefix match); the JPA and JDBC implementations were not read for wildcard handling (inferred equivalent).
- **Configuration & Defaults**: Persistence implementation chosen by Spring profile (default `jpa`, [PetclinicInitializer.java:52](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)).
- **Related Features**: View Owner Details
- **Business Rules**: Pets are fetched with the owner (left join fetch).
- **Evidence**: [OwnerController.java:70-99](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [SpringDataOwnerRepository.java:35](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java)
- **Confidence**: HIGH

### GET /owners/find
- **Purpose**: Show owner search form
- **Parameters**: none
- **Response**: View `owners/findOwners`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `OwnerController.initFindForm()`

### GET /owners
- **Purpose**: Search owners by last name (prefix); list, redirect, or error
- **Parameters**: `lastName` (query, optional)
- **Response**: View `owners/ownersList` (many), redirect to `/owners/{id}` (one), or `owners/findOwners` with error (none)
- **Status Codes**: 200, 302
- **Authentication**: None found
- **Implementation**: `OwnerController.processFindForm()`

## Feature: Register New Owner
- **Module**: Owners, Pets and Visits
- **Type**: UI Flow / API
- **Triggering Mechanism**: User submits the New Owner form
- **User Role**: Clinic staff
- **Description**: Creates an owner with first name, last name, address, city and telephone, then redirects to the owner's details.
- **Entry Points**: `OwnerController.initCreationForm()`, `processCreationForm()`
- **Constraints & Limits**: First name, last name, address, city, telephone are `@NotEmpty`; telephone also `@Digits(integer=10, fraction=0)` (digits only, max 10). The `id` field is disallowed from binding.
- **Related Features**: Edit Owner
- **Business Rules**: Validation errors re-display the form.
- **Evidence**: [OwnerController.java:53-68](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [Owner.java:46-58](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [Person.java:30-36](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java)
- **Confidence**: HIGH

### GET /owners/new
- **Purpose**: Show empty owner form
- **Parameters**: none
- **Response**: View `owners/createOrUpdateOwnerForm`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `OwnerController.initCreationForm()`

### POST /owners/new
- **Purpose**: Validate and save new owner
- **Parameters**: form fields firstName, lastName, address, city, telephone
- **Response**: Redirect to `/owners/{id}` or form with errors
- **Status Codes**: 302, 200 (validation errors)
- **Authentication**: None found
- **Implementation**: `OwnerController.processCreationForm()`

## Feature: Edit Owner
- **Module**: Owners, Pets and Visits
- **Type**: UI Flow / API
- **Triggering Mechanism**: "Edit Owner" from owner details
- **User Role**: Clinic staff
- **Description**: Updates an existing owner's contact data using the same form and validation as creation.
- **Entry Points**: `OwnerController.initUpdateOwnerForm()`, `processUpdateOwnerForm()`
- **Constraints & Limits**: Same validation as registration; id taken from the path, not the form.
- **Evidence**: [OwnerController.java:101-117](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- **Confidence**: HIGH

### GET /owners/{ownerId}/edit
- **Purpose**: Show pre-filled owner form
- **Parameters**: `ownerId` (path)
- **Response**: View `owners/createOrUpdateOwnerForm`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `OwnerController.initUpdateOwnerForm()`

### POST /owners/{ownerId}/edit
- **Purpose**: Validate and save owner changes
- **Parameters**: `ownerId` (path), form fields
- **Response**: Redirect to `/owners/{ownerId}` or form with errors
- **Status Codes**: 302, 200
- **Authentication**: None found
- **Implementation**: `OwnerController.processUpdateOwnerForm()`

## Feature: View Owner Details
- **Module**: Owners, Pets and Visits
- **Type**: UI Flow / API
- **Triggering Mechanism**: Redirect after search/create/edit, or link from list
- **User Role**: Clinic staff
- **Description**: Shows owner data with their pets (sorted by name, case-insensitive) and each pet's visits (newest first), with links to add pets, add visits, edit.
- **Entry Points**: `OwnerController.showOwner()`
- **Distinguishing Semantics**: Pet ordering in `Owner.getPets()`; visit ordering in `Pet.getVisits()`.
- **Evidence**: [OwnerController.java:125-130](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [Owner.java:98-102](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [Pet.java:99-103](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)
- **Confidence**: HIGH

### GET /owners/{ownerId}
- **Purpose**: Show owner with pets and visits
- **Parameters**: `ownerId` (path)
- **Response**: View `owners/ownerDetails`
- **Status Codes**: 200 (unknown-id behaviour not verified)
- **Authentication**: None found
- **Implementation**: `OwnerController.showOwner()`

## Feature: Add Pet to Owner
- **Module**: Owners, Pets and Visits
- **Type**: UI Flow / API
- **Triggering Mechanism**: "Add New Pet" from owner details
- **User Role**: Clinic staff
- **Description**: Creates a pet (name, birth date, type from the pet-type list) for an owner.
- **Entry Points**: `PetController.initCreationForm()`, `processCreationForm()`
- **Constraints & Limits**: `PetValidator`: name required, birth date required, type required for new pets. Name must be unique among the owner's existing pets (`Owner.getPet(name, true)`), else error "already exists".
- **Related Features**: Edit Pet; pet types loaded via `findPetTypes()` (ordered by name in the Spring Data query)
- **Evidence**: [PetController.java:55-90](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java), [PetValidator.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java), [PetTypeFormatter.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java)
- **Confidence**: HIGH

### GET /owners/{ownerId}/pets/new
- **Purpose**: Show new pet form
- **Parameters**: `ownerId` (path)
- **Response**: View `pets/createOrUpdatePetForm`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `PetController.initCreationForm()`

### POST /owners/{ownerId}/pets/new
- **Purpose**: Validate and save new pet
- **Parameters**: `ownerId` (path), name, birthDate, type
- **Response**: Redirect to `/owners/{ownerId}` or form with errors
- **Status Codes**: 302, 200
- **Authentication**: None found
- **Implementation**: `PetController.processCreationForm()`

## Feature: Edit Pet
- **Module**: Owners, Pets and Visits
- **Type**: UI Flow / API
- **Triggering Mechanism**: "Edit Pet" from owner details
- **User Role**: Clinic staff
- **Description**: Updates pet name, birth date and type.
- **Entry Points**: `PetController.initUpdateForm()`, `processUpdateForm()`
- **Constraints & Limits**: Same validator; the duplicate-name check runs only for new pets.
- **Evidence**: [PetController.java:92-106](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
- **Confidence**: HIGH

### GET /owners/{ownerId}/pets/{petId}/edit
- **Purpose**: Show pre-filled pet form
- **Parameters**: `ownerId`, `petId` (path)
- **Response**: View `pets/createOrUpdatePetForm`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `PetController.initUpdateForm()`

### POST /owners/{ownerId}/pets/{petId}/edit
- **Purpose**: Validate and save pet changes
- **Parameters**: `ownerId`, `petId` (path), form fields
- **Response**: Redirect to `/owners/{ownerId}` or form with errors
- **Status Codes**: 302, 200
- **Authentication**: None found
- **Implementation**: `PetController.processUpdateForm()`

## Feature: Record Pet Visit
- **Module**: Owners, Pets and Visits
- **Type**: UI Flow / API
- **Triggering Mechanism**: "Add Visit" from owner details
- **User Role**: Clinic staff
- **Description**: Adds a visit (date and description) to a pet. The visit is created for the current date by default and the date format is `yyyy/MM/dd`.
- **Entry Points**: `VisitController.loadPetWithVisit()`, `initNewVisitForm()`, `processNewVisitForm()`
- **Constraints & Limits**: Description `@NotEmpty`. `id` not bindable.
- **Evidence**: [VisitController.java:41-80](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [Visit.java:36-50](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)
- **Confidence**: HIGH

### GET /owners/*/pets/{petId}/visits/new
- **Purpose**: Show new visit form
- **Parameters**: `petId` (path); owner segment is a wildcard
- **Response**: View `pets/createOrUpdateVisitForm`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `VisitController.initNewVisitForm()`

### POST /owners/{ownerId}/pets/{petId}/visits/new
- **Purpose**: Validate and save visit
- **Parameters**: `ownerId`, `petId` (path), date, description
- **Response**: Redirect to `/owners/{ownerId}` or form with errors
- **Status Codes**: 302, 200
- **Authentication**: None found
- **Implementation**: `VisitController.processNewVisitForm()`

## Feature: List Pet Visits
- **Module**: Owners, Pets and Visits
- **Type**: API (view)
- **Triggering Mechanism**: Direct URL
- **User Role**: Clinic staff
- **Description**: Puts the pet's visits (newest first) in the model and returns logical view `visitList`. No `visitList.jsp` was found under `src/main` (searched), so rendering likely fails (inferred, not run).
- **Entry Points**: `VisitController.showVisits()`
- **Evidence**: [VisitController.java:82-89](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)
- **Confidence**: MEDIUM

### GET /owners/*/pets/{petId}/visits
- **Purpose**: List visits of a pet
- **Parameters**: `petId` (path)
- **Response**: Logical view `visitList` (template not found)
- **Status Codes**: 200 expected; rendering unverified
- **Authentication**: None found
- **Implementation**: `VisitController.showVisits()`

## Flow: Register Owner, Add Pet, Record Visit
- **Start**: Find Owners page, "Add Owner"
- **Screens**: 1. New owner form 2. Owner details 3. New pet form 4. Owner details 5. New visit form 6. Owner details
- **Data Submission**: POST /owners/new, POST /owners/{ownerId}/pets/new, POST /owners/{ownerId}/pets/{petId}/visits/new
- **Success Outcome**: Redirect to owner details
- **Error Handling**: Field errors rendered on the same form; messages from `messages*.properties` (en/de/es)

- **Confidence rollup**: HIGH 7, MEDIUM 1, LOW 0 -> (3 + 3 + 3 + 3 + 3 + 3 + 3 + 2) / 8 = 2.88 -> HIGH

---
tags:
  - extraction
  - functional
---
# Module: Veterinarians and Platform Services

## Table of Contents
- Welcome page, Vets list (HTML/JSON/XML), Error demo, Call monitoring, Persistence switch

---

## Feature: Welcome Page
- **Module**: Veterinarians and Platform Services
- **Type**: UI Flow
- **Triggering Mechanism**: GET /
- **User Role**: Any visitor
- **Description**: Landing page mapped by a view-controller (no Java handler).
- **Entry Points**: `<mvc:view-controller path="/" view-name="welcome"/>`
- **Evidence**: [mvc-core-config.xml:35](../../../src/main/resources/spring/mvc-core-config.xml)
- **Confidence**: HIGH

### GET /
- **Purpose**: Show welcome page
- **Parameters**: none
- **Response**: View `welcome`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: view-controller in `mvc-core-config.xml`

## Feature: List Veterinarians
- **Module**: Veterinarians and Platform Services
- **Type**: UI Flow / API
- **Triggering Mechanism**: Menu link or direct request
- **User Role**: Any visitor
- **Description**: Lists all vets with their specialties (sorted case-insensitively by name). The same data is offered as JSON and XML endpoints.
- **Entry Points**: `VetController.showVetList()`, `showJsonVetList()`, `showXmlVetList()`
- **Invocation Paths**: `/vets` (HTML), `/vets.json`, `/vets.xml`
- **Constraints & Limits**: Unpaginated full list. Read-only; no vet create/edit.
- **Configuration & Defaults**: Result cached in Caffeine cache `vets` via `@Cacheable(value = "vets")` on `ClinicServiceImpl`; no expiry or size configured (cache names `default`, `vets`).
- **Distinguishing Semantics**: Three representations of one dataset; JSON/XML are restricted by `produces`.
- **Evidence**: [VetController.java:32-60](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java), [ClinicServiceImpl.java:99-100](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java), [tools-config.xml:38-48](../../../src/main/resources/spring/tools-config.xml), [Vet.java:64-66](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java)
- **Confidence**: HIGH

### GET /vets
- **Purpose**: Veterinarian list page
- **Parameters**: none
- **Response**: View `vets/vetList`
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `VetController.showVetList()`

### GET /vets.json
- **Purpose**: Vets as JSON
- **Parameters**: none
- **Response**: `Vets` object (JSON)
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `VetController.showJsonVetList()`

### GET /vets.xml
- **Purpose**: Vets as XML
- **Parameters**: none
- **Response**: `Vets` object (XML)
- **Status Codes**: 200
- **Authentication**: None found
- **Implementation**: `VetController.showXmlVetList()`

## Feature: Error Page Demonstration
- **Module**: Veterinarians and Platform Services
- **Type**: UI Flow
- **Triggering Mechanism**: GET /oups
- **User Role**: Developer / demo
- **Description**: Deliberately throws a RuntimeException to show the global error view (`exception.jsp`) set as default by `SimpleMappingExceptionResolver`.
- **Entry Points**: `CrashController.triggerException()`
- **Evidence**: [CrashController.java:30-35](../../../src/main/java/org/springframework/samples/petclinic/web/CrashController.java), [mvc-core-config.xml:60-63](../../../src/main/resources/spring/mvc-core-config.xml)
- **Confidence**: HIGH

### GET /oups
- **Purpose**: Trigger a demo exception
- **Parameters**: none
- **Response**: Error view `exception`
- **Status Codes**: error view (HTTP status not verified)
- **Authentication**: None found
- **Implementation**: `CrashController.triggerException()`

## Feature: Repository Call Monitoring (JMX)
- **Module**: Veterinarians and Platform Services
- **Type**: Capability (internal use only)
- **Triggering Mechanism**: Automatically wraps every `@Repository` call; operated via JMX bean `petclinic:type=CallMonitor`
- **User Role**: Operator / System
- **Description**: An AspectJ around-advice counts repository calls and accumulates call time; operators can toggle `enabled` and call `reset()` over JMX.
- **Entry Points**: `CallMonitoringAspect` (pointcut `within(@Repository *)`)
- **Configuration & Defaults**: `enabled` = true; counters start at 0. Exported by `<context:mbean-export/>`. Per the class comment, not useful with the Spring Data JPA profile.
- **Evidence**: [CallMonitoringAspect.java:37-77](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java), [tools-config.xml:29-36](../../../src/main/resources/spring/tools-config.xml)
- **Confidence**: HIGH

## Feature: Persistence Implementation Switch
- **Module**: Veterinarians and Platform Services
- **Type**: Capability (configuration)
- **Triggering Mechanism**: Startup profile selection
- **User Role**: Developer / Operator
- **Description**: The same functionality runs on JPA, JDBC or Spring Data JPA repositories; the database (H2, HSQLDB, MySQL, PostgreSQL) is chosen by Maven profile.
- **Configuration & Defaults**: Spring profile default `jpa`; Maven profile default H2; override with `-Dspring.profiles.active`.
- **Evidence**: [PetclinicInitializer.java:52-58](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java), [business-config.xml](../../../src/main/resources/spring/business-config.xml)
- **Confidence**: HIGH

- **Confidence rollup**: HIGH 5, MEDIUM 0, LOW 0 -> (3 + 3 + 3 + 3 + 3) / 5 = 3.00 -> HIGH

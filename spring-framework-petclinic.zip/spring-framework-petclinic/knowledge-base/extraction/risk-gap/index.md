---
tags:
  - extraction
  - risk
---
# Risk Gap Analysis: Index

**Generated**: 2026-11-11
**Repository**: spring-framework-petclinic (single WAR module; Spring Framework 7, XML config, three persistence profiles)
**Inputs**: repository, architecture, functional, data-model, data-flow, integrations, ui-ux, business-logic-rules, security, runtime-operations and ai extraction outputs. No input was missing. The rule-engine mapping does not exist because the codebase has no database-resident rule engine, so no rule-engine risks are recorded. The AI summary lists no `aiRisks`.

## Files
- [security.md](./security.md): 11 risks, authentication, CSRF, ids, credentials, transport, logging, PII lifecycle
- [functional-data.md](./functional-data.md): 6 risks, missing view, unchecked dates, vets cache, profile divergence
- [operations.md](./operations.md): 4 risks, destructive startup init, observability, dependencies, plus an end-of-life and obsolete technology table

## Totals
21 risks: 0 Critical, 4 High, 8 Medium, 6 Low, 3 Monitor.

## Top Risks
| Risk ID | Title | Score | File |
|---|---|---|---|
| RISK-001 | No authentication or authorization | H×M (High) | [security.md](./security.md) |
| RISK-002 | No CSRF protection | H×M (High) | [security.md](./security.md) |
| RISK-003 | Path ids not verified against ownership | M×H (High) | [security.md](./security.md) |
| RISK-011 | `visitList` view missing | M×H (High) | [functional-data.md](./functional-data.md) |

## Open Decisions
RISK-001 (login and roles), RISK-013 (vets freshness) and RISK-019 (retention and erasure) carry an Open Decision; all other risks are plain remediation.

## Roadmap Summary
- **Quick wins**: escape the error message, disallow pet `id`, ownership check on visit routes, add the missing visit list view, date validation, guard startup DROP scripts, add a dependency-audit CI job.
- **Strategic**: security layer (authn/authz, CSRF, TLS), credential externalisation, decide whether to keep three persistence implementations.
- **Monitoring**: JMX exposure, owner list volume, vets cache policy, transaction scope.

## Limits of this assessment
Static analysis only. Runtime behaviour (missing view result, binder `id` overwrite, MySQL/PostgreSQL search case, Spring Data vet order) and dependency vulnerabilities were not verified.

## Related
[security/index.md](../security/index.md), [business-logic-rules/index.md](../business-logic-rules/index.md), [runtime-operations/index.md](../runtime-operations/index.md), [repository/index.md](../repository/index.md)

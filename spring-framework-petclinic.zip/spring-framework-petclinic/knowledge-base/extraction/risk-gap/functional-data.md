---
tags:
  - extraction
  - risk
---
# Risk Assessment Report: Functional and Data Gaps

**Generated**: 2026-11-11
**Analysis Scope**: [business-logic-rules/index.md](../business-logic-rules/index.md), [visits.md](../business-logic-rules/visits.md), [pets.md](../business-logic-rules/pets.md), [vets.md](../business-logic-rules/vets.md), [platform.md](../business-logic-rules/platform.md), [functional/index.md](../functional/index.md), [ui-ux/pets-visits.md](../ui-ux/pets-visits.md), [data-flow/vet-flows.md](../data-flow/vet-flows.md), [architecture/petclinic.md](../architecture/petclinic.md)
**Rule engine**: none exists in this codebase (see [business-logic-rules/index.md](../business-logic-rules/index.md)); no rule-engine risks are raised.

## Executive Summary
- One functional defect candidate (missing `visitList` view), unchecked date inputs, a never-evicted vets cache, and behaviour that silently differs by Spring or Maven profile.
- Top risk: RISK-011 (visit list endpoint targets a view that does not exist; runtime outcome inferred, not run).
- Effort: RISK-011 and RISK-012 are small fixes; RISK-014 and RISK-015 need decisions about how many persistence implementations to keep.

## Risk Register
| Risk ID | Title | Impact | Likelihood | Score | Affected Module | Recommended Follow-up |
|---------|-------|--------|------------|-------|-----------------|----------------------|
| RISK-011 | `visitList` view missing for visits endpoint | Medium | High | M×H (High) | `VisitController.showVisits` | Add view or remove endpoint |
| RISK-012 | Pet birth date and visit date not range-checked | Medium | Medium | M×M (Medium) | `PetValidator`, `Visit` | Add past-date and not-null checks |
| RISK-013 | Vets cache never evicted, no TTL or size limit | Low | Medium | L×M (Low) | `ClinicServiceImpl.findVets`, `tools-config.xml` | Decide refresh policy |
| RISK-014 | Behaviour differs silently by Spring and Maven profile | Medium | Medium | M×M (Medium) | repository implementations | Align behaviour, add tests |
| RISK-015 | Three parallel persistence implementations to maintain | Medium | Medium | M×M (Medium) | `repository/{jpa,jdbc,springdatajpa}` | Confirm scope of retained variants |
| RISK-020 | Form flow spans several transactions | Low | Low | L×L (Monitor) | `ClinicServiceImpl` | Keep under review |

## Detailed Risk Analysis

### RISK-011: `visitList` view missing for visits endpoint
- **Category**: maintainability
- **Description**: `GET /owners/*/pets/{petId}/visits` puts the pet's visits in the model and returns view `visitList`. No `visitList.jsp` exists under `WEB-INF/jsp` (verified by file listing) and no UI link targets the endpoint. Runtime resolution failure is inferred, not run.
- **Affected Projects/Modules**: [VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), `src/main/webapp/WEB-INF/jsp/`
- **Impact**: Medium. A direct request would fail instead of showing visit history. **Likelihood**: High for any client that calls the URL (it is documented as an endpoint).
- **Evidence**: Business rule VIS-009; [ui-ux/pets-visits.md](../ui-ux/pets-visits.md); [functional/index.md](../functional/index.md) "Open point".
- **Recommended Follow-up**: Either create the JSP or remove the handler; add a `VisitControllerTests` case asserting the response.

### RISK-012: Pet birth date and visit date not range-checked
- **Category**: technicalDebt
- **Description**: `PetValidator` requires a non-null birth date but never compares it with today, so future dates are accepted (PET-003 area). Visit date has a format (`yyyy/MM/dd`) but no not-null, past or future check, and an empty field may bind to null (VIS-005; not verified).
- **Affected Projects/Modules**: [PetValidator.java:41-58](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java), [Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)
- **Impact**: Medium. Invalid history can be stored (and a null visit date may break the `visit_date` column or sorting; inferred). **Likelihood**: Medium. Needs a user typing such a date.
- **Evidence**: Business rules pets.md ("future dates are accepted"), VIS-005.
- **Recommended Follow-up**: Add `@NotNull` and past-or-present validation, with unit tests in `ValidatorTests`.

### RISK-013: Vets cache never evicted, no TTL or size limit
- **Category**: performance
- **Description**: `findVets` is `@Cacheable("vets")` on a `CaffeineCacheManager` with no size or expiry; a grep found no `@CacheEvict`. The list is served from memory for the life of the process. Vets have no write path in the app, so staleness arises only when the database changes externally.
- **Affected Projects/Modules**: [ClinicServiceImpl.java:100](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java), [tools-config.xml](../../../src/main/resources/spring/tools-config.xml)
- **Impact**: Low. **Likelihood**: Medium once vets are maintained outside the app.
- **Evidence**: VET-004; [data-flow/vet-flows.md](../data-flow/vet-flows.md); the JDBC repository Javadoc mentions "refresh the cache" but no refresh code exists.
- **Recommended Follow-up**: Add a TTL or evict hook, and a test showing the second call is served from cache.
- **Open Decision**: How quickly must a change to the vet list (new vet, changed specialty) appear to users: immediately, within minutes, or only after a restart?

### RISK-014: Behaviour differs silently by Spring and Maven profile
- **Category**: architectural
- **Description**: Visit update throws `UnsupportedOperationException` under `jdbc` but merges under `jpa` (VIS-007). Vet ordering is explicit for jpa/jdbc but unspecified for spring-data-jpa (VET-001, not verified). Owner search is case-insensitive on H2/HSQLDB and engine-dependent on MySQL/PostgreSQL (OWN-009, inferred). The call monitor is not effective with spring-data-jpa.
- **Affected Projects/Modules**: [JdbcVisitRepositoryImpl.java:55-64](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java), [SpringDataVetRepository](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa), `db/*/schema.sql`
- **Impact**: Medium. Same feature can behave differently per deployment. **Likelihood**: Medium. Only when the non-default profile or database is used.
- **Evidence**: Business rules VIS-007, VET-001, OWN-009, PLT-001/002; [runtime-operations](../runtime-operations/spring-framework-petclinic.md) metrics note.
- **Recommended Follow-up**: Add an explicit `ORDER BY` for spring-data-jpa vets and extend `AbstractClinicServiceTests` with ordering and case-insensitivity assertions run on all profiles.

### RISK-015: Three parallel persistence implementations to maintain
- **Category**: maintainability
- **Description**: Every repository method must be written three times (JPA, JDBC, Spring Data) and verified against all three via `AbstractClinicServiceTests`, per project guidance. Divergence (RISK-014) is the consequence.
- **Affected Projects/Modules**: `src/main/java/.../repository/{jpa,jdbc,springdatajpa}`, `src/test/.../service/ClinicService*Tests.java`
- **Impact**: Medium. **Likelihood**: Medium. Each new repository method triples the work.
- **Evidence**: [architecture/petclinic.md](../architecture/petclinic.md); [CLAUDE.md](../../../CLAUDE.md).
- **Recommended Follow-up**: Keep the shared abstract test suite as the contract; if the three variants are not a teaching goal in the target, plan consolidation to one.

### RISK-020: Form flow spans several transactions
- **Category**: technicalDebt
- **Description**: Each `ClinicService` call is its own transaction; the add-visit and pet flows span several calls. `findVisitsByPetId` has no transaction annotation (PLT-005).
- **Affected Projects/Modules**: [ClinicServiceImpl.java:54-108](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)
- **Impact**: Low. **Likelihood**: Low. No concurrent-edit scenario was identified in the extraction.
- **Evidence**: PLT-005.
- **Recommended Follow-up**: Monitor; revisit if concurrent editing or optimistic locking is introduced.

## Remediation Roadmap
- **Quick Wins** (1-2 weeks): RISK-011, RISK-012, vets `ORDER BY` from RISK-014.
- **Strategic Initiatives** (1-3 months): RISK-015 consolidation decision; cross-profile test matrix for RISK-014.
- **Long-term Monitoring**: RISK-013, RISK-020.

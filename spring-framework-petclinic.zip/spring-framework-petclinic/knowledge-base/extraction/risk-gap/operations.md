---
tags:
  - extraction
  - risk
---
# Risk Assessment Report: Operations and Dependencies

**Generated**: 2026-11-11
**Analysis Scope**: [runtime-operations/spring-framework-petclinic.md](../runtime-operations/spring-framework-petclinic.md), [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md), [repository/spring-framework-petclinic.md](../repository/spring-framework-petclinic.md), [ai/index.md](../ai/index.md)
**AI**: the AI summary reports `present=true` for the engineering harness only (`CLAUDE.md`) and an empty `aiRisks` list, so no `ai` category risks are raised.

## Executive Summary
- Startup scripts drop and recreate tables on every context start, there are no health checks or metrics endpoints, and dependency/vulnerability status was never checked (static analysis only).
- Top risk: RISK-016 (destructive re-initialisation if pointed at a real database).
- Effort: RISK-016 and RISK-018 are small configuration and CI changes.

## Risk Register
| Risk ID | Title | Impact | Likelihood | Score | Affected Module | Recommended Follow-up |
|---------|-------|--------|------------|-------|-----------------|----------------------|
| RISK-016 | Schema scripts DROP tables on every startup | High | Low | H×L (Medium) | `datasource-config.xml`, `db/*/schema.sql` | Guard re-init by profile |
| RISK-017 | No health check, thin metrics and no tracing | Low | Medium | L×M (Low) | runtime | Add health endpoint if deployed |
| RISK-018 | Dependency currency unverified; no audit or SAST in CI | Medium | Medium | M×M (Medium) | `pom.xml`, `.github/workflows` | Add dependency audit job |
| RISK-021 | `javaee` JNDI datasource override not verified | Low | Low | L×L (Monitor) | `datasource-config.xml` | Test the profile |

## Detailed Risk Analysis

### RISK-016: Schema scripts DROP tables on every startup
- **Category**: operational
- **Description**: `<jdbc:initialize-database>` runs `schema.sql` (beginning with DROP TABLE) and `data.sql` at every context start for the selected database. Harmless for in-memory H2 (default); destructive for the MySQL and PostgreSQL profiles pointed at persistent data.
- **Affected Projects/Modules**: [datasource-config.xml:38-42](../../../src/main/resources/spring/datasource-config.xml), [db/h2/schema.sql:1-7](../../../src/main/resources/db/h2/schema.sql), [data-access.properties:7-8](../../../src/main/resources/spring/data-access.properties)
- **Impact**: High. Loss of all data on restart. **Likelihood**: Low for a demo; rises if the MySQL/PostgreSQL profiles are used with real data.
- **Evidence**: Security analysis "Destructive DB re-init at startup"; runtime-operations "Data Stores".
- **Recommended Follow-up**: Run init scripts only for in-memory profiles or behind an explicit property; introduce a migration tool for persistent databases.

### RISK-017: No health check, thin metrics and no tracing
- **Category**: operational
- **Description**: No Actuator or health endpoint; metrics are JMX-only (and ineffective with spring-data-jpa); logging is console-only; tracing is absent. A probe would have to use `GET /` (inferred).
- **Affected Projects/Modules**: [CallMonitoringAspect.java](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java), [logback.xml](../../../src/main/resources/logback.xml)
- **Impact**: Low. **Likelihood**: Medium if the Jib image is run under an orchestrator.
- **Evidence**: runtime-operations "Observability" (Health Checks: none, Tracing: disabled).
- **Recommended Follow-up**: Add a lightweight health controller and decide the probe URL before containerised deployment.

### RISK-018: Dependency currency unverified; no audit or SAST in CI
- **Category**: dependency
- **Description**: Vulnerability status of Spring 7.0.8, Hibernate 7.4.0, Tomcat 11.0.18, H2 2.4.240, MySQL driver 8.1.0 was not checked (no network); their support dates were checked on 2026-11-13 (see the end-of-life table below). The readme test images (mysql:5.7.8, postgres:9.6.0) are past end of life; the MySQL driver coordinates are unverified. CI runs `verify` and Sonar plus Dependabot, but no dependency-audit, SAST or security test job was found. Availability of `mysql-connector-java` 8.1.0 was also not verified.
- **Affected Projects/Modules**: [pom.xml](../../../pom.xml), [.github/workflows/maven-build-main.yml](../../../.github/workflows/maven-build-main.yml), [readme.md](../../../readme.md)
- **Impact**: Medium. **Likelihood**: Medium.
- **Evidence**: Security analysis "Aged DB driver / test images" and "Limited security testing"; repository summary "Unclear / not verified".
- **Recommended Follow-up**: Add an OWASP dependency-check or equivalent CI step, review the Dependabot backlog, and move the MySQL driver and test images to supported versions.

### RISK-021: `javaee` JNDI datasource override not verified
- **Category**: operational
- **Description**: The `javaee` profile declares a JNDI DataSource in the same file as the default `dataSource`; whether it cleanly replaces the default bean was not verified (bean override decides, inferred). It is the only built-in route to remove committed credentials (RISK-004).
- **Affected Projects/Modules**: [datasource-config.xml:46-49](../../../src/main/resources/spring/datasource-config.xml)
- **Impact**: Low. **Likelihood**: Low.
- **Evidence**: runtime-operations "Data Stores".
- **Recommended Follow-up**: Verify with a container deployment test before relying on it for RISK-004.

## End-of-Life and Obsolete Technology Flags
Basis: the versions and file references below are read from the repository (verified). The support dates were retrieved on 2026-11-13 from the public lifecycle tracker endoflife.date (`https://endoflife.date/api/<product>.json`, which collects vendor lifecycle data) with a page-fetch tool. They were not read from the vendors' own pages, so confirm any date against the vendor before relying on it commercially. Where no date could be retrieved the row says so.

### Ranking by migration urgency (as of 2026-11-13)
1. **Past end of life and on the application's own runtime path:** Jetty 11.
2. **Past end of life, used only for the documented local test databases:** MySQL 5.7 and PostgreSQL 9.6.
3. **Standard support ended, extended or other-vendor support continues:** Java 17.
4. **Supported, plan the next move:** Spring Framework 7.0, Hibernate ORM 7.4, Tomcat 11.0 (the repository versions are behind the latest listed patch: Hibernate 7.4.0 against 7.4.15, Tomcat 11.0.18 against 11.0.29, Spring Framework 7.0.8 against 7.0.10).
5. **Not assessed:** H2 database, the MySQL driver coordinates, Caffeine, Logback.

| Item (version in the repository) | Where | Support position on 2026-11-13 (tracker data) | Status | Confidence |
|---|---|---|---|---|
| Jetty 11.0.26 (build plugin; container base image `jetty:11.0-jdk17`) | [pom.xml:76](../../../pom.xml), [pom.xml:478](../../../pom.xml) | The 11 line's support ended 2024-01-01 and it reached end of life 2025-01-01. Jetty 12.1 is current. | Verified against tracker | MEDIUM |
| Java 17 (`java.version` 17) | [pom.xml:17](../../../pom.xml) | Oracle JDK 17: standard support ended 2026-09-30, extended support to 2029-09-30. Eclipse Temurin 17: end of life 2027-10-31. Which vendor's build the clinic uses is not stated. | Verified against tracker | MEDIUM |
| MySQL 5.7.8 (documented test container) | [readme.md:69](../../../readme.md) | 5.7 reached end of life 2023-10-31. The 8.0 line reached end of life 2026-04-30; 8.4 (long-term support) runs to 2032-04-30. | Verified against tracker | MEDIUM |
| PostgreSQL 9.6.0 (documented test container) | [readme.md:92](../../../readme.md) | 9.6 reached end of life 2021-11-11. Versions 17 (to 2029-11-08) and 18 (to 2030-11-14) are current. | Verified against tracker | MEDIUM |
| Spring Framework 7.0.8 | [pom.xml:31](../../../pom.xml) | The 7.0 line (released 2025-11-30) is supported to 2027-07-31, extended support to 2028-07-31. Latest listed patch is 7.0.10. | Verified against tracker | MEDIUM |
| Hibernate ORM 7.4.0.Final | [pom.xml:50](../../../pom.xml) | The 7.4 line (released 2026-05-26) is not end of life. Latest listed patch is 7.4.15. | Verified against tracker | MEDIUM |
| Apache Tomcat 11.0.18 | [pom.xml:39](../../../pom.xml) | The 11.0 line is not end of life. Latest listed patch is 11.0.29. | Verified against tracker | MEDIUM |
| `mysql-connector-java` 8.1.0 | [pom.xml:68](../../../pom.xml), [pom.xml:575](../../../pom.xml) | No date retrieved. The artifact id is believed to be a legacy name; newer releases are believed to be published as `mysql-connector-j`. | Inferred | LOW |
| H2 database 2.4.240 | [pom.xml:53](../../../pom.xml) | No data retrieved (the tracker has no page for it). | Not assessed | - |
| Stale EhCache comment | [pom.xml:182](../../../pom.xml) | The comment says the dependency is "used for EhCacheCacheManager", but the configured cache manager is Caffeine (repository summary). Documentation drift, not an end-of-life item. | Verified in the repository | HIGH |

Caffeine and Logback were not assessed.

## Remediation Roadmap
- **Quick Wins** (1-2 weeks): RISK-016 guard, RISK-018 audit job.
- **Strategic Initiatives** (1-3 months): migration tooling, health and metrics endpoints (RISK-017).
- **Long-term Monitoring**: RISK-021, dependency upgrades via Dependabot.

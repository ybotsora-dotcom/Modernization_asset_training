---
tags:
  - extraction
  - risk
---
# Risk Assessment Report: Security and Data Protection

**Generated**: 2026-11-11
**Analysis Scope**: [security/spring-framework-petclinic.md](../security/spring-framework-petclinic.md), [business-logic-rules/index.md](../business-logic-rules/index.md), [business-logic-rules/visits.md](../business-logic-rules/visits.md), [runtime-operations/spring-framework-petclinic.md](../runtime-operations/spring-framework-petclinic.md)
**Context**: Spring Petclinic is a sample application. Severity is rated as if the code were reused or deployed beyond a demo. Items marked *inferred* come from static reading only (nothing was run).

## Executive Summary
- The application has no authentication, authorization, CSRF protection or transport security. All owner PII can be read and changed by any anonymous client.
- Top risks: RISK-001 (no authn/authz), RISK-002 (no CSRF), RISK-003 (unchecked ids / IDOR).
- Positive controls verified: bound SQL parameters in all three persistence implementations, Bean Validation on owner and visit input, `c:out` encoding in owner views.
- Effort: adding a security layer is a strategic initiative (weeks); items RISK-006, RISK-007 and RISK-008 are quick wins (hours).

## Risk Register
| Risk ID | Title | Impact | Likelihood | Score | Affected Module | Recommended Follow-up |
|---------|-------|--------|------------|-------|-----------------|----------------------|
| RISK-001 | No authentication or authorization | High | Medium | H×M (High) | `web/*Controller`, `pom.xml` | Add Spring Security if reused |
| RISK-002 | No CSRF protection on state-changing POSTs | High | Medium | H×M (High) | `web/*Controller`, JSP forms | Add CSRF tokens with RISK-001 |
| RISK-003 | Path ids not verified against ownership (IDOR) | Medium | High | M×H (High) | `VisitController`, `PetController` | Check `ownerId` owns `petId` |
| RISK-004 | Database credentials committed in `pom.xml` and readme | Medium | Medium | M×M (Medium) | `pom.xml`, `readme.md` | Externalise credentials |
| RISK-005 | No TLS, HSTS, CSP or frame protection | Medium | Medium | M×M (Medium) | `PetclinicInitializer`, DB URLs | Add TLS and security headers |
| RISK-006 | Raw `${exception.message}` in error view | Medium | Low | M×L (Low) | `exception.jsp` | Wrap in `c:out` |
| RISK-007 | Pet binder does not disallow `id` (inferred) | Medium | Medium | M×M (Medium) | `PetController` | Add `setDisallowedFields("id")` |
| RISK-008 | SQL and DEBUG logging on by default | Low | Medium | L×M (Low) | `data-access.properties`, `logback.xml` | Default to off outside dev |
| RISK-009 | Writable JMX MBean, exposure depends on JVM flags | Low | Low | L×L (Monitor) | `CallMonitoringAspect` | Document JMX hardening |
| RISK-010 | Unbounded owner list, no rate limiting | Low | Medium | L×M (Low) | `OwnerController.processFindForm` | Add paging |
| RISK-019 | No PII retention, erasure or audit capability | Medium | Low | M×L (Low) | `Owner`, `schema.sql` | Decide policy, then implement |

## Detailed Risk Analysis

### RISK-001: No authentication or authorization
- **Category**: security
- **Description**: There is no Spring Security or other security filter. Only `CharacterEncodingFilter` is registered. Controllers have no role checks.
- **Affected Projects/Modules**: [web/OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [PetclinicInitializer.java:70-74](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java), [pom.xml](../../../pom.xml)
- **Impact**: High. Owner name, address, city and telephone can be created and edited anonymously.
- **Likelihood**: Medium. Certain for any deployment of this code as-is; low for its intended demo use.
- **Evidence**: Security analysis, "No authentication or authorization" (High); business rules index: "Authorization: none"; 0 Authorization rules in the 40-rule catalogue.
- **Recommended Follow-up**: If the code is reused, add Spring Security with role-based authorization on `/owners/**`. Add a controller-level test proving anonymous requests are rejected.
- **Open Decision**: Should the target system require users to log in, and if so which roles (for example receptionist, vet) may change owner, pet and visit data?

### RISK-002: No CSRF protection on state-changing POSTs
- **Category**: security
- **Description**: No token filter or token tag exists for owner, pet and visit POST forms (inferred from absence of CSRF code).
- **Affected Projects/Modules**: `web/*Controller`, `src/main/webapp/WEB-INF/jsp/**` forms
- **Impact**: High. A third-party page can submit forms on behalf of a user's browser.
- **Likelihood**: Medium. Becomes likely only once RISK-001 is fixed and sessions exist; today any client can POST directly.
- **Evidence**: Security analysis governance table, "No CSRF protection" (High).
- **Recommended Follow-up**: Enable CSRF tokens together with RISK-001; add a test posting without a token.

### RISK-003: Path ids not verified against ownership (IDOR)
- **Category**: security
- **Description**: `VisitController` loads the pet by `petId` without checking it belongs to `ownerId`; the owner id is not checked and the GET mapping uses `*`. Pet and visit routes accept arbitrary ids.
- **Affected Projects/Modules**: [VisitController.java:60-83](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
- **Impact**: Medium. A visit can be added to any pet through any owner URL; with no authentication the exposure is the same as RISK-001 but integrity of the owner-pet relation is also unenforced.
- **Likelihood**: High. Any request with a wrong pair of ids triggers it.
- **Evidence**: Security analysis "IDOR: owner/pet relation not verified"; business rule VIS-008: "The owner id in the path is not checked against the pet's actual owner".
- **Recommended Follow-up**: In `loadPetWithVisit` compare `pet.getOwner().getId()` with `ownerId` and return 404 on mismatch; add a web test for the mismatch.

### RISK-004: Database credentials committed in `pom.xml` and readme
- **Category**: security
- **Description**: MySQL (`petclinic`/`petclinic`) and PostgreSQL (`postgres`/`petclinic`, superuser) passwords sit in Maven profiles and are filtered into the packaged `data-access.properties`. The same values appear in readme commands.
- **Affected Projects/Modules**: [pom.xml:567-589](../../../pom.xml), [readme.md](../../../readme.md), [data-access.properties](../../../src/main/resources/spring/data-access.properties)
- **Impact**: Medium. Values are development defaults, but they are baked into the WAR at package time.
- **Likelihood**: Medium. Risk materialises if the same defaults are reused outside local development.
- **Evidence**: Security analysis and runtime-operations "Secrets Management: No secrets manager". `system-properties-mode=OVERRIDE` and the `javaee` JNDI profile are the existing escape routes.
- **Recommended Follow-up**: Supply credentials via `-D` properties or JNDI at deploy time and remove them from the profile defaults; use a non-superuser database account.

### RISK-005: No TLS, HSTS, CSP or frame protection
- **Category**: security
- **Description**: No TLS connector, HTTPS redirect, response-header configuration or database TLS parameters exist in the repository.
- **Affected Projects/Modules**: [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java), JDBC URLs in [pom.xml:568, 587](../../../pom.xml)
- **Impact**: Medium. PII crosses the network in clear text unless the container adds TLS.
- **Likelihood**: Medium. Depends on how the WAR or Jib image is fronted (not specified in the repository).
- **Evidence**: Security analysis "No transport security / security headers" (Medium).
- **Recommended Follow-up**: Terminate TLS at the container or proxy, add a header filter, and add TLS options to non-H2 JDBC URLs.

### RISK-006: Raw `${exception.message}` in the error view
- **Category**: security
- **Description**: The error JSP prints the exception message without escaping. If a message ever echoes user input, script injection is possible (inferred, not exercised).
- **Affected Projects/Modules**: [exception.jsp:13](../../../src/main/webapp/WEB-INF/jsp/exception.jsp)
- **Impact**: Medium. **Likelihood**: Low. No evidence yet that a message reflects input.
- **Evidence**: Security analysis, output encoding exception.
- **Recommended Follow-up**: Wrap in `<c:out>` (one-line fix) and keep `CrashControllerTests` passing.

### RISK-007: Pet binder does not disallow `id` (inferred)
- **Category**: security
- **Description**: The `pet` `@InitBinder` only sets a validator; Owner and Visit binders disallow `id`. A posted `id` may bind to the Pet and merge over another pet.
- **Affected Projects/Modules**: [PetController.java:59-67, 92-110](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
- **Impact**: Medium. **Likelihood**: Medium. Needs a crafted form post; unverified at runtime.
- **Evidence**: Security analysis "Pet binder does not disallow `id`" (Medium).
- **Recommended Follow-up**: Add `setDisallowedFields("id")` to the pet binder and a web test posting a foreign `id`.

### RISK-008: SQL and DEBUG logging on by default
- **Category**: security
- **Description**: `jpa.showSql=true`, application logger at `debug`, `scan="true"` every 30 s. `Owner.toString()` contains address and telephone; whether it reaches logs was not verified.
- **Affected Projects/Modules**: [data-access.properties:11](../../../src/main/resources/spring/data-access.properties), [logback.xml](../../../src/main/resources/logback.xml)
- **Impact**: Low. **Likelihood**: Medium. Shipped defaults apply to every run.
- **Evidence**: Security analysis; runtime-operations "Logging".
- **Recommended Follow-up**: Default `jpa.showSql=false` and `info` outside development; confirm no PII in logs by grepping a test run (later phase).

### RISK-009: Writable JMX MBean
- **Category**: security
- **Description**: `petclinic:type=CallMonitor` is exported with writable `enabled` and a `reset` operation. No remote JMX is configured in the repo; exposure depends on JVM flags (inferred).
- **Affected Projects/Modules**: [CallMonitoringAspect.java:37-67](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java), [tools-config.xml:35](../../../src/main/resources/spring/tools-config.xml)
- **Impact**: Low. **Likelihood**: Low.
- **Evidence**: Security analysis; runtime-operations "Metrics".
- **Recommended Follow-up**: Document that remote JMX must be authenticated; no code change needed.

### RISK-010: Unbounded owner list, no rate limiting
- **Category**: performance
- **Description**: `/owners` without a last name returns every owner; no paging or throttling.
- **Affected Projects/Modules**: [OwnerController.java:67-72](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- **Impact**: Low (seed data is 10 owners). **Likelihood**: Medium with real data volumes.
- **Evidence**: Security analysis "Unbounded list-all".
- **Recommended Follow-up**: Add paging to the search and a test with a large data set.

### RISK-019: No PII retention, erasure or audit capability
- **Category**: security
- **Description**: No delete endpoints, retention policy or audit trail exist (cascade from Owner to Pet to Visit is declared but never triggered). Owner contact data is personal data.
- **Affected Projects/Modules**: [Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [schema.sql](../../../src/main/resources/db/h2/schema.sql)
- **Impact**: Medium. **Likelihood**: Low for the sample (data is fictitious); rises with real data.
- **Evidence**: Security analysis "Retention / deletion / audit: none"; business rules OWN-008 (no delete anywhere).
- **Recommended Follow-up**: Define the retention and erasure requirement before adding delete functions.
- **Open Decision**: How long must owner, pet and visit records be kept, and must the system let a person's data be erased on request?

## Remediation Roadmap
- **Quick Wins** (1-2 weeks): RISK-006, RISK-007, RISK-008, RISK-003 ownership check.
- **Strategic Initiatives** (1-3 months): RISK-001/002/005 security layer; RISK-004 credential externalisation.
- **Long-term Monitoring**: RISK-009, RISK-010, RISK-019 as data and deployment context evolve.

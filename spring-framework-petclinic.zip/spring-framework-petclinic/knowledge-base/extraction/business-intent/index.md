---
tags:
  - extraction
  - business-intent
---

# Business Intent Analysis: Index

## Executive Summary
Spring Petclinic is a veterinary clinic management web application: staff keep a register of pet owners and their pets, record visits, and consult a read-only list of vets and specialties.

## Primary Business Intent
Front-desk record keeping for a small veterinary clinic (owners, pets, visit history), with a reference directory of vets. It also serves as a reference application demonstrating interchangeable persistence layers. There is no database-resident rule engine; capabilities derive from the rules in [business-logic-rules/index.md](../business-logic-rules/index.md).

## Domain Files
- [owners.md](./owners.md): client register, search, edit (4 capabilities)
- [pets.md](./pets.md): pet registration and edit, type list (3 capabilities)
- [visits.md](./visits.md): visit recording and history; no vet link (3 capabilities)
- [vets.md](./vets.md): read-only vet and specialty directory, JSON/XML (2 capabilities)
- [platform.md](./platform.md): database/persistence selection, monitoring, errors (3 capabilities)

## User Personas
- Clinic receptionist / front-desk staff: finds owners, registers owners and pets, records visits (inferred; there are no roles or login).
- Anyone viewing the vet directory (no authentication).
- Developer / operator: chooses database and persistence profile, reads JMX metrics.

## Key Findings
- A visit does not involve a vet (VIS-002).
- No delete operation exists for owners, pets or visits (OWN-008).
- No authorization (0 authorization rules).
- 15 capabilities in total; none AI-powered.

## Related Extraction
[functional/index.md](../functional/index.md), [data-model/index.md](../data-model/index.md), [ui-ux/index.md](../ui-ux/index.md), [security/index.md](../security/index.md), [architecture/index.md](../architecture/index.md), [ai/index.md](../ai/index.md)

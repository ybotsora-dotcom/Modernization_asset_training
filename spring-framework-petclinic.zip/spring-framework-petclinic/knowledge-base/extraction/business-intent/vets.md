---
tags:
  - extraction
  - business-intent
---

# Business Intent Analysis: Vets

## Executive Summary
A read-only directory of the clinic's veterinarians and their specialties, viewable as a web page and as JSON or XML.

## Primary Business Intent
Let users see who the vets are and what they specialise in. Vets are reference data and are not connected to visits. Authority: [business-logic-rules/vets.md](../business-logic-rules/vets.md).

## Domain Concepts
### Vets
- **Entities**: Vet (first name, last name), Specialty (e.g. dentistry, radiology, surgery), link table between them.
- **Relationships**: Many-to-many Vet to Specialty; no link to Visit or Pet (VET-005).
- **Business Rules**: List ordered by last then first name under the default JPA profile (VET-001, Medium); specialties sorted by name (VET-002); "none" shown when a vet has no specialty (VET-003); list cached with no eviction (VET-004).
- **Evidence**: [Vet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java), [VetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java), [VetRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/VetRepository.java).

## Business Capabilities
### View veterinarians and specialties
- **Description**: The Veterinarians page lists each vet with specialties sorted by name, or "none".
- **Type**: Reporting
- **Related Domains**: Vets
- **Configurable**: Partly. Ordering is declared under `jpa` and `jdbc` but not `spring-data-jpa` (Spring profile, default `jpa`, set in PetclinicInitializer.SPRING_PROFILE). Caching is on by default and not externalised (VET-004).
- **Evidence**: GET /vets; VET-001..004.
- **Confidence**: High (content); Medium (ordering across profiles)

### Publish vet list as JSON and XML
- **Description**: The same list is available for other systems at /vets.json and /vets.xml, linked from the page (VET-007). No consumer is configured in the repository.
- **Type**: Integration
- **Related Domains**: Vets
- **Configurable**: No
- **Evidence**: VetController `produces` mappings; [integrations/index.md](../integrations/index.md).
- **Confidence**: High

## Intent Assumptions
- **Assumption 1**: Vet and specialty data is maintained outside the application (database scripts) — Evidence: VetRepository only has findAll (VET-005).
- **Assumption 2**: Staleness of the cached list is acceptable — Evidence: no cache eviction or TTL (VET-004).

## Technical Patterns Supporting Intent
- Caffeine cache on the service call reduces repeat database reads — Location: tools-config.xml, ClinicServiceImpl.findVets.

## Known Limitations or Ambiguities
- Vet maintenance, scheduling and assignment to visits are absent, not merely hidden.

## Confidence Summary
- **High Confidence**: Directory view, JSON/XML publication, read-only nature.
- **Medium Confidence**: Ordering under spring-data-jpa.
- **Low Confidence**: None.

---
tags:
  - extraction
  - business-intent
---

# Business Intent Analysis: Visits

## Executive Summary
Staff log a clinic visit against a pet with a date and a free-text description, and see the pet's earlier visits when doing so.

## Primary Business Intent
Keep a visit history per pet. A visit is NOT linked to a vet: the code neither requires nor records one (VIS-002, High). Authority: [business-logic-rules/visits.md](../business-logic-rules/visits.md).

## Domain Concepts
### Visits
- **Entities**: Visit (date, description), Pet (parent).
- **Relationships**: Many visits per pet; no relationship to Vet in the entity, the form or the `visits` table in any of the four database scripts.
- **Business Rules**: Description required (VIS-001); date defaults to today (VIS-004); date typed as yyyy/MM/dd (VIS-005, Medium); visits shown newest first (VIS-003); must belong to an existing pet (VIS-006); JDBC mode cannot update an existing visit (VIS-007).
- **Evidence**: [Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java), [VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), createOrUpdateVisitForm.jsp.

## Business Capabilities
### Record a visit for a pet
- **Description**: From the owner page choose Add Visit, review previous visits (newest first), enter date (today by default) and description, save, and return to the owner page. No vet is captured.
- **Type**: Workflow
- **Related Domains**: Visits, Pets, Owners
- **Configurable**: No
- **Evidence**: GET/POST /owners/*/pets/{petId}/visits/new; VIS-001, VIS-003, VIS-004, VIS-008; service test saving a visit with only a description.
- **Confidence**: High

### Visit history per pet
- **Description**: Visits appear under each pet on the owner page, most recent first (VIS-003).
- **Type**: Reporting
- **Related Domains**: Visits, Pets
- **Configurable**: No
- **Evidence**: Pet.getVisits; owner details page.
- **Confidence**: High

### Visit list endpoint (not usable)
- **Description**: A URL for listing a pet's visits exists but its view template is absent from the repository and no page links to it (VIS-009). Treat as a dead endpoint, not a working capability.
- **Type**: Reporting
- **Related Domains**: Visits
- **Configurable**: No
- **Evidence**: GET /owners/*/pets/{petId}/visits; no `visitList` JSP under WEB-INF/jsp.
- **Confidence**: Medium

## Intent Assumptions
- **Assumption 1**: Stakeholders who expect a visit to name the attending vet are describing a feature that does not exist; it would need schema, entity, form and validation changes in all three persistence implementations — Evidence: VIS-002, VET-005.
- **Assumption 2**: Visits are append-only history — Evidence: no UI path to edit or delete a visit (VIS-007).

## Technical Patterns Supporting Intent
- Controller preloads the pet and attaches a new Visit via `pet.addVisit` — Location: VisitController.loadPetWithVisit.

## Known Limitations or Ambiguities
- Whether a cleared date field binds null or errors was not verified (VIS-005); the runtime outcome of the missing `visitList` view is inferred.

## Confidence Summary
- **High Confidence**: Record visit, visit history, no vet link.
- **Medium Confidence**: Date handling, visit list endpoint.
- **Low Confidence**: None.

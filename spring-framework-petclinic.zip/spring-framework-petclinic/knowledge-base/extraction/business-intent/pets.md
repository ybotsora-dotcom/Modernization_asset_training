---
tags:
  - extraction
  - business-intent
---

# Business Intent Analysis: Pets

## Executive Summary
Each owner's animals are recorded with name, birth date and type (seed types: cat, dog, lizard, snake, bird, hamster), so visits can be tied to a specific animal.

## Primary Business Intent
Register and correct patient records under an owner. Authority: [business-logic-rules/pets.md](../business-logic-rules/pets.md).

## Domain Concepts
### Pets
- **Entities**: Pet (name, birth date), PetType (reference list), Owner (parent).
- **Relationships**: A pet belongs to exactly one owner and one type; a pet has many visits.
- **Business Rules**: Name required (PET-001); type required for new pets (PET-002); birth date required, future dates accepted (PET-003); no two pets of one owner share a name, case-insensitive, checked on creation only (PET-004); birth date typed as yyyy/MM/dd (PET-005); type matched by exact lower-case name (PET-006).
- **Evidence**: [Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java), [PetType.java](../../../src/main/java/org/springframework/samples/petclinic/model/PetType.java), [PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java), PetValidator, PetTypeFormatter.

## Business Capabilities
### Add a pet to an owner
- **Description**: From the owner page staff add an animal with name, birth date and type; duplicates for the same owner are refused; success returns to the owner page (PET-001 to PET-007).
- **Type**: Workflow
- **Related Domains**: Owners, Pets
- **Configurable**: No (the type list is seed data in `db/<name>/data.sql`; no screen maintains it)
- **Evidence**: GET/POST /owners/{ownerId}/pets/new; PET-001..007; service tests for id generation.
- **Confidence**: High

### Edit a pet
- **Description**: Change a pet's name, birth date or type. The duplicate-name check does not apply to renames (PET-004) and the type requirement applies only when the pet is treated as new (PET-002).
- **Type**: CRUD
- **Related Domains**: Pets, Owners
- **Configurable**: No
- **Evidence**: GET/POST /owners/{ownerId}/pets/{petId}/edit; PET-002, PET-004, PET-007.
- **Confidence**: High

### Pet type selection list
- **Description**: Alphabetical list of animal types offered on the pet form (PET-008). Types cannot be added through the application.
- **Type**: Reporting
- **Related Domains**: Pets
- **Configurable**: No
- **Evidence**: `findPetTypes` in ClinicService; ORDER BY name in the three repositories.
- **Confidence**: High

## Intent Assumptions
- **Assumption 1**: Future birth dates are not intentionally blocked — Evidence: no date comparison in PetValidator; a service test saves a pet born today (PET-003).
- **Assumption 2**: The pet type vocabulary is administered directly in the database — Evidence: no PetType write operation in the service (inferred).

## Technical Patterns Supporting Intent
- Custom validator and formatter keep form rules and type lookup explicit — Location: PetValidator, PetTypeFormatter in web/.

## Known Limitations or Ambiguities
- The edit form binds a fresh Pet, so the new-pet rules depend on the hidden id field (PET-002); owner and pet ids are not cross-checked (PET-007).

## Confidence Summary
- **High Confidence**: Add pet, edit pet, type list.
- **Medium Confidence**: None.
- **Low Confidence**: None.

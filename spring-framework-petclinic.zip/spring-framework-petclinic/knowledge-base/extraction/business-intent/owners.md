---
tags:
  - extraction
  - business-intent
---

# Business Intent Analysis: Owners

## Executive Summary
The clinic keeps a register of pet owners (clients). Staff can find an owner by surname, register a new owner, correct contact details and open an owner's page showing all pets and their visits.

## Primary Business Intent
Maintain the client register that every other clinic activity (pets, visits) hangs from. Authority: [business-logic-rules/owners.md](../business-logic-rules/owners.md) and [functional/owners-pets-visits.md](../functional/owners-pets-visits.md).

## Domain Concepts
### Owners
- **Entities**: Owner (first name, last name, address, city, telephone), owning a set of Pets.
- **Relationships**: One owner has many pets; pets and visits are saved through the owner when using JPA (OWN-008). Pets are shown in name order, ignoring case (OWN-007).
- **Business Rules**: Name, address, city and telephone are mandatory (OWN-001); telephone must be numeric, max 10 significant digits (OWN-002, Medium); a posted owner id is ignored (OWN-005); no owner can be deleted because no delete operation exists (OWN-008).
- **Evidence**: [Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [OwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/OwnerRepository.java).

## Business Capabilities
### Find owners by surname
- **Description**: Staff enter the start of a surname (or nothing, to list everyone). No match returns a "not found" message; one match opens that owner directly; several matches show a pick list (OWN-003, OWN-004).
- **Type**: Workflow
- **Related Domains**: Owners, Pets, Visits
- **Configurable**: Partly. Case sensitivity depends on the database chosen by Maven profile `db.script` (default `h2`; options h2, hsqldb, mysql, postgresql). H2/HSQLDB are case-insensitive; MySQL/PostgreSQL behaviour is unverified (OWN-009).
- **Evidence**: GET /owners/find and /owners in OwnerController; rules OWN-003, OWN-004, OWN-009.
- **Confidence**: High (routing); Medium (case sensitivity on non-default databases)

### Register a new owner
- **Description**: Capture a new client with validated contact details; on success the new owner's page opens (OWN-001, OWN-002, OWN-006).
- **Type**: CRUD
- **Related Domains**: Owners
- **Configurable**: No
- **Evidence**: GET/POST /owners/new; validation annotations on Owner; controller tests post invalid forms and assert field errors.
- **Confidence**: High

### Edit owner details
- **Description**: Correct an existing owner's name, address, city or telephone (OWN-006).
- **Type**: CRUD
- **Related Domains**: Owners
- **Configurable**: No
- **Evidence**: GET/POST /owners/{ownerId}/edit; OWN-005, OWN-006.
- **Confidence**: High

### View owner record
- **Description**: One page showing the owner's details, their pets (alphabetical) and each pet's visits (newest first), with entry points to edit the owner, add a pet and add a visit (OWN-007, VIS-003). An unknown owner id ends in the generic error page (OWN-010, Medium).
- **Type**: Reporting
- **Related Domains**: Owners, Pets, Visits
- **Configurable**: No
- **Evidence**: GET /owners/{ownerId}; owner pages in [ui-ux/index.md](../ui-ux/index.md).
- **Confidence**: High

## Intent Assumptions
- **Assumption 1**: Telephone is a numeric string, not an international format — Evidence: `@Digits` rule OWN-002; success tests use 11-character numbers with a leading zero.
- **Assumption 2**: Owners are never removed (design intent unconfirmed) — Evidence: no delete method in any repository interface (OWN-008).

## Technical Patterns Supporting Intent
- Bean validation on the entity keeps owner data-entry rules in one place — Location: Owner.java, Person.java.
- Three interchangeable repositories give the same owner behaviour across JPA, JDBC and Spring Data — Location: repository/jpa, jdbc, springdatajpa.

## Known Limitations or Ambiguities
- Leading-zero telephone handling and non-default-database search case sensitivity were not verified by execution.
- Whether the absence of delete is a deliberate retention policy is not stated anywhere.

## Confidence Summary
- **High Confidence**: Search routing, register, edit, view owner.
- **Medium Confidence**: Telephone validation edge cases, case-insensitive search on MySQL/PostgreSQL, unknown-id handling.
- **Low Confidence**: None.

---
tags:
  - extraction
  - business-intent
---

# Business Intent Analysis: Platform

## Executive Summary
Supporting behaviour: choice of database and persistence style, call monitoring, error page and transactions. No end-user business function, but it governs how the application can be deployed.

## Primary Business Intent
Make the same clinic application run on different databases and persistence technologies (reference-application purpose). Authority: [business-logic-rules/platform.md](../business-logic-rules/platform.md).

## Domain Concepts
### Platform
- **Entities**: None business-facing; configuration profiles, a call-monitor bean, a cache manager.
- **Relationships**: Maven profile picks the database; Spring profile picks the repository implementation; the two are independent.
- **Business Rules**: PLT-001 to PLT-005. Authorization: none exists, so any user can do everything.
- **Evidence**: business-config.xml, data-access.properties, tools-config.xml, [security/index.md](../security/index.md), [runtime-operations/index.md](../runtime-operations/index.md).

## Business Capabilities
### Select database and persistence implementation
- **Description**: Deploy against H2 (default, in-memory so data is lost on restart), HSQLDB, MySQL or PostgreSQL, and run on JPA, JDBC or Spring Data JPA repositories.
- **Type**: Admin
- **Related Domains**: Owners, Pets, Visits, Vets
- **Configurable**: Yes. Maven profile `db.script` (h2 default, hsqldb, mysql, postgresql); Spring profile (jpa default, jdbc, spring-data-jpa; overridable with -Dspring.profiles.active).
- **Evidence**: PLT-001, PLT-002; PetclinicInitializer.
- **Confidence**: High

### Monitor repository activity
- **Description**: Call counts and accumulated time of data access are exposed over JMX, with an `enabled` flag (default true) and a reset operation (PLT-003).
- **Type**: Admin
- **Related Domains**: Owners, Pets, Visits, Vets
- **Configurable**: Yes. JMX attribute `enabled`, default true.
- **Evidence**: PLT-003.
- **Confidence**: High

### Generic error handling
- **Description**: Any unhandled failure, such as an unknown owner id, shows one generic error page (PLT-004).
- **Type**: Admin
- **Related Domains**: Owners, Pets, Visits, Vets
- **Configurable**: No
- **Evidence**: SimpleMappingExceptionResolver, exception.jsp.
- **Confidence**: High

## Intent Assumptions
- **Assumption 1**: The product is a reference/sample application rather than a production clinic system — Evidence: CLAUDE.md project overview, in-memory default database, no authentication, three parallel persistence layers.
- **Assumption 2**: No AI-powered capability exists — Evidence: [ai/index.md](../ai/index.md) reports none.

## Technical Patterns Supporting Intent
- Profile-switched bean wiring — Location: business-config.xml.
- Repository interfaces decoupled from implementations — Location: repository/.

## Known Limitations or Ambiguities
- No rule engine, scheduler or messaging exists; `taskengine-inferred-mapping.md` is intentionally absent.

## Confidence Summary
- **High Confidence**: All platform capabilities.
- **Medium Confidence**: None.
- **Low Confidence**: None.

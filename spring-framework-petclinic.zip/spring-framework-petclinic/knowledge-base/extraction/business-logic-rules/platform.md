---
tags:
  - extraction
  - business-logic-rules
---

# Business Logic Rules Documentation

**Generated**: 2026-11-11
**Repository/Project**: spring-framework-petclinic
**Scope**: Platform rules: persistence and database selection, transactions, call monitoring, error handling

## Table of Contents
- [Executive Summary](#executive-summary)
- [Module Rules](#module-rules)
- [Business Workflows](#business-workflows)
- [Cross-Module Rules](#cross-module-rules)
- [Appendix: Evidence Map](#appendix-evidence-map)

## Executive Summary

Cross-cutting rules that govern how the domain rules run. There are 5 rules: 3 Configuration, 1 Workflow and 1 Constraint. No authentication or authorization exists: a grep of `src/main` and `pom.xml` for Spring Security and `@PreAuthorize` found nothing, so every page is open to any visitor (no Authorization rules are recorded).

## Module Rules

### Platform

#### Runtime configuration and cross-cutting behaviour

| Rule ID | Name | Type | Description | Conditions | Affected Entities | Action | Governing Setting | Evidence | Confidence | Related Rules |
|---------|------|------|-------------|------------|-------------------|--------|-------------------|----------|-----------|---------------|
| PLT-001 | Persistence implementation chosen by Spring profile | Configuration | Exactly one of three repository implementations is active, selected by Spring profile. | Application start | Owner, Pet, Visit, Vet | Matching package is component-scanned; transaction manager type follows the profile (JPA or DataSource) | Spring profile: default `jpa` (`PetclinicInitializer.SPRING_PROFILE`); `jdbc` = JdbcClient repositories; `spring-data-jpa` = Spring Data interfaces; override with `-Dspring.profiles.active` | [PetclinicInitializer.java:52-59](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java), [business-config.xml:35-98](../../../src/main/resources/spring/business-config.xml) | HIGH | VIS-007, VET-001 |
| PLT-002 | Database chosen by Maven profile | Configuration | The Maven profile picks the driver, URL and which `db/<name>/schema.sql` and `data.sql` pair initialises the database. | Build or run with -P | all entities | In-memory H2 by default, seeded with 6 vets, 3 specialties, 6 types, 10 owners, 13 pets, 4 visits | Maven profile: default `H2`; `HSQLDB`, `MySQL`, `PostgreSQL`; resolved through `db.script`, `jdbc.*`, `jpa.database` placeholders in data-access.properties; `jpa.showSql` shipped `true` | [pom.xml:520-600](../../../pom.xml), [data-access.properties:7-19](../../../src/main/resources/spring/data-access.properties), [h2/data.sql](../../../src/main/resources/db/h2/data.sql) | HIGH | OWN-009 |
| PLT-003 | Repository call monitoring | Configuration | An aspect wraps every `@Repository` bean method, counting calls and accumulating elapsed time; average call time is total divided by count, or 0 when no calls. It is exposed over JMX where it can be switched off or reset. | Any repository call | all repositories | Counters updated under synchronisation; when disabled the call proceeds untimed | JMX attribute `enabled` on `petclinic:type=CallMonitor`, default `true` | [CallMonitoringAspect.java:41-95](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java), [tools-config.xml:24-35](../../../src/main/resources/spring/tools-config.xml) | HIGH | PLT-005 |
| PLT-004 | Unhandled errors show a generic error page | Workflow | Any uncaught exception is mapped to the `exception` view and logged under the "warn" category; `/oups` deliberately throws a RuntimeException to demonstrate this. | Exception in a controller | all | HTTP 200 with `exception.jsp` (the test asserts status 200) | - | [mvc-core-config.xml:60-66](../../../src/main/resources/spring/mvc-core-config.xml), [CrashController.java:32-36](../../../src/main/java/org/springframework/samples/petclinic/web/CrashController.java), [CrashControllerTests.java:38-44](../../../src/test/java/org/springframework/samples/petclinic/web/CrashControllerTests.java) | HIGH | OWN-010 |
| PLT-005 | Transaction boundaries on the service | Constraint | Read methods run in read-only transactions, save methods in read-write transactions. `findVisitsByPetId` has no transaction annotation. | Any ClinicService call | all | Writes are atomic per service call; the form flow spans several calls with no wider transaction | - | [ClinicServiceImpl.java:54-108](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java), [business-config.xml:25-26](../../../src/main/resources/spring/business-config.xml) | HIGH | PLT-001 |

**Detailed Rules**:

##### PLT-001: Persistence implementation chosen by Spring profile
- **Description**: `PetclinicInitializer` sets `jpa` as the default profile (used only when no profile is active). `business-config.xml` has `<beans profile="jpa,spring-data-jpa">` (EntityManagerFactory, JpaTransactionManager), `<beans profile="jdbc">` (DataSourceTransactionManager), `<beans profile="jpa">` and `<beans profile="spring-data-jpa">` scanning blocks. The rule set differs by profile in several places: VIS-007 (visit update) and VET-001 (vet ordering).
- **Conditions**: Context start.
- **Affected Entities**: all repositories
- **Action/Consequence**: Domain rules in `CLAUDE.md` terms are meant to behave identically across profiles; the shared `AbstractClinicServiceTests` is run for each. The JDBC code enforces some domain rules by hand (loading pet types, rebuilding owner-pet-visit graph).
- **Governing Setting**: As in table.
- **Evidence**:
  - [PetclinicInitializer.java:52-59](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)
  - [ClinicServiceJdbcTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJdbcTests.java), [ClinicServiceJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceJpaTests.java), [ClinicServiceSpringDataJpaTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/ClinicServiceSpringDataJpaTests.java): one subclass per profile
- **Confidence**: HIGH
- **Related Rules**: VIS-007, VET-001

##### PLT-002: Database chosen by Maven profile
- **Description**: `H2` is `activeByDefault`. Spring placeholders in `data-access.properties` resolve `jdbc.initLocation=classpath:db/${db.script}/schema.sql` and the data script, with system properties overriding (`system-properties-mode="OVERRIDE"`). The scripts are applied at start; H2 and HSQLDB scripts drop and recreate tables, MySQL and PostgreSQL use `CREATE TABLE IF NOT EXISTS`. PostgreSQL resets the visit, vet, etc. id sequences to start at 100 (verified for vets and visits).
- **Conditions**: Build profile.
- **Affected Entities**: all
- **Action/Consequence**: In-memory H2 loses data at restart.
- **Governing Setting**: As in table.
- **Evidence**:
  - [business-config.xml:20-23](../../../src/main/resources/spring/business-config.xml)
  - [postgresql/schema.sql:10,84](../../../src/main/resources/db/postgresql/schema.sql)
- **Confidence**: HIGH
- **Related Rules**: OWN-009

##### PLT-003: Repository call monitoring
- **Description**: `@Around("within(@org.springframework.stereotype.Repository *)")`. `callCount` and `accumulatedCallTime` are updated in a `finally` block, so failed calls are counted too.
- **Conditions**: Aspect bean `callMonitor` is registered and `enabled`.
- **Affected Entities**: none (technical)
- **Action/Consequence**: Metrics only; no domain effect.
- **Governing Setting**: JMX `enabled`, default `true`; `reset` operation zeroes counters.
- **Evidence**:
  - [CallMonitoringAspect.java:77-95](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java)
- **Confidence**: HIGH
- **Related Rules**: PLT-005

##### PLT-004: Unhandled errors show a generic error page
- **Description**: `SimpleMappingExceptionResolver` with `defaultErrorView=exception`.
- **Conditions**: Any controller exception, including unknown ids (OWN-010).
- **Affected Entities**: none
- **Action/Consequence**: Generic page; message detail depends on `exception.jsp`.
- **Governing Setting**: -
- **Evidence**:
  - [mvc-core-config.xml:60-66](../../../src/main/resources/spring/mvc-core-config.xml)
- **Confidence**: HIGH
- **Related Rules**: OWN-010

##### PLT-005: Transaction boundaries on the service
- **Description**: `<tx:annotation-driven/>` is on; `findPetTypes`, `findOwnerById`, `findOwnerByLastName`, `findPetById`, `findVets` are `readOnly = true`; `saveOwner`, `saveVisit`, `savePet` are plain `@Transactional`. Tests are mostly annotated `@Transactional` and roll back.
- **Conditions**: Service calls.
- **Affected Entities**: all
- **Action/Consequence**: Each save is its own transaction. Edge case: in `PetController.processCreationForm`, `owner.addPet(pet)` mutates the owner before `savePet`; nothing is saved if validation fails.
- **Governing Setting**: -
- **Evidence**:
  - [ClinicServiceImpl.java:54-108](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)
- **Confidence**: HIGH
- **Related Rules**: PLT-001

## Business Workflows

Request flow: DispatcherServlet, controller (binding and validation), `ClinicService` (transaction, optional cache), repository (profile-selected, timed by PLT-003), database.

## Cross-Module Rules

PLT-001 changes behaviour in [visits.md](./visits.md) (VIS-007) and [vets.md](./vets.md) (VET-001). PLT-002 affects owner search case sensitivity ([owners.md](./owners.md) OWN-009).

## Appendix: Evidence Map

- [business-config.xml](../../../src/main/resources/spring/business-config.xml), [tools-config.xml](../../../src/main/resources/spring/tools-config.xml), [mvc-core-config.xml](../../../src/main/resources/spring/mvc-core-config.xml), [data-access.properties](../../../src/main/resources/spring/data-access.properties): wiring and settings
- [pom.xml](../../../pom.xml): Maven database profiles
- [PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java): default profile

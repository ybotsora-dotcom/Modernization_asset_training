---
tags:
  - extraction
  - business-logic-rules
---

# Business Logic Rules Documentation

**Generated**: 2026-11-11
**Repository/Project**: spring-framework-petclinic
**Scope**: Vets and specialties (read-only directory of veterinarians)

## Table of Contents
- [Executive Summary](#executive-summary)
- [Module Rules](#module-rules)
- [Business Workflows](#business-workflows)
- [Cross-Module Rules](#cross-module-rules)
- [Appendix: Evidence Map](#appendix-evidence-map)

## Executive Summary

Vets are a read-only reference list: the application can display them (HTML, JSON, XML) but has no way to create, edit or delete a vet, a specialty or a vet-specialty link, and vets are not connected to visits (see VET-005 and [visits.md](./visits.md) VIS-002). There are 7 rules: 3 Calculation (ordering and count), 2 Constraint, 1 Configuration (cache) and 1 Workflow.

## Module Rules

### Vets

#### Vet directory

| Rule ID | Name | Type | Description | Conditions | Affected Entities | Action | Governing Setting | Evidence | Confidence | Related Rules |
|---------|------|------|-------------|------------|-------------------|--------|-------------------|----------|-----------|---------------|
| VET-001 | Vets ordered by last then first name | Calculation | JPA and JDBC repositories return vets ordered by last name, then first name. The Spring Data JPA interface declares no query or ordering, so under that profile the order is whatever `findAll` returns (not verified). | Listing vets | Vet | Ordered collection (jpa, jdbc); unspecified order (spring-data-jpa) | Spring profile `jpa` (default), `jdbc`, `spring-data-jpa` | [JpaVetRepositoryImpl.java:43-47](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVetRepositoryImpl.java), [JdbcVetRepositoryImpl.java:56-62](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVetRepositoryImpl.java), [SpringDataVetRepository.java:28](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataVetRepository.java) | MEDIUM | VET-007 |
| VET-002 | Specialties sorted by name | Calculation | A vet's specialties are returned as a read-only list sorted by name ignoring case. | Reading vet.specialties | Vet, Specialty | Sorted unmodifiable list; empty list when none. Seed vet 3 (Douglas) shows dentistry before surgery | - | [Vet.java:62-67](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java), [VetTests.java:21-67](../../../src/test/java/org/springframework/samples/petclinic/model/VetTests.java), [AbstractClinicServiceTests.java:165-174](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java) | HIGH | VET-003 |
| VET-003 | Specialty count and "none" display | Calculation | `nrOfSpecialties` is the size of the specialty set; the vet list page prints "none" when it is 0. | Rendering the vet list | Vet | Count 0 shows "none" | - | [Vet.java:69-71](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java), [vetList.jsp:25-28](../../../src/main/webapp/WEB-INF/jsp/vets/vetList.jsp), [VetTests.java:69-86](../../../src/test/java/org/springframework/samples/petclinic/model/VetTests.java) | HIGH | VET-002 |
| VET-004 | Vet list is cached | Configuration | `findVets` is cached in the `vets` cache (Caffeine) and there is no eviction anywhere, so the list is served from memory for the life of the application. | Any call to ClinicService.findVets | Vet | After the first call, later calls return the cached collection without a database query | Cache names `default` and `vets` declared in tools-config.xml; caching enabled by `<cache:annotation-driven/>`; no expiry or size configured; no on/off setting | [ClinicServiceImpl.java:98-103](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java), [tools-config.xml:37-47](../../../src/main/resources/spring/tools-config.xml) | HIGH | VET-001 |
| VET-005 | Vets are read-only and unrelated to visits | Constraint | No controller, service or repository method creates, updates or deletes a vet, specialty or vet-specialty link; vets are loaded from the seed `data.sql`. Vets have no link to visits or pets. | Always | Vet, Specialty, Visit | Vet data can change only by editing SQL scripts or the database directly | - | [VetRepository.java:38](../../../src/main/java/org/springframework/samples/petclinic/repository/VetRepository.java), [VetController.java:42-71](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java), [h2/data.sql:1-16](../../../src/main/resources/db/h2/data.sql) | HIGH | VIS-002 |
| VET-006 | Vet-specialty link integrity | Constraint | Each vet_specialties row needs an existing vet and specialty (foreign keys). A vet may have zero specialties (seed: vets 1 and 6). Duplicate pairs are blocked only by the MySQL and PostgreSQL schemas (UNIQUE); the H2 and HSQLDB schemas have no uniqueness, though the Java Set prevents duplicates in memory. | Seeding or inserting vet_specialties | Vet, Specialty | Database rejects dangling references | - | [h2/schema.sql:23-28](../../../src/main/resources/db/h2/schema.sql), [mysql/schema.sql:20-26](../../../src/main/resources/db/mysql/schema.sql), [postgresql/schema.sql:24-30](../../../src/main/resources/db/postgresql/schema.sql) | HIGH | VET-005 |
| VET-007 | Vet list published in three formats | Workflow | GET /vets renders HTML; /vets.json returns JSON and /vets.xml returns XML, all from the same `Vets` wrapper holding the cached list. | GET request | Vet | JSON shape is `{"vetList":[...]}` (test asserts `$.vetList[0].id`); XML root `vets` with `vet` elements | - | [VetController.java:42-71](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java), [VetControllerTests.java:54-76](../../../src/test/java/org/springframework/samples/petclinic/web/VetControllerTests.java) | HIGH | VET-001, VET-004 |

**Detailed Rules**:

##### VET-001: Vets ordered by last then first name
- **Description**: JPA: `ORDER BY vet.lastName, vet.firstName` with `left join fetch vet.specialties` so vets without specialties still appear. JDBC: `ORDER BY last_name,first_name`, then one extra query per vet for specialty ids.
- **Conditions**: Cache miss on `findVets`.
- **Affected Entities**: Vet
- **Action/Consequence**: Ordered list under jpa and jdbc. `SpringDataVetRepository` inherits `findAll()` from `VetRepository` with no `@Query`, so no ordering is declared there.
- **Governing Setting**: Spring profile (default `jpa`); `jdbc` and `spring-data-jpa` as alternatives.
- **Evidence**:
  - [JpaVetRepositoryImpl.java:46](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVetRepositoryImpl.java)
  - [JdbcVetRepositoryImpl.java:59-60](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVetRepositoryImpl.java)
- **Confidence**: MEDIUM
- **Related Rules**: VET-007

##### VET-002: Specialties sorted by name
- **Description**: Sorted copy via `String.CASE_INSENSITIVE_ORDER`. Edge cases from tests: empty list for a new vet; radiology/surgery/dentistry added in any order come back dentistry, radiology, surgery.
- **Conditions**: Any read.
- **Affected Entities**: Vet, Specialty
- **Action/Consequence**: As above. `addSpecialty` goes through a Set so the same specialty is not added twice.
- **Governing Setting**: -
- **Evidence**:
  - [Vet.java:46-49,73-75](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java)
- **Confidence**: HIGH
- **Related Rules**: VET-003

##### VET-003: Specialty count and "none" display
- **Description**: `getNrOfSpecialties()` returns `getSpecialtiesInternal().size()`.
- **Conditions**: Vet list page.
- **Affected Entities**: Vet
- **Action/Consequence**: "none" is printed in the Specialties column when the count is 0.
- **Governing Setting**: -
- **Evidence**:
  - [vetList.jsp:28](../../../src/main/webapp/WEB-INF/jsp/vets/vetList.jsp)
- **Confidence**: HIGH
- **Related Rules**: VET-002

##### VET-004: Vet list is cached
- **Description**: `@Cacheable(value = "vets")` on `findVets`, with a `CaffeineCacheManager` listing cache names `default` and `vets`. A grep for `CacheEvict` over `src/main` found none, and no TTL is set in the XML. The JDBC repository's Javadoc mentions "refresh the cache" but no refresh code exists. New vets inserted in the database after the first call are not shown until restart.
- **Conditions**: Calls through the Spring proxy of `ClinicServiceImpl`.
- **Affected Entities**: Vet
- **Action/Consequence**: Stale data is possible; reduces database load.
- **Governing Setting**: Not externalised. Cache names are fixed in `tools-config.xml`; the only toggle is removing `<cache:annotation-driven/>`. Shipped default: cache on.
- **Evidence**:
  - [ClinicServiceImpl.java:98-103](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)
  - [tools-config.xml:37-47](../../../src/main/resources/spring/tools-config.xml)
- **Confidence**: HIGH
- **Related Rules**: VET-001

##### VET-005: Vets are read-only and unrelated to visits
- **Description**: `VetRepository` has only `findAll()`. `ClinicService` has no vet write method. No navigation entry or page offers vet maintenance. No relationship from `Visit` or `Pet` to `Vet` exists.
- **Conditions**: Always.
- **Affected Entities**: Vet, Specialty, Visit
- **Action/Consequence**: Because the data cannot be removed, there is no delete/retain question for vets.
- **Governing Setting**: -
- **Evidence**:
  - [VetRepository.java:38](../../../src/main/java/org/springframework/samples/petclinic/repository/VetRepository.java)
  - [menu.tag:25-28](../../../src/main/webapp/WEB-INF/tags/menu.tag)
- **Confidence**: HIGH
- **Related Rules**: VIS-002

##### VET-006: Vet-specialty link integrity
- **Description**: DDL rule. `vet_specialties` has no primary key in H2/HSQLDB.
- **Conditions**: Inserting link rows.
- **Affected Entities**: Vet, Specialty
- **Action/Consequence**: Dangling references fail at the database.
- **Governing Setting**: Maven profile `db.script` (default `h2`) decides which schema file is applied.
- **Evidence**:
  - [h2/schema.sql:27-28](../../../src/main/resources/db/h2/schema.sql)
  - [h2/data.sql:12-16](../../../src/main/resources/db/h2/data.sql): vet 2 radiology; vet 3 surgery and dentistry; vet 4 surgery; vet 5 radiology
- **Confidence**: HIGH
- **Related Rules**: VET-005

##### VET-007: Vet list published in three formats
- **Description**: `getVets()` wraps the service result in `Vets`. Content negotiation is fixed by path and `produces`.
- **Conditions**: GET /vets, /vets.json, /vets.xml.
- **Affected Entities**: Vet
- **Action/Consequence**: Same data in each format. The vet list page links to the XML and JSON forms.
- **Governing Setting**: -
- **Evidence**:
  - [VetController.java:51-63](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java)
  - [Vets.java:30-41](../../../src/main/java/org/springframework/samples/petclinic/model/Vets.java)
- **Confidence**: HIGH
- **Related Rules**: VET-001, VET-004

## Business Workflows

**View vets**: user opens Veterinarians (menu), list served from cache (VET-004), ordered (VET-001), specialties sorted (VET-002) and "none" shown when empty (VET-003); the same list is available as JSON and XML (VET-007).

## Cross-Module Rules

Vets and visits are independent: [visits.md](./visits.md) VIS-002.

## Appendix: Evidence Map

- [Vet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java), [Vets.java](../../../src/main/java/org/springframework/samples/petclinic/model/Vets.java): model rules
- [VetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java): endpoints
- [ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java): cache annotation
- [VetTests.java](../../../src/test/java/org/springframework/samples/petclinic/model/VetTests.java), [VetControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/VetControllerTests.java): tests

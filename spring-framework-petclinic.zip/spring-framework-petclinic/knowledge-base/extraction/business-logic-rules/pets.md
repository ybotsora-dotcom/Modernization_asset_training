---
tags:
  - extraction
  - business-logic-rules
---

# Business Logic Rules Documentation

**Generated**: 2026-11-11
**Repository/Project**: spring-framework-petclinic
**Scope**: Pets and pet types (pet registration, editing, type selection)

## Table of Contents
- [Executive Summary](#executive-summary)
- [Module Rules](#module-rules)
- [Business Workflows](#business-workflows)
- [Cross-Module Rules](#cross-module-rules)
- [Appendix: Evidence Map](#appendix-evidence-map)

## Executive Summary

Pet rules sit in a hand-written `PetValidator` (which replaces bean validation for the pet form), a duplicate-name check in `PetController`, a `PetTypeFormatter` that converts a submitted type name to a `PetType`, and the `Pet` entity. There are 9 rules: 6 Validation (including the date and type input-format rules), 1 Workflow, 1 Calculation and 1 Constraint. Edge cases from `PetControllerTests`, `PetTypeFormatterTests`, `PetTests` and `AbstractClinicServiceTests` are folded in.

## Module Rules

### Pets

#### Pet registration and editing

| Rule ID | Name | Type | Description | Conditions | Affected Entities | Action | Governing Setting | Evidence | Confidence | Related Rules |
|---------|------|------|-------------|------------|-------------------|--------|-------------------|----------|-----------|---------------|
| PET-001 | Pet name required | Validation | A pet must have a non-empty name. | Create or update pet form submitted | Pet | Field error "required" on name; pet not saved | - | [PetValidator.java:41-45](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java), [PetController.java:64-67](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java) | HIGH | PET-002, PET-003 |
| PET-002 | Pet type required only for new pets | Validation | The type is mandatory when the pet is new (no id); an existing pet is not re-checked for type. | pet.isNew() | Pet, PetType | Field error "required" on type | - | [PetValidator.java:47-50](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java), [PetControllerTests.java:108-118](../../../src/test/java/org/springframework/samples/petclinic/web/PetControllerTests.java) | HIGH | PET-001, PET-006 |
| PET-003 | Pet birth date required | Validation | A birth date must be supplied; there is no check that it is in the past. | Any pet form submission | Pet | Field error "required" on birthDate | - | [PetValidator.java:52-55](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java) | HIGH | PET-005 |
| PET-004 | Duplicate pet name per owner | Validation | An owner cannot get a second new pet whose name matches an existing saved pet of that owner, compared ignoring case. | Creating a pet (pet.isNew()) with non-empty name | Owner, Pet | Field error "already exists" on name; pet not saved | - | [PetController.java:77-85](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java), [Owner.java:115-137](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java) | HIGH | OWN-007 |
| PET-005 | Birth date input format yyyy/MM/dd | Validation | The birth date is accepted only in the pattern `yyyy/MM/dd` (for example 2015/02/12) and is stored as a LocalDate. | Pet form field birthDate | Pet.birthDate | Other formats cause a binding error on birthDate and the form is redisplayed | - | [Pet.java:48-50](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java), [PetControllerTests.java:66-75](../../../src/test/java/org/springframework/samples/petclinic/web/PetControllerTests.java) | HIGH | PET-003 |
| PET-006 | Pet type resolved by exact name | Validation | The submitted type text is converted to a PetType by case-sensitive name equality against the list of existing types; unknown text raises a parse error and nothing is created. | Pet form field type | PetType, Pet | `ParseException("type not found: ...")`, which surfaces as a binding error on type. Test: "Bird" resolves, "Fish" fails; printing uses the type name | - | [PetTypeFormatter.java:54-63](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java), [PetTypeFormatterTests.java:38-59](../../../src/test/java/org/springframework/samples/petclinic/web/PetTypeFormatterTests.java), [mvc-core-config.xml:41-47](../../../src/main/resources/spring/mvc-core-config.xml) | HIGH | PET-002 |
| PET-007 | Pet attached to owner and saved | Workflow | On create and update the pet is added to the owner from the URL path and then saved; the pet always belongs to exactly one owner. Pets cannot be moved to another owner through the UI. | POST /owners/{ownerId}/pets/new or .../pets/{petId}/edit with no errors | Owner, Pet | Pet persisted (insert when id is null, merge otherwise), redirect to owner details | - | [PetController.java:86-89,106-108](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java), [JpaPetRepositoryImpl.java:56-63](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaPetRepositoryImpl.java), [JdbcPetRepositoryImpl.java:87-115](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java) | HIGH | OWN-008 |
| PET-008 | Pet types listed alphabetically | Calculation | Pet types offered on the form are loaded ordered by name in all three persistence implementations. | Rendering the pet form | PetType | Sorted collection supplied as model attribute `types` | - | [PetController.java:49-52](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java), [JpaPetRepositoryImpl.java:45-49](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaPetRepositoryImpl.java), [SpringDataPetRepository.java:34-36](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataPetRepository.java) | HIGH | PET-006 |
| PET-009 | Pet must reference an existing type and owner | Constraint | The pets table requires type_id and owner_id (NOT NULL) with foreign keys to types and owners. | Any pet insert | Pet, PetType, Owner | Database rejects rows with a missing or unknown type or owner. The JDBC save dereferences `pet.getType().getId()`, so a null type there would fail in code first (inferred) | - | [h2/schema.sql:46-55](../../../src/main/resources/db/h2/schema.sql), [JdbcPetRepositoryImpl.java:108-115](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java) | HIGH | PET-002 |

**Detailed Rules**:

##### PET-001: Pet name required
- **Description**: `PetValidator.validate` rejects `name` with code "required" when `StringUtils.hasLength(name)` is false. The validator is installed with `dataBinder.setValidator(new PetValidator())` for the "pet" binder, so it replaces the default bean-validation for this form.
- **Conditions**: POST create or edit.
- **Affected Entities**: Pet
- **Action/Consequence**: The pet form is redisplayed. Tests assert `attributeHasErrors("pet")`, no errors on "owner", status 200.
- **Governing Setting**: -
- **Evidence**:
  - [PetValidator.java:41-45](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java)
  - [PetControllerTests.java:77-87](../../../src/test/java/org/springframework/samples/petclinic/web/PetControllerTests.java)
- **Confidence**: HIGH
- **Related Rules**: PET-002, PET-003

##### PET-002: Pet type required only for new pets
- **Description**: `pet.isNew() && pet.getType() == null` is the only condition. Note the edit form binds a fresh `Pet` object, with the id coming from the hidden form field, so a post without the id counts as new. Tests: an edit post lacking `type` reports pet errors.
- **Conditions**: Pet form submission.
- **Affected Entities**: Pet, PetType
- **Action/Consequence**: "required" error on type.
- **Governing Setting**: -
- **Evidence**:
  - [PetValidator.java:47-50](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java)
  - [createOrUpdatePetForm.jsp:21](../../../src/main/webapp/WEB-INF/jsp/pets/createOrUpdatePetForm.jsp): hidden id field
- **Confidence**: HIGH
- **Related Rules**: PET-001, PET-006

##### PET-003: Pet birth date required
- **Description**: Null birth date is rejected. No code compares the date with today, so future dates are accepted (verified by absence in `PetValidator` and `Pet`). The service test even creates a pet with `LocalDate.now()`.
- **Conditions**: Any pet form submission.
- **Affected Entities**: Pet
- **Action/Consequence**: "required" error on birthDate.
- **Governing Setting**: -
- **Evidence**:
  - [PetValidator.java:52-55](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java)
  - [AbstractClinicServiceTests.java:128-149](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java)
- **Confidence**: HIGH
- **Related Rules**: PET-005

##### PET-004: Duplicate pet name per owner
- **Description**: `StringUtils.hasLength(name) && pet.isNew() && owner.getPet(name, true) != null`. `getPet(name, true)` lower-cases both names and ignores pets that are themselves new (unsaved). The check is only on creation; renaming a pet on the edit form to an existing name is not checked (verified by absence in `processUpdateForm`).
- **Conditions**: POST /owners/{ownerId}/pets/new.
- **Affected Entities**: Owner, Pet
- **Action/Consequence**: `rejectValue("name","duplicate","already exists")`. The check is per owner, so different owners may have same-named pets (seed data has two owners with a pet called Lucky).
- **Governing Setting**: -
- **Evidence**:
  - [PetController.java:79-81](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
  - [Owner.java:125-137](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)
  - [h2/data.sql](../../../src/main/resources/db/h2/data.sql): Lucky for owners 7 and 10
- **Confidence**: HIGH
- **Related Rules**: OWN-007

##### PET-005: Birth date input format yyyy/MM/dd
- **Description**: `@DateTimeFormat(pattern = "yyyy/MM/dd")` on `Pet.birthDate`. Accepted input: one form only, for example `2015/02/12`; canonical stored value is a `LocalDate` (DB column DATE). The seed data uses ISO `yyyy-MM-dd` but that is SQL, not user input.
- **Conditions**: Form binding.
- **Affected Entities**: Pet.birthDate
- **Action/Consequence**: Unparseable text produces a type-mismatch binding error and the form is redisplayed (standard Spring behaviour, inferred).
- **Governing Setting**: -
- **Evidence**:
  - [Pet.java:48-50](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)
  - [PetControllerTests.java:66-75](../../../src/test/java/org/springframework/samples/petclinic/web/PetControllerTests.java): "2015/02/12"
- **Confidence**: HIGH
- **Related Rules**: PET-003, VIS-005

##### PET-006: Pet type resolved by exact name
- **Description**: The formatter fetches all types through `ClinicService.findPetTypes()` on every parse and returns the first with `getName().equals(text)`.
- **Conditions**: Field `type` submitted as text.
- **Affected Entities**: PetType, Pet
- **Action/Consequence**: Match gives the PetType; no match throws ParseException. Matching is case-sensitive: "hamster" matches, "Hamster" does not (seed names are lower case).
- **Governing Setting**: -
- **Evidence**:
  - [PetTypeFormatter.java:54-63](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java)
  - [PetTypeFormatterTests.java:46-59](../../../src/test/java/org/springframework/samples/petclinic/web/PetTypeFormatterTests.java)
- **Confidence**: HIGH
- **Related Rules**: PET-002

##### PET-007: Pet attached to owner and saved
- **Description**: Creation calls `owner.addPet(pet)` then `savePet`. The owner comes from `@ModelAttribute findOwner(ownerId)`. In the edit handler the pet id and owner are not cross-checked: the pet is bound from form fields and attached to the owner in the URL.
- **Conditions**: Valid form.
- **Affected Entities**: Owner, Pet
- **Action/Consequence**: Redirect `/owners/{ownerId}`. Service tests: new pet gets an id; renaming pet 7 persists.
- **Governing Setting**: -
- **Evidence**:
  - [PetController.java:54-57,86-89,106-108](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
  - [AbstractClinicServiceTests.java:151-163](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java)
- **Confidence**: HIGH
- **Related Rules**: OWN-008

##### PET-008: Pet types listed alphabetically
- **Description**: `ORDER BY ptype.name` (JPA, Spring Data) and `ORDER BY name` (JDBC).
- **Conditions**: Pet form model population.
- **Affected Entities**: PetType
- **Action/Consequence**: Sorted selection list. Seed types: cat, dog, lizard, snake, bird, hamster.
- **Governing Setting**: -
- **Evidence**:
  - [JdbcPetRepositoryImpl.java:63-69](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java)
- **Confidence**: HIGH
- **Related Rules**: PET-006

##### PET-009: Pet must reference an existing type and owner
- **Description**: Constraint from the DDL. Visits also use the pet as parent (see VIS-006).
- **Conditions**: Pet insert.
- **Affected Entities**: Pet, PetType, Owner
- **Action/Consequence**: Database error on violation.
- **Governing Setting**: -
- **Evidence**:
  - [h2/schema.sql:46-55](../../../src/main/resources/db/h2/schema.sql)
- **Confidence**: HIGH
- **Related Rules**: PET-002

## Business Workflows

**Add a pet**: open the form (a new Pet is attached to the owner, PET-007), validate (PET-001 to PET-003, PET-005, PET-006), duplicate check (PET-004), save and redirect to the owner page.
**Edit a pet**: load the pet, post changes, same validators except the type requirement applies only to new pets (PET-002).

## Cross-Module Rules

Pet ordering and lookup on Owner: OWN-007. Visit ordering on Pet: VIS-003 in [visits.md](./visits.md).

## Appendix: Evidence Map

- [PetController.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java), [PetValidator.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetValidator.java), [PetTypeFormatter.java](../../../src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java): web rules
- [Pet.java](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java): entity mapping and date format
- [PetControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/PetControllerTests.java), [PetTypeFormatterTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/PetTypeFormatterTests.java): tests

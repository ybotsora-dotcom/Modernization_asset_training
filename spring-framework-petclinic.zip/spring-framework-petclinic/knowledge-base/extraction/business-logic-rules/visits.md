---
tags:
  - extraction
  - business-logic-rules
---

# Business Logic Rules Documentation

**Generated**: 2026-11-11
**Repository/Project**: spring-framework-petclinic
**Scope**: Visits (recording and listing a pet's clinic visits), including the question of whether a visit requires a vet

## Table of Contents
- [Executive Summary](#executive-summary)
- [Module Rules](#module-rules)
- [Business Workflows](#business-workflows)
- [Cross-Module Rules](#cross-module-rules)
- [Appendix: Evidence Map](#appendix-evidence-map)

## Executive Summary

**Does a visit require a vet? No. The code neither requires nor records one.** `Visit` has only `id`, `date`, `description` and `pet` ([Visit.java:40-56](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)); the `visits` table has only `id`, `pet_id`, `visit_date`, `description` in all four database scripts; the visit form offers only Date and Description; `VisitController` and `ClinicService.saveVisit` never mention a vet; and no test sets or asserts a vet on a visit. The only vet tables are `vets`, `specialties` and `vet_specialties`, none of which reference visits. See VIS-002 for the full evidence. The only mandatory visit input is a non-empty description (VIS-001). A requirement that a visit be assigned to a vet is therefore a stakeholder expectation not implemented in this codebase.

There are 9 rules: 2 Validation, 3 Constraint, 2 Calculation and 2 Workflow. Edge cases from `VisitControllerTests`, `PetTests` and `AbstractClinicServiceTests` are folded in.

## Module Rules

### Visits

#### Recording and listing visits

| Rule ID | Name | Type | Description | Conditions | Affected Entities | Action | Governing Setting | Evidence | Confidence | Related Rules |
|---------|------|------|-------------|------------|-------------------|--------|-------------------|----------|-----------|---------------|
| VIS-001 | Visit description required | Validation | A visit must have a non-empty description. | POST new visit form | Visit | Form redisplayed with an error on description; visit not saved | - | [Visit.java:47-49](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java), [VisitController.java:75-79](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [VisitControllerTests.java:59-67](../../../src/test/java/org/springframework/samples/petclinic/web/VisitControllerTests.java) | HIGH | VIS-002, VIS-008 |
| VIS-002 | A visit does not require or record a vet | Constraint | A visit is linked only to a pet. No vet is required, selectable, stored or validated anywhere; the visit form and table have no vet field. | Creating any visit | Visit, Pet, Vet | A visit with date and description and no vet is saved successfully | - | [Visit.java:40-56](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java), [h2/schema.sql:57-64](../../../src/main/resources/db/h2/schema.sql), [createOrUpdateVisitForm.jsp:37-49](../../../src/main/webapp/WEB-INF/jsp/pets/createOrUpdateVisitForm.jsp), [VisitController.java:60-83](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [AbstractClinicServiceTests.java:176-190](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java) | HIGH | VIS-001, VET-005 |
| VIS-003 | Pet visits shown newest first | Calculation | A pet's visits are returned as a read-only list sorted by visit date, descending. | Reading pet.visits | Pet, Visit | Sorted unmodifiable list; empty list for a pet without visits | - | [Pet.java:99-103](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java), [PetTests.java:22-67](../../../src/test/java/org/springframework/samples/petclinic/model/PetTests.java) | HIGH | VIS-004 |
| VIS-004 | Visit date defaults to today | Calculation | A new Visit gets today's date at construction; the user may overwrite it. | new Visit() | Visit.date | Date prefilled with the current local date | - | [Visit.java:62-64](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java) | HIGH | VIS-005 |
| VIS-005 | Visit date format yyyy/MM/dd, not validated further | Validation | The date text is parsed with pattern `yyyy/MM/dd` into a LocalDate. There is no not-null or past/future check, so a past, future or (through an empty field) possibly null date is not rejected by the code. | Visit form field date | Visit.date | Unparseable text yields a binding error; otherwise any date is accepted | - | [Visit.java:40-42](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java), [h2/schema.sql:60](../../../src/main/resources/db/h2/schema.sql) | MEDIUM | VIS-003, VIS-004 |
| VIS-006 | Visit must belong to an existing pet | Constraint | `pet_id` is NOT NULL with a foreign key to pets. The controller loads the pet by the path petId before binding and attaches the new visit to it. | Any visit insert | Visit, Pet | Database rejects a visit without a valid pet; JDBC `findByPetId` uses `.single()` and errors for an unknown pet | - | [h2/schema.sql:57-64](../../../src/main/resources/db/h2/schema.sql), [VisitController.java:60-66](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [JdbcVisitRepositoryImpl.java:78-97](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java) | HIGH | PET-009 |
| VIS-007 | Visits are insert-only in JDBC mode | Constraint | With the `jdbc` profile, saving a visit that already has an id throws `UnsupportedOperationException("Visit update not supported")`. JPA persists when the id is null and merges otherwise, so update is possible there; no controller offers visit editing or deletion. | Visit.save with id set | Visit | Exception under jdbc; merge under jpa. Spring Data uses its generic save | Spring profile `jpa` (default) / `jdbc` / `spring-data-jpa` | [JdbcVisitRepositoryImpl.java:55-64](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java), [JpaVisitRepositoryImpl.java:47-54](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVisitRepositoryImpl.java) | HIGH | PLT-001 |
| VIS-008 | Add-visit workflow | Workflow | `@ModelAttribute` loads the pet and attaches a new Visit to it before the form is shown or processed; on a valid post the visit is saved and the user is redirected to the owner page. The `id` field is not bindable. | GET/POST /owners/{ownerId}/pets/{petId}/visits/new | Pet, Visit | Redirect `/owners/{ownerId}`. The owner id in the path is not checked against the pet's actual owner (GET uses `*`) | - | [VisitController.java:45-83](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [VisitControllerTests.java:42-57](../../../src/test/java/org/springframework/samples/petclinic/web/VisitControllerTests.java) | HIGH | VIS-001, VIS-006 |
| VIS-009 | Visit list endpoint targets a view that is not in the repo | Workflow | GET /owners/*/pets/{petId}/visits puts the pet's visits in the model and returns view name `visitList`; no `visitList.jsp` exists under WEB-INF/jsp, so the endpoint would resolve to a missing view when run for real (the standalone MockMvc test only checks the view name). | GET /owners/*/pets/{petId}/visits | Pet, Visit | Model attribute `visits` set; rendering fails at runtime (inferred, not executed) | - | [VisitController.java:85-89](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [VisitControllerTests.java:69-75](../../../src/test/java/org/springframework/samples/petclinic/web/VisitControllerTests.java) | MEDIUM | VIS-003 |

**Detailed Rules**:

##### VIS-001: Visit description required
- **Description**: `@NotEmpty` on `description`. The date has no such annotation.
- **Conditions**: POST /owners/{ownerId}/pets/{petId}/visits/new with `@Valid Visit`.
- **Affected Entities**: Visit
- **Action/Consequence**: `result.hasErrors()` returns `pets/createOrUpdateVisitForm`. Edge case from tests: a post carrying only an irrelevant `name` parameter (no description) gives status 200, errors on "visit" and the form view; a post with description gives a 3xx redirect.
- **Governing Setting**: -
- **Evidence**:
  - [Visit.java:47-49](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)
  - [VisitControllerTests.java:49-67](../../../src/test/java/org/springframework/samples/petclinic/web/VisitControllerTests.java)
- **Confidence**: HIGH
- **Related Rules**: VIS-002, VIS-008

##### VIS-002: A visit does not require or record a vet
- **Description**: Stakeholders disagree on whether a visit needs a vet; this is exactly what the code enforces. Searched evidence:
  1. Entity `Visit` declares date, description and pet only; there is no Vet reference ([Visit.java:40-56](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)). A text search for "vet" in `Visit.java`, `VisitController.java`, `VisitRepository.java` and `createOrUpdateVisitForm.jsp` returned nothing.
  2. Table `visits` has columns id, pet_id, visit_date, description (H2 [schema.sql:57-64](../../../src/main/resources/db/h2/schema.sql); HSQLDB identical; MySQL [schema.sql:55-62](../../../src/main/resources/db/mysql/schema.sql); PostgreSQL [schema.sql:75-82](../../../src/main/resources/db/postgresql/schema.sql)). No vet_id column.
  3. The only column named `vet_id` in the whole source tree is in `vet_specialties`, which links vets to specialties.
  4. The visit form renders Date and Description inputs and a hidden petId; there is no vet selector ([createOrUpdateVisitForm.jsp:37-49](../../../src/main/webapp/WEB-INF/jsp/pets/createOrUpdateVisitForm.jsp)).
  5. `VisitController.processNewVisitForm` only validates and calls `saveVisit` ([VisitController.java:75-83](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)); `ClinicServiceImpl.saveVisit` delegates straight to the repository ([ClinicServiceImpl.java:79-83](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)).
  6. Tests: `shouldAddNewVisitForPet` saves a visit with only a description (date defaulted) and passes; no test mentions a vet on a visit ([AbstractClinicServiceTests.java:176-190](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java)).
  7. The vets page lists names and specialties only; it shows no visits ([vetList.jsp:19-31](../../../src/main/webapp/WEB-INF/jsp/vets/vetList.jsp)).
- **Conditions**: Creating any visit.
- **Affected Entities**: Visit, Pet, Vet
- **Action/Consequence**: A visit is saved without any vet. A vet cannot be assigned or later queried per visit. Making a vet mandatory would be a new rule requiring schema, entity, form and validation changes in all three persistence implementations.
- **Governing Setting**: -
- **Evidence**:
  - [Visit.java:33-121](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)
  - [h2/data.sql](../../../src/main/resources/db/h2/data.sql): the four seed visits are `(default, pet_id, date, description)` with no vet
- **Confidence**: HIGH
- **Related Rules**: VIS-001, VET-005

##### VIS-003: Pet visits shown newest first
- **Description**: `getVisits()` copies the set and sorts by `Visit::getDate` reversed. A null date would break the comparator (inferred). Tests: empty list when none, two returned, newest first.
- **Conditions**: Any read of pet.visits, including the owner page and the visit form's "Previous Visits".
- **Affected Entities**: Pet, Visit
- **Action/Consequence**: Sorted unmodifiable list. Visits are fetched EAGER with the pet.
- **Governing Setting**: -
- **Evidence**:
  - [Pet.java:60-61,99-103](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)
  - [PetTests.java:49-67](../../../src/test/java/org/springframework/samples/petclinic/model/PetTests.java)
- **Confidence**: HIGH
- **Related Rules**: VIS-004

##### VIS-004: Visit date defaults to today
- **Description**: Constructor sets `date = LocalDate.now()`. `AbstractClinicServiceTests` relies on it: the new visit only gets a description and is stored with a date.
- **Conditions**: Visit instantiation.
- **Affected Entities**: Visit.date
- **Action/Consequence**: Form shows today's date; JDBC `findByPetId` test asserts saved visits have a non-null date.
- **Governing Setting**: -
- **Evidence**:
  - [Visit.java:62-64](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)
  - [AbstractClinicServiceTests.java:192-200](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java)
- **Confidence**: HIGH
- **Related Rules**: VIS-005

##### VIS-005: Visit date format yyyy/MM/dd, not validated further
- **Description**: Accepted input form: `yyyy/MM/dd` only, canonical result `LocalDate` stored in a DATE column. `visit_date` is nullable in all schemas, and the entity has no `@NotNull`. Whether a cleared field binds null or fails was not verified by execution.
- **Conditions**: Visit form submission.
- **Affected Entities**: Visit.date
- **Action/Consequence**: As in the table.
- **Governing Setting**: -
- **Evidence**:
  - [Visit.java:40-42](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)
- **Confidence**: MEDIUM
- **Related Rules**: VIS-003, VIS-004, PET-005

##### VIS-006: Visit must belong to an existing pet
- **Description**: DDL foreign key `fk_visits_pets` plus the controller's pet lookup. JDBC `findByPetId` first loads the pet with `.single()`, so an unknown pet id raises an exception rather than an empty list; JPA returns an empty list for an unknown id (query on `v.pet.id`).
- **Conditions**: Visit insert or lookup by pet.
- **Affected Entities**: Visit, Pet
- **Action/Consequence**: Rejection or exception as described. Service test: pet 7 has 2 seed visits, each with pet and date set.
- **Governing Setting**: -
- **Evidence**:
  - [JpaVisitRepositoryImpl.java:57-63](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVisitRepositoryImpl.java)
  - [h2/schema.sql:63](../../../src/main/resources/db/h2/schema.sql)
- **Confidence**: HIGH
- **Related Rules**: PET-009

##### VIS-007: Visits are insert-only in JDBC mode
- **Description**: See table. `ClinicServiceImpl.findVisitsByPetId` has no `@Transactional` annotation (verified by reading the class).
- **Conditions**: Saving a visit with a non-null id.
- **Affected Entities**: Visit
- **Action/Consequence**: Profile-dependent behaviour; no UI path reaches it today.
- **Governing Setting**: Spring profile `jpa` default (set in `PetclinicInitializer.SPRING_PROFILE`); `jdbc` throws on update; `spring-data-jpa` uses the framework save; overridable with `-Dspring.profiles.active`.
- **Evidence**:
  - [JdbcVisitRepositoryImpl.java:62](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java)
  - [PetclinicInitializer.java:52,58](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)
- **Confidence**: HIGH
- **Related Rules**: PLT-001

##### VIS-008: Add-visit workflow
- **Description**: `loadPetWithVisit` runs on every request to the controller that has a petId, creates `new Visit()`, calls `pet.addVisit(visit)` (sets the back-reference) and exposes it as `visit`. Both id binding and the owner id are unchecked.
- **Conditions**: Visit form GET or POST.
- **Affected Entities**: Pet, Visit
- **Action/Consequence**: See table. The test stubs `findPetById` with an empty `Pet`.
- **Governing Setting**: -
- **Evidence**:
  - [VisitController.java:45-48,60-66](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)
  - [Pet.java:105-108](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)
- **Confidence**: HIGH
- **Related Rules**: VIS-001, VIS-006

##### VIS-009: Visit list endpoint targets a view that is not in the repo
- **Description**: `ls src/main/webapp/WEB-INF/jsp` shows only exception.jsp, owners, pets, vets and welcome.jsp. No menu or page links to this URL.
- **Conditions**: GET /owners/*/pets/{petId}/visits.
- **Affected Entities**: Pet, Visit
- **Action/Consequence**: Likely a dead endpoint (inferred).
- **Governing Setting**: -
- **Evidence**:
  - [VisitController.java:85-89](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java)
- **Confidence**: MEDIUM
- **Related Rules**: VIS-003

## Business Workflows

**Record a visit**: owner page, choose "Add Visit" for a pet, form shows pet details and previous visits newest first (VIS-003), user supplies date (default today, VIS-004/VIS-005) and description (VIS-001), save (VIS-008), return to owner page. No vet step exists (VIS-002).

## Cross-Module Rules

Visits cascade from Pet (`CascadeType.ALL`, EAGER fetch, [Pet.java:60-61](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)) and are therefore loaded with every owner fetch; see OWN-008. Vets are unrelated to visits (VET-005).

## Appendix: Evidence Map

- [Visit.java](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java): visit fields, defaults, validation
- [VisitController.java](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java): workflow
- [createOrUpdateVisitForm.jsp](../../../src/main/webapp/WEB-INF/jsp/pets/createOrUpdateVisitForm.jsp): form fields
- Schema scripts under `src/main/resources/db/*/schema.sql`: table definitions
- [VisitControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/VisitControllerTests.java), [PetTests.java](../../../src/test/java/org/springframework/samples/petclinic/model/PetTests.java), [AbstractClinicServiceTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java): tests

---
tags:
  - extraction
  - business-logic-rules
---

# Business Logic Rules Documentation

**Generated**: 2026-11-11
**Repository/Project**: spring-framework-petclinic
**Scope**: Owners (client records, owner search, owner form handling)

## Table of Contents
- [Executive Summary](#executive-summary)
- [Module Rules](#module-rules)
- [Business Workflows](#business-workflows)
- [Cross-Module Rules](#cross-module-rules)
- [Appendix: Evidence Map](#appendix-evidence-map)

## Executive Summary

The owner rules are almost entirely declarative bean-validation plus a small search workflow in `OwnerController`. There are 10 rules: 2 Validation (form fields), 3 Workflow (search, result routing, create/update), 3 Constraint (id binding, cascade with no delete, missing-owner lookup), 1 Calculation (pet ordering) and 1 Configuration (database-dependent search case sensitivity). No role-based authorization exists anywhere in the codebase. Edge cases drawn from `OwnerControllerTests`, `OwnerTests` and `AbstractClinicServiceTests` are folded into the rule text.

## Module Rules

### Owners

#### Owner data entry and validation

| Rule ID | Name | Type | Description | Conditions | Affected Entities | Action | Governing Setting | Evidence | Confidence | Related Rules |
|---------|------|------|-------------|------------|-------------------|--------|-------------------|----------|-----------|---------------|
| OWN-001 | Owner mandatory fields | Validation | firstName, lastName, address, city and telephone must all be non-empty. | Create or update owner form submitted | Owner | Form redisplayed with field errors; owner not saved | - | [Owner.java:46-57](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [Person.java:30-36](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java), [OwnerController.java:60-68](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) | HIGH | OWN-002, OWN-006 |
| OWN-002 | Telephone digits only, at most 10 integer digits | Validation | Telephone must be numeric with no fraction and at most 10 integer digits. | Create or update owner form submitted | Owner.telephone | Field error on telephone; owner not saved | - | [Owner.java:54-57](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [OwnerControllerTests.java:64-73](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java) | MEDIUM | OWN-001 |
| OWN-003 | Last-name prefix search | Workflow | Owner search matches every owner whose last name starts with the entered text; blank or absent text returns all owners. | GET /owners | Owner, Pet, Visit | Matching owners loaded with their pets (and visits) | - | [OwnerController.java:76-85](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [JpaOwnerRepositoryImpl.java:53-58](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java), [JdbcOwnerRepositoryImpl.java:70-82](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) | HIGH | OWN-004, OWN-009 |
| OWN-004 | Search result routing | Workflow | Zero results gives a "not found" error on lastName, exactly one result redirects to that owner, several results show a list. | Search returned 0, 1 or n owners | Owner | View selected by result count | - | [OwnerController.java:86-98](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [OwnerControllerTests.java:98-127](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java) | HIGH | OWN-003 |
| OWN-005 | Owner id cannot be bound from a request | Constraint | The `id` field is disallowed for data binding on owner forms (the pet and visit controllers apply the same restriction). | Any owner form post | Owner | A posted id is ignored | - | [OwnerController.java:48-51](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java) | HIGH | OWN-006 |
| OWN-006 | Owner create versus update | Workflow | New owners are persisted; updates take the id from the URL path and overwrite all editable fields. | POST /owners/new or /owners/{ownerId}/edit | Owner | Insert or update, then redirect to owner details | - | [OwnerController.java:60-68,108-117](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [JpaOwnerRepositoryImpl.java:71-77](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java), [JdbcOwnerRepositoryImpl.java:121-136](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java) | HIGH | OWN-001, OWN-005 |
| OWN-007 | Owner pets ordered by name | Calculation | An owner's pets are returned as a read-only list sorted by pet name, ignoring case. | Reading owner.pets | Owner, Pet | Sorted unmodifiable list; empty list when no pets | - | [Owner.java:98-102](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [OwnerTests.java:14-98](../../../src/test/java/org/springframework/samples/petclinic/model/OwnerTests.java) | HIGH | PET-004 |
| OWN-008 | Owner-to-pet cascade; no delete capability | Constraint | Persist and merge operations on an owner cascade to its pets (and from pets to visits); the application offers no delete operation for any entity. | Saving an owner | Owner, Pet, Visit | Child rows saved with the owner; nothing is ever removed | - | [Owner.java:59-60](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [OwnerRepository.java:42-60](../../../src/main/java/org/springframework/samples/petclinic/repository/OwnerRepository.java) | MEDIUM | PET-007 |
| OWN-009 | Search case sensitivity depends on database | Configuration | On H2 and HSQLDB `owners.last_name` is `VARCHAR_IGNORECASE`, so the prefix search ignores case; MySQL and PostgreSQL columns are plain VARCHAR. | Database chosen by Maven profile | Owner.last_name | Search is case-insensitive on H2/HSQLDB; on MySQL/PostgreSQL it follows the engine's LIKE behaviour (inferred) | Maven profile `db.script`, default `H2`; options H2, HSQLDB, MySQL, PostgreSQL | [h2/schema.sql:39](../../../src/main/resources/db/h2/schema.sql), [mysql/schema.sql:37](../../../src/main/resources/db/mysql/schema.sql), [postgresql/schema.sql:47](../../../src/main/resources/db/postgresql/schema.sql) | MEDIUM | OWN-003 |
| OWN-010 | Missing owner lookup fails | Constraint | Loading an owner id that does not exist raises an error instead of returning null. | GET /owners/{ownerId} with unknown id | Owner | JDBC throws `ObjectRetrievalFailureException`; JPA `getSingleResult` throws (inferred, not tested); the generic error view is shown | - | [JdbcOwnerRepositoryImpl.java:88-104](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java), [JpaOwnerRepositoryImpl.java:61-68](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java) | MEDIUM | PLT-004 |

**Detailed Rules**:

##### OWN-001: Owner mandatory fields
- **Description**: `address`, `city` and `telephone` carry `@NotEmpty` on Owner; `firstName` and `lastName` carry it on the Person superclass.
- **Conditions**: POST /owners/new or /owners/{ownerId}/edit with `@Valid Owner`.
- **Affected Entities**: Owner
- **Action/Consequence**: `result.hasErrors()` returns the form view `owners/createOrUpdateOwnerForm`. Tests post without address and telephone and assert field errors on both and status 200. `ValidatorTests` confirms an empty firstName yields exactly one violation, message "must not be empty". There is no length validation: DB columns are VARCHAR(30) names, 255 address, 80 city, 20 telephone, so over-long input would fail at the database (inferred).
- **Governing Setting**: -
- **Evidence**:
  - [Owner.java:46-57](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java): annotations
  - [OwnerControllerTests.java:76-88,155-167](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java): create and update with missing fields
  - [ValidatorTests.java:37-52](../../../src/test/java/org/springframework/samples/petclinic/model/ValidatorTests.java): empty firstName
- **Confidence**: HIGH
- **Related Rules**: OWN-002, OWN-006

##### OWN-002: Telephone digits only, at most 10 integer digits
- **Description**: `@Digits(fraction = 0, integer = 10)` on a String field. Hibernate Validator parses the string as a number, so leading zeros are not counted.
- **Conditions**: Owner form submitted.
- **Affected Entities**: Owner.telephone
- **Action/Consequence**: Non-numeric or more than 10 significant digits is rejected. Edge case from tests: the success tests post `01316761638` and `01616291589` (11 characters, leading zero) and expect a redirect, which is consistent with the leading zero not counting (inferred from validator behaviour, not read in library source).
- **Governing Setting**: -
- **Evidence**:
  - [Owner.java:54-57](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java): annotations
  - [OwnerControllerTests.java:64-73,142-153](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java): 11-character numbers accepted
- **Confidence**: MEDIUM
- **Related Rules**: OWN-001

##### OWN-003: Last-name prefix search
- **Description**: The JPA and JDBC repositories bind `lastName + "%"` to a LIKE query; the Spring Data version writes `:lastName%` in its query. A null lastName becomes "" before the call, so a parameterless GET /owners lists everyone.
- **Conditions**: GET /owners.
- **Affected Entities**: Owner, Pet, Visit
- **Action/Consequence**: JPA uses `left join fetch owner.pets` so owners without pets are still returned; JDBC loads pets and visits per owner. Test data: "Davis" returns 2 owners, "Daviss" returns none.
- **Governing Setting**: -
- **Evidence**:
  - [OwnerController.java:79-85](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java): null-to-empty rule
  - [SpringDataOwnerRepository.java:34-36](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java): query
  - [AbstractClinicServiceTests.java:58-65](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java): Davis and Daviss
- **Confidence**: HIGH
- **Related Rules**: OWN-004, OWN-009

##### OWN-004: Search result routing
- **Description**: 0 results: `rejectValue("lastName","notFound","not found")` and the find form is redisplayed. 1 result: redirect to `/owners/{id}`. More than 1: model attribute `selections` and view `owners/ownersList`.
- **Conditions**: After OWN-003.
- **Affected Entities**: Owner
- **Action/Consequence**: As described. Tests: empty-string search with two owners gives the list; "Franklin" with one owner redirects; an unknown surname gives field error code `notFound`.
- **Governing Setting**: -
- **Evidence**:
  - [OwnerController.java:86-98](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java): branches
  - [OwnerControllerTests.java:98-127](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java): all three outcomes
- **Confidence**: HIGH
- **Related Rules**: OWN-003

##### OWN-005: Owner id cannot be bound from a request
- **Description**: `dataBinder.setDisallowedFields("id")` on the owner controller (and the owner binder in the pet controller).
- **Conditions**: Any binding of an Owner.
- **Affected Entities**: Owner
- **Action/Consequence**: A posted `id` is silently ignored; the update path sets the id explicitly from the URL.
- **Governing Setting**: -
- **Evidence**:
  - [OwnerController.java:48-51,114](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
  - [PetController.java:59-62](../../../src/main/java/org/springframework/samples/petclinic/web/PetController.java)
- **Confidence**: HIGH
- **Related Rules**: OWN-006

##### OWN-006: Owner create versus update
- **Description**: JPA persists when id is null, otherwise merges; JDBC inserts via `SimpleJdbcInsert` when `isNew()`, otherwise runs an UPDATE of the five editable columns. `BaseEntity.isNew()` is simply `id == null`.
- **Conditions**: Valid form.
- **Affected Entities**: Owner
- **Action/Consequence**: Creation redirects to `/owners/{newId}`; update redirects to `/owners/{ownerId}`. Service tests confirm id generation on insert and name change on update.
- **Governing Setting**: -
- **Evidence**:
  - [BaseEntity.java:43-45](../../../src/main/java/org/springframework/samples/petclinic/model/BaseEntity.java): isNew
  - [AbstractClinicServiceTests.java:76-108](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java): insert and update
- **Confidence**: HIGH
- **Related Rules**: OWN-001, OWN-005

##### OWN-007: Owner pets ordered by name
- **Description**: `getPets()` copies the internal set, sorts by `Pet::getName` with `String.CASE_INSENSITIVE_ORDER` and wraps it unmodifiable. Tests: Alpha, buddy, ZEPHYR order; empty list for a new owner; list cannot be modified.
- **Conditions**: Any read of owner.pets.
- **Affected Entities**: Owner, Pet
- **Action/Consequence**: Stable display order; callers must use `addPet` to add. A pet with a null name would fail the comparator (inferred).
- **Governing Setting**: -
- **Evidence**:
  - [Owner.java:87-107](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)
  - [OwnerTests.java:14-98](../../../src/test/java/org/springframework/samples/petclinic/model/OwnerTests.java)
- **Confidence**: HIGH
- **Related Rules**: PET-004

##### OWN-008: Owner-to-pet cascade; no delete capability
- **Description**: `@OneToMany(cascade = ALL, mappedBy = "owner")` on Owner.pets. No repository interface declares a delete method and no controller maps a delete or removal; a repository-wide grep for delete found nothing in `src/main`. So no data is ever destroyed by the application and there is nothing to restore.
- **Conditions**: Saving an owner.
- **Affected Entities**: Owner, Pet, Visit
- **Action/Consequence**: Save/merge of an owner flows to pets and their visits (JPA annotation; the JDBC implementation has no cascade and saves each entity through its own repository call).
- **Governing Setting**: -
- **Evidence**:
  - [Owner.java:59-60](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)
  - [OwnerRepository.java:42-60](../../../src/main/java/org/springframework/samples/petclinic/repository/OwnerRepository.java): find and save only
- **Confidence**: MEDIUM
- **Related Rules**: PET-007

##### OWN-009: Search case sensitivity depends on database
- **Description**: Only H2 and HSQLDB schemas declare `last_name VARCHAR_IGNORECASE(30)` for owners. The MySQL and PostgreSQL schemas use VARCHAR(30). The code adds no lower-casing of its own.
- **Conditions**: Database chosen with the Maven `-P` profile.
- **Affected Entities**: Owner.last_name
- **Action/Consequence**: Case-insensitive prefix match on H2/HSQLDB. Behaviour on MySQL/PostgreSQL depends on collation or LIKE semantics and was not verified (inferred).
- **Governing Setting**: `db.script` (Maven profile, set in pom.xml), default `h2`; options `h2`, `hsqldb`, `mysql`, `postgresql`.
- **Evidence**:
  - [h2/schema.sql:39](../../../src/main/resources/db/h2/schema.sql)
  - [pom.xml:522-527](../../../pom.xml)
- **Confidence**: MEDIUM
- **Related Rules**: OWN-003, PLT-002

##### OWN-010: Missing owner lookup fails
- **Description**: JDBC `findById` catches `EmptyResultDataAccessException` and throws `ObjectRetrievalFailureException`. JPA uses `getSingleResult`, which throws if no row exists. The controller adds no handling.
- **Conditions**: Unknown owner id in a URL.
- **Affected Entities**: Owner
- **Action/Consequence**: Exception propagates to the `SimpleMappingExceptionResolver` and the `exception` view.
- **Governing Setting**: -
- **Evidence**:
  - [JdbcOwnerRepositoryImpl.java:99-101](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcOwnerRepositoryImpl.java)
  - [mvc-core-config.xml:60-66](../../../src/main/resources/spring/mvc-core-config.xml)
- **Confidence**: MEDIUM
- **Related Rules**: PLT-004

## Business Workflows

**Find and open an owner**: GET /owners/find, then GET /owners with optional lastName (OWN-003), routing by result count (OWN-004), then GET /owners/{id} details with pets and visits (OWN-007).

**Register or edit an owner**: validate (OWN-001, OWN-002), ignore a posted id (OWN-005), save (OWN-006), redirect to details.

## Cross-Module Rules

Pet ordering and duplicate-name checks that rely on the owner's pet set are in [pets.md](./pets.md) (PET-004). Cascade to visits is covered with OWN-008 and VIS-004.

## Appendix: Evidence Map

- [OwnerController.java](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java): all owner web rules
- [Owner.java](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [Person.java](../../../src/main/java/org/springframework/samples/petclinic/model/Person.java): validation and pet ordering
- JPA, JDBC and Spring Data owner repositories under `src/main/java/org/springframework/samples/petclinic/repository/`: search and save
- [OwnerControllerTests.java](../../../src/test/java/org/springframework/samples/petclinic/web/OwnerControllerTests.java), [OwnerTests.java](../../../src/test/java/org/springframework/samples/petclinic/model/OwnerTests.java), [AbstractClinicServiceTests.java](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java): test evidence

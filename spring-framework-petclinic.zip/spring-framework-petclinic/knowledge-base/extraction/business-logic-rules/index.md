---
tags:
  - extraction
  - business-logic-rules
---

# Business Logic Rules: Index

**Generated**: 2026-11-11
**Repository/Project**: spring-framework-petclinic
**Scope**: All of `src/main` and `src/test` (Java, XML configuration, SQL schema and seed scripts, JSP views). The `.claude/` folder was ignored.

## Module Files

- [owners.md](./owners.md): owner data entry, search, pet ordering (10 rules, OWN-001 to OWN-010)
- [pets.md](./pets.md): pet registration, validation, type conversion (9 rules, PET-001 to PET-009)
- [visits.md](./visits.md): visit recording and listing, including the vet question (9 rules, VIS-001 to VIS-009)
- [vets.md](./vets.md): read-only vet directory, caching, JSON/XML output (7 rules, VET-001 to VET-007)
- [platform.md](./platform.md): profiles, database selection, monitoring, errors, transactions (5 rules, PLT-001 to PLT-005)

## Rule Count by Category (40 rules)

| Category | Count |
|----------|-------|
| Validation | 10 |
| Workflow | 8 |
| Calculation | 7 |
| Constraint | 10 |
| Configuration | 5 |
| Authorization | 0 |
| StateTransition | 0 |

## Answer to the disputed question: does a visit require a vet?

**No. The code does not require, record or validate a vet on a visit.** Details and file:line evidence are in [visits.md](./visits.md) rule VIS-002. In short: `Visit` has only date, description and pet ([Visit.java:40-56](../../../src/main/java/org/springframework/samples/petclinic/model/Visit.java)); the `visits` table has no vet column in any of the four database scripts (for example [h2/schema.sql:57-64](../../../src/main/resources/db/h2/schema.sql)); the form has only Date and Description ([createOrUpdateVisitForm.jsp:37-49](../../../src/main/webapp/WEB-INF/jsp/pets/createOrUpdateVisitForm.jsp)); the controller and service never touch a vet ([VisitController.java:75-83](../../../src/main/java/org/springframework/samples/petclinic/web/VisitController.java), [ClinicServiceImpl.java:79-83](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)); and the service test saves a visit with only a description ([AbstractClinicServiceTests.java:176-190](../../../src/test/java/org/springframework/samples/petclinic/service/AbstractClinicServiceTests.java)). The only mandatory visit field is the description (VIS-001). Any requirement to assign a vet is not implemented. Vets themselves are a read-only list (VET-005).

## Key Workflows

- Find and open an owner: OWN-003, OWN-004
- Register or edit an owner: OWN-001, OWN-002, OWN-005, OWN-006
- Add or edit a pet: PET-001 to PET-007
- Record a visit: VIS-001, VIS-004, VIS-008
- View vets: VET-004, VET-007

## Cross-Module Rules

- Visits and vets are independent (VIS-002, VET-005).
- The Spring profile changes visit-update and vet-ordering behaviour (PLT-001 with VIS-007, VET-001).
- The Maven database profile changes owner search case sensitivity (PLT-002 with OWN-009).
- Cascade from Owner to Pet to Visit with no delete operation anywhere (OWN-008).

## Rule-Engine Analysis

No database-resident rule engine was detected. Business operations are dispatched through ordinary Spring MVC controller methods and `ClinicService` calls resolved in source; there is no `(Module, Action)` event dispatch, no handler or task tables, and the SQL scripts contain only DDL and seed `INSERT` statements (no stored procedures, functions, views or triggers). Therefore `taskengine-inferred-mapping.md` was intentionally not created.

## Other Source Tiers and Gaps

- Stored procedures, views, triggers: none exist (verified by listing `src/main/resources/db`). Database rules are the DDL constraints (keys and NOT NULLs) captured in PET-009, VIS-006 and VET-006.
- Authorization: none. No security framework or role check exists in `src/main` or `pom.xml`.
- Delete behaviour: no delete operation exists, so cascade deletion and retention questions do not arise (OWN-008).
- Not verified (no execution allowed): MySQL/PostgreSQL case-sensitivity behaviour (OWN-009), exact `@Digits` handling of leading zeros (OWN-002), runtime outcome of the missing `visitList` view (VIS-009), Spring Data vet ordering (VET-001). These are marked MEDIUM.
- AI: the project profile reports no AI artifacts, so no `aiRef` entries are recorded.

See also: [repository/index.md](../repository/index.md)

---
tags:
  - extraction
  - repository
---
# Repository Structure Overview — spring-framework-petclinic

## Projects Identified

### spring-framework-petclinic
**Location**: `.` (repository root)
**Type**: Application (WAR) — confidence: HIGH. Evidence: [pom.xml:10](../../../pom.xml) `<packaging>war</packaging>`
**Build System**: Maven (wrapper `mvnw`, `.mvn/`) — confidence: HIGH. Evidence: [pom.xml](../../../pom.xml)
**Primary Language**: Java 17 (`java.version`, [pom.xml:17](../../../pom.xml)); CI matrix runs 17 and 21 ([maven-build-main.yml:16](../../../.github/workflows/maven-build-main.yml))

**Modules** (Java packages under `org.springframework.samples.petclinic`, single Maven module; no `<modules>` in pom):
- `model`: JPA entities and DTOs — `BaseEntity`, `NamedEntity`, `Person`, `Owner`, `Pet`, `PetType`, `Vet`, `Vets`, `Specialty`, `Visit` ([src/main/java/.../model](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java)). HIGH
- `repository`: interfaces `OwnerRepository`, `PetRepository`, `VetRepository`, `VisitRepository` ([OwnerRepository.java](../../../src/main/java/org/springframework/samples/petclinic/repository/OwnerRepository.java)). HIGH
- `repository.jpa`: plain-JPA implementations (`Jpa*RepositoryImpl`), active under Spring profile `jpa`. HIGH ([business-config.xml:84-92](../../../src/main/resources/spring/business-config.xml))
- `repository.jdbc`: Spring JDBC implementations (`Jdbc*RepositoryImpl`, row mappers, `OneToManyResultSetExtractor`), profile `jdbc`. HIGH ([business-config.xml:66-82](../../../src/main/resources/spring/business-config.xml))
- `repository.springdatajpa`: Spring Data JPA interfaces (`SpringData*Repository`), profile `spring-data-jpa`, wired by `<jpa:repositories>`. HIGH ([business-config.xml:94-96](../../../src/main/resources/spring/business-config.xml))
- `service`: `ClinicService` / `ClinicServiceImpl` (`@Transactional`, `@Cacheable("vets")`) ([ClinicServiceImpl.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)). HIGH
- `web`: Spring MVC controllers (`OwnerController`, `PetController`, `VisitController`, `VetController`, `CrashController`), `PetValidator`, `PetTypeFormatter`. HIGH
- `util`: `CallMonitoringAspect` (AOP + JMX `@ManagedResource`), `EntityUtils` ([tools-config.xml](../../../src/main/resources/spring/tools-config.xml)). HIGH
- `PetclinicInitializer` (root package): programmatic servlet bootstrap replacing web.xml. HIGH
- Non-Java assets: JSPs `src/main/webapp/WEB-INF/jsp/{owners,pets,vets}`, JSP tag files `WEB-INF/tags`, static `resources/{css,fonts,images,scss}`, SQL scripts `src/main/resources/db/{h2,hsqldb,mysql,postgresql}`, i18n `messages/messages{,_de,_en,_es}.properties`.

**Build Files**: [pom.xml](../../../pom.xml), [.mvn/](../../../.mvn), [mvnw](../../../mvnw), [mvnw.cmd](../../../mvnw.cmd)

**Entry Points**:
- Application: `org.springframework.samples.petclinic.PetclinicInitializer` (extends `AbstractDispatcherServletInitializer`; root context `business-config.xml` + `tools-config.xml`, servlet context `mvc-core-config.xml`, mapping `/`) — [PetclinicInitializer.java:39-79](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java). HIGH. No `main()` method and no `web.xml`: the pom sets `failOnMissingWebXml=false`.
- Default persistence profile: `SPRING_PROFILE = "jpa"` ([PetclinicInitializer.java:52](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)), applied via `setDefaultProfiles`, so `-Dspring.profiles.active` overrides it.
- HTTP routes (annotation mappings): `/` (`<mvc:view-controller path="/" view-name="welcome"/>` in mvc-core-config.xml), `/owners/find`, `/owners`, `/owners/new`, `/owners/{ownerId}`, `/owners/{ownerId}/edit`, `/owners/{ownerId}/pets/new`, `/owners/{ownerId}/pets/{petId}/edit`, `/owners/{ownerId}/pets/{petId}/visits/new`, `/owners/*/pets/{petId}/visits`, `/vets`, `/vets.json`, `/vets.xml`, `/oups`. Evidence: `@GetMapping`/`@PostMapping` in [web/](../../../src/main/java/org/springframework/samples/petclinic/web).- Run: `./mvnw jetty:run-war` ([readme.md:23](../../../readme.md)); container image via `jib-maven-plugin` ([pom.xml:471-491](../../../pom.xml)).
- Tests: `./mvnw test` (surefire includes `**/*Tests.java`, [pom.xml:375-377](../../../pom.xml)); test classes under [src/test/java](../../../src/test/java/org/springframework/samples/petclinic) (`model`, `service`, `web`).

**Key Dependencies**:
- Internal: none (single module). Layering web -> service -> repository interfaces -> one of three implementation packages.
- External (versions from [pom.xml](../../../pom.xml)): Spring Framework 7.0.8 (webmvc, jdbc, orm, context-support, oxm, test); Spring Data JPA (BOM 2025.1.5); Hibernate ORM 7.4.0.Final (+ hibernate-jcache), Hibernate Validator 9.1.0.Final; Jakarta Persistence 3.2.0; Servlet API 6.1.0 (provided); JSTL 3.0; Jackson 3.2.1 (`tools.jackson`); Caffeine 3.2.4; AspectJ weaver 1.9.25.1; tomcat-jdbc 11.0.18 pool; Logback 1.6.1 / SLF4J 2.0.17; JAXB 4.0; WebJars Bootstrap 5.3.8, Font Awesome 4.7.0, Flatpickr 4.6.13. Test: JUnit Jupiter 6.1.2, AssertJ 3.27.7, Mockito 5.23.0, Hamcrest 3.0, JsonPath 2.10.0, JaCoCo 0.8.15. Confidence HIGH.
- Note: pom comment mentions `EhCacheCacheManager`, but the actual cache manager is `CaffeineCacheManager` ([tools-config.xml](../../../src/main/resources/spring/tools-config.xml)); the pom comment is stale (HIGH).

**Technologies**: Spring Framework (XML config, not Spring Boot), Spring MVC + JSP/JSTL + tag files, Spring Data JPA, Hibernate/JPA, Spring JDBC (`JdbcClient`, `NamedParameterJdbcTemplate`), Caffeine cache (`cacheNames` `default`, `vets`), AspectJ/AOP + JMX call monitor, Bean Validation. Databases: H2 (default), HSQLDB, MySQL, PostgreSQL.

**Database (Maven profile) axis** — [pom.xml:520-599](../../../pom.xml): `H2` (activeByDefault, `jdbc:h2:mem:petclinic`), `HSQLDB` (`jdbc:hsqldb:mem:petclinic`), `MySQL` (`jdbc:mysql://localhost:3306/petclinic`), `PostgreSQL` (`jdbc:postgresql://localhost:5432/petclinic`). Each sets `db.script`, `jpa.database`, `jdbc.*` placeholders, resolved by resource filtering into [data-access.properties](../../../src/main/resources/spring/data-access.properties). A further `css` profile recompiles `resources/scss` to CSS with libsass.

**Persistence (Spring profile) axis** — `jpa` (default), `jdbc`, `spring-data-jpa`; the two axes are independent. HIGH.

**Schema initialisation**: `<jdbc:initialize-database>` runs `schema.sql` and `data.sql` from `db/${db.script}` at startup ([datasource-config.xml:34-37](../../../src/main/resources/spring/datasource-config.xml)).

**Unclear / not verified**: effective test-profile wiring (`src/test/resources/spring/mvc-test-config.xml` exists; test contents not deeply read); whether the `jetty-web.xml` workaround is still required; MySQL driver artifact `mysql-connector-java` 8.1.0 availability (not checked, no network).

**confidence**: HIGH (structure and wiring read directly from pom and XML); MEDIUM for route list completeness.

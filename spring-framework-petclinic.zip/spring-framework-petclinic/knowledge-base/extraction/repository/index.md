---
tags:
  - extraction
  - repository
---
# Repository Structure Overview

**Analysis Date**: 2026-11-11
**Repository Type**: SingleProject — one root `pom.xml` ([pom.xml](../../../pom.xml)) with no `<modules>`, no nested independent project roots (`.claude/` excluded by instruction as non-application tooling). Confidence: HIGH.

## Project Files

- [spring-framework-petclinic](./spring-framework-petclinic.md) — Spring Framework (XML config) Petclinic WAR with web/service/repository layers and three switchable persistence implementations.

## Cross-Project Dependency Map

```
No cross-project dependencies: single Maven module.
Intra-project layering: web -> service (ClinicService) -> repository interfaces -> {jpa | jdbc | springdatajpa} implementation (chosen by Spring profile)
```

## Technology Summary

**Languages**: Java 17 (CI also 21), JSP/JSTL, SQL, SCSS/CSS
**Frameworks**: Spring Framework 7.0.8 (XML config, no Spring Boot), Spring MVC, Spring Data JPA 2025.1.5, Hibernate 7.4.0.Final, Hibernate Validator 9.1.0.Final, AspectJ, Caffeine cache
**Databases**: H2 (default), HSQLDB, MySQL, PostgreSQL (Maven profiles)
**Build Tools**: Maven (wrapper), Jetty Maven plugin 11.0.26, Jib 3.5.1, JaCoCo, Enforcer, libsass (profile `css`)
**Testing**: JUnit Jupiter 6.1.2, AssertJ, Mockito, Hamcrest, spring-test (`@SpringJUnitWebConfig`, `@ActiveProfiles`)
**CI/CD**: GitHub Actions ([maven-build-main.yml](../../../.github/workflows/maven-build-main.yml), [maven-build-pull-request.yml](../../../.github/workflows/maven-build-pull-request.yml)); Dependabot ([dependabot.yml](../../../.github/dependabot.yml)); SonarCloud step on main
**Infrastructure**: Jetty 11 / Tomcat 11 servlet container, Docker image via Jib (base `jetty:11.0-jdk17`), devcontainer ([devcontainer.json](../../../.devcontainer/devcontainer.json))
**AI footprint**: none in the application (no AI SDK in the pom). Developer harness: `CLAUDE.md` exists at the root ([CLAUDE.md](../../../CLAUDE.md)) and `.claude/` is toolkit footprint, excluded from analysis.

## Notable Patterns

- Classic 3-layer architecture: web -> service -> repository.
- Three interchangeable persistence implementations per repository, selected by Spring profile (`jpa` default, `jdbc`, `spring-data-jpa`) in [business-config.xml](../../../src/main/resources/spring/business-config.xml).
- Independent second axis: Maven profile picks the database and SQL script folder through filtered placeholders in `data-access.properties`.
- Pure XML Spring configuration with programmatic servlet bootstrap ([PetclinicInitializer.java](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)), no `web.xml`.
- Cross-cutting: caching (`@Cacheable("vets")`), AOP call monitor exposed over JMX, i18n bundles (en/de/es).
- Server-rendered JSP views with custom tag files; `/vets.json` and `/vets.xml` content-negotiated endpoints.

## Quick Start

- Build all: `./mvnw clean verify`
- Run main app: `./mvnw jetty:run-war` (serves on http://localhost:8080/; add `-P MySQL`/`-P PostgreSQL` for other DBs, `-Dspring.profiles.active=jdbc|spring-data-jpa` for other persistence) — [readme.md](../../../readme.md)
- Run tests: `./mvnw test` (single class: `-Dtest=ClinicServiceJdbcTests`)
(Commands taken from pom, readme and CLAUDE.md; not executed.)

## Related

- No sibling extraction folders yet; later phases will add folders under `knowledge-base/extraction/`.

---
tags:
  - extraction
  - architecture
---
# Architecture Overview

## System Context
Web application for a pet clinic: find/create/edit owners, add/edit pets, record visits, list vets (HTML, `/vets.json`, `/vets.xml`). It is the only deployable; it talks to one relational database and exposes a JMX MBean. See the L1 diagram in [index.md](./index.md).

## Architectural Style
Layered monolith (HIGH). Three layers (`web`, `service`, `repository`) share a `model` package of JPA-annotated entities. The persistence layer is a Strategy chosen by Spring profile: `jpa` (default), `jdbc`, `spring-data-jpa`. Bootstrapping is programmatic (no `web.xml`) with a root context and a DispatcherServlet child context.

## Layers and Components

### Layer: Bootstrap and Configuration
**Responsibility**: Create the root and servlet contexts, pick the default profile, define beans in XML.
**Components**:
- PetclinicInitializer: `AbstractDispatcherServletInitializer`; root context = `business-config.xml` + `tools-config.xml`; servlet context = `mvc-core-config.xml`; mapping `/`; UTF-8 `CharacterEncodingFilter`.
- business-config.xml: profile blocks for persistence beans, `tx:annotation-driven`, component scan of `service`.
- datasource-config.xml: Tomcat JDBC pool `dataSource`, SQL init scripts, `javaee` profile with JNDI lookup.
**Patterns**: XML configuration, profile-based bean selection, placeholder-driven settings (`data-access.properties`).
**Evidence**: [PetclinicInitializer.java:52-66](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java), [business-config.xml:35-96](../../../src/main/resources/spring/business-config.xml), [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml). Confidence HIGH.

### Layer: Presentation (web)
**Responsibility**: HTTP routing, form binding/validation, view selection; delegates to `ClinicService`.
**Components**:
- OwnerController (`/owners/**`), PetController (`/owners/{ownerId}/pets/**`), VisitController (`.../visits`), VetController (`/vets`, `/vets.json`, `/vets.xml`), CrashController (`/oups`, deliberate exception).
- PetValidator, PetTypeFormatter (uses `ClinicService`).
- JSP views and tag files under `WEB-INF/jsp`, `WEB-INF/tags`; `mvc-view-config.xml` content-negotiating resolver, JAXB marshalling view for XML; `SimpleMappingExceptionResolver` -> `exception` view; message bundles `messages/messages`.
**Patterns**: MVC, Front Controller, Formatter/Validator, content negotiation.
**Evidence**: [OwnerController.java:38-125](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java), [VetController.java:33-60](../../../src/main/java/org/springframework/samples/petclinic/web/VetController.java), [mvc-core-config.xml:22-66](../../../src/main/resources/spring/mvc-core-config.xml), [mvc-view-config.xml](../../../src/main/resources/spring/mvc-view-config.xml). Confidence HIGH.

### Layer: Service
**Responsibility**: Single facade and transaction boundary.
**Components**:
- ClinicService (interface) / ClinicServiceImpl (`@Service`): constructor-injected with the four repository interfaces; `@Transactional` (read-only on reads); `@Cacheable("vets")` on `findVets`.
**Patterns**: Facade, declarative transactions, declarative caching.
**Evidence**: [ClinicServiceImpl.java:39-100](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java), [ClinicService.java](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicService.java). Confidence HIGH.

### Layer: Persistence (repository)
**Responsibility**: Data access behind interfaces.
**Components**:
- Interfaces: OwnerRepository, PetRepository, VetRepository, VisitRepository.
- repository.jpa: JpaOwnerRepositoryImpl, JpaPetRepositoryImpl, JpaVetRepositoryImpl, JpaVisitRepositoryImpl (profile `jpa`, scanned).
- repository.jdbc: JdbcOwnerRepositoryImpl, JdbcPetRepositoryImpl, JdbcVetRepositoryImpl, JdbcVisitRepositoryImpl plus JdbcPet, JdbcPetRowMapper, JdbcVisitRowMapper, JdbcPetVisitExtractor, OneToManyResultSetExtractor (profile `jdbc`, scanned).
- repository.springdatajpa: SpringDataOwnerRepository, SpringDataPetRepository, SpringDataVetRepository, SpringDataVisitRepository (profile `spring-data-jpa`, `<jpa:repositories>`).
**Patterns**: Repository, Strategy (profile-selected), exception translation (`PersistenceExceptionTranslationPostProcessor` for JPA profiles).
**Evidence**: [business-config.xml:66-96](../../../src/main/resources/spring/business-config.xml), [JpaOwnerRepositoryImpl.java:36](../../../src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaOwnerRepositoryImpl.java), [SpringDataOwnerRepository.java:23-24](../../../src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataOwnerRepository.java). Confidence HIGH.

### Layer: Domain Model
**Responsibility**: Entities and the XML wrapper.
**Components**: BaseEntity, NamedEntity, Person, Owner, Pet, PetType, Specialty, Vet, Vets, Visit (JPA `@Entity`/`@MappedSuperclass`, Bean Validation, JAXB on Vet/Vets).
**Evidence**: [Owner.java:43-44](../../../src/main/java/org/springframework/samples/petclinic/model/Owner.java), [Vets.java:21-22](../../../src/main/java/org/springframework/samples/petclinic/model/Vets.java). Confidence HIGH.

### Layer: Cross-cutting (util / tools)
**Responsibility**: Monitoring, caching, helpers.
**Components**: CallMonitoringAspect (`@Aspect`, `@ManagedResource`, `@Around` on any `@Repository` class), Caffeine `cacheManager` (caches `default`, `vets`), EntityUtils (used by JDBC repositories).
**Evidence**: [CallMonitoringAspect.java:37-77](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java), [tools-config.xml](../../../src/main/resources/spring/tools-config.xml). Confidence HIGH.

## Module Dependencies

### Dependency Map
web -> service -> repository interfaces <- {jpa, jdbc, springdatajpa}; all layers -> model; aspect -> `@Repository` beans.

### Dependency Direction
- web controllers -> ClinicService: the only service type controllers import ([OwnerController.java:24](../../../src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)). HIGH
- ClinicServiceImpl -> the four repository interfaces, never an implementation ([ClinicServiceImpl.java:26-29](../../../src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java)). HIGH
- repository implementations -> repository interfaces (dependency inversion). HIGH
- JdbcPetRepositoryImpl -> OwnerRepository ([JdbcPetRepositoryImpl.java:51-83](../../../src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcPetRepositoryImpl.java)). HIGH
- JDBC implementations -> EntityUtils (util). HIGH
- CallMonitoringAspect -> beans annotated `@Repository` ([CallMonitoringAspect.java:77](../../../src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java)). HIGH

## Coupling Points

### High Coupling Areas (Refactoring Candidates)
- Domain entities carry JPA, Bean Validation, JAXB and Spring `@DateTimeFormat` annotations, so one model class serves persistence, web binding and XML output ([Vet.java:25-31](../../../src/main/java/org/springframework/samples/petclinic/model/Vet.java), [Pet.java:18](../../../src/main/java/org/springframework/samples/petclinic/model/Pet.java)). HIGH
- Persistence profile default is a hardcoded constant `SPRING_PROFILE` ([PetclinicInitializer.java:52](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)); the three implementations must be kept behaviourally identical by hand. HIGH
- `packagesToScan` covers the whole base package alongside a named persistence unit ([business-config.xml:48-50](../../../src/main/resources/spring/business-config.xml)); the XML comment itself notes the persistence unit wins. HIGH
- `ClinicService` is one wide facade for all four aggregates. MEDIUM

### Appropriate Coupling
- Controllers and service depend on interfaces; the Maven profile (database) and the Spring profile (persistence API) are independent axes ([data-access.properties](../../../src/main/resources/spring/data-access.properties)).

## Architectural Patterns Used

- Layered architecture: package-per-layer under `org.springframework.samples.petclinic`.
- Strategy via Spring profiles: persistence implementations.
- Facade: ClinicService.
- Repository: four interfaces.
- AOP: CallMonitoringAspect exported over JMX.
- Declarative cache and transactions: `@Cacheable`, `@Transactional`.
- Content negotiation: HTML, JSON, XML for vets.

## Evidence and Observations

- Only the repository layer is switched by profile; the service layer is unchanged ([business-config.xml](../../../src/main/resources/spring/business-config.xml)).
- Config split: the root context holds service/repository/tools; the servlet context holds controllers and MVC ([PetclinicInitializer.java:54-60](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java)).
- The aspect matches `@Repository` classes; the Spring Data interfaces are not annotated in this repo, so whether it applies under that profile is inferred, not verified at runtime.
- Under the `jdbc` profile no EntityManagerFactory is created; only JDBC beans ([business-config.xml:66-82](../../../src/main/resources/spring/business-config.xml)).
- Violations: none in layer direction (no controller imports a repository; no repository imports a service or web class, checked via imports). Minor: JdbcPetRepositoryImpl depends sideways on OwnerRepository.
- AI: none in the application (`ai.product.present` is false in the profile).

## Recommendations

- Introduce DTOs or separate view/XML types to free `model` from web and JAXB annotations.
- Keep the shared test base (AbstractClinicServiceTests) running against all three implementations when repository behaviour changes.
- Externalise the default persistence profile instead of a code constant.
- Watch `ClinicService` growth; split by aggregate if it expands.

## C4 Level 2 - Containers and Components

> **Diagram validated:** rendered successfully with `mermaid_check.py` (Mermaid CLI with chrome-headless-shell 157.0.8103.50), 2026-11-11.

```mermaid
graph TB
    subgraph System["Spring Petclinic WAR"]
        Init["PetclinicInitializer<br/>AbstractDispatcherServletInitializer"]
        Web["web controllers<br/>Spring MVC"]
        Views["JSP views and tag files"]
        Svc["ClinicService / ClinicServiceImpl<br/>Transactional, Cacheable"]
        Repo["Repository interfaces"]
        Jpa["repository.jpa<br/>profile jpa"]
        Jdbc["repository.jdbc<br/>profile jdbc"]
        Sdj["repository.springdatajpa<br/>profile spring-data-jpa"]
        Model["model entities"]
        Aspect["CallMonitoringAspect<br/>AOP and JMX"]
        Cache["Caffeine cache vets"]
    end
    DB[("Relational DB")]
    Init --> Web
    Web --> Views
    Web --> Svc
    Svc --> Repo
    Svc --> Cache
    Repo -.-> Jpa
    Repo -.-> Jdbc
    Repo -.-> Sdj
    Jpa -->|JPA| DB
    Jdbc -->|JDBC| DB
    Sdj -->|JPA| DB
    Aspect -.->|around Repository beans| Jpa
    Aspect -.-> Jdbc
    Web --> Model
    Svc --> Model
    Repo --> Model
```

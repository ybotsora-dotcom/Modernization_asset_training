---
tags:
  - extraction
  - architecture
---
# Architecture Index

Spring Petclinic is a single-module Spring Framework 7 (XML configuration, no Spring Boot) WAR with a classic web -> service -> repository layering. Each repository interface has three interchangeable implementations chosen by a Spring profile. Style: layered monolith with a profile-switched persistence strategy (HIGH; see [petclinic.md](./petclinic.md)).

Diagrams: both diagrams were rendered successfully with `mermaid_check.py` on 2026-11-11 (see the note above each diagram); no gaps are open.

## Domain Files

- [petclinic.md](./petclinic.md) - the whole application (one bounded domain): layers, dependencies, coupling, C4 L2.

## C4 Level 1 - System Context

> **Diagram validated:** rendered successfully with `mermaid_check.py` (Mermaid CLI with chrome-headless-shell 157.0.8103.50), 2026-11-11.

```mermaid
graph TB
    Browser["Browser user"]
    System["Spring Petclinic WAR<br/>Spring MVC, JSP, JPA/JDBC"]
    DB[("Relational database<br/>H2, HSQLDB, MySQL, PostgreSQL")]
    JMX["JMX client"]
    Browser -->|HTTP| System
    System -->|JDBC| DB
    JMX -->|JMX| System
```

Evidence: servlet mapping `/` in [PetclinicInitializer.java:63-66](../../../src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java); data source in [datasource-config.xml](../../../src/main/resources/spring/datasource-config.xml); JMX export in [tools-config.xml](../../../src/main/resources/spring/tools-config.xml). No outbound service calls were found (see [repository/index.md](../repository/index.md)).

## Related

- [repository/index.md](../repository/index.md)

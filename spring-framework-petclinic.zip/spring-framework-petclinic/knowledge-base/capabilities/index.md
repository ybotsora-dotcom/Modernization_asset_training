---
tags:
  - capabilities
  - wave-planning
status: APPROVED
---

# Capability Split — Spring Petclinic

## Summary

Spring Petclinic is a small veterinary clinic web application (one WAR, no external integrations, no jobs). The approved split has 9 capabilities in 4 waves. The main risk themes are the absence of any authentication or authorization (RISK-001), request-level protection gaps (CSRF, ownership of path ids), a missing visit list view (RISK-011), unchecked dates (RISK-012), and three parallel persistence implementations (RISK-015). There are no Critical findings; 4 are High (RISK-001, 002, 003, 011). Visit History and Clinical Staff Management are kept separate with no dependency between them, so the open stakeholder question about whether a visit requires a named vet (the code does not require one, VIS-002) is not resolved here.

Ownership principle: each requirement, rule and risk has a single accountable owner, and that BRD is its source of truth. Every other BRD that touches it writes only "See <Capability>" and does not restate it.

**Total capabilities**: 9
**Migration waves**: 4
**Capabilities with BRDs**: 9 / 9
**Generated**: 2026-11-12

## Capability Map

| Wave | Capability | Business Intent | Complexity | Priority | BRD |
|------|-----------|-----------------|------------|----------|-----|
| Wave 0 — Safe and Dependable Foundations | RBAC | Decide and enforce who may access or modify clinic records; today there are no users, roles or authorization checks (RISK-001), plus the ownership check on pet and visit routes (RISK-003). | standard | high | available |
| Wave 0 — Safe and Dependable Foundations | Application Security | Protect the web channel and stored data: CSRF, transport security and headers, safe error output, safe handling of request ids, committed credentials. | complex | high | available |
| Wave 0 — Safe and Dependable Foundations | Persistence and Data Platform | Decide which persistence variants and databases to keep, align their behavior, guard schema re-initialization and externalize DB configuration. | complex | high | available |
| Wave 0 — Safe and Dependable Foundations | Operations, Observability and Delivery | Make the app deployable and supportable: health, metrics, logging defaults, JMX hardening, CI audit, packaging, JDK baseline. | standard | medium | available |
| Wave 1 — Working Client, Patient and Visit Records | Client Management | Find, register, edit and view clients (pet owners); client record retention and erasure is an open policy decision (RISK-019). | standard | high | available |
| Wave 1 — Working Client, Patient and Visit Records | Patient Management | Add and edit pets (patients) of an owner with validated name, type and birth date. | standard | high | available |
| Wave 1 — Working Client, Patient and Visit Records | Visit History | Record a pet's visits and review the history newest first; resolves the missing visit list view and the date-checking gap. | standard | high | available |
| Wave 2 — Reference Directory | Clinical Staff Management | Read-only list of vets and specialties as HTML, JSON and XML; no management functions exist. | simple | low | available |
| Wave 3 — Consistent Shell and Language | Web Shell and Localization | Consistent landing page, navigation, layout, generic error page and aligned en/de/es messages. | simple | low | available |
## Waves

### Wave 0 — Safe and Dependable Foundations

**Objective**: At the end of this wave the clinic has an agreed answer to who may view and change client and patient records, with the web channel and stored data protected against tampering and leakage. The clinic also has one agreed data platform whose behavior is the same across the databases it supports, and an operations view in which staff and operators can see whether the system is healthy. Each domain capability that follows can then be specified and judged against these agreed answers.
**Sequencing Rationale**: Today anyone who can reach the application can change any record and nobody can tell whether the system is healthy, so the rest of the work needs these answers first.

#### Capabilities

##### RBAC
- **Slug**: `rbac`
- **Business Intent**: Decide and enforce who is permitted to access or modify clinic business records. Two things belong here. First, a gap: the current system has no users, accounts, roles, login or authorization checks at all (RISK-001, 0 authorization rules), so anyone who can reach the URL can view and edit everything. The business must decide whether login is wanted, which roles exist (the extraction only infers "clinic receptionist / front-desk staff", with no evidence of other roles), and which screens each role may use. Second, a concrete, fixable finding (RISK-003): the pet and visit routes do not verify that the pet in the URL belongs to the owner in the URL. The ownership rule to enforce is that a pet or visit can only be changed through the owner it belongs to. This is a business authorization decision, not a data-storage concern.
- **Complexity**: standard
- **Modernization Priority**: high
- **Domain Mapping**: security, risk-gap/security.md, business-intent personas
- **BRD**: available
- **Owned risks**: RISK-001 (no authentication or authorization; the open decision on login and roles lives here), RISK-003 (path ids not verified against ownership; a concrete, fixable finding)
- **Owned rules**: none to carry over (0 authorization rules exist); the ownership rule above would be a new rule
- **See**: Application Security for RISK-002 (CSRF follows the session model decided here)

##### Application Security
- **Slug**: `application-security`
- **Business Intent**: Protect the web channel and the stored data: forgery protection on state-changing forms, transport security and browser headers, safe error output, safe handling of ids supplied in requests, and handling of committed credentials. The goal is that client and pet data cannot be tampered with or leaked through the web layer.
- **Complexity**: complex
- **Modernization Priority**: high
- **Domain Mapping**: security, risk-gap/security.md
- **BRD**: available
- **Owned risks**: RISK-002 (CSRF), RISK-004 (committed DB credentials), RISK-005 (TLS, HSTS, CSP, frame protection), RISK-006 (unescaped error message), RISK-007 (pet binder does not disallow `id`)
- **Owned rules**: OWN-005 (owner id cannot be bound from a request)
- **See**: RBAC for RISK-001 and RISK-003

##### Persistence and Data Platform
- **Slug**: `persistence-data-platform`
- **Business Intent**: Decide which persistence variants to keep (jpa, jdbc, spring-data-jpa) and which databases to support (H2, HSQLDB, MySQL, PostgreSQL). Align behavior across them, guard schema re-initialization and externalize DB configuration. This gives one consistent, safe data foundation.
- **Complexity**: complex
- **Modernization Priority**: high
- **Domain Mapping**: data-model, architecture, data-flow, integrations (database only), `db/*` scripts
- **BRD**: available
- **Owned rules**: PLT-001, PLT-002, PLT-005, VIS-007 (profile-dependent visit-update behavior)
- **Owned risks**: RISK-014, RISK-015, RISK-016, RISK-020, RISK-021
- **See**: Client Management (OWN-009) and Clinical Staff Management (VET-001), whose database and profile differences it must align as a constraint

##### Operations, Observability and Delivery
- **Slug**: `operations-observability-delivery`
- **Business Intent**: Make the app deployable and supportable: health and metrics, logging defaults, JMX call-monitoring hardening, CI dependency and SAST audit, Jib/WAR packaging, JDK baseline. This lets operators run and trust the platform.
- **Complexity**: standard
- **Modernization Priority**: medium
- **Domain Mapping**: runtime-operations, risk-gap/operations.md, repository (CI/Jib)
- **BRD**: available
- **Owned rules**: PLT-003
- **Owned risks**: RISK-008, RISK-009, RISK-017, RISK-018

### Wave 1 — Working Client, Patient and Visit Records

**Objective**: At the end of this wave front-desk staff can run the clinic's daily record keeping with the agreed protections in place. They find or register a client, add or edit a patient, and record and review visits. Dates are checked, and a pet's visit history can always be displayed.
**Sequencing Rationale**: Client, patient and visit records are the clinic's main business activity, and they carry the High functional finding RISK-011 plus the data-quality gaps in dates and retention.

#### Capabilities

##### Client Management
- **Slug**: `client-management`
- **Business Intent**: Front-desk staff find pet owners (the clinic's clients) by last-name prefix, register them, edit their details and view the owner record as the hub for pets and visits. The code has no delete or archive for owners (OWN-008), so how long client records are kept and whether they can be erased is an open business policy decision for the client register (RISK-019).
- **Complexity**: standard
- **Modernization Priority**: high
- **Domain Mapping**: business-intent/owners.md, functional/owners-pets-visits.md, ui-ux/owners.md
- **BRD**: available
- **Features**: Find Owners by Last Name, Register New Owner, Edit Owner, View Owner Details
- **Owned rules**: OWN-001, OWN-002, OWN-003, OWN-004, OWN-006, OWN-007, OWN-008, OWN-009 (search case sensitivity depends on the database), OWN-010
- **Owned risks**: RISK-010 (unbounded list, paging), RISK-019 (no PII retention, erasure or audit; open decision on retention and erasure stays attached)
- **See**: Application Security (OWN-005), Persistence and Data Platform (for aligning OWN-009 across databases)

##### Patient Management
- **Slug**: `patient-management`
- **Business Intent**: Staff add pets (the clinic's patients) to an owner and edit them. Name, type, birth date and per-owner name uniqueness are validated, and pet types are served from a reference list. There is no way to remove a pet or change its owner.
- **Complexity**: standard
- **Modernization Priority**: high
- **Domain Mapping**: business-intent/pets.md, ui-ux/pets-visits.md
- **BRD**: available
- **Features**: Add Pet to Owner, Edit Pet
- **Owned rules**: PET-001 to PET-009 (including PET-003, pet birth date required)
- **Owned risks**: none
- **See**: Visit History (RISK-012), RBAC (RISK-003), Application Security (RISK-007)

##### Visit History
- **Slug**: `visit-history`
- **Business Intent**: Staff record a visit for a pet (description, date defaulting to today) and see the pet's visit history newest first. The unusable visit-list endpoint and missing view are resolved here, and the clinic's date-checking gap is resolved here for both pet birth dates and visit dates (RISK-012). Visits carry no vet link in the current code.
- **Complexity**: standard
- **Modernization Priority**: high
- **Domain Mapping**: business-intent/visits.md
- **BRD**: available
- **Features**: Record Pet Visit, List Pet Visits
- **Owned rules**: VIS-001 to VIS-006, VIS-008, VIS-009 (including VIS-005, visit date format)
- **Owned risks**: RISK-011 (`visitList` view missing), RISK-012 (pet birth date and visit date not range-checked). The remediation of RISK-012 covers both date checks: the pet birth date check and the visit date check. Visit History is the single source of truth for it. The existing PET and VIS rules stay with their current owners.
- **See**: RBAC (RISK-003), Persistence and Data Platform (VIS-007)

### Wave 2 — Reference Directory

**Objective**: At the end of this wave anyone can look up the clinic's vets and their specialties in a stable order, as a web page and as JSON/XML feeds. How fresh that list must be is agreed.
**Sequencing Rationale**: The vet list is read-only and stands apart from client, patient and visit records, so it is complete once the core records are in good shape.

#### Capabilities

##### Clinical Staff Management
- **Slug**: `clinical-staff-management`
- **Business Intent**: Anyone can look up the clinic's vets and their specialties, sorted by name, as an HTML page and as JSON/XML feeds. Despite the name, the current system offers no management functions: vets are a read-only list (VET-005) with no create, edit or delete, and no link to visits. Any management function would be new scope to decide.
- **Complexity**: simple
- **Modernization Priority**: low
- **Domain Mapping**: business-intent/vets.md, business-logic-rules/vets.md, ui-ux/shell-and-vets.md
- **BRD**: available
- **Features**: List Veterinarians (HTML, JSON, XML)
- **Owned rules**: VET-001 to VET-007 (VET-001, vet ordering by last then first name, is owned here)
- **Owned risks**: RISK-013 (cache never evicted; open decision on freshness)
- **See**: Persistence and Data Platform (for aligning VET-001 across persistence profiles)

### Wave 3 — Consistent Shell and Language

**Objective**: At the end of this wave every page shares the same landing page, menu, layout and error page, and the supported languages (en, de, es) match what the pages actually show.
**Sequencing Rationale**: It is a finishing layer over screens that already exist, with only low-severity items.

#### Capabilities

##### Web Shell and Localization
- **Slug**: `web-shell-experience`
- **Business Intent**: Give staff a consistent landing page, navigation menu, branded layout and a generic error page. The en/de/es message bundles are brought in line with what the pages actually use.
- **Complexity**: simple
- **Modernization Priority**: low
- **Domain Mapping**: ui-ux/navigation.md, ui-ux/shell-and-vets.md, ui-ux/index.md (i18n, Bootstrap, Flatpickr, Pivotal logo)
- **BRD**: available
- **Features**: Welcome Page, Error Page Demonstration
- **Owned rules**: PLT-004
- **Owned risks**: none
- **See**: Application Security (RISK-006)

## Items Touched by More Than One Capability

| Item | Single owner (source of truth) | Capabilities that write only "See <Owner>" |
|---|---|---|
| RISK-003 | RBAC | Patient Management, Visit History |
| RISK-006 | Application Security | Web Shell and Localization |
| RISK-007 | Application Security | Patient Management |
| RISK-012 | Visit History (both date parts) | Patient Management |
| RISK-019 | Client Management | none |
| OWN-005 | Application Security | Client Management |
| OWN-009 | Client Management | Persistence and Data Platform |
| VET-001 | Clinical Staff Management | Persistence and Data Platform |
| VIS-007 | Persistence and Data Platform | Visit History |
| RISK-002 (follows the RBAC session decision) | Application Security | RBAC |

## Coverage Check

All 13 functional features map to a capability:
- Client Management: 4 features.
- Patient Management: 2 features.
- Visit History: 2 features.
- Clinical Staff Management: 1 feature.
- Web Shell and Localization: 2 features (Welcome, Error Page).
- Operations, Observability and Delivery: Repository Call Monitoring.
- Persistence and Data Platform: Persistence Implementation Switch.

### Rules per owner (40 rules, each once)

| Owner | Rules | Count |
|---|---|---|
| Client Management | OWN-001, 002, 003, 004, 006, 007, 008, 009, 010 | 9 |
| Application Security | OWN-005 | 1 |
| Patient Management | PET-001 to PET-009 | 9 |
| Visit History | VIS-001 to VIS-006, 008, 009 | 8 |
| Clinical Staff Management | VET-001 to VET-007 | 7 |
| Persistence and Data Platform | VIS-007, PLT-001, 002, 005 | 4 |
| Operations, Observability and Delivery | PLT-003 | 1 |
| Web Shell and Localization | PLT-004 | 1 |
| RBAC | none (0 authorization rules) | 0 |

The total is 40.

### Risks per owner (21 risks, each once)

| Owner | Risks | Count |
|---|---|---|
| RBAC | RISK-001, 003 | 2 |
| Application Security | RISK-002, 004, 005, 006, 007 | 5 |
| Client Management | RISK-010, 019 | 2 |
| Visit History | RISK-011, 012 | 2 |
| Clinical Staff Management | RISK-013 | 1 |
| Persistence and Data Platform | RISK-014, 015, 016, 020, 021 | 5 |
| Operations, Observability and Delivery | RISK-008, 009, 017, 018 | 4 |
| Patient Management | none | 0 |
| Web Shell and Localization | none | 0 |

The total is 21.

Nine capabilities in total: 4 in Wave 0, 3 in Wave 1, 1 in Wave 2, 1 in Wave 3.

## Cross-Capability Dependencies

| Capability | Depends On | Rationale |
|-----------|------------|-----------|
| client-management, patient-management, visit-history | rbac | Today every route is open; the business must decide who may change records, and pet and visit changes must go through the owning owner (RISK-003, owned by RBAC). |
| client-management, patient-management, visit-history | application-security | Every state-changing form lacks CSRF protection and request ids can be overwritten. |
| application-security | rbac | CSRF and session protection are easiest once a login or session model is decided. |
| client-management, patient-management, visit-history, clinical-staff-management | persistence-data-platform | The persistence strategy and schema init apply to all repositories. Persistence and Data Platform must align the database and profile differences behind OWN-009 and VET-001, which their owners describe. |
| patient-management | client-management | A pet belongs to an owner (PET-009). |
| visit-history | patient-management | A visit must belong to a pet (VIS-006). |
| clinical-staff-management | none (independent of visit-history) | VET-005 and VIS-002: no vet link exists on visits. |
| web-shell-experience | client-management, patient-management, visit-history, clinical-staff-management | The shell wraps all screens. |
| operations-observability-delivery | persistence-data-platform | The monitoring aspect wraps the repositories. |

## Open Questions

1. RISK-012 sits with Visit History for both date checks; the cost is that a pet-side date defect is tracked in the visit BRD. The shared date-validation approach is written once, in Visit History.
2. Patient Management owns no risk and references three, so its BRD will be thin on risk content.
3. RBAC is rated "standard" and "high". If the business decides that no login is wanted, RBAC shrinks to the ownership check (RISK-003) plus a recorded decision, and the CSRF part of Application Security needs a different session model.
4. OWN-005 and RISK-007 stay with Application Security because both prevent client-supplied ids from overwriting stored ids (data integrity, not authorization); they could instead belong with RISK-003 in RBAC.
5. RISK-019 carries an open policy decision, so the Client Management BRD needs a business owner for the retention answer.
6. OWN-009 and VET-001 are database or profile behaviors owned by the domain capabilities; the link to Persistence and Data Platform is a reference and a dependency, not ownership.
7. Wave 0 has no Critical risks and rests on four High items and dependency logic; it could run alongside Wave 1.
8. Owners, Pets and Visits are three capabilities; they could be one patient-records capability (merging would reduce the total to 7). They are kept separate to keep Visits and Vets distinguishable.
9. The stakeholder question whether a visit requires a named vet is not resolved here. If stakeholders decide a visit must name a vet, Clinical Staff Management and Visit History would gain a dependency and a data-model change; this is not modelled.
10. The name Clinical Staff Management implies management functions that the code lacks, and the intent says so.
11. Operations and Persistence could be merged into one platform capability, and the vet and shell capabilities could join earlier waves; they are kept separate, with Persistence exactly as proposed.

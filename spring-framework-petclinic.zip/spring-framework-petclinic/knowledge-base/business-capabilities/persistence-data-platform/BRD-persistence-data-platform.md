---
tags:
  - brd
  - capability/persistence-data-platform
---
# Business Requirements Document: Persistence and Data Platform

> **Nature of this document.** This capability is the clinic's *data foundation*: where its client, pet, visit and vet records are kept, and the promise that they are kept safely and behave the same way however the clinic chooses to store them. It has no screen of its own; every other record-keeping capability depends on it. The capability definition in the source material is written in technology terms. This BRD restates it as business needs so that the requirements still hold if the clinic changes platform. Technology names appear only in the Appendix.
>
> **How statements are labelled.** *Extraction fact* = something the analysis of the existing system found. *Customer input* = something the customer has said; **none has been recorded for this capability**. *Analysts' working framing* = the analysts' interpretation, not yet agreed with the customer.

## 1. Executive Summary
The clinic's records (clients who own pets, the pets, their visits, and the vets and specialties) are held in a data store: the place where all records are kept. The system as built can keep those records in several different ways internally and on several different data store products (the current counts are given as a baseline in Section 5). Out of the box it uses a temporary store that is emptied every time the system is switched off and on again (a restart), and it loads a fixed set of sample records (vets, specialties, pet types, clients, pets and visits) at the same moment. If the same system were pointed at a store holding real records, the loading step would erase them. The different ways of storing also do not always behave identically: for example, a saved visit can be corrected in one of them but not in another.

This capability owns the business decisions and requirements that fix this: the clinic's records behave the same however its data is stored, are not erased when the system restarts, and are never replaced by sample records; the clinic decides which ways of storing data it will support; and a record save either completes fully or not at all.

Key stakeholders: COO / business sponsor (decides which storage options the clinic supports), practice managers (own the continuity and safety of records), front-desk lead and front-desk staff (who rely on records being there and behaving predictably), and the lead vet (relies on the vet and visit information being correct).

Sources: extracted knowledge only; no source code was re-analysed. See the Appendix.

## 2. Business Capability Definition
- **Capability Name**: Persistence and Data Platform
- **Business Domain**: Data foundation and platform integrity (Wave 0 - Safe and Dependable Foundations). Rated complex, priority high.
- **Primary Stakeholders**: COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet
- **Business Objective**: Give the clinic one agreed, dependable place and manner of keeping its records: a decision on which ways of storing data are supported, the same behaviour in all of them, records that survive a restart, and protection against records being wiped by mistake. Keeping database access details out of shared files: See Application Security (RISK-004).
- **Key Business Value**: Client, pet and visit history is not lost or silently changed by how the system happens to be set up. The extraction records no revenue figures and none are claimed here. The value is risk avoidance: loss of every record on a restart or a mistaken set-up (impact rated High, likelihood Low for a demonstration and rising with real records), and the same feature giving different answers at different sites (impact and likelihood both Medium).
- **Extraction fact**: the system is described as a reference (sample) application whose purpose is to run on different data stores; its default set-up keeps data only until the next restart.
- **Analysts' working framing (not agreed with the customer)**: if the clinic intends to run the system with real client and patient records, the safeguards in this document move from "nice to have" to "needed before use".

## 3. Business Workflows
Workflows 1, 2 and 6 describe the behaviour identified during the review of the current system. Workflows 3, 4 and 5 describe areas where business decisions are still required.

- **Workflow 1: Keeping the clinic's records between uses (current behaviour)**
  - Trigger: The clinic starts using the system for the first time, or switches it off and on again (a restart).
  - Primary Actors: Practice managers, front-desk staff.
  - Steps:
    1. The system is started with its out-of-the-box set-up.
    2. It loads a fixed set of sample records: vets, specialties, pet types, clients, pets and visits.
    3. Front-desk staff register clients, add pets and record visits during the day.
    4. The system is switched off and on again.
    5. The records entered in step 3 are gone, and the sample records are loaded afresh.
  - Business Rules: With the out-of-the-box set-up, records exist only until the next restart. A set-up that keeps records permanently is available, but the clinic has not recorded which one it uses.
  - Outcome: Suitable for a demonstration or training. For real clinic use, all records entered since the last start would be lost at every restart.

- **Workflow 2: Starting the system against a store that already holds the clinic's records (current risk)**
  - Trigger: A practice manager points the system at a permanent store that already contains real client, pet and visit records.
  - Primary Actors: Practice managers.
  - Steps:
    1. The system is started against the permanent store.
    2. On every start, it first deletes the clinic's record tables and rebuilds them empty.
    3. It then loads the sample records.
  - Business Rules: Nothing today prevents the rebuild on a store holding real records. There is no safeguard and no record of consent.
  - Outcome: All real records are lost at the next start and replaced by sample records. Proposed outcome: the system must never replace real records without an explicit, deliberate decision.

- **Workflow 3: Decide which ways of storing data the clinic supports (proposed, requires customer decision)**
  - Trigger: The clinic wants one agreed approach for storing records instead of maintaining multiple storage options.
  - Primary Actors: COO / business sponsor, practice managers.
  - Steps:
    1. The business lists which data stores it actually uses or may use.
    2. The business states whether supporting several ways of storing data is a goal in itself (for example to teach or demonstrate) or whether one is enough.
    3. The business confirms the list of supported options and names the single default.
    4. The decision is recorded.
  - Business Rules: Every option kept must behave the same (Workflow 4) and be checked every time a change is made. Each option kept multiplies the effort of every future change; the extraction notes that every new data-access function currently has to be built and checked once for every way of storing the system keeps.
  - Outcome: A signed-off list of supported options. Options not on the list are retired.

- **Workflow 4: The same behaviour whichever way records are stored (proposed requirement, partly broken today)**
  - Trigger: The clinic uses a supported option other than the default, or changes from one to another.
  - Primary Actors: Front-desk staff, lead vet, practice managers.
  - Steps:
    1. Staff do the normal daily tasks: search for a client, view a pet's visits, look at the vet list, correct a visit.
    2. The system gives the same result regardless of how the clinic's data is stored.
    3. Where the results differ, the difference is treated as a defect and listed.
  - Business Rules: One difference is owned here (extraction fact): correcting an already-saved visit works in one option and is refused in another (VIS-007). The other known differences are described by their owners: vet list order, See Clinical Staff Management (VET-001); client search letter case, See Client Management (OWN-009); data-access monitoring, See Operations, Observability and Delivery (PLT-003).
  - Outcome: Records and results do not depend on the storage set-up. This capability keeps the behaviour consistent; the rules for vet order, client search letter case and monitoring are owned elsewhere.

- **Workflow 5: Correcting a visit that has already been saved (current gap, decision needed)**
  - Trigger: A visit record has been saved and the front-desk wants to change it, for example a wrong description.
  - Primary Actors: Front-desk staff, practice managers.
  - Steps (today):
    1. Staff look for a way to edit a saved visit. No screen offers one.
    2. If a correction were attempted by other means in one storage option, it would be applied. In another option it would be refused with an error.
  - Business Rules: Visits are effectively add-only today because no screen allows editing or deleting. The difference between storage options is hidden behind that gap.
  - Outcome: The clinic must decide whether visits may be corrected. If yes, correction must work identically in all supported options. If no, visits must be added but not changed in any supported option. No stakeholder decision currently exists on this point.

- **Workflow 6: Saving a record completely or not at all (current behaviour)**
  - Trigger: Staff submit a new client, a new or edited pet, or a new visit.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff fill in the form and submit it.
    2. If the entries are valid, the system saves the record as one all-or-nothing step: either the whole record is saved or none of it is.
    3. If the entries are not valid, nothing is saved and staff see the form again.
  - Business Rules: Each save is complete by itself. A form that takes several steps (for example adding a pet and then a visit) is not protected as a whole: each step is saved independently. Looking up a pet's visits is not covered by the read-only protection that other lookups have.
  - Outcome: A single save never leaves a half-written record. No situation was found in the analysis where two people edit the same record at the same time, so the multi-step gap is monitored rather than treated as a defect.

## 4. Business Rules and Constraints
- **PLT-001 (owned) - One way of storing is active at a time.** Exactly one of the supported ways of storing records is in use; it is chosen when the system starts, and a default applies if nothing is chosen. Rationale: the clinic needs a single, predictable foundation. The business intent is that all clinic rules behave identically in all options; this is not fully true today (Workflow 4).
- **PLT-002 (owned) - The data store product is chosen when the system is set up.** The choice decides where the records live and which starter records are loaded. The out-of-the-box choice is temporary and loses data at a restart. Some products rebuild their record tables from scratch at every start; others create them only if missing. Rationale: the clinic must be able to choose a permanent store. Note the safeguard gap in Workflow 2.
- **PLT-005 (owned) - Each save is all-or-nothing.** Lookups are read-only; saves of clients, pets and visits are each complete in themselves. Multi-step forms are not protected as a whole, and the pet-visits lookup is not covered by read-only protection.
- **VIS-007 (owned) - Visit correction depends on the way of storing.** One storing option refuses to update a saved visit; another saves the update. No screen offers visit editing today, so staff cannot trigger it. Rationale for ownership here: the difference is caused by the storage choice, not by a visit rule. Visit History writes only "See Persistence and Data Platform".
- **Not owned here (dependencies only).** Client search letter-case behaviour: See Client Management (OWN-009). Vet list order: See Clinical Staff Management (VET-001). This capability must only keep both consistent across supported options.
- **Proposed new rules (analysts' working framing, for customer confirmation).** (1) Real records are never replaced by sample records without a deliberate, recorded decision. (2) Records entered are still there after a restart. Keeping data store access details out of shared files: See Application Security (RISK-004).
- **Operational Constraint**: The extraction states no availability, volume or speed requirements for the data foundation, so none are specified. Those numbers are open items for the customer.

## 5. Current Capabilities and Gaps
- **What Works Well** (extraction facts): The system can run on several data store products and in several ways of storing without any change to the screens. A shared set of automated checks (tests that run by themselves and report pass or fail) is run once for each way of storing, so differences can be found. Each save is complete by itself. A default set-up works with no preparation, which suits demonstration and training.
- **Current-state baseline (not a requirement)**: The system today supports 3 ways of storing data and 4 data store products, and its fixed set of sample records holds 6 vets, 3 specialties, 6 pet types, 10 clients, 13 pets and 4 visits. Of the 4 data store products, 2 rebuild their record tables at every start and 2 create them only if missing. These counts describe the platform as built; no requirement or KPI in this document depends on them.
- **Identified Gaps**:
  - RISK-016: the record tables are deleted and rebuilt at every start; fatal if pointed at real records (impact High, likelihood Low for a demonstration, rising with real data).
  - RISK-014: the same feature can behave differently depending on how data is stored (impact Medium, likelihood Medium). Owned difference: visit correction (VIS-007). The other known differences are described by their owners: See Clinical Staff Management (VET-001), See Client Management (OWN-009), See Operations, Observability and Delivery (PLT-003).
  - RISK-015: parallel ways of storing must all be kept up to date (impact Medium, likelihood Medium). Every new data-access function is built and checked once for each way of storing, which is the cause of RISK-014.
  - RISK-020: multi-step forms save step by step (impact Low, likelihood Low).
  - RISK-021: an option to supply data store access details from the hosting environment instead of shared files exists but whether it correctly replaces the built-in details was not verified (impact Low, likelihood Low).
  - No decision exists on which options the clinic supports, or whether visits may be corrected.
  - The extraction does not say which data store the clinic actually uses, nor whether anything is used permanently.
  - No retention, backup or recovery requirements are stated in the extraction. They are open questions.
- **Workarounds**: None documented. Whether the clinic uses a permanent store and keeps its own backups is unknown and must be confirmed with the customer.

## 6. Stakeholder Requirements
Roles are the customer's roles only. No customer statements have been recorded for this capability; the requirements below are the analysts' working framing based on extraction facts, to be confirmed.
- **COO / business sponsor**: A recorded decision on which ways of storing data and which data store products the clinic supports, and whether supporting several is a goal in itself. Visibility of the five owned findings (RISK-014, 015, 016, 020, 021) and their status.
- **Practice managers**: Assurance that records survive a restart and that setting up or moving the system cannot erase real records. A named person accountable for the data store. Backup and recovery expectations are not stated and must come from the customer.
- **Front-desk lead**: The same behaviour in every set-up the clinic runs, so that training and procedures do not depend on how the system is installed.
- **Front-desk staff**: Records they enter are still there tomorrow; searches and visit lists give the same answers every time; a failed save does not leave half a record. Satisfaction targets are not stated and are an open item.
- **Lead vet**: The vet list and a pet's visit history are always complete, whichever storage option is used. Order of the vet list: See Clinical Staff Management (VET-001). Order of the visit history: See Visit History (VIS-003). A decision on whether visits can be corrected is needed (Workflow 5).

## 7. Future-State Vision
- **Desired Capabilities** (proposed): (1) a signed-off list of supported ways of storing and data store products, with one default; (2) the same behaviour in every supported option, checked by the same automated checks on each one; (3) permanent storage that keeps records across restarts; (4) a deliberate safeguard so that sample records and rebuilding of tables can never overwrite real records; (5) See Application Security (RISK-004) for data store access details; (6) visit correction either allowed or disallowed identically everywhere.
- **Business Outcomes**: No loss of client, pet or visit history because of set-up; fewer places where behaviour has to be built and verified; staff procedures that do not depend on the installation.
- **Timeline Considerations**: Wave 0 (Safe and Dependable Foundations), priority high, complexity complex. Domain capabilities in Waves 1 and 2 (Client Management, Patient Management, Visit History, Clinical Staff Management) depend on it, so the supported-options decision should precede them. The extraction notes that Wave 0 has no Critical findings and could run alongside Wave 1. No dates are stated by the customer; target dates are an open item.

### Open questions for the customer
1. Does the clinic intend to run this system with real records, or is it for demonstration or training?
2. Which data store products and which ways of storing are in use today, and which must be supported going forward?
3. Is supporting several ways of storing a goal in itself (teaching, demonstration), or is one enough?
4. May a saved visit be corrected or deleted? If so, by whom (the question of roles is with RBAC)?
5. What are the expectations for backup and recovery? (How long records are kept, and erasure of client data: See Client Management, OD-1 and RISK-019.)
6. Who is accountable for the data store and for approving any change that could replace records?
7. How soon must a restart bring the system back to its full set of records (continuity expectation)?

## 8. Related Business Capabilities
- **Depends On**: None upstream (extraction: the persistence and data platform has no dependency on another capability).
- **Supports**: Client Management, Patient Management, Visit History and Clinical Staff Management all depend on this capability. Operations, Observability and Delivery depends on it too: its data-access monitoring sits around every record access. Application of consistent behaviour for client search letter case: See Client Management (OWN-009). Vet ordering: See Clinical Staff Management (VET-001).
- **Integration Points**: The data store is the only system the application connects to. There are no other systems, no scheduled jobs and no messaging. For data store access details held in shared files (RISK-004): See Application Security.

## 9. Success Metrics and KPIs
All targets are derived from this BRD's own content and the documented findings. No volumes or speeds are invented.

- **KPI 1: Supported-options decision recorded.** Target: 1 signed-off decision listing the supported ways of storing data and data store products, with one default. Target date: **open item, to be set by the customer**.
- **KPI 2: Differences between storage options owned here.** Baseline: 1 (visit correction, VIS-007). Target: 0 differences left across the supported options, shown by running the same automated checks on every supported option (see also KPI 5). The checks for the differences owned elsewhere are measured in their owners' KPIs: See Clinical Staff Management (KPI 1), See Client Management (KPI 5, OWN-009), See Operations, Observability and Delivery (KPI 5).
- **KPI 3: Records kept across a restart.** Target: 100% of records entered before a restart are present afterwards on the clinic's chosen permanent option (testable: add a client, a pet and a visit, restart, confirm all three are present).
- **KPI 4: Real records overwritten at start.** Target: 0. Testable: starting against a store that holds records leaves every record unchanged and loads no sample records unless explicitly requested.
- **KPI 5: Visit correction decision applied identically.** Target: 100% of supported options give the same result when a saved visit is corrected (accepted in all, or refused in all, per the decision).
- **KPI 6: Alternative way of supplying access details verified (RISK-021).** Target: 1 documented successful test showing it replaces the built-in details, or the route is formally dropped. Baseline: not verified.
- **KPI 7: Owned findings closed.** Target: RISK-014, 015, 016, 020, 021 move from 5 open to 0, or are each formally accepted by the business with a recorded reason. RISK-020 and RISK-021 are rated Monitor (Low impact, Low likelihood) and may be accepted.
- **KPI 8: Owned rules with an agreed business position.** Target: 4 of 4 (PLT-001, PLT-002, PLT-005, VIS-007).
- **Open items needing customer decision**: target date for KPI 1; any availability, recovery or backup targets; any user satisfaction thresholds.

## 10. Risks and Mitigation
- **Business Risk 1 (RISK-016): Records are deleted and rebuilt at every start.** Impact High, likelihood Low for a demonstration, rising if used with real records. All client, pet and visit history would be lost. Overall rated Medium by the extraction.
  - Mitigation: Add a deliberate safeguard so that the rebuild and sample loading happen only for temporary stores or by explicit request; adopt a controlled way to change the structure of a permanent store; verify with KPI 4.
- **Business Risk 2 (RISK-014): The same feature behaves differently depending on how data is stored.** Impact Medium, likelihood Medium (only when a non-default option is used). Staff could see different results at different sites, or a feature that works in one set-up fails in another.
  - Mitigation: Agree the consistent behaviour, add automated checks for each known difference and run them on every supported option (KPI 2).
- **Business Risk 3 (RISK-015): Parallel ways of storing are expensive to keep correct.** Impact Medium, likelihood Medium. Each new function must be built and checked once for each way of storing, and divergence (RISK-014) results.
  - Mitigation: Take the supported-options decision (Workflow 3); keep the shared automated checks as the contract; consolidate if several options are not a goal in themselves.
- **Business Risk 4 (RISK-020): Multi-step forms are saved step by step.** Impact Low, likelihood Low; no concurrent-edit situation was identified.
  - Mitigation: Monitor; revisit if two people editing at once, or conflict protection, becomes a requirement.
- **Business Risk 5 (RISK-021): The alternative way of supplying data store access details is unverified.** Impact Low, likelihood Low. The clinic might rely on it to keep access details out of shared files (RISK-004, See Application Security) and find it does not work.
  - Mitigation: Test it before relying on it (KPI 6).
- **Business Risk 6: The supported-options decision stalls.** Without it, domain capabilities cannot say which behaviour they must support.
  - Mitigation: Put the open questions in Section 7 to the customer in the first planning workshop and record the answers.
- **Business Risk 7: The clinic's real data store is unknown.** The analysis cannot rule out that real records are already at risk.
  - Mitigation: Practice managers confirm the data store in use and take a backup before any change (open question 2).

## Appendix: Traceability to Technical Implementation
Commit: `dc4f7b7c1f878fde2995ed2733d22ba987b827dd`. Everything in this BRD comes from extracted knowledge; no source code was re-analysed. Technology names appear only here. Claims in the body map as follows.

| Claim | Source |
|---|---|
| Capability definition, owned rules PLT-001, PLT-002, PLT-005, VIS-007, owned risks RISK-014, 015, 016, 020, 021; single-owner boundaries for OWN-009 and VET-001; dependencies from four domain capabilities | [capabilities/index.md](../../capabilities/index.md) |
| One of three repository implementations (JPA, JDBC, Spring Data JPA) selected by Spring profile, default `jpa` (PLT-001) | [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md); [src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java:52](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/PetclinicInitializer.java#L52); [src/main/resources/spring/business-config.xml:35](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/spring/business-config.xml#L35) |
| Database chosen by Maven profile (H2 default, HSQLDB, MySQL, PostgreSQL); sample record counts (6 vets, 3 specialties, 6 types, 10 owners, 13 pets, 4 visits); in-memory H2 loses data on restart (PLT-002) | [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md); [pom.xml:520](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/pom.xml#L520); [src/main/resources/spring/data-access.properties:7](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/spring/data-access.properties#L7) |
| Transaction boundaries on the service; `findVisitsByPetId` not annotated (PLT-005, RISK-020) | [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md); [src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java:54](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java#L54) |
| Visit update refused in JDBC mode, merged under JPA; no screen edits visits (VIS-007) | [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md); [src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java:62](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVisitRepositoryImpl.java#L62) |
| Behaviour differs by Spring and Maven profile; three parallel implementations (RISK-014, RISK-015); data-access monitoring ineffective under Spring Data JPA | [risk-gap/index.md](../../extraction/risk-gap/index.md); [data-flow/index.md](../../extraction/data-flow/index.md) |
| Schema scripts DROP tables at every startup (RISK-016) | [risk-gap/index.md](../../extraction/risk-gap/index.md); [src/main/resources/spring/datasource-config.xml:38](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/spring/datasource-config.xml#L38) |
| `javaee` profile JNDI datasource override not verified (RISK-021) | [risk-gap/index.md](../../extraction/risk-gap/index.md); [src/main/resources/spring/datasource-config.xml:46](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/spring/datasource-config.xml#L46) |
| Data entities and stored records | [data-model/index.md](../../extraction/data-model/index.md) |
| Reference-application purpose; no external systems | [business-intent/index.md](../../extraction/business-intent/index.md); [integrations/index.md](../../extraction/integrations/index.md) |
| Owned elsewhere: OWN-009 (Client Management), VET-001 (Clinical Staff Management), RISK-004 (Application Security), RISK-019 (Client Management) | [capabilities/index.md](../../capabilities/index.md) |

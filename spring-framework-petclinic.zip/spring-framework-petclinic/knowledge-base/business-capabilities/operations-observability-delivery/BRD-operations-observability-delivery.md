---
tags:
  - brd
  - capability/operations-observability-delivery
---

# Business Requirements Document: Operations, Observability and Delivery

> Source basis: sections 1-10 are based on extracted knowledge only (see the Appendix); no repository source code was read for this document. Three kinds of statement appear and are labelled where it matters: **extraction fact** (what the analysis of the current system found), **analysts' working framing** (the analysts' interpretation of the business need, not yet confirmed by the customer) and **customer input**. No customer input specific to this capability has been recorded; every need below is therefore the analysts' working framing until the customer confirms it. Terms are explained where first used; technology names appear only in the Appendix.

## 1. Executive Summary

This capability makes the clinic's system something the clinic can rely on and support. It covers five needs: (1) whoever supports the system can tell whether it is working; (2) problems are noticed before staff have to report them; (3) the software the clinic depends on is regularly checked for known weaknesses; (4) the system can be installed and updated in a repeatable way, on a software version the clinic has chosen on purpose; and (5) sensitive client and patient information is not written into the system's diagnostic records ("logs", the running diary the system keeps for troubleshooting).

Extraction facts: today there is no way to ask the system "are you working?" (RISK-017), the diary of system activity is more detailed than needed by default and may expose client details (RISK-008), a control used to read and reset the counters of record-storage activity can be changed by anyone who can reach it (RISK-009), and nobody has checked the software the clinic relies on for known weaknesses (RISK-018). Analysts' working framing: the current system looks like a demonstration application, so these are gaps to close before real clinic data is entrusted to it, not failures of a live service. Priority is medium, in Wave 0.

Key stakeholders: COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet.

## 2. Business Capability Definition

- **Capability Name**: Operations, Observability and Delivery
- **Business Domain**: Running and supporting the clinic system (Wave 0 - Safe and Dependable Foundations)
- **Primary Stakeholders**: COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet. Front-desk staff, the front-desk lead and the lead vet are the people who notice first when the system is not working; practice managers and the COO / business sponsor decide how much assurance is required.
- **Business Objective**: The clinic can run and trust its system: it knows when the system is working, hears about problems early, keeps its software free of known weaknesses, installs and updates the system the same way every time, and keeps sensitive information out of diagnostic records.
- **Key Business Value**: Fewer and shorter periods in which front-desk staff cannot work without knowing why; lower risk that client contact details leak through diagnostic records; reduced exposure to publicly known software weaknesses; updates that do not depend on one person's memory. No revenue impact is documented in the extraction and none is claimed.
- **Owned in this document (single source of truth)**: rule PLT-003; risks RISK-008, RISK-009, RISK-017, RISK-018.

## 3. Business Workflows

Current-state basis for all workflows: findings from the review of the current system together with proposed future behaviour. Where a step does not exist today it is marked "(needed)".

- **Workflow 1: Find out whether the system is working**
  - Trigger: A front-desk staff member cannot open a client record, or a practice manager wants to know before opening time whether the system is ready.
  - Primary Actors: Front-desk staff, front-desk lead, practice manager, whoever supports the system.
  - Steps:
    1. The person asks for the system's current status through a simple, documented way (needed).
    2. The system answers with a clear "working" or "not working" result, including whether the part that stores client, patient and visit records is reachable (needed; the dependency on the record-storage capability is described in section 8).
    3. If the answer is "not working", the supporter is told which part is affected so staff can be given a plain explanation.
  - Business Rules: The status answer must not reveal client or patient information. What counts as "working enough to open the clinic" is an open item for the customer.
  - Outcome: Staff and supporters can tell, without guessing, whether a problem is in the system. Extraction fact: today no such status exists; the only indirect check is to open the welcome page, and that is an inference, not a documented procedure.

- **Workflow 2: Notice a problem before staff do**
  - Trigger: The system starts failing, slows down or loses contact with the part that stores records.
  - Primary Actors: Whoever supports the system, practice manager.
  - Steps:
    1. The system keeps simple running figures about how often it reads and writes records and how long that takes (exists today; see Workflow 3).
    2. A supporter reviews those figures, and the diagnostic records, for signs of trouble.
    3. A warning reaches the supporter when a problem appears (needed; no automatic warning exists today).
    4. The supporter acts, and tells the front-desk lead if work will be interrupted.
  - Business Rules: Warnings go to a named person or role; who that is, is an open item for the customer. Extraction fact: the "events worth alerting on" in the analysis (failed start-up, lost contact with the record store, errors) are the analysts' inference at LOW confidence.
  - Outcome: Problems are normally known to the support person before the first staff complaint. Extraction fact: today problems are discovered by staff, and there is no simple way to follow an issue across all parts of the system.

- **Workflow 3: Review record-storage activity figures (rule PLT-003)**
  - Trigger: A supporter wants to know how busy the record store is or how long its operations take, for example after staff report slowness.
  - Primary Actors: Whoever supports the system.
  - Steps:
    1. The supporter opens the running figures kept by the system: number of record operations and the average time an operation takes.
    2. The supporter, if needed, switches the counting off or sets the figures back to zero.
    3. The supporter compares the figures with what they normally see.
  - Business Rules (PLT-003, extraction fact, high confidence): Every operation that reads or writes clinic records is counted and timed, including operations that fail. The average time is the total time divided by the number of operations, and is shown as zero when nothing has run. The counting is on by default and can be switched off or reset by whoever can reach the control. The counting affects no client, patient or visit record; it is information for supporters only. Documented limitation: the counting is not effective for one of the ways the system can currently store records (which one is described in Persistence and Data Platform).
  - Outcome: Supporters can see storage activity. Open concern (RISK-009): the people allowed to switch the counting off or reset it are not restricted by the system itself.

- **Workflow 4: Check the software for known weaknesses (RISK-018)**
  - Trigger: A regular schedule, a new software release, or a public warning about a weakness in software the clinic uses.
  - Primary Actors: Whoever supports the system; practice manager as the person who receives the result.
  - Steps:
    1. The list of third-party software the system relies on is compared with public lists of known weaknesses (needed; never done according to the extraction).
    2. Findings are ranked by seriousness and given an owner.
    3. Serious findings lead to an update of the affected software and a repeat check.
    4. The result is recorded so the practice manager can see the date of the last check and what is outstanding.
  - Business Rules: A software component whose supplier no longer supports it is a finding in its own right. Extraction fact: some older components and test setups were flagged as probably unsupported; the flag is an inference from version numbers and the suppliers' published support dates were not consulted.
  - Outcome: The clinic knows, with a date, whether it is running software with known weaknesses. Extraction fact: the status of the current versions is unknown, because the check could not be done in the analysis.

- **Workflow 5: Install and update the system in a repeatable way**
  - Trigger: A new version is ready, a new installation is needed (for example a replacement machine), or a rollback is needed.
  - Primary Actors: Whoever supports the system; practice manager approves timing so front-desk work is not interrupted.
  - Steps:
    1. The supporter produces the installable package from the approved version (exists today in two forms: a single deployable package and a ready-to-run bundled copy).
    2. The supporter installs it using the same documented procedure each time.
    3. The supporter confirms with the status check (Workflow 1) that the system works, and tells the front-desk lead that staff can resume.
  - Business Rules: The result of an install must not depend on who performs it. The system must be installed on a software platform version that the clinic has deliberately chosen and that its supplier still supports; the chosen version is an open item (see section 4). Current-state baseline (not a requirement): the build is limited to one runtime version and is tested on two.
  - Outcome: Installs and updates are predictable. Extraction facts: no installation guide beyond developer instructions was found, and no memory or capacity limits are declared.

- **Workflow 6: Keep sensitive information out of diagnostic records (RISK-008)**
  - Trigger: The system is started in a normal (non-development) setting, or a supporter reads the diagnostic records.
  - Primary Actors: Whoever supports the system; practice manager as accountable owner for client privacy.
  - Steps:
    1. In a normal setting the system keeps only the level of detail needed for supporting it.
    2. Detailed troubleshooting is switched on deliberately, for a limited period, by a supporter.
    3. Supporters can review a sample of the diagnostic records to confirm that no client names, addresses or telephone numbers appear (needed; never verified).
  - Business Rules: Client contact details must not appear in diagnostic records. Extraction fact: by default the system records every instruction it sends to the record store and detailed application activity, and the settings are re-read every 30 seconds; the analysis did not verify whether client addresses or telephone numbers actually reach the records.
  - Outcome: Diagnostic records help support without becoming a second, unprotected copy of client information.

## 4. Business Rules and Constraints

- **Rule PLT-003 - Record-storage activity is counted and timed (owned here)**: described in Workflow 3. Rationale: lets supporters see how the record store is used; it has no effect on clinic records. Evidence: extraction fact, high confidence.
- **Rule 2 (needed, analysts' working framing)**: Anyone who supports the system can obtain a status answer without special knowledge of how the system is built.
- **Rule 3 (needed, analysts' working framing)**: Sensitive client and patient information is not written into diagnostic records (RISK-008). Diagnostic detail is the exception, not the default.
- **Rule 4 (needed, analysts' working framing)**: The controls that switch record-storage counting off or reset it can be used only by authorised supporters (RISK-009). Who is authorised is an open item for the customer. The wider question of who may access clinic records at all is not decided here: See RBAC.
- **Rule 5 (needed, analysts' working framing)**: The software the clinic depends on is checked for known weaknesses on a regular basis and the result is recorded (RISK-018).
- **Rule 6 (needed, analysts' working framing)**: The system is installed and updated by the same procedure each time, on a software platform version that is deliberately chosen and supported by its supplier.
- **Operational Constraint (extraction fact)**: The system runs as a single application with no scheduled jobs, no background processing and no outside services; the only outside dependency is the record store. No limits on memory, capacity or availability are declared, and no availability target is documented. Any availability or recovery target is an open item for the customer (see section 9).
- **Out of scope here**: protection against destructive re-initialisation of the record store, choice of record-storage options and database configuration: See Persistence and Data Platform. Browser and web-channel protections: See Application Security.

## 5. Current Capabilities and Gaps

- **What Works Well** (extraction facts):
  - Record-storage activity is counted and timed, with a switch and a reset (PLT-003).
  - Failures on the pages shown to staff are written to the diagnostic records and staff see a generic error page.
  - The system can be built into a single deployable package and into a ready-to-run bundled copy, and an automatic build-and-test run happens on every change, on each runtime version the build supports.
  - The software supplier's automatic update suggestions and a code-quality scan are already in place.
  - The system has no scheduled jobs or outside services that could fail unnoticed.
- **Identified Gaps**:
  - RISK-017: no status answer, thin running figures, no tracing of one action across the system, no warnings. Impact Low, likelihood Medium (extraction).
  - RISK-008: record-store instructions and detailed application activity are recorded by default; whether client details reach the records is unverified. Impact Low, likelihood Medium (extraction).
  - RISK-009: the counting control can be changed and reset; whether it is reachable from outside depends on how the machine is started, which is not recorded. Impact Low, likelihood Low (extraction).
  - RISK-018: no check for known weaknesses and no automatic security testing was found; the status of the main components is unverified. Impact Medium, likelihood Medium (extraction).
  - No documented installation or update procedure for clinic support; diagnostic records go only to the screen of the machine and are not kept; no declared capacity limits.
  - The older database test setups named in the developer guide are probably past supplier support (analysts' inference from version numbers, medium confidence).
- **Workarounds** (analysts' inference, not documented by the customer): staff report problems to whoever supports the system; opening the welcome page is the only apparent way to see if the system is up; the developer instructions double as the install procedure.
- **Unknowns**: whether the clinic intends to use this system with real data, who currently supports it, and whether anyone reads the diagnostic records. None of these is stated in the extraction.

## 6. Stakeholder Requirements

All entries below are analysts' working framing for confirmation, except where a roles' stated need exists. No statement from the customer on this capability was recorded.

- **COO / business sponsor**: Assurance that the system can be run safely before real clinic data is entrusted to it, and visibility of the last check for known weaknesses. Decisions needed: required level of assurance and who owns support.
- **Practice managers**: A way to know whether the system is working, and the date and result of the last weakness check. Decide when updates may interrupt front-desk work. Accountable for keeping client details out of diagnostic records.
- **Front-desk lead**: A plain message from the support person when the system is down, and advance notice of updates that interrupt work. Wants fewer surprises at opening time.
- **Front-desk staff**: Do not want to diagnose failures; need one place or person to tell, and a clear explanation. No change to how they record clients, pets and visits.
- **Lead vet**: Needs to know whether patient history will be available during consultations; no clinical change expected.
- **Performance, reliability and scale expectations**: none are documented. Any targets (for example how quickly a failure must be detected) are open items for the customer.

## 7. Future-State Vision

- **Desired Capabilities**:
  - A simple status answer that says whether the system and its record store are working, without exposing client information.
  - Warnings that reach a named support person when something fails.
  - Running figures that cover all ways the system stores records, with the controls restricted to authorised supporters.
  - A regular, recorded check for known weaknesses in the software the clinic relies on, with a visible last-checked date and open findings.
  - A repeatable installation and update procedure, on a deliberately chosen, supplier-supported platform version.
  - Diagnostic records that carry only what supporters need and no client contact details by default.
- **Business Outcomes**: Problems found by the clinic rather than by clients; reduced exposure to known software weaknesses; predictable updates; lower privacy exposure.
- **Timeline Considerations**: Wave 0, priority medium. This capability depends on Persistence and Data Platform (the status answer must cover the record store, and figures must work whichever storage option is chosen) and should follow the decision on whether login is wanted (See RBAC) for the question of who may use supporter controls. No dates are set; any dates are for the customer.

## 8. Related Business Capabilities

- **Depends On**: Persistence and Data Platform. The monitoring covers the part of the system that stores records, so the status answer and running figures depend on which storage options are retained and on how that platform is configured (extraction fact: capability split dependency table). For rules and risks owned there: See Persistence and Data Platform.
- **Supports**: All capabilities that use the system (Client Management, Patient Management, Visit History, Clinical Staff Management, Web Shell and Localization), because they all depend on the system being running and trusted. Their records are not changed by this capability.
- **Related, owned elsewhere**: access control for clinic records and the decision on logins (RISK-001, RISK-003): See RBAC. Web channel protections and committed credentials: See Application Security.
- **Integration Points**: None to outside organisations. Extraction fact: the system has no outside services other than its record store; the only outside contact is the source-code hosting and the code-quality scan service used in the automatic build, which are part of how the clinic's software is built, not of clinic operations.

## 9. Success Metrics and KPIs

Every target below is derived from this document's own content. No availability, speed or date target exists in the extraction; where one is needed it is marked as an OPEN item for the customer.

- **KPI 1 - Status answer available (RISK-017)**: The system gives a status answer that distinguishes "working" from "not working" for the system itself and for its record store. Target: 100% of test cases pass, including a deliberate stop of the record store reported as "not working", and the answer contains no client or patient information. Required response time is an OPEN item for the customer.
- **KPI 2 - Detected before reported (RISK-017)**: In controlled failure tests, a warning reaches the named support person. Target: warning observed in 100% of test cases (system stop, record store unreachable, repeated page errors). The acceptable delay is an OPEN item for the customer.
- **KPI 3 - Diagnostic records free of client details (RISK-008)**: A review of diagnostic records from a full test run (registering a client, adding a pet, recording a visit) finds zero client names, addresses or telephone numbers. In the normal setting the record-store instruction logging and detailed application activity are off by default. Target: zero findings; checked at each release.
- **KPI 4 - Supporter controls restricted (RISK-009)**: Attempts to switch off or reset record-storage counting by an unauthorised person fail in 100% of tested cases. Who is authorised is an OPEN item for the customer.
- **KPI 5 - Running figures cover all storage options (PLT-003)**: For each retained storage option, call counts are recorded for 100% of test operations on clients, pets, visits and vets; for any option dropped under Persistence and Data Platform, the measure falls away. Existing behaviour (count includes failed operations; average shown as zero when nothing has run) still passes.
- **KPI 6 - Weakness check in place (RISK-018)**: A check for known weaknesses runs for 100% of releases and the result is recorded with a date. Target: zero unreviewed serious findings at any release; the definition of "serious" and the review frequency outside releases are OPEN items for the customer. The first run also establishes the baseline: number of components checked and number of findings (currently unknown).
- **KPI 7 - Repeatable installation**: A second person following only the written procedure installs the system from the approved version on a clean machine, and the status check (KPI 1) passes. Target: 2 of 2 independent trial installs succeed without help, and one update followed by a rollback succeeds.
- **KPI 8 - Platform version decision**: The supported platform version is named, with the supplier's support end date recorded. Target: decision recorded before the first release under this capability; the chosen version and the owner are OPEN items for the customer.
- **KPI 9 - Open items closed**: Each OPEN item in this document has an owner and a recorded decision. Target: 100%.

## 10. Risks and Mitigation

- **RISK-017: No status answer, thin running figures, no tracing (Impact Low, likelihood Medium)**. Business impact: outages are found by staff, support has no clear starting point, and a failure may last longer than necessary. Likelihood rises if the system is run unattended in a managed environment.
  - Mitigation: Provide the status answer and warnings in section 7; decide what "working" means and who is warned before the system is used in a shared setting.
- **RISK-018: Software currency and security testing unverified (Impact Medium, likelihood Medium)**. Business impact: the clinic may be running software with known weaknesses without knowing, and older test setups are probably unsupported.
  - Mitigation: Run and record the weakness check (Workflow 4, KPI 6), review pending update suggestions, move unsupported components to supported versions, and confirm the inferred support-end dates with the suppliers.
- **RISK-008: Detailed activity and record-store instructions recorded by default (Impact Low, likelihood Medium)**. Business impact: client names, addresses or telephone numbers may be stored in diagnostic records where they are not protected as client data.
  - Mitigation: Make minimal logging the default outside development, verify by reviewing a test run (KPI 3), and agree who reviews diagnostic records.
- **RISK-009: Counting control can be changed or reset by anyone who can reach it (Impact Low, likelihood Low)**. Business impact: figures could be hidden or wiped, delaying diagnosis. Exposure depends on how the system is started, which is not recorded.
  - Mitigation: Restrict the control to authorised supporters and document that any remote use must be authenticated (KPI 4). Record how the system is started in each environment.
- **Unconfirmed need (open question)**: this document rests on the analysts' working framing that the system will hold real clinic data. If the customer decides it stays a demonstration system, the priority of this capability should be re-confirmed.
  - Mitigation: Ask the COO / business sponsor to confirm intended use before planning.
- **Dependency risk**: the status answer and figures depend on decisions in Persistence and Data Platform.
  - Mitigation: See Persistence and Data Platform; do not plan this work until its storage-option decision is made.

## Appendix: Traceability to Technical Implementation

Provenance and technology names are confined to this appendix. Business terms used above map to technology as follows: "status answer" = health endpoint (none exists); "running figures" = JMX MBean metrics; "diagnostic records" = Logback console logs and SQL logging; "weakness check" = dependency audit and SAST in the CI pipeline; "installable package" = WAR and Jib container image; "platform version" = Java 17 baseline (CI builds on 17 and 21).

Extraction documents:
- [runtime-operations/index.md](../../extraction/runtime-operations/index.md) ([spring-framework-petclinic.md](../../extraction/runtime-operations/spring-framework-petclinic.md): deployment, logging, metrics, health checks, tracing)
- [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) ([platform.md](../../extraction/business-logic-rules/platform.md): PLT-003)
- [business-intent/index.md](../../extraction/business-intent/index.md) ([platform.md](../../extraction/business-intent/platform.md): "Monitor repository activity")
- [risk-gap/index.md](../../extraction/risk-gap/index.md) ([operations.md](../../extraction/risk-gap/operations.md): RISK-017, RISK-018, end-of-life flags; [security.md](../../extraction/risk-gap/security.md): RISK-008, RISK-009)
- [security/index.md](../../extraction/security/index.md) (logging of client details, management exposure)
- [repository/index.md](../../extraction/repository/index.md) (build and CI)
- [data-flow/index.md](../../extraction/data-flow/index.md), [data-model/index.md](../../extraction/data-model/index.md)
- [capabilities/index.md](../../capabilities/index.md) (ownership split and dependency on Persistence and Data Platform)

| Claim | Source |
|---|---|
| PLT-003 repository call monitoring, counts failed calls, default on, reset | [business-logic-rules/platform.md](../../extraction/business-logic-rules/platform.md); [CallMonitoringAspect.java:37-77](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java#L37-L77) and [tools-config.xml](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/spring/tools-config.xml) (whole file; the extraction gives no line) |
| Monitoring not effective with Spring Data JPA persistence | [runtime-operations/spring-framework-petclinic.md](../../extraction/runtime-operations/spring-framework-petclinic.md) (Metrics) |
| RISK-017: no Actuator or health endpoint, JMX-only metrics, console-only Logback, no tracing | [risk-gap/operations.md](../../extraction/risk-gap/operations.md); [runtime-operations/spring-framework-petclinic.md](../../extraction/runtime-operations/spring-framework-petclinic.md) |
| Probe via welcome page is inferred (LOW) | [runtime-operations/spring-framework-petclinic.md](../../extraction/runtime-operations/spring-framework-petclinic.md) (Health Checks) |
| RISK-018: no dependency audit or SAST in CI; Sonar and Dependabot exist; versions unchecked | [risk-gap/operations.md](../../extraction/risk-gap/operations.md); maven-build-main.yml, pom.xml |
| End-of-life flags (MySQL 5.7.8, PostgreSQL 9.6.0, MySQL driver 8.1.0) are inferred | [risk-gap/operations.md](../../extraction/risk-gap/operations.md) (End-of-Life table) |
| RISK-008: jpa.showSql=true, DEBUG logging, 30-second rescan, PII in toString unverified | [risk-gap/security.md](../../extraction/risk-gap/security.md); [security/spring-framework-petclinic.md](../../extraction/security/spring-framework-petclinic.md) |
| RISK-009: writable MBean `petclinic:type=CallMonitor`, exposure depends on JVM flags | [risk-gap/security.md](../../extraction/risk-gap/security.md); [CallMonitoringAspect.java:37](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/util/CallMonitoringAspect.java#L37) |
| Packaging: WAR plus Jib image from jetty:11.0-jdk17; no Dockerfile | [runtime-operations/spring-framework-petclinic.md](../../extraction/runtime-operations/spring-framework-petclinic.md); pom.xml |
| JDK baseline: Java 17 enforced; CI matrix 17 and 21 | [runtime-operations/index.md](../../extraction/runtime-operations/index.md) |
| No scheduled jobs, async processing or external services | [runtime-operations/spring-framework-petclinic.md](../../extraction/runtime-operations/spring-framework-petclinic.md) |
| Dependency on Persistence and Data Platform | [capabilities/index.md](../../capabilities/index.md) (Cross-Capability Dependencies) |
| Needs, KPIs and intended-use assumption | Analysts' working framing; no customer input recorded |
| RISK-001, RISK-003 | Owned elsewhere: See RBAC |
| Storage options, re-initialisation, database configuration | Owned elsewhere: See Persistence and Data Platform |

---
tags:
  - brd
  - capability/clinical-staff-management
---

# Business Requirements Document: Clinical Staff Management

> Source basis: sections 1-10 are based on extracted knowledge (see the Appendix). No repository source code was needed. Three kinds of statement are labelled throughout: **Extraction fact** (found in the analysed system), **Customer input** (a statement by the customer) and **Analysts' working framing** (our own proposal, not yet agreed). No customer statement about the vet directory has been recorded for this capability; every customer-side item below is therefore an open question, not a decision.

## 1. Executive Summary

Clinical Staff Management gives anyone a look-up of the clinic's vets and their specialties, sorted by name. It is available as a web page and as machine-readable lists (the same information in a structured form that other programs can read automatically).

**Despite its name, the current system offers no management functions.** The list is read-only (VET-005): there is no way to add, edit or remove a vet or a specialty, and no way to link a vet to a pet or a visit. Vet information can change only when someone edits the clinic's underlying data directly. Any management function (adding vets, maintaining specialties, assigning vets to visits) would be new scope for the customer to decide; it is not an existing feature and is not described as one in this document.

One open decision belongs here: the vet list is kept in short-term memory and is never refreshed until the system restarts (RISK-013), and the customer has not said how quickly a change must show up.

Key stakeholders: COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet.

## 2. Business Capability Definition

- **Capability Name**: Clinical Staff Management
- **Business Domain**: Reference directory (Wave 2 - Reference Directory). Complexity: simple. Modernization priority: low.
- **Primary Stakeholders**: Front-desk staff, front-desk lead, lead vet, practice managers, COO / business sponsor
- **Business Objective**: Let people see who the clinic's vets are and what each specialises in, in a stable, predictable order, in a form that people and other programs can use.
- **Key Business Value**: A single, consistent answer to "which vets do we have and what are their specialties?". No revenue or cost figures are stated in the extraction and none are claimed here.

## 3. Business Workflows

- **Workflow 1: Look up the clinic's vets**
  - Trigger: A staff member or other visitor wants to know which vets work at the clinic and what their specialties are.
  - Primary Actors: Front-desk staff, lead vet, practice managers, any other visitor (no sign-in exists).
  - Steps:
    1. The person chooses "Veterinarians" in the menu.
    2. The page shows a table of vets, each with a name and a list of specialties.
    3. Specialties for each vet appear in alphabetical order, ignoring upper or lower case.
    4. A vet with no specialty shows the word "none".
  - Business Rules: Vets are listed in order of last name, then first name (VET-001, with a caveat in section 5). Specialties are sorted by name (VET-002). "none" is shown when a vet has no specialty (VET-003). The page offers no search, filter or paging.
  - Outcome: The reader sees the full vet directory.

- **Workflow 2: Obtain the vet list in a machine-readable form**
  - Trigger: Another program, or a person wanting the data in a structured form, needs the vet list.
  - Primary Actors: Staff or technical colleagues acting for the clinic; any outside program using the published addresses.
  - Steps:
    1. The person follows one of the available export links at the bottom of the vet page to obtain the same information in a structured format.
    2. The same vets and specialties are returned, in the chosen format, in the same order as on the page.
  - Business Rules: The three forms (page and two structured lists) always show the same data (VET-007). No current use of these exports was identified during the review, and their business purpose remains to be confirmed.
  - Outcome: The vet list is available to other programs without manual copying.

- **Workflow 3: Change who is in the vet list (not available in the application)**
  - Trigger: A vet joins or leaves, or specialties change.
  - Primary Actors: Whoever is responsible for maintaining clinic staff information outside the application.
  - Steps:
    1. The application offers no screen for this. The change has to be made outside the application, in the underlying data (VET-005).
    2. The vet list shown to users does not pick up the change until the system is restarted (VET-004, RISK-013).
  - Business Rules: A vet or specialty link must refer to a vet and specialty that exist (VET-006). A vet may have no specialty.
  - Outcome: Today this task must be performed outside the application and the changes are not visible until the system is restarted. It is documented as a limitation, not a feature.

## 4. Business Rules and Constraints

All seven rules are owned by this capability. Source type for all: extraction facts.

- **VET-001 - Vet order**: Vets are listed by last name, then first name, and on every way of storing data the clinic supports the result is the same. Current-state baseline (not a requirement; extraction confidence MEDIUM): the order is confirmed for two of the three current ways of storing data; for the third it is not specified and not verified. Keeping this rule consistent across data stores is See Persistence and Data Platform.
- **VET-002 - Specialty order**: A vet's specialties are shown alphabetically, ignoring case; no specialty gives an empty list.
- **VET-003 - "none" display**: A vet with zero specialties shows "none" on the page.
- **VET-004 - Short-term memory of the list**: After the first look-up, the vet list is held in the system's memory and reused. There is no expiry and no refresh. This reduces repeat reads of the clinic's data but means changes are invisible until restart. The only way to switch it off is a technical change, not a business setting.
- **VET-005 - Read-only and unrelated to visits**: The application cannot create, change or remove a vet, a specialty or the link between them. Vets are not linked to pets or visits. For the open question about whether a visit should name a vet: See Visit History.
- **VET-006 - Vet-specialty link integrity**: A vet-to-specialty link must refer to an existing vet and an existing specialty. The same pair must not be stored twice, on every way of storing data the clinic supports. Current-state baseline (not a requirement): today this is enforced by the data store itself for two of the four supported databases only; the other two rely on the application not creating duplicates in memory.
- **VET-007 - Three forms of the same list**: A web page and two structured lists show the same data.
- **Operational constraint**: No speed, volume or availability targets are stated in the extraction. No sign-in exists; anyone who can reach the system can see the list (access decisions: See RBAC).

## 5. Current Capabilities and Gaps

- **What Works Well** (extraction facts): The directory shows vets and sorted specialties clearly; the structured lists are linked from the page; a vet without specialties is handled; the rules above are covered by automated checks (repeatable tests the delivery team runs) for sorting, the "none" display and the structured list.
- **Identified Gaps**:
  - No management functions: no add, edit or remove for vets, specialties or links (VET-005). New scope if wanted.
  - No link between vets and visits or pets (VET-005). See Visit History for the open vet question.
  - The vet list is not refreshed until restart (RISK-013); how fresh it must be is undecided.
  - Current-state baseline: vet order is not verified under one of the three current ways of storing data (VET-001, MEDIUM). Alignment: See Persistence and Data Platform.
  - No search, filter or paging on the page (fine for a small list; list size at the clinic is not stated).
  - Who uses the structured lists is unknown (Q3).
  - Two details are unverified in the extraction: whether an additional, alternative structured-list view that is configured is ever used, and how the structured formats are switched on.
- **Workarounds**: Vet data is changed directly in the underlying data outside the application, followed by a restart so the list refreshes (inference from VET-004/VET-005; the extraction does not document an actual clinic procedure).

## 6. Stakeholder Requirements

Roles are the customer's roles. The requirements below are **analysts' working framing** unless marked otherwise; no customer statements are recorded for this capability.

- **COO / business sponsor and practice managers**: Decide whether this capability stays a read-only directory (the current state) or grows into real vet management (new scope), and decide how fresh the list must be (RISK-013, open decision OD-V1). Low priority in the wave plan.
- **Front-desk lead and front-desk staff**: Need a correct, readable vet list that is reachable from the menu in one step (the menu has one Veterinarians entry). Satisfaction targets are not available and would need collecting.
- **Lead vet**: Needs the list to show vets and specialties correctly and in a predictable order. Whether vets should be assigned to visits is a question owned elsewhere: See Visit History.
- **Practice managers (for upkeep)**: Need to know who maintains vet data today and how a change reaches users (Q2).

## 7. Future-State Vision

All items below are analysts' working framing, offered for customer decision. None is committed.

- **Desired Capabilities**:
  - A vet list whose freshness matches an agreed rule (OD-V1).
  - A vet order that is the same however the system stores its data (See Persistence and Data Platform).
  - Optional, only if the customer wants it: screens to add, edit and retire vets and specialties. This is new scope, not a fix.
- **Business Outcomes**: Staff and other programs can trust that the directory reflects the current team; any change to the team reaches users within the agreed time.
- **Timeline Considerations**: Wave 2, low priority; it stands apart from client, patient and visit records and follows the core records work. No dates are set; any date is a customer decision.
- **Open items needing a customer decision**:
  - **OD-V1**: How quickly must a change to the vet list (new vet, changed specialty) appear: immediately, within minutes, or only after a restart? (Question carried from the extraction's risk finding.)
  - **OD-V2**: Is read-only acceptable, or are management functions wanted? If wanted, who may use them (See RBAC)?
  - **OD-V3**: Should vets be linked to visits? See Visit History.

## 8. Related Business Capabilities

- **Depends On**: Persistence and Data Platform (the vet list is read from the clinic's data; alignment of VET-001 across data stores is See Persistence and Data Platform). Independent of Visit History: no link exists.
- **Supports**: Web Shell and Localization wraps this page in the common layout and menu (See Web Shell and Localization).
- **Integration Points**: No outside systems are configured in the extraction. The structured lists are published for any program that wants them; actual consumers are unknown.

## 9. Success Metrics and KPIs

Targets use only conditions testable from this BRD. No volumes, speeds or dates are invented.

- **KPI 1 - Order correctness (VET-001)**: In 100% of checks, on 100% of the ways of storing data the clinic supports, the vet list is in last-name-then-first-name order. Current-state baseline (not the target): verified today for two of the three current ways of storing data. (Alignment: See Persistence and Data Platform.)
- **KPI 2 - Specialty display (VET-002, VET-003)**: 100% of vets show specialties alphabetically; 100% of vets with no specialty show "none".
- **KPI 3 - Same data in all forms (VET-007)**: In 100% of checks, the page and both structured lists contain the same vets and specialties in the same order.
- **KPI 4 - Freshness rule (RISK-013)**: A change to the vet list appears within the time bound the customer sets in OD-V1, tested by a repeatable check that changes a vet and measures when it shows. The time bound itself is OPEN.
- **KPI 5 - Open decisions closed**: OD-V1, OD-V2 and OD-V3 each have a named decision owner and a recorded decision before any related scope is planned. Target date: OPEN, set by the customer.
- **KPI 6 - Honest scope**: 0 mentions in clinic documentation or training of add/edit/remove vet functions as existing, until the customer chooses to build them (testable by document review).

## 10. Risks and Mitigation

- **RISK-013 - Vet list never refreshed until restart (extraction rating: Low impact, Medium likelihood once vets are maintained outside the application; overall Low)**: Changes to vets or specialties stay invisible to users until the system restarts, and no limit on how long the list is held exists. Because the application cannot change vets itself, staleness arises only when someone changes the underlying data directly.
  - Mitigation: Get the freshness decision (OD-V1); then add an agreed refresh or expiry rule and a repeatable check that proves it. Until then, state that a restart is needed after any vet change. Open decision carried from the extraction.
- **Scope-expectation risk (analysts' working framing)**: The name "Clinical Staff Management" suggests management functions that do not exist; stakeholders may assume they do.
  - Mitigation: State plainly in planning and training material that the capability is a read-only directory; treat any management function as new scope (OD-V2).
- **Order inconsistency across data stores (owned elsewhere)**: Whether the order holds under every storage variant is See Persistence and Data Platform.
  - Mitigation: See Persistence and Data Platform.
- **Unlinked vets and visits**: The open vet question for visits is See Visit History.
  - Mitigation: See Visit History.

## Appendix: Traceability to Technical Implementation

Extraction documents:
- [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) and [vets rules](../../extraction/business-logic-rules/vets.md): VET-001 to VET-007
- [business-intent/index.md](../../extraction/business-intent/index.md) and [vets intent](../../extraction/business-intent/vets.md): purpose, assumptions
- [data-flow/index.md](../../extraction/data-flow/index.md) and [vet flows](../../extraction/data-flow/vet-flows.md): list, memory reuse, formats
- [data-model/index.md](../../extraction/data-model/index.md): vet, specialty and link entities
- [risk-gap/index.md](../../extraction/risk-gap/index.md) and [functional-data findings](../../extraction/risk-gap/functional-data.md): RISK-013
- [ui-ux/shell-and-vets.md](../../extraction/ui-ux/shell-and-vets.md): vet page
- [integrations/index.md](../../extraction/integrations/index.md): no consumers configured
- [capabilities/index.md](../../capabilities/index.md): ownership and boundaries

Source code evidence (provenance only, taken from the extraction's evidence references):
- Vet order, JPA: [JpaVetRepositoryImpl.java:43](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/repository/jpa/JpaVetRepositoryImpl.java#L43)
- Vet order, JDBC: [JdbcVetRepositoryImpl.java:56](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/repository/jdbc/JdbcVetRepositoryImpl.java#L56)
- No declared order, Spring Data variant: [SpringDataVetRepository.java:28](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/repository/springdatajpa/SpringDataVetRepository.java#L28)
- Specialty sorting and count: [Vet.java:62](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/model/Vet.java#L62)
- Three formats: [VetController.java:42](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/VetController.java#L42)
- Memory reuse of list: [ClinicServiceImpl.java:98](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/service/ClinicServiceImpl.java#L98) and [tools-config.xml:37](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/spring/tools-config.xml#L37)
- Read-only: [VetRepository.java:38](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/repository/VetRepository.java#L38)
- "none" display: [vetList.jsp:25](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/webapp/WEB-INF/jsp/vets/vetList.jsp#L25)

Open questions (unknown in the extraction):
- Q1: Order of vets under the third storage variant (not verified).
- Q2: Who maintains vet data today and how.
- Q3: Who or what uses the structured lists.

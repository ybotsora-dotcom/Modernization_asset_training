---
tags:
  - brd
  - capability/visit-history
---

# Business Requirements Document: Visit History

> Source basis: sections 1-10 are based on extracted knowledge (see the Appendix). No repository source code was needed to fill gaps. Stakeholder statements about vets are customer input, not extraction evidence, and are labelled as such.

## 1. Executive Summary

Visit History lets clinic front-desk staff record a visit for a pet (a short description and a date that defaults to today) and review that pet's earlier visits, newest first. It is the clinic's running record of what happened to each patient and when. Two defects weaken it today: the stand-alone "list a pet's visits" page does not exist, so that entry point cannot show anything (RISK-011), and neither visit dates nor pet birth dates are checked against any allowed range (RISK-012). One policy question is open and needs a customer decision: whether every visit must name the attending vet (see section 4, OPEN DECISION OD-1).

Key stakeholders: Front-desk lead, Lead vet, Front-desk staff (the people who record visits), COO / business sponsor, practice managers.

## 2. Business Capability Definition

- **Capability Name**: Visit History
- **Business Domain**: Clinic patient records (Wave 1 - Working Client, Patient and Visit Records)
- **Primary Stakeholders**: Front-desk staff, Front-desk lead, Lead vet, COO / business sponsor, practice managers
- **Business Objective**: Keep a trustworthy, readable history of every visit per pet, and make sure the dates held in that history (visit dates and pet birth dates) fall within a range the customer decides (see section 7, open items).
- **Key Business Value**: Staff and vets can see what was done for a pet and when without searching elsewhere; the clinic avoids carrying impossible dates in its patient records. No revenue figures are stated in the extraction and none are claimed here.

## 3. Business Workflows

- **Workflow 1: Record a pet visit**
  - Trigger: A pet has been seen at the clinic and staff need to log the visit.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff opens the owner's record and chooses to add a visit for one of the owner's pets.
    2. The visit form shows the pet's details together with its earlier visits, newest first.
    3. The visit date is pre-filled with today's date; staff may change it, typing it as year/month/day.
    4. Staff enters a description of the visit and submits the form.
    5. If the description is empty or the date cannot be read, the form is shown again with an error message and nothing is saved.
    6. Otherwise the visit is saved and staff return to the owner's record, where the new visit appears under the pet.
  - Business Rules: A description is required (VIS-001). The date defaults to today (VIS-004) and must be typed in the year/month/day form (VIS-005). A visit always belongs to one existing pet (VIS-006). No veterinarian is recorded against a visit. Whether a veterinarian should be recorded remains an open business decision.
  - Outcome: The visit becomes part of the pet's history and is visible on the owner's record.

- **Workflow 2: Review a pet's visit history**
  - Trigger: Staff or a vet wants to know what happened on earlier visits.
  - Primary Actors: Front-desk staff, Vet.
  - Steps:
    1. Staff opens the owner's record.
    2. Under each pet, the visits are listed with the most recent first.
    3. The same list appears on the visit form while a new visit is being entered.
  - Business Rules: Visits are always ordered newest first (VIS-003). A pet with no visits shows an empty history. Visits can be added but there is no way for staff to edit or delete one (see VIS-007 for how update behaviour varies by deployment: See Persistence and Data Platform).
  - Outcome: The reader sees the pet's complete visit history in date order.

- **Workflow 3: Open a pet's dedicated visit list (currently broken)**
  - Trigger: A person or an outside program asks for the stand-alone list of one pet's visits.
  - Primary Actors: Front-desk staff, any person or outside program that uses the visit-list web address that is already published.
  - Steps:
    1. Someone asks for the pet's visit list.
    2. The system gathers the pet's visits but has no page to show them, so the attempt ends in an error message instead of a list. No menu or page links to it today, so staff do not meet this in normal use.
  - Business Rules: VIS-009 records that the list page is missing. This workflow does not currently work and is recorded as a known issue.
  - Outcome: Today, no list is shown. The target outcome is defined in section 7.

## 4. Business Rules and Constraints

- **Rule VIS-001 - Description required**: Every visit needs a non-empty description so the history is meaningful. A visit without one is not saved.
- **Rule VIS-002 - A visit does not require or record a vet**: The current system links a visit only to a pet. No vet can be chosen, saved or validated on a visit; the form, the saved visit and the sample data supplied with the system have no vet. A visit with just a date and a description saves successfully.
- **Rule VIS-003 - Newest first**: A pet's visits are always presented from the most recent to the oldest.
- **Rule VIS-004 - Date defaults to today**: A new visit starts with today's date so that same-day entry needs no typing.
- **Rule VIS-005 - Date input form**: The visit date is accepted only in year/month/day form. Beyond that it is not checked: past, far-future and (possibly) empty dates are not rejected. Whether an emptied field is saved as "no date" was not verified by running the system (confidence MEDIUM).
- **Rule VIS-006 - A visit belongs to an existing pet**: A visit cannot exist without a pet that is already on file.
- **Rule VIS-008 - Add-visit workflow**: The pet is identified before the form is shown; on success the user returns to the owner's record. A visit's identity cannot be supplied by the user. RISK-003: See RBAC.
- **Rule VIS-009 - Visit list page absent**: The stand-alone visit list has no page to display it (confidence MEDIUM; the failure at run time is inferred, not executed).
- **VIS-007**: See Persistence and Data Platform.
- **RISK-003**: See RBAC.
- **OPEN DECISION OD-1 - Must a visit name a vet? (customer decision required)**
  - Current state (extraction fact, rule VIS-002): the system neither requires nor records a vet on a visit.
  - Position A - Front-desk lead (customer input): a visit can be recorded against a pet with no vet assigned, because that is how walk-ins work in practice. This matches what the system does today.
  - Position B - Lead vet (customer input): every visit must have a named vet, for clinical accountability. This is not implemented today: the system cannot record a vet on a visit.
  - Both stakeholders believe they are describing current policy.
  - [CONFLICT-RESOLUTION-NEEDED: The front-desk lead (a visit may be recorded with no vet, for walk-ins) and the lead vet (every visit must name a vet, for clinical accountability) hold opposing positions, and the documents cannot settle which is policy. The customer must decide the vet-on-visit policy, name the decision owner and set a decision date; stakeholder decision required.]
  - Recommended resolution (analyst recommendation, not a customer decision): record the attending vet on every visit, entered by the end of the visit so that walk-ins are not slowed. This meets the front-desk lead's walk-in need and the lead vet's accountability need. It needs a rule for who enters the vet and by when, a way to find visits still missing a vet, a decision on past visits that have no vet, and a named owner for keeping the vet list up to date. See the decision brief (Option 3).
  - Status: RECOMMENDATION RECORDED, CUSTOMER DECISION STILL OPEN. No requirement in this BRD depends on the recommendation; the current behaviour (VIS-002) stands. Earlier wording: this BRD takes neither side and contains no requirement that assumes either. Needed from the customer: a decision on the policy (and, if a vet is to be recorded, whether it is mandatory, optional, or mandatory except for walk-ins), named decision owner and date. Until decided, the current behaviour (VIS-002) stands.
- **Operational Constraint**: The extraction states no volume, availability or speed requirements for this capability, so none are asserted. Any such target is an open item for the customer.

## 5. Current Capabilities and Gaps

- **What Works Well**: Recording a visit is a short, single-form task with the date pre-filled as today. Previous visits are shown on the same form, newest first. Required-description and existing-pet rules are enforced. Ordering, empty history and description rules are covered by tests that can be repeated at any time.
- **Identified Gaps**:
  - RISK-011 (Medium impact, High likelihood): the dedicated visit list page is missing, so that entry point fails.
  - RISK-012 (Medium impact, Medium likelihood): pet birth dates and visit dates are not range-checked. A pet birth date must be supplied but may lie in the future (PET-003 area, owned by Patient Management who write "See Visit History"); a visit date has no required check and no allowed-range check, and an emptied field may be saved as no date, which could also disturb the newest-first ordering (inferred).
  - Correcting or removing a visit: removal, See Client Management (OWN-008); correction, See Persistence and Data Platform (VIS-007).
  - Whether a visit is tied to a vet is undecided (OPEN DECISION OD-1).
- **Workarounds**: None are documented in the extraction. Staff who need a pet's history use the owner's record, which already shows it.

## 6. Stakeholder Requirements

- **COO / business sponsor and practice managers**: Resolve the missing visit list (RISK-011) and both date checks (RISK-012) together as one high-priority change set in Wave 1. Obtain the OD-1 decision before any change to what a visit records.
- **Business Users**: Front-desk staff need recording to stay as quick as today (one form, pre-filled date). Front-desk lead: walk-in visits must remain recordable (stated position, see OD-1). Lead vet: clinical accountability for each visit (stated position, see OD-1). Satisfaction metrics are not available in the extraction; collecting them is an open item.
- **Practice managers**: The visit history must display the same way regardless of how the clinic chooses to store its data (dependency on Persistence and Data Platform). No speed or volume expectation is stated in the extraction; any such target is to be set by the customer.

## 7. Future-State Vision

- **Desired Capabilities**:
  - A working "visit list" for a pet, showing the same newest-first history as the owner's record, with a clear message for a pet with no visits. (The alternative of withdrawing the unused entry point is a choice for the customer to confirm; this BRD recommends providing the list because the visit-list web address is already published.)
  - Date checks, specified once for both dates (RISK-012 remediation, single source of truth here):
    - Pet birth date: required (already so) and must not be later than today.
    - Visit date: required, and must not be empty.
    - Visit date: the allowed range (for example how far in the past or future a visit may be dated) is a customer decision and is not set in this BRD; see the open items below.
    - Rejected dates produce a clear message on the form and nothing is saved.
  - The outcome of OD-1, once decided by the customer.
- **Business Outcomes**: Fewer impossible dates in patient records; a visit history that can always be displayed from every entry point; an explicit, documented policy on vet accountability.
- **Timeline Considerations**: RISK-011 and RISK-012 sit in Wave 1 (high priority). OD-1 needs a customer decision before any related scope is planned.
- **Open items needing a customer decision**: (a) OD-1 above; (b) the allowed range for visit dates (for example whether future-dated visits, such as booked appointments, are acceptable); (c) whether to provide or withdraw the visit list entry point; (d) whether the earliest acceptable pet birth date is to be limited.

## 8. Related Business Capabilities

- **Depends On**: Patient Management (a visit must belong to a pet); RBAC (who may add visits, and the owner-to-pet check: RISK-003, See RBAC); Application Security; Persistence and Data Platform (VIS-007: See Persistence and Data Platform).
- **Supports**: Client Management (the owner's record is where visits are recorded and shown); Web Shell and Localization (wraps the visit screens).
- **Connections to other systems**: None. The extraction found no external systems for this capability. Clinical Staff Management has no link to visits today; if OD-1 is decided in favour of recording a vet, a new dependency would arise and is not modelled here.

## 9. Success Metrics and KPIs

- **KPI 1 - Visit list availability (RISK-011)**: For 100% of pets, including pets with no visits, asking for the pet's visit list shows a list (or a clear "no visits" message) and never an error. Testable by a repeatable test of what is shown. Target: 100%; measured on release.
- **KPI 2 - Visit order**: In 100% of checked pets with two or more visits, the displayed order is newest first, on the owner's record, the visit form and the visit list. Testable condition.
- **KPI 3 - Pet birth date check (RISK-012)**: 100% of attempts to save a pet with a birth date later than today are rejected with a message on the form. Testable with a set of future-date test cases.
- **KPI 4 - Visit date checks (RISK-012)**: 100% of attempts to save a visit with an empty date are rejected; 100% of visits saved with a valid, in-range date still succeed. The limits of the allowed range are an OPEN item for the customer (no number is proposed here).
- **KPI 5 - Existing rules preserved**: 100% of attempts to save a visit with an empty description or with an unknown pet continue to be rejected (VIS-001, VIS-006); a visit with today's default date and a description continues to save.
- **KPI 6 - Open decision closure (OD-1)**: OD-1 has a named decision owner and a recorded decision before any work touching what a visit records is planned. Target date: OPEN, to be set by the customer.
- **KPI 7 - Recording effort**: The number of fields staff must complete to record a standard visit does not rise above the current two (date, description) unless OD-1 is decided otherwise. Testable by form inspection. Any time-to-record or user-satisfaction target is an OPEN item for the customer; no figure is stated in the extraction.

## 10. Risks and Mitigation

- **Business Risk 1 - RISK-011: Visit list page is missing** (Medium impact, High likelihood). Anyone or any outside program that uses the published visit-list web address gets an error instead of the history.
  - Mitigation: Provide the list page (recommended) or withdraw the entry point; add a repeatable test that a list is shown. Covered by KPI 1.
- **Business Risk 2 - RISK-012: Pet birth date and visit date are not range-checked** (Medium impact, Medium likelihood). Invalid dates (future birth dates, empty visit dates, or visit dates outside whatever range the customer decides) can enter the record and may disturb the newest-first ordering. This BRD is the single source of truth for both date checks; Patient Management writes "See Visit History".
  - Mitigation: Implement both date checks together as in section 7, with test cases per KPI 3 and KPI 4; obtain the range decision from the customer first.
- **Business Risk 3 - Unresolved vet policy (OD-1)**: Two senior stakeholders each believe they are describing current policy, but their positions differ, so expectations differ and either could be disappointed. Risk of building to the wrong assumption.
  - Mitigation: Hold a decision session with the front-desk lead and lead vet, record the outcome, and only then plan any change. Meanwhile communicate that the system does not record vets on visits.
- **Business Risk 4 - RISK-003**: See RBAC.

## Appendix: Traceability to Technical Implementation

Extraction documents:
- [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) (visit rules VIS-001 to VIS-009; visits detail in [visits.md](../../extraction/business-logic-rules/visits.md); pet date rules in [pets.md](../../extraction/business-logic-rules/pets.md))
- [business-intent/index.md](../../extraction/business-intent/index.md) ([visits.md](../../extraction/business-intent/visits.md))
- [data-flow/index.md](../../extraction/data-flow/index.md) ([visit-flows.md](../../extraction/data-flow/visit-flows.md))
- [data-model/index.md](../../extraction/data-model/index.md)
- [risk-gap/index.md](../../extraction/risk-gap/index.md) ([functional-data.md](../../extraction/risk-gap/functional-data.md): RISK-011, RISK-012)
- [ui-ux/index.md](../../extraction/ui-ux/index.md) ([pets-visits.md](../../extraction/ui-ux/pets-visits.md))
- [capabilities/index.md](../../capabilities/index.md) (ownership split)

| Claim | Source |
|---|---|
| Description required (VIS-001) | [business-logic-rules/visits.md](../../extraction/business-logic-rules/visits.md); [Visit.java:47](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/model/Visit.java#L47) |
| No vet on a visit (VIS-002) | [business-logic-rules/visits.md](../../extraction/business-logic-rules/visits.md); [Visit.java:40](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/model/Visit.java#L40) |
| Newest first (VIS-003) | [business-logic-rules/visits.md](../../extraction/business-logic-rules/visits.md); [Pet.java:99](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/model/Pet.java#L99) |
| Date default and format (VIS-004, VIS-005) | [business-logic-rules/visits.md](../../extraction/business-logic-rules/visits.md); [Visit.java:62](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/model/Visit.java#L62) |
| Visit belongs to a pet (VIS-006) | [business-logic-rules/visits.md](../../extraction/business-logic-rules/visits.md) |
| Add-visit workflow (VIS-008) | [data-flow/visit-flows.md](../../extraction/data-flow/visit-flows.md); [VisitController.java:75](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/VisitController.java#L75) |
| Missing visit list page (VIS-009, RISK-011) | [risk-gap/functional-data.md](../../extraction/risk-gap/functional-data.md); [VisitController.java:85](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/VisitController.java#L85) |
| Dates not range-checked (RISK-012) | [risk-gap/functional-data.md](../../extraction/risk-gap/functional-data.md); [business-logic-rules/pets.md](../../extraction/business-logic-rules/pets.md) |
| Vet-on-visit disagreement (OD-1) | Customer input (not extraction evidence); current state per VIS-002 in [business-logic-rules/visits.md](../../extraction/business-logic-rules/visits.md); unresolved per [capabilities/index.md](../../capabilities/index.md) open question 9 |
| VIS-007, RISK-003 | Owned elsewhere: See Persistence and Data Platform; See RBAC |

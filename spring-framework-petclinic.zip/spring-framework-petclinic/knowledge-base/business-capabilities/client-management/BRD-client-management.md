---
tags:
  - brd
  - capability/client-management
---

# Business Requirements Document: Client Management

> Source basis: sections 1-10 are based on extracted knowledge (see the Appendix). No repository source code was read for this document. Statements are labelled as **extraction fact** (what the extraction found in the system), **customer input** (none was provided for this capability; there are no customer statements in this BRD), or **analysts' working framing** (our own proposal, not yet agreed with the customer).

## 1. Executive Summary

Client Management is how front-desk staff keep the clinic's register of clients, who are the pet owners. Staff find a client by typing the first letters of the last name, register a new client, correct a client's details and open the client record, which is the starting point for that client's pets and their visits. It is the register every other record in the clinic hangs from. Three limits matter to the business. First, a search with no text lists every client on one page with no paging (RISK-010). Second, the system has no way to delete or archive a client (OWN-008), and there is no retention rule, no way to erase a person's data on request and no record of who changed what (RISK-019); the policy behind this is an open decision for whoever owns the client register. Third, whether the search ignores capital letters depends on how the clinic stores its data (OWN-009), and this has not been verified for every storage option.

Key stakeholders: COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet.

## 2. Business Capability Definition

- **Capability Name**: Client Management
- **Business Domain**: Clinic client and patient records (Wave 1 - Working Client, Patient and Visit Records)
- **Primary Stakeholders**: Front-desk staff, front-desk lead, practice managers, COO / business sponsor; lead vet as a reader of client records
- **Business Objective**: Staff can reliably find, register, correct and view clients, and the clinic has an agreed policy for how long client personal data is kept and whether it can be erased.
- **Key Business Value**: One trustworthy client record per owner that pets and visits can be attached to. The extraction states no revenue figures and none are claimed here.
- **Priority and wave** (extraction fact, capability split): high priority, Wave 1.
- **Features** (extraction fact): Find Owners by Last Name, Register New Owner, Edit Owner, View Owner Details.

## 3. Business Workflows

- **Workflow 1: Find a client by last name**
  - Trigger: A client calls or arrives and staff need to open that client's record.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff opens the "Find owners" page from the menu.
    2. Staff types the first letters of the client's last name, or leaves the box empty, and submits.
    3. If no client matches, the same page is shown again with a "not found" message under the last-name box.
    4. If exactly one client matches, that client's record opens straight away.
    5. If several clients match, a table lists them with name, address, city, telephone and pets, and staff pick the right one.
  - Business Rules: The search matches every client whose last name starts with the typed text (OWN-003). Empty text lists all clients. The outcome depends on how many clients match (OWN-004). Whether capital letters affect search results depends on the clinic's chosen record-storage approach.
  - Outcome: Staff reach the correct client record, or learn that no such client is on file.

- **Workflow 2: Register a new client**
  - Trigger: A person who is not yet on file brings in a pet.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. From the "Find owners" page staff chooses "Add Owner".
    2. Staff enters first name, last name, address, city and telephone number and submits.
    3. If anything is missing, or the telephone number is not made of digits, the form is shown again with a message next to the field and nothing is saved.
    4. Otherwise the client is saved and the new client's record opens.
  - Business Rules: All five details are required (OWN-001). The telephone number must be digits only, up to 10 significant digits (OWN-002). Creating a client saves a new record; it never overwrites an existing one (OWN-006). The system does not check whether a client is already registered.
  - Outcome: The client exists in the register and pets can be added to them.

- **Workflow 3: Correct a client's details**
  - Trigger: A client's name, address, city or telephone number has changed or was entered wrongly.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff opens the client's record and chooses to edit the client.
    2. The form is shown pre-filled with the current details; staff change what is needed and submit.
    3. If a detail is missing or the telephone number is not digits, the form is shown again with a message and nothing is changed.
    4. Otherwise all five details are replaced with what was submitted and the client's record opens again.
  - Business Rules: The same required-detail and telephone rules apply as when registering (OWN-001, OWN-002). An edit always replaces all five details together (OWN-006). Rules governing client identifiers are defined in Application Security.
  - Outcome: The client's record shows the corrected details.

- **Workflow 4: View a client record**
  - Trigger: Staff or the lead vet need the client's details, their pets or the pets' visits.
  - Primary Actors: Front-desk staff, lead vet.
  - Steps:
    1. Staff reach the client record by search or after registering or editing.
    2. The page shows the client's details and each pet, with the pets listed alphabetically regardless of capital letters (OWN-007) and each pet's visits (order: See Visit History, VIS-003).
    3. From this page staff can choose to edit the client, add a pet or add a visit.
    4. If staff try to open a client record that does not exist, a general error page is shown instead.
  - Business Rules: Pets appear alphabetically by name (OWN-007). Unknown clients produce an error, not an empty page (OWN-010). Pet and visit rules belong to Patient Management and Visit History.
  - Outcome: Staff see the complete picture for one client in one place.

- **Workflow 5: Remove or archive a client (not available)**
  - Trigger: A client asks to be removed, or the clinic wants to clear out old records.
  - Primary Actors: Front-desk staff, practice managers.
  - Steps:
    1. No such function exists. Staff cannot delete or archive a client, and the system offers no other route to do it (OWN-008).
  - Business Rules: The reason this capability is unavailable is not documented. Retention and erasure are an open decision (OD-1, section 4).
  - Outcome: In the application, client records stay in the register because staff have no function to delete or archive them. This describes what staff can do in the application. It does not describe how records are retained or restored by the underlying storage approach (for that: See Persistence and Data Platform).

## 4. Business Rules and Constraints

Rules owned by this capability (extraction facts, from the business logic rules):

- **OWN-001 - Required client details**: First name, last name, address, city and telephone must all be filled in, so every client can be identified and contacted. A form with a missing detail is not saved. No limit on the length of the details is checked by the form (extraction note: very long entries may be refused by the data store; inferred, not verified).
- **OWN-002 - Telephone format**: The telephone number must be digits only, with at most 10 significant digits. Numbers written with a leading zero and 11 characters were accepted in the extraction's test cases. Confidence MEDIUM: this relies on how the number is read, not on a run of the live system. International formats with a plus sign or spaces appear not to be accepted (inferred).
- **OWN-003 - Search by start of last name**: The search returns every client whose last name starts with the typed text; empty text returns everyone. Clients with no pets are still found.
- **OWN-004 - What happens after a search**: No match shows a "not found" message; one match opens that client; several matches show a table.
- **OWN-006 - Register versus edit**: Registering saves a new client; editing replaces all five details of the existing client and opens the record afterwards.
- **OWN-007 - Pets shown alphabetically**: A client's pets are always displayed in name order, ignoring capital letters; a client without pets shows an empty list.
- **OWN-008 - No delete or archive**: The application offers no function to delete or archive a client, pet or visit. This describes what staff can do in the application, not what happens to the stored records when the system restarts or its data store is rebuilt (for that: See Persistence and Data Platform). Whether saving a client also saves its pets and their visits depends on how the clinic's data is stored: See Persistence and Data Platform (extraction confidence MEDIUM). Because staff cannot remove anything in the application, there is also nothing for staff to restore in the application.
- **OWN-009 - Search and capital letters**: The last-name search gives the same result whatever capital letters are typed, on every way of storing data the clinic supports. Current-state baseline (not a requirement; extraction confidence MEDIUM): with the clinic's default storage option and one other option the search ignores capital letters; with the two real-use database options the behaviour was not verified, and the extraction infers it follows the database's own default. This rule is owned here because it is a business-visible behaviour (does "smith" find "Smith"?). Keeping it consistent across data stores: See Persistence and Data Platform.
- **OWN-010 - Unknown client**: Asking for a client that does not exist ends in the general error page rather than an empty record (confidence MEDIUM; the behaviour of one storage option is inferred, not tested).
- **OWN-005**: See Application Security.
- **Access control (who may view or change client records)**: See RBAC.
- **Operational Constraint (extraction fact)**: The search has no paging; the clinic's sample data holds 10 clients. How many clients the real clinic holds is not stated anywhere in the extraction.

**OPEN DECISION OD-1 - Retention, erasure and audit of client personal data (RISK-019)**
- Current state (extraction fact): there is no delete or archive (OWN-008), no retention rule, no way to erase a person's data on request and no record of who changed or viewed a client. Client name, address, city and telephone are personal data.
- Question for the business (from the extraction): how long must client, pet and visit records be kept, and must the system let a person's data be erased on request?
- Decision owner: not yet named. The extraction does not say who owns the client register. A named owner is needed before any delete, archive or audit function is specified (analysts' working framing).
- Legal or regulatory obligations that apply to the clinic are not stated in the extraction and are not assumed here.
- No customer position has been recorded; none is invented.

## 5. Current Capabilities and Gaps

- **What Works Well** (extraction facts): Searching by start of last name routes staff sensibly (not found, straight to the client, or pick from a table). Registering and editing apply the same checks with messages on the form. The client record gathers pets and visits in one place with pets in a stable alphabetical order.
- **Identified Gaps**:
  - RISK-010: a search with no text lists every client with no paging. Impact is low with the 10 sample clients and rises with real volumes (extraction rating: impact Low, likelihood Medium).
  - RISK-019 / OD-1: no retention, erasure or audit for client personal data.
  - OWN-008: no way to delete or archive a client, including correcting a client registered by mistake or in duplicate.
  - OWN-009: current-state baseline: capital-letter behaviour of the search is not verified for the two real-use database options. Alignment: See Persistence and Data Platform.
  - No check for duplicate clients (analysts' note: nothing in the extraction describes one).
  - Telephone rule accepts digits only; whether the clinic needs other formats is a question for front-desk staff (open).
  - No length limits are checked on the form (OWN-001 note; inferred).
  - Not traced in the extraction: how the pages display individual fields, and what happens when an edit is submitted for a client whose pets were not on the form, under one of the storage variants (the effect was not determined).
- **Workarounds**: None are recorded in the extraction. How staff deal with duplicates, wrong entries or erasure requests outside the system is not known and is not assumed.

## 6. Stakeholder Requirements

No customer statements were provided for this capability. The items below are the analysts' working framing, derived from the documented findings, and are for confirmation.

- **COO / business sponsor and practice managers**: Name the owner of the client register and obtain the retention and erasure decision (OD-1) before any delete, archive or audit function is planned. Agree whether paging of the client list is wanted (RISK-010).
- **Front-desk lead and front-desk staff**: Finding, registering and editing a client stays a short task on one form each. Front-desk staff must confirm whether the digits-only telephone rule fits the clinic's clients, and whether the search is to ignore capital letters on whichever data store the clinic uses (also an open item in section 7).
- **Lead vet**: Reads the client record to see pets and visits; no specific requirement is documented. To be asked.
- **Needs from the clinic's technical owners (listed under the roles above, not as a separate team)**: The search must behave the same whichever data store is used (See Persistence and Data Platform). Access to client records: See RBAC.

## 7. Future-State Vision

All of the following are analysts' working framing, not agreed scope.

- **Desired Capabilities**:
  - A client list that is shown in pages when many clients match, with the search results still reachable by last name (RISK-010).
  - A recorded decision on retention, erasure and audit of client personal data, followed by whatever functions that decision requires (RISK-019). Delete or archive functions are added only after the decision.
  - The same search result for the same text on every supported data store (alignment owned by Persistence and Data Platform).
- **Business Outcomes**: The clinic can show a clear policy for client personal data; large client lists stay usable; staff find the same clients regardless of how a name is capitalised.
- **Timeline Considerations**: Wave 1, high priority (extraction). Sequence: the decision on OD-1 comes before any retention or erasure functions; paging is independent of it. Dates and effort are not estimated here and are open for the customer.
- **Open items for the customer**: who owns the client register and decides OD-1; the expected number of clients; whether the search should be case-insensitive on all data stores; whether duplicate-client protection and other telephone formats are wanted.

## 8. Related Business Capabilities

- **Depends On**: RBAC (who may change client records; today anyone who can reach the system can); Application Security (OWN-005 and protection of the forms); Persistence and Data Platform (consistent behaviour of OWN-009 across data stores).
- **Supports**: Patient Management (a pet belongs to a client), Visit History (visits reach the client record through the pet), Web Shell and Localization (menu and pages that wrap the client screens).
- **Integration Points**: None. The extraction found no connections to outside systems; the client register is held in the clinic's own data store only.

## 9. Success Metrics and KPIs

- **KPI 1 - Search accuracy (OWN-003, OWN-004)**: 100% of test searches return exactly the clients whose last name starts with the typed text, including clients with no pets, and route correctly to not found / single client / table.
- **KPI 2 - Required details and telephone rule (OWN-001, OWN-002)**: 100% of attempts to save a client with a missing detail or a non-digit telephone number are rejected with a message and nothing is saved; 100% of valid forms are saved.
- **KPI 3 - Edit integrity (OWN-006)**: 100% of tested edits change only the submitted client and keep the client's pets and visits visible afterwards. This also covers the unverified effect noted in section 5.
- **KPI 4 - Paging (RISK-010)**: With a test list larger than one page, 100% of searches show a limited number of clients per page and let staff reach all matches. The page size and the client volume to test with are OPEN items for the customer.
- **KPI 5 - Capital letters (OWN-009)**: 100% of tested last names found with the same result in upper-case, lower-case and mixed-case typing, on 100% of the ways of storing data the clinic supports. Current-state baseline (not the target): the result on the two real-use database options is currently unverified. Which options the clinic supports is the customer's data-store decision (OPEN).
- **KPI 6 - Retention decision (OD-1 / RISK-019)**: A named decision owner and a recorded answer to "how long are records kept and can a person's data be erased" exist before any delete, archive or audit function is specified. Target date is OPEN, set by the customer.
- **KPI 7 - Unknown client (OWN-010)**: 100% of requests for a non-existent client end in a clear error page and never in a blank or partial record.

## 10. Risks and Mitigation

- **RISK-010 - The client list is unbounded**: A search with no text returns every client with no paging or throttling. Extraction rating: impact Low (10 sample clients), likelihood Medium with real volumes; the clinic's real volume is unknown.
  - Mitigation: Add paging to the search and test it with a large client list (extraction recommendation).
- **RISK-019 - No retention, erasure or audit for client personal data**: Extraction rating: impact Medium, likelihood Low for the sample (fictitious data), rising with real data. The clinic holds names, addresses and telephone numbers it cannot remove or trace changes to. Open decision OD-1 is attached.
  - Mitigation: Name the owner of the client register, decide the retention and erasure requirement first, then specify delete, archive or audit functions (extraction recommendation).
- **Unverified search behaviour on some data stores (OWN-009)**: Current-state baseline: staff using either real-use database option may not find "smith" when the record is "Smith". Not verified by running the system.
  - Mitigation: Verify on every supported data store; alignment: See Persistence and Data Platform.
- **Unprotected client records**: See RBAC.
- **Request-level protection of the forms**: See Application Security.

## Appendix: Traceability to Technical Implementation

Extraction documents (knowledge base):
- Capability definition and ownership split: [capabilities/index.md](../../capabilities/index.md)
- Rules OWN-001 to OWN-010: [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) (detail in [business-logic-rules/owners.md](../../extraction/business-logic-rules/owners.md))
- Business intent for owners: [business-intent/owners.md](../../extraction/business-intent/owners.md)
- Data flows for find, register, edit and view: [data-flow/index.md](../../extraction/data-flow/index.md) (detail in [data-flow/owner-flows.md](../../extraction/data-flow/owner-flows.md))
- Data model: [data-model/index.md](../../extraction/data-model/index.md)
- Screens: [ui-ux/owners.md](../../extraction/ui-ux/owners.md)
- RISK-010 and RISK-019: [risk-gap/index.md](../../extraction/risk-gap/index.md) (detail in [risk-gap/security.md](../../extraction/risk-gap/security.md))

Source code references quoted by the extraction (provenance only; not read again for this BRD):
- Search, create, edit, view: [OwnerController.java](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/OwnerController.java)
- Validation and pet ordering: [Owner.java](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/model/Owner.java)
- No delete operation: [OwnerRepository.java](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/repository/OwnerRepository.java)
- Case-insensitive last name column (default store): [h2/schema.sql:39](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/db/h2/schema.sql#L39)

Provenance labels: all rules and risks above are extraction facts; the workflows are plain-language restatements of extraction facts; sections 6 and 7 are the analysts' working framing; no customer input is included.

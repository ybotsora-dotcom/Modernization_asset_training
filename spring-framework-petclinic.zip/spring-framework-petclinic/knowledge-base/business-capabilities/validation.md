# BRD Validation Report

Generated: 2026-11-13
Scope: rbac, application-security, persistence-data-platform, operations-observability-delivery, client-management, patient-management, visit-history, clinical-staff-management, web-shell-experience
Capability map: present (knowledge-base/capabilities/index.md and summary.json; 9 of 9 BRDs marked available)

This is a completely new run on the current files. No earlier finding was assumed open or fixed; every item below was checked against the current text.

## Executive Summary
- Total BRDs evaluated: 9
- Portfolio score: 97 / Grade: A
- CRITICAL: 0 | HIGH: 0 | MEDIUM: 21 | LOW: 8
- Wave/Capability gaps: none. All 9 approved capabilities have a BRD, all 4 waves are covered, and the capability map is current.
- Single-owner check: every one of the 21 risks and 40 rules is stated in its owner's BRD, and no BRD claims an item owned elsewhere. Four minor restatements of owned items remain outside the owner (DUP-01 to DUP-04). No owned requirement is stated in full in two BRDs.
- Conflicts: none. No BRD contradicts another, and there is no wording tension that contradicts another BRD.
- Business language: no product, data store, format, framework or tool name appears in the body of any BRD. All such names are confined to the Appendices. Counts tied to today's platform still appear in bodies (see PDP-P1, AS-P1, CM-P1).
- Customer input: Visit History OD-1 (does a visit need a vet) is labelled customer input, lists both stakeholder positions and takes neither side. No other BRD states a position.

## Dimension Scores (portfolio means)
| Dimension | Score | Max |
|---|---|---|
| Capability & Wave Alignment | 20.0 | 20 |
| Document Structure Completeness | 20.0 | 20 |
| Requirement Clarity & Measurability | 23.0 | 25 |
| Acceptance Criteria Quality | 14.7 | 15 |
| No Duplication / No Conflicts | 18.9 | 20 |
| **Total** | **96.6 (97)** | **100** |

## Score summary
| BRD | Score | Grade | Align | Structure | Clarity | Acceptance | Dedup |
|---|---|---|---|---|---|---|---|
| persistence-data-platform | 99 | A | 20 | 20 | 25 | 15 | 19 |
| application-security | 98 | A | 20 | 20 | 25 | 15 | 18 |
| patient-management | 98 | A | 20 | 20 | 23 | 15 | 20 |
| clinical-staff-management | 98 | A | 20 | 20 | 23 | 15 | 20 |
| rbac | 97 | A | 20 | 20 | 23 | 15 | 19 |
| client-management | 96 | A | 20 | 20 | 23 | 15 | 18 |
| visit-history | 96 | A | 20 | 20 | 23 | 15 | 18 |
| web-shell-experience | 94 | A | 20 | 20 | 23 | 12 | 19 |
| operations-observability-delivery | 93 | A | 20 | 20 | 19 | 15 | 19 |

## How the dimensions were judged
- **Alignment (all 20/20):** every front-matter `capability/` tag matches the Section 2 capability name; every capability exists in the map with a wave; no BRD spans waves; every Related Business Capabilities entry resolves to another BRD. Index and summary.json both show 9 of 9 BRDs, so the earlier stale-map note no longer applies.
- **Structure (all 20/20):** each BRD has all ten mandatory sections plus the traceability appendix (11 H2 headings each).
- **Clarity:** deduction of 2 per vague term in Sections 3, 4 and 6 (question phrasing such as "whether a visit should name a vet" is not counted). No untraceable requirement clusters: every BRD uses rule or risk identifiers throughout.
- **Acceptance:** every KPI states a number, percentage or testable condition, with the open customer decisions marked OPEN, except Web Shell KPI 7.
- **Deduplication:** 1 point per minor restatement of an owned item, applied to both participating BRDs (the restater and the canonical owner). A "See <Capability>" plus a one-clause gloss is not counted.

## BRD Scorecards

### rbac: Business Requirements Document: RBAC
**Score**: 97/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 23/25 · acceptance 15/15 · dedup 19/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| RBAC-D1 | MEDIUM | Duplication | Sec 5 gap; Sec 7 Q5; Sec 9 open items | The audit (who changed what) need is part of RISK-019, owned by Client Management. RBAC raises it as a gap, a question and an open KPI item without a See reference. | Replace with "See Client Management (RISK-019)"; keep only whether a sign-in identity is needed. |
| RBAC-V1 | MEDIUM | Clarity | Sec 6, Business Users | "without added friction" has no measurable meaning. | State a testable condition, for example the same number of steps as today. |

#### Strengths
- States plainly that it is a gap and a decision, not a working feature; owns no rules and says so.
- Owns RISK-001 and RISK-003 completely; Patient Management and Visit History write only "See RBAC".
- Six open questions are numbered and KPI 2 measures their closure (6 of 6).
- No platform count or product name anywhere in the body.

---

### application-security: Business Requirements Document: Application Security
**Score**: 98/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 25/25 · acceptance 15/15 · dedup 18/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| AS-D1 | MEDIUM | Duplication | Sec 5, What Works Well | "A single generic error page is used for every failure" restates PLT-004 (Web Shell and Localization). | "See Web Shell and Localization (PLT-004)". |
| AS-D2 | MEDIUM | Duplication | Sec 3 Workflow 2 rules; Sec 5 What Works Well | States that client and visit forms ignore a supplied identifier (VIS-008, Visit History) and that client and visit entries are checked for required details (OWN-001, VIS-001). | Keep OWN-005 and RISK-007 only; refer to the owners for the rest. |
| AS-P1 | MEDIUM | Platform neutrality | Sec 3 Workflow 5; Sec 5; Sec 9 KPI 3 | "two real-use database setups", "in any of the three ways the application stores data"; KPI 3 baseline 2, target "0 of 2". The count enters a measurable target and would not survive a platform decision. | Target: 0 passwords in shared files or the packaged application on every supported setup; keep the count only as a labelled baseline. |
| AS-L1 | LOW | Traceability | Sec 10 Risk 7; Sec 9 KPI 4 | Risk 7 cites open question 5 for "real clinic use", but Q5 asks whether findings may be accepted; KPI 4 cites Q1 and Q2 only loosely. | Correct references or add the intended-use question to Section 7. |

#### Strengths
- Owns all five risks and OWN-005 and states each protection as a testable KPI (5 of 5 pages, 100% of pages, 0 occurrences).
- Sections 3 and 6 contain no vague terms; See references to RBAC, Client Management and Persistence are explicit.
- Technology terms (forgery protection, TLS, headers) are confined to the Appendix, which says so.

---

### persistence-data-platform: Business Requirements Document: Persistence and Data Platform
**Score**: 99/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 25/25 · acceptance 15/15 · dedup 19/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| PDP-D1 | MEDIUM | Duplication | Sec 3 Workflow 5; Sec 7 Q4 | "no screen allows editing or deleting" and "May a saved visit be corrected or deleted?" restate the no-delete part of OWN-008 (Client Management). | Keep visit correction (VIS-007); for deletion write "See Client Management (OWN-008, OD-1)". |
| PDP-P1 | MEDIUM | Platform neutrality | Sec 1; Sec 3 W1, W3; Sec 4 PLT-002; Sec 5; Sec 10 Risk 3 | The body is built on today's counts: three ways of storing, four data store products, "two of the products rebuild, the other two create if missing" (inside PLT-002), "built and checked three times", sample record counts (6 vets, 3 specialties, 6 pet types, 10 clients, 13 pets, 4 visits). The requirements themselves are neutral, but the counts are wrong after any platform decision. | Move to a labelled current-state baseline or the Appendix; reword PLT-002 and Risk 3 without counts. |
| PDP-I1 | MEDIUM | Completeness | Sec 3 W4; Sec 5; Sec 9 KPI 2 | The list of known differences between storage options omits the cascade-save difference in Client Management OWN-008 and the uncertain edit-with-pets-not-on-form behaviour in Client Management Sec 5. RISK-014 is owned here. | Add See pointers to the list and KPI 2 or state the list is completed after the options decision. |
| PDP-L1 | LOW | Readability | Sec 3 W2; Sec 5 | "deletes the clinic's record tables and rebuilds them" is data-store vocabulary; the retention mention in the last gap bullet has no See pointer (RISK-019). | Say "erases and recreates all stored records"; add "retention: See Client Management". |
| PDP-L2 | LOW | Open questions | Sec 7 Q1 | The question "will real records be used?" is also asked in Operations (Unconfirmed need) and Application Security (Risk 7). | Ask once here; others write "See Persistence and Data Platform". |

#### Strengths
- Owned rules (PLT-001, 002, 005, VIS-007) and risks (014, 015, 016, 020, 021) are all present and each KPI has a testable target.
- Differences owned elsewhere (vet order, search letter case, monitoring) are one-clause glosses with See references; RISK-004 is "See Application Security" throughout.
- States that no customer input exists and labels analysts' framing.
- The body explains in business terms and keeps product names in the Appendix.

---

### operations-observability-delivery: Business Requirements Document: Operations, Observability and Delivery
**Score**: 93/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 19/25 · acceptance 15/15 · dedup 19/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| OPS-D1 | MEDIUM | Duplication | Sec 5, What Works Well | "staff see a generic error page" and failure logging restate PLT-004 (Web Shell and Localization). | "See Web Shell and Localization (PLT-004)". |
| OPS-V1 | MEDIUM | Clarity | Sec 3 W1 step 1; Sec 4 Rule 2 | "a simple, documented way", "without special knowledge" are not measurable. | Define a testable condition (steps, no training needed). |
| OPS-V2 | MEDIUM | Clarity | Sec 6, Front-desk staff | "a clear explanation" is not measurable. | Define the content (affected part, expected time to resume). |
| OPS-V3 | MEDIUM | Clarity | Sec 6, Front-desk lead | "fewer surprises at opening time" is not measurable. | Replace with a testable notice condition. |
| OPS-R1 | MEDIUM | Cross-reference | Sec 3 W3; Persistence Sec 3 W4 | Operations says the storage option where counting is ineffective is "described in Persistence and Data Platform"; Persistence only says "See Operations". Neither body describes it. PLT-003 is owned here. | Describe the limitation in plain words here; Persistence keeps a See pointer. |
| OPS-L1 | LOW | Platform neutrality | Sec 3 W5, W6 | "re-read every 30 seconds", "a ready-to-run bundled copy", "limited to one runtime version and tested on two" (labelled baseline). | Move to the Appendix; keep the baseline label. |

#### Strengths
- Owns PLT-003 and RISK-008, 009, 017, 018 completely; items owned elsewhere are See references.
- Nine KPIs with 100% or 2-of-2 targets; every open number is marked OPEN with an owner needed.
- The platform baseline (runtime version) is labelled "not a requirement" and the requirement is worded neutrally (a version the clinic chose and its supplier supports).
- Technology mapping from business terms to products sits in the Appendix.

---

### client-management: Business Requirements Document: Client Management
**Score**: 96/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 23/25 · acceptance 15/15 · dedup 18/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| CM-V1 | MEDIUM | Clarity | Sec 6, Front-desk | "stays a short task on one form each" is not measurable. | State a testable condition (no more fields or screens than today). |
| CM-P1 | MEDIUM | Platform neutrality | Sec 4 OWN-008 and operational constraint; Sec 5; Sec 10 | OWN-008 says the carry-over is "built into only one of the system's three interchangeable ways of storing data" with no baseline label; "two real-use database options" and "sample data holds 10 clients" tie text to today's platform (OWN-009 and KPI 5 do label theirs). | Label as baseline or move to the Appendix; reword OWN-008 without the count. |

Participates as canonical owner in DUP-03 (OWN-008) and DUP-04 (RISK-019); one point deducted for each, no issue of its own.

#### Strengths
- Owns OWN-001 to 010 (except OWN-005) and RISK-010 and RISK-019; OD-1 is set out as an open decision with no invented position.
- OWN-009 is written as a platform-neutral requirement with the count shown as a labelled baseline.
- "Add Owner", search routing and the five-detail edit are described in terms a practice manager can follow.
- Persistence, Application Security and RBAC items are See references.

---

### patient-management: Business Requirements Document: Patient Management
**Score**: 98/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 23/25 · acceptance 15/15 · dedup 20/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| PM-V1 | MEDIUM | Clarity | Sec 6, Front-desk | "a single short form" and "messages tell staff clearly what to fix" are not measurable. | Tie to testable conditions (message beside each rejected field; no more fields than today). |
| PM-L1 | LOW | Readability | Sec 3 W2 rules | "depends on how the edit form passes the pet's identity" is implementation-shaped wording. | Reword as "whether an edited pet is re-checked for type is to be confirmed". |

#### Strengths
- Owns PET-001 to PET-009 and no risks; RISK-003, RISK-007, RISK-012 are written only as "See" in Sections 1, 4, 5, 10 with no restatement.
- Seven KPIs are measurable; the clinical-information question is raised as a customer question, not a finding.
- Cleanest BRD on single ownership: no duplication or tension found.

---

### visit-history: Business Requirements Document: Visit History
**Score**: 96/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 23/25 · acceptance 15/15 · dedup 18/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| VH-D1 | MEDIUM | Duplication | Sec 3 W2 rules | "no way for staff to edit or delete one" restates the no-delete part of OWN-008 (Client Management). Also participates, as owner of VIS-008, in DUP-02 (Application Security AS-D2). | "See Client Management (OWN-008); correction: See Persistence and Data Platform (VIS-007)". |
| VH-V1 | MEDIUM | Clarity | Sec 6, Business Users | "recording to stay as quick as today" is relative and not measurable. | Use the testable condition of KPI 7 (no more than the current two fields). |

#### Strengths
- OD-1 (does a visit need a vet): Front-desk lead and Lead vet positions are labelled customer input, not extraction evidence; the BRD takes neither side, defers to the current behaviour (VIS-002) and asks for a decision owner and date.
- RISK-012 is specified once for both dates, as the map requires; Patient Management only points here.
- VIS-007 and RISK-003 are See references. KPI 3 matches the cross-reference in Patient Management.

---

### clinical-staff-management: Business Requirements Document: Clinical Staff Management
**Score**: 98/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 23/25 · acceptance 15/15 · dedup 20/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| CSM-V1 | MEDIUM | Clarity | Sec 6, Front-desk | "a correct, readable vet list": "readable" is not measurable. | All vets and specialties visible on one page in rule order. |
| CSM-L1 | LOW | Platform neutrality | Sec 4 VET-001, VET-006; Sec 5; Sec 9 KPI 1 | Counts and mechanisms of today's platform ("two of the three ways", "enforced by the data store itself for two of the four supported databases, the other two rely on the application not creating duplicates in memory"). Labelled "Current-state baseline (not a requirement)", so not scored; the mechanism wording is technical. | Shorten to "not verified on every supported option"; detail to the Appendix. |

#### Strengths
- Requirements are platform-neutral (same order and link integrity on every supported option) with the baseline separated.
- Says plainly that the capability is a read-only directory despite its name; management functions are new scope (OD-V2).
- Vet-on-visit question is a See Visit History reference, not restated.
- Owns VET-001 to 007 and RISK-013 with a testable freshness KPI.

---

### web-shell-experience: Business Requirements Document: Web Shell and Localization
**Score**: 94/100 (Grade: A) | **Alignment**: ALIGNED
**Breakdown**: align 20/20 · structure 20/20 · clarity 23/25 · acceptance 12/15 · dedup 19/20

#### Issues Found
| ID | Severity | Category | Section/Line | Description | Recommendation |
|---|---|---|---|---|---|
| WS-K1 | MEDIUM | Acceptance criteria | Sec 9 KPI 7 | "Owned risks closed: not applicable; this capability owns 0 risks" has no measurable target. | Delete or replace. |
| WS-V1 | MEDIUM | Clarity | Sec 6, Front-desk | "a clear way back to the starting point" is not measurable. | Home entry reachable from 100% of pages. |
| WS-L1 | LOW | Platform neutrality | Preamble; Sec 3 W3; Sec 5 | "message bundle", "icon names that the icon set may not contain", "older and newer style of layout", "treats the error page as a successful page display". | Rephrase in business terms; detail to the Appendix. |

Participates as canonical owner in DUP-01 (PLT-004); one point deducted, no issue of its own.

#### Strengths
- Owns PLT-004 only and no risks; RISK-006 is a See reference throughout.
- A glossary of plain-language terms at the top lets a non-technical reader follow Section 3.
- Honestly reports that only one heading is localised (KPI 3 baseline 0 of 9 with a 9 of 9 target).

---

## Cross-BRD Issues

### Single-owner check (all nine BRDs)
- Risk ownership: RISK-001/003 only in RBAC; 002/004/005/006/007 in Application Security; 008/009/017/018 in Operations; 010/019 in Client Management; 011/012 in Visit History; 013 in Clinical Staff Management; 014/015/016/020/021 in Persistence. Other BRDs write "See" only (Patient Management, Visit History, Web Shell, Persistence, Client Management and RBAC checked line by line).
- Rule ownership: all 40 rules appear in their owners' BRDs (OWN-005 in Application Security; VIS-007 in Persistence; PLT-003 in Operations; PLT-004 in Web Shell; none in RBAC).
- The only restatements are the four below, each a behaviour description or open question rather than a re-specified requirement.

### Duplications
| Issue ID | BRD A | BRD B | Description | Canonical Owner |
|---|---|---|---|---|
| DUP-01 | application-security | operations-observability-delivery | Generic error page for every failure (PLT-004) described as working behaviour in AS Sec 5 and Ops Sec 5 (AS-D1, OPS-D1). Also deducted from Web Shell. | web-shell-experience (PLT-004) |
| DUP-02 | application-security | visit-history | AS states that the visit form ignores a supplied identifier (VIS-008) and that client and visit entries are checked for required details (OWN-001, VIS-001) (AS-D2). | visit-history (VIS-008, VIS-001); client-management (OWN-001) |
| DUP-03 | visit-history | persistence-data-platform | No-delete of visits (part of OWN-008) and the question whether a visit may be deleted, restated in VH Sec 3 W2 and PDP Sec 3 W5 and Sec 7 Q4 (VH-D1, PDP-D1). | client-management (OWN-008, OD-1) |
| DUP-04 | rbac | client-management | Audit (who changed what) element of RISK-019 restated in RBAC Sec 5, Sec 7 Q5 and Sec 9 (RBAC-D1). | client-management (RISK-019) |

### Conflicts
| Issue ID | BRD A | BRD B | Description | Resolution Needed |
|---|---|---|---|---|
| none | | | No contradictory behaviour found. Scope-limited statements (for example "client records stay in the register" in Client Management versus "records are lost at restart" in Persistence) are explicitly qualified and point to each other. | none |

### Other cross-BRD consistency findings (no formula term)
| ID | Severity | Description |
|---|---|---|
| OPS-R1 | MEDIUM | Circular reference for the PLT-003 limitation (Operations and Persistence). |
| PDP-I1 | MEDIUM | Persistence's list of storage-option differences omits the Client Management OWN-008 cascade-save difference. |
| PDP-L2 | LOW | The same "real records or demonstration?" question is raised in three BRDs. |
| PORT-L1 | LOW | Provenance vocabulary ("extraction fact", "analysts' working framing", "confidence MEDIUM", "inferred") and rule ids inline in workflow steps appear in the body of all nine BRDs and read as analysis jargon to a practice manager. |

### Business-language review (customer requirement: no technology in the body)
- **Product, store, format or tool names in bodies:** none in any of the nine BRDs (checked against the project-profile stack terms and a wider list; every hit was before the Appendix line and none remained). Visit History's only hit was "decision session".
- **Section 3 readable by a practice manager:** yes in all nine, with small exceptions (PDP-L1 "record tables", WS-L1 "message bundle").
- **Counts tied to today's platform in bodies:** present in Persistence (PDP-P1), Application Security (AS-P1, including a KPI target), Client Management (CM-P1). Clinical Staff Management, Operations and Client Management OWN-009 / KPI 5 label theirs as "Current-state baseline (not a requirement)" and are rated LOW or not flagged.
- **Requirements that survive a platform decision:** OWN-009, VET-001, VET-006, KPI 5 (Operations), PLT-001 and the Operations platform-version rule are worded as "every supported option" and pass; AS KPI 3 and Persistence PLT-002 do not.
- **Customer input labelled correctly:** Visit History OD-1 only. Other BRDs state "no customer input recorded".

### Wave/Capability Gaps
| Wave/Capability | Missing Coverage | Recommendation |
|---|---|---|
| none | All 9 capabilities have a BRD; Waves 0 to 3 are covered. Index and summary.json agree (9 of 9 available). | none |

## Prioritised Fix List
No CRITICAL or HIGH issues. Recommended order for the MEDIUM items:
1. AS-P1, PDP-P1, CM-P1 (customer requirement: platform-neutral body). Start with AS KPI 3 and Persistence PLT-002 because those carry counts into requirements.
2. DUP-01 to DUP-04 (single ownership): AS-D1, AS-D2, OPS-D1, VH-D1, PDP-D1, RBAC-D1; replace each with a "See <Owner>" pointer.
3. OPS-R1 and PDP-I1: describe the monitoring limitation once in Operations; complete the Persistence difference list with a pointer to Client Management OWN-008.
4. WS-K1: remove or replace Web Shell KPI 7.
5. Vague wording (RBAC-V1, OPS-V1 to V3, CM-V1, PM-V1, VH-V1, CSM-V1, WS-V1): replace with testable conditions.
6. LOW items: AS-L1, PDP-L1, PDP-L2, OPS-L1, PM-L1, CSM-L1, WS-L1, PORT-L1.

## Fix Report
Generated: 2026-11-13
Based on: User input (stakeholder conflict described in the request)

### Conflicts needing stakeholder input
| BRD | Section | Item | Status |
|---|---|---|---|
| visit-history | Section 4, OPEN DECISION OD-1 | Front-desk lead: a visit may be recorded with no vet (walk-ins). Lead vet: every visit must name a vet (clinical accountability). Both believe they describe current policy. Current behaviour (VIS-002): no vet is required or recorded, so the first position matches today and the second is not implemented. | OPEN - unresolved by design |

- Change made: the marker `[CONFLICT-RESOLUTION-NEEDED: ...]` was inserted at OD-1 in `visit-history/BRD-visit-history.md` and mirrored in `identifiedGaps` of `visit-history/capability-summary.json`. The existing OD-1 text, the customer-input labels and all See references are unchanged. No requirement assumes either position.
- Decision needed from the customer: the vet-on-visit policy (and, if a vet is recorded, whether it is mandatory, optional, or mandatory except for walk-ins), a named decision owner, and a decision date.
- Update 2026-11-17: a recommended resolution (Option 3: attending vet recorded on every visit, entered by the end of the visit) was added to OD-1 in the BRD and its JSON and to `CONF-VH-OD1`. It is an analyst recommendation. The status stays OPEN until the customer decides, because only the customer can settle which position is policy.
- Nothing is marked RESOLVED. The conflict is recorded in `validation-summary.json` under `crossBrdConflicts` as `CONF-VH-OD1` with status OPEN. Scores, grades and issue counts of the original report are not changed.

### Recommended Next Steps
- Obtain the customer decision, then update OD-1 and the dependent items (KPI 6, KPI 7, Clinical Staff Management dependency note).
- Re-run /validate-brd to verify.

## Fix Report
Generated: 2026-11-13
Based on: User input (fix WS-K1 and the platform-neutral findings AS-P1, PDP-P1, CM-P1) and the latest report above.

### Changes Made
| BRD | Section | Change Type | Description | Status |
|---|---|---|---|---|
| web-shell-experience | Section 9 | Remove | KPI 7 ("Owned risks closed: not applicable") removed. KPIs 1 to 6 and the open customer item are unchanged, so numbering stays consistent. The capability-summary.json kpis list already held 6 KPIs, so it needed no change (WS-K1). | RESOLVED |
| application-security | Section 5 (What Works Well), Appendix | Rewrite | "three ways the application stores data" and "all three persistence variants" now read "every supported way of storing data" and "every persistence variant" (AS-P1). | RESOLVED |
| application-security | Section 9 KPI 3 and capability-summary.json | Rewrite | Target is now "0% of supported database setups have a password in shared files, and none in the packaged application". The count of 2 is kept only as "Current-state baseline (not a requirement)" (AS-P1). | RESOLVED |
| persistence-data-platform | Sections 1, 3 (Workflows 1 and 3), 4 (PLT-002), 5, 10 and capability-summary.json | Rewrite / relocate | Counts of ways of storing, products, sample records and the "two rebuild / two create" detail are replaced by neutral wording ("several", "once for every way of storing", "some products ... others"). All current counts are kept once, in a new Section 5 bullet "Current-state baseline (not a requirement)", mirrored in the JSON summary text. No product names. KPIs already used neutral targets (PDP-P1). | RESOLVED |
| client-management | Section 4 (OWN-008) and capability-summary.json | Rewrite | "one of the system's three interchangeable ways of storing data" replaced by: whether saving a client also saves its pets and visits depends on how data is stored, See Persistence and Data Platform (CM-P1). | RESOLVED |

### Unresolved Items (require stakeholder input)
- Unchanged: OD-1 and its [CONFLICT-RESOLUTION-NEEDED] marker in Visit History, and all customer open items.
- All other open Medium and Low findings remain OPEN. Appendix evidence rows that name the current implementations and sample counts were left as traceability.

### Recommended Next Steps
- Re-run /validate-brd to verify improvements. Scores in this report were not recalculated.

---
tags:
  - brd
  - capability/web-shell-experience
---
# Business Requirements Document: Web Shell and Localization

> **Nature of this document.** This capability is the cross-cutting layer around the clinic's screens: the landing page, the navigation menu, the shared look and the generic error page, plus the languages the pages are offered in. It is **Wave 3 (Consistent Shell and Language)**, priority **low**, complexity **simple**. The error page is a **deliberately triggered demonstration, not a business function**. Customer input has not been captured for this capability: statements below are labelled as **extraction fact** (taken from the analysis of the existing system), **customer input** (none recorded) or **analysts' working framing** (to be confirmed with the customer).

Plain-language terms used in this document:
- **Shell**: the parts every page shares: the top menu, the page frame, the logo and the colours and fonts.
- **Localization**: showing the pages in the language of the reader (here English, German or Spanish). A **locale** is simply the language (and region) a reader prefers.
- **Message bundle**: the list of wordings the application keeps for each supported language.

## 1. Executive Summary
Every screen of the clinic application sits inside the same frame: a top menu with four entries (Home, Find owners, Veterinarians, Error), a consistent look, and a sponsor logo at the bottom. A landing page welcomes staff, and one generic error page appears whenever something unexpected goes wrong, for example when staff open a client that does not exist. The application also carries wording for three languages (English, German, Spanish), but according to the extraction almost all on-screen text is fixed in English; only the heading of the landing page is actually taken from the language wording. This capability exists so that the frame, the error page and the languages are consistent and match what the pages really show. It adds no new business activity and carries no risks of its own.

Key stakeholders: COO / business sponsor, practice managers, front-desk lead, front-desk staff (daily users of the menu and landing page) and the lead vet (an occasional reader of the vet list reached through the menu).

Sources: this BRD is based on extracted knowledge only (no source-code re-analysis). See the Appendix.

## 2. Business Capability Definition
- **Capability Name**: Web Shell and Localization (slug: web-shell-experience)
- **Business Domain**: User experience and platform (Wave 3 - Consistent Shell and Language)
- **Primary Stakeholders**: COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet
- **Business Objective**: Give staff a consistent landing page, navigation menu and look, a generic error page, and make the wording offered in English, German and Spanish match what the pages actually show.
- **Key Business Value**: Staff reach any part of the application from the same menu and see the same look everywhere, and a failure never leaves them on a blank or unfamiliar page. Language alignment matters only if the clinic needs staff to work in German or Spanish; that need is not recorded in the extraction. No revenue or cost figures are stated and none are claimed.
- **Features in scope (extraction fact)**: Welcome Page; Error Page Demonstration.
- **Rule owned here**: PLT-004 (unhandled errors show a generic error page). No other rule and **no risk** is owned by this capability.
- **Not in scope**: the content of the client, pet, visit and vet screens (owned by their capabilities). Who may see which page is owned by RBAC.

## 3. Business Workflows
- **Workflow 1: Start at the landing page and move around the application**
  - Trigger: A staff member opens the clinic application at the start of the day or returns to the starting point.
  - Primary Actors: Front-desk staff, front-desk lead, practice managers, lead vet.
  - Steps:
    1. Staff open the application and see a welcome heading with a picture of a cat and a dog.
    2. A menu across the top offers four entries: Home, Find owners, Veterinarians and Error.
    3. Staff choose an entry; the matching page opens and the chosen entry is highlighted so staff can see where they are.
    4. The same menu, look and sponsor logo are shown on every page.
  - Business Rules: The menu is the same for everyone; there is no sign-in and no menu entry is hidden or shown by role (extraction fact; access decisions belong to RBAC). Forms have no "Back" or "Cancel" button, so staff leave a form using the application menu or their browser navigation controls.
  - Outcome: Staff reach client search, the vet list and the landing page from any screen without needing to remember addresses.

- **Workflow 2: Demonstrate the error page (deliberately triggered)**
  - Trigger: Someone selects the "Error" entry in the menu to see what the application shows when something goes wrong.
  - Primary Actors: Practice managers or testers/demonstrators (no business owner for this activity was identified during the review).
  - Steps:
    1. The person selects "Error" in the menu.
    2. The application deliberately raises a failure on purpose.
    3. The generic error page opens, showing the picture, the heading "Something happened..." and the text of the failure message.
  - Business Rules: This is a demonstration only. It supports no clinic activity and changes no records.
  - Outcome: The person sees what staff would see in a real failure. Whether the "Error" entry should stay in the menu used by front-desk staff is an open question (Section 5).

- **Workflow 3: An unexpected failure during normal work (fallback)**
  - Trigger: Something goes wrong while staff use any screen, for example opening a client that does not exist.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff request a page and the application cannot complete it.
    2. Instead of the requested page, the same generic error page is shown inside the usual menu and look.
    3. The failure is written to the application's warning log.
    4. Staff use the menu to continue.
  - Business Rules: PLT-004: any unexpected failure shows one generic error page, whichever screen it came from. Current automated checks treat this page as successfully displayed even when an error has occurred. The impact of this approach on system monitoring requires further review.
  - Outcome: Staff always land on a familiar page with a way forward. The page currently shows the technical failure text; the safety of that is a finding owned by Application Security (see Section 10).

- **Workflow 4: Read the pages in English, German or Spanish (current state)**
  - Trigger: A staff member prefers to work in German or Spanish.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff open the landing page. Its welcome heading is available in the three languages.
    2. Staff open any other page. Menu entries, page titles, buttons and form labels appear in English.
  - Business Rules: Wording for English, German and Spanish exists, but only the welcome heading is used by the pages (extraction fact). How the language is selected was not confirmed during the review. The current behaviour suggests it may follow the browser's language settings, but this has not been verified.
  - Outcome: Today the application is effectively English-only apart from one heading.

## 4. Business Rules and Constraints
- **Rule PLT-004 (owned here; extraction fact)**: Any unexpected failure on any screen shows one generic error page and is logged as a warning. Rationale: staff must never be left on a broken or blank page. The error demonstration entry in the menu triggers this rule on purpose.
- **Constraint (extraction fact)**: A client that does not exist also leads to this error page (rule OWN-010, owned by Client Management; see Client Management).
- **Constraint (extraction fact)**: One kind of client only: a web browser. No separate mobile or native application exists.
- **Constraint (extraction fact)**: The sponsor logo appears on every page.
- **Operational Constraint**: No availability, speed or scale expectations for the shell are stated in the extraction. They are customer questions (Section 6).

## 5. Current Capabilities and Gaps
- **What Works Well (extraction fact)**:
  - One menu, one look and one page frame for all nine screens.
  - The landing page and the generic error page both display correctly inside that frame.
  - The page currently highlighted in the menu matches the page the user is on.
  - The page adapts to smaller screens (menu collapses).
- **Identified Gaps** (this capability owns no risks; these are functional gaps, not risks):
  - Only 1 piece of on-screen text, the welcome heading, is taken from the language wording; all other labels are fixed in English, so the German and Spanish wording does not reach the pages (extraction fact).
  - How a reader's language is selected is not verified, and no language switch is visible on any page.
  - Whether German and Spanish are actually required by the clinic is not recorded (open question).
  - The "Error" entry is visible in the everyday menu, and its icon probably does not display (inferred, not run).
  - Success and failure marks on forms may not display because they use icon names that the icon set may not contain (inferred, medium confidence).
  - Forms mix an older and a newer style of layout; the extraction recommends normalising them.
  - The sponsor logo is for a sponsor named in the sample application; whether the clinic wants its own branding is a customer decision.
  - The error page being counted as a successful page display may hide failures from any future monitoring (analysts' working framing).
- **Workarounds**: None recorded. Staff who need German or Spanish presumably rely on English labels; current practice is not known.
- **Risks**: none owned. For the raw failure text shown on the error page (RISK-006): See Application Security.

## 6. Stakeholder Requirements
No stakeholder interviews are recorded for this capability. The statements below are the analysts' working framing, to be confirmed by the customer.
- **COO / business sponsor and practice managers**: Decide which languages are really required and whether the clinic's own branding replaces the sample sponsor logo; decide whether the error demonstration belongs in a menu used for daily work.
- **Front-desk lead and front-desk staff**: A menu that is the same everywhere, a clear way back to the starting point, and wording in the language they work in. Satisfaction targets are an open item for the customer.
- **Lead vet**: A route from the menu to the vet list that is reachable in one step from any page (the menu has one Veterinarians entry). No other requirement is recorded.
- **Availability, speed and scale expectations**: not stated in the extraction; to be provided by the customer.

## 7. Future-State Vision
- **Desired Capabilities** (analysts' working framing):
  - Every visible word on every page comes from the language wording, and English, German and Spanish wording is complete and equivalent, if the customer confirms these languages.
  - The way a reader's language is chosen is agreed and documented.
  - The error demonstration entry is either kept for demonstration or removed from the daily menu, as decided.
  - Forms use one consistent style and all marks display.
- **Business Outcomes**: A single consistent experience for all roles; staff who prefer German or Spanish can work in that language; no confusing blank or unfamiliar pages.
- **Timeline Considerations**: Wave 3, priority low. It is a finishing layer over screens that already exist and is scheduled after the screen capabilities it wraps. No dates are set; any dates are for the customer to decide.

## 8. Related Business Capabilities
- **Depends On**: Client Management, Patient Management, Visit History and Clinical Staff Management (the shell wraps all their screens; wording to be translated comes from them).
- **Supports**: All users of the above four capabilities, through the menu and error page.
- **See**: Application Security for RISK-006 (raw failure text on the error page). RBAC for any decision about who sees which menu entry.
- **Integration Points**: None. The application has no external system connections (extraction fact).

## 9. Success Metrics and KPIs
- **KPI 1 - Menu entries that open a working page**: 4 of 4 (Home, Find owners, Veterinarians, Error), verified by an automated check on each entry.
- **KPI 2 - Unexpected-failure cases showing the generic error page inside the shared menu and look**: 100% of the failure cases tested (at minimum the demonstration and a non-existent client).
- **KPI 3 - Screens whose visible wording is available in all supported languages**: today 0 of 9 screens fully (only the welcome heading is). Target 9 of 9 for each confirmed language. The list of required languages is an open item for the customer.
- **KPI 4 - Wording gaps between languages**: 0 pieces of wording present in one language and missing in another. Testable by comparing the three wording lists.
- **KPI 5 - Language-selection method documented**: 1 documented and customer-agreed method. Date is an open item for the customer.
- **KPI 6 - Decision on keeping the error demonstration in the daily menu**: 1 recorded decision (keep or remove).
- **Open item needing a customer decision**: staff satisfaction with navigation and language has no target or baseline and is not a KPI yet. The customer must decide who measures it and what threshold applies.

## 10. Risks and Mitigation
This capability owns **no risks**. Risks that touch it are written only as references:
- **RISK-006** (raw failure text shown on the error page): See Application Security.

## Appendix: Traceability to Technical Implementation
Commit: `dc4f7b7c1f878fde2995ed2733d22ba987b827dd`. Everything in this BRD comes from extracted knowledge; no source code was re-analysed. Items the extraction marks as inferred or unverified are labelled as such in the body.

| Claim | Source |
|---|---|
| Capability definition, owned rule PLT-004, no owned risks, See Application Security for RISK-006, dependencies | [capabilities/index.md](../../capabilities/index.md) |
| Shared frame, menu entries, sponsor logo, Welcome and Error screens, styling | [ui-ux/shell-and-vets.md](../../extraction/ui-ux/shell-and-vets.md) |
| Menu structure, routes, no back/cancel buttons, any failure leads to error page | [ui-ux/navigation.md](../../extraction/ui-ux/navigation.md) |
| Screen inventory (9 screens), only the welcome heading uses language wording | [ui-ux/index.md](../../extraction/ui-ux/index.md) |
| Generic error handling intent | [business-intent/platform.md](../../extraction/business-intent/platform.md) |
| PLT-004 and OWN-010 rule detail | [business-logic-rules/platform.md](../../extraction/business-logic-rules/platform.md), [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) |
| RISK-006 detail (owned by Application Security) | [risk-gap/security.md](../../extraction/risk-gap/security.md) |
| Language wording not used by pages except the welcome heading | [knowledge-graph/experience-integration.md](../../extraction/knowledge-graph/experience-integration.md) |
| Data flows | [data-flow/index.md](../../extraction/data-flow/index.md) |
| Error handling configuration | [src/main/resources/spring/mvc-core-config.xml:60-66](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/spring/mvc-core-config.xml#L60) |
| Deliberate failure trigger and its test | [src/main/java/org/springframework/samples/petclinic/web/CrashController.java:32](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/CrashController.java#L32), [src/test/java/org/springframework/samples/petclinic/web/CrashControllerTests.java:38](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/test/java/org/springframework/samples/petclinic/web/CrashControllerTests.java#L38) |
| Menu entries | [src/main/webapp/WEB-INF/tags/menu.tag:16](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/webapp/WEB-INF/tags/menu.tag#L16) |
| Welcome and error pages | [src/main/webapp/WEB-INF/jsp/welcome.jsp:6](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/webapp/WEB-INF/jsp/welcome.jsp#L6), [src/main/webapp/WEB-INF/jsp/exception.jsp:13](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/webapp/WEB-INF/jsp/exception.jsp#L13) |

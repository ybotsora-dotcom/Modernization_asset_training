---
tags:
  - brd
  - capability/application-security
---
# Business Requirements Document: Application Security

> **Nature of this document.** Application Security describes **protections the clinic application does not have today**, plus one protection it does have (a client's identifier cannot be changed by what a user types into a form). Content is split into three kinds and labelled as such: **Extraction fact** (found in the knowledge base), **Customer input** (none is recorded for this capability in the sources used), and **Analysts' working framing** (proposed wording to confirm with the customer). Some extraction facts are marked *inferred*: they come from reading the code, not from running it.

## 1. Executive Summary
The clinic application holds client (pet owner) names, addresses and telephone numbers, pet details and visit notes that may be health related. This capability is about keeping that information from being changed or exposed by the way the web pages work. Five concrete findings belong here: forms can be submitted on a user's behalf without their knowledge; the clinic's database password is kept in shared project files; the pages travel over the network without protection and without the browser safeguards that stop misuse; the error page prints raw error text; and the pet form does not stop someone from supplying another pet's identifier. One protection already works and must be kept: a client's identifier cannot be set by what a user types into a client form.

Key stakeholders: COO / business sponsor, practice managers, front-desk lead, front-desk staff and the lead vet.

Sources: extracted knowledge only (analysts' working framing where stated). No source code was re-analysed. See the Appendix.

## 2. Business Capability Definition
- **Capability Name**: Application Security
- **Business Domain**: Security and access governance (Wave 0 - Safe and Dependable Foundations)
- **Primary Stakeholders**: COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet
- **Business Objective** (analysts' working framing): Client and pet records cannot be changed or read by people who should not be able to, through the way the clinic's web pages behave; and the clinic's database password is not kept in shared files.
- **Key Business Value**: Client personal data and the accuracy of pet records are protected from misuse. The extraction rates one owned finding High (RISK-002), three Medium (RISK-004, RISK-005, RISK-007) and one Low (RISK-006) for any use beyond a demonstration. No revenue figures are stated in the extraction and none are claimed.
- **Priority and placement**: Priority high, complexity complex, Wave 0 (from the approved capability split).
- **Context (extraction fact)**: The application is a sample, and the findings are rated as if it were deployed for real clinic use.

## 3. Business Workflows
The workflows below describe what happens today (as-is) and what the protection must achieve (proposed, analysts' working framing).

- **Workflow 1: Staff save a change to a client, pet or visit (RISK-002)**
  - Trigger: A staff member registers or edits a client, adds or edits a pet, or records a visit.
  - Primary Actors: Front-desk staff, front-desk lead.
  - Steps (today):
    1. Staff open the relevant page and fill in the details.
    2. Staff submit the page.
    3. The change is saved. The application cannot tell whether the staff member really chose to submit it, or whether another website or program caused it to be submitted for them.
  - Steps (proposed):
    1. Staff open the page and fill in the details.
    2. Staff submit the page.
    3. The change is saved only if the submission is recognisably the staff member's own deliberate action. Anything else is refused and nothing is saved.
  - Business Rules: Extraction fact: no such protection exists on any of the five record-changing pages (register client, edit client, add pet, edit pet, record visit). Today anyone can submit these pages directly, so the added protection matters most once staff sign in. Whether staff are required to sign in is covered by Access Control (RBAC). See RBAC.
  - Outcome: A change to clinic records is made only when a staff member really meant to make it.

- **Workflow 2: Staff edit a pet (RISK-007)**
  - Trigger: A staff member edits an existing pet from the client's record.
  - Primary Actors: Front-desk staff.
  - Steps (today):
    1. Staff open the pet from the client's record, change details such as name or birth date, and save.
    2. The pet page does not stop a different pet identifier being supplied along with the form. *(Inferred from the code, not exercised.)* A crafted submission could therefore overwrite another pet's details.
  - Steps (proposed):
    1. Staff edit and save as before.
    2. The pet's identifier always comes from the pet being edited, never from what is submitted; any supplied identifier is ignored.
  - Business Rules: A pet's identifier cannot be set by what a user types or submits. The client forms and visit form already behave this way; the pet form is the exception. Whether a pet belongs to the client shown is a separate matter; See RBAC.
  - Outcome: Editing one pet can never change another pet's record.

- **Workflow 3: A client's identifier cannot be supplied by the user (rule OWN-005, existing)**
  - Trigger: A staff member registers a new client or edits an existing one. The register and edit steps are owned by Client Management; See Client Management.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. If an identifier is supplied with the submission, it is ignored. A new client receives an identifier from the system. An edited client keeps the identifier of the client being edited.
  - Business Rules: **OWN-005 (owned here, extraction fact, confidence high)**: the client's identifier cannot be supplied by the user. Client Management owns the other client rules; See Client Management for those.
  - Outcome: Client records cannot be redirected onto another client's record by what is typed or submitted. This behaviour is to be preserved in any future version.

- **Workflow 4: Staff meet an error (RISK-006)**
  - Trigger: Something goes wrong while staff use the application (for example a client that does not exist is opened).
  - Primary Actors: Front-desk staff.
  - Steps (today):
    1. A page cannot be completed.
    2. The application shows its single error page, which prints the detailed system error information exactly as produced.
  - Steps (proposed):
    1. A page cannot be completed.
    2. The error page shows a plain, safe message. Anything a user typed that might appear in the error text is shown as harmless text only, never acted on.
  - Business Rules: Extraction fact (inferred, not exercised): if an error text ever repeats something a user typed, unexpected content could be displayed to the staff member. No evidence yet that any error text does this. The look and wording of the error page belongs to Web Shell and Localization; this capability owns only its safety.
  - Outcome: An error never becomes a way to attack the person looking at it.

- **Workflow 5: The clinic sets up the password for the clinic record store (RISK-004)**
  - Trigger: The clinic's system is set up or moved to a new place for real use with either of its two real-use record store setups.
  - Primary Actors: Practice managers (or whoever they appoint to set up the system).
  - Steps (today):
    1. The setup uses passwords for the clinic record store that are written into the project's shared files and its setup instructions.
    2. Those passwords are also built into the packaged application.
    3. If the same passwords are reused outside local development, anyone who can read the shared files knows them. In one of the two record store setups the account used is the most powerful one.
  - Steps (proposed):
    1. The password is supplied when the system is set up and is not kept in shared files or built into the application.
    2. The clinic record store account has only the access the clinic needs.
  - Business Rules: Extraction fact: the shared passwords are development defaults, and a way to supply them at setup time already exists, so removing them from shared files does not require a new capability. Which record store the clinic will use is decided in Persistence and Data Platform; See Persistence and Data Platform.
  - Outcome: The password for the clinic record store is not kept in shared files.

- **Workflow 6: Staff reach the clinic pages over the network (RISK-005)**
  - Trigger: Staff open the application in a browser from anywhere other than the machine it runs on.
  - Primary Actors: Front-desk staff, front-desk lead, practice managers.
  - Steps (today):
    1. Staff open the pages. Client names, addresses and telephone numbers travel across the network without protection unless whoever sets the system up adds it. Nothing in the project does so.
    2. The browser is not told to apply its own safeguards, such as refusing to show the clinic's pages hidden inside another website or limiting what content may run on them.
    3. The connection between the application and the database is also not protected.
  - Steps (proposed):
    1. Staff always reach the pages over a protected connection, and an unprotected attempt is redirected to it.
    2. The browser is told to apply its safeguards.
    3. The connection to the database is protected as well, if the database is on another machine.
  - Business Rules: Extraction fact: how the application is put in front of staff is not specified in the project, so the real exposure depends on that setup (open question 4).
  - Outcome: Client and pet data cannot be read in transit, and the pages cannot be misused through other websites.

## 4. Business Rules and Constraints
- **OWN-005 (owned here, existing)**: A client's identifier cannot be supplied by the user. Rationale: stops a form from overwriting or redirecting a client record. Extraction fact, confidence high.
- **Rule 2 (proposed, new, covers RISK-007)**: A pet's identifier cannot be supplied by the user either. Rationale: the same protection as OWN-005 must apply to pets; today it does not.
- **Rule 3 (proposed, new, covers RISK-002)**: A change to clinic records is accepted only when it is a deliberate action by the person using the application.
- **Rule 4 (proposed, new, covers RISK-004)**: The clinic's database password is not kept in shared files or built into the application.
- **Rule 5 (proposed, new, covers RISK-005)**: Client and pet data is not sent across the network unprotected, and browsers are told to apply their own safeguards.
- **Rule 6 (proposed, new, covers RISK-006)**: The error page shows only safe text.
- **Operational Constraint**: The extraction states no availability, volume or speed requirements for these protections, so none are specified here (open item).
- **Scope boundary**: Who may sign in and what each person may do is owned by RBAC; See RBAC for RISK-001 and RISK-003. How long client records are kept and whether they can be erased is owned by Client Management; See Client Management for RISK-019. How staff stay signed in is decided in RBAC; this capability depends on that decision (Section 8).

## 5. Current Capabilities and Gaps
- **What Works Well** (extraction fact): Typed search text is never run as database commands, in every supported way of storing data. Client and visit entries are checked for required details. Client pages show typed text as harmless text. The client and visit forms ignore a supplied identifier (OWN-005). A single generic error page is used for every failure.
- **Identified Gaps**:
  - RISK-002 (High; impact High, likelihood Medium): nothing stops a record-changing page from being submitted without the user's knowledge. Likelihood rises once staff sign in. *Inferred from the absence of any such protection.*
  - RISK-004 (Medium; impact Medium, likelihood Medium): database passwords for the two real-use database setups are in shared project files and setup instructions, and are built into the packaged application.
  - RISK-005 (Medium; impact Medium, likelihood Medium): no protection for pages in transit, none for the database connection, and no browser safeguards.
  - RISK-006 (Low; impact Medium, likelihood Low): the error page prints raw error text. *Inferred, not exercised.*
  - RISK-007 (Medium; impact Medium, likelihood Medium): the pet form does not ignore a supplied identifier. *Inferred, not verified in operation.*
  - Gap in the evidence: nothing was run, so none of the inferred findings has been demonstrated, and the extraction did not check whether the software the application depends on has known weaknesses.
- **Workarounds**: None are documented in the extraction. Any informal protection (for example, the application being reachable only inside the clinic's network) is unknown and must be confirmed with the customer.

## 6. Stakeholder Requirements
No stakeholder statements are recorded in the sources used. The entries below are the **analysts' working framing**, to be confirmed.
- **COO / business sponsor**: Assurance that client personal data and pet records are protected against misuse before the application is used for real clinic work; a decision on whether findings may be accepted rather than fixed.
- **Practice managers**: A database password that is not kept in shared files; clarity on how the application is put in front of staff (inside the clinic only, or reachable from outside) because that sets how much the network protection matters.
- **Front-desk lead and front-desk staff**: Registering clients, editing pets and recording visits must keep working exactly as today. Satisfaction targets are not stated and are an open item for the customer.
- **Lead vet**: Visit notes may contain health information about a pet and must not be exposed in transit or through the error page. Whether the lead vet has further requirements is an open question.

## 7. Future-State Vision
- **Desired Capabilities** (proposed, analysts' working framing): record-changing pages accept only deliberate actions; pages and the database connection are protected on the network and browsers apply their safeguards; the error page is safe; a pet's identifier cannot be supplied by a user, matching clients and visits; no database password is kept in shared files.
- **Business Outcomes**: Client and pet data cannot be tampered with or leaked through the way the web pages behave; the clinic can show, finding by finding, which protections are in place.
- **Timeline Considerations**: Wave 0, priority high. The protection against forms submitted without the user's knowledge follows the decision in RBAC on how staff sign in and stay signed in, so that decision should be taken early. The customer has asked for no plan or estimate, and none is given here.

### Open questions for the customer
1. Is the application reachable from outside the clinic, or only from inside? (Sets the weight of RISK-005.)
2. Which database will the clinic use for real work? (Sets which database password is affected by RISK-004; decided with Persistence and Data Platform.)
3. Are the passwords currently in shared files real passwords or only development defaults? (The extraction says they appear to be defaults.)
4. How will the application be put in front of staff (who sets up the protected connection)? The project does not say.
5. May any of the five owned findings be formally accepted rather than fixed, and by whom?
6. Is there a standard the clinic must meet for client personal data (privacy law, insurer requirements)? The extraction notes that data protection rules may apply but names no clinic standard.

## 8. Related Business Capabilities
- **Depends On**: RBAC, for the decision on how staff sign in and stay signed in (See RBAC). Protection against forms submitted without the user's knowledge is designed around that decision. If the clinic decides that no sign-in is wanted, this protection needs a different approach (from the capability split).
- **Supports**: Client Management, Patient Management and Visit History (every record-changing page in them needs the protections here). Web Shell and Localization (the error page's safety is owned here; its look and wording is owned there).
- **Connections to other systems**: None. The application connects to no other system except its own database. The database connection protection (RISK-005) and password (RISK-004) apply to that one connection.
- **Cross-references**: See RBAC for RISK-001 and RISK-003. See Client Management for RISK-019 and the other client rules. See Persistence and Data Platform for the choice of databases.

## 9. Success Metrics and KPIs
All targets are derived from this BRD's content and the documented findings. No volume, speed or date is invented; where a target needs a customer decision it is marked as an open item.

- **KPI 1: Record-changing pages protected against unintended submission.** Target: 5 of 5 (register client, edit client, add pet, edit pet, record visit) refuse a submission that was not a deliberate action by the user and change nothing. Condition: testable by submitting each page from outside the application. Dependent on the RBAC decision on how staff stay signed in.
- **KPI 2: Normal use unaffected.** Target: 100% of deliberate submissions from the 5 pages still succeed (existing behaviour unchanged).
- **KPI 3: Database passwords in shared files.** Current-state baseline (not a requirement): 2 real-use database setups have a password in shared files. Target: 0% of supported database setups have a password in shared files, and none in the packaged application.
- **KPI 4: Pages delivered over a protected connection.** Target: 100% of pages that show or change client, pet or visit data. Whether the database connection must also be protected depends on open question 1 and 2 (open item).
- **KPI 5: Pages told to use browser safeguards.** Target: 100% of pages carry the safeguards the customer approves; the list of safeguards is an open item for the customer.
- **KPI 6: Error page safety.** Target: 0 occurrences of unescaped typed text on the error page, tested by causing a failure whose text includes markup and confirming it is shown as plain text.
- **KPI 7: Pet identifier supplied by a user.** Target: 100% of pet-form submissions that include a foreign identifier ignore it and change 0 other pets.
- **KPI 8: Client identifier rule preserved (OWN-005).** Target: 100% of client-form submissions that include an identifier ignore it (existing behaviour, to be kept).
- **KPI 9: Owned findings closed.** Target: the 5 owned findings (RISK-002, RISK-004, RISK-005, RISK-006, RISK-007) from 5 open to 0, or formally accepted by the business with a recorded reason.
- **Open items needing customer decision**: the list of browser safeguards (KPI 5); whether database connection protection is required (KPI 4); target date for KPI 9; satisfaction thresholds for front-desk staff.

## 10. Risks and Mitigation
- **Business Risk 1 (RISK-002): Forms can be submitted without the user's knowledge.** Severity High (impact High, likelihood Medium). Client and pet records could be altered when a staff member visits another website.
  - Mitigation: Adopt Rule 3 and test each of the 5 record-changing pages; settle the staff sign-in decision in RBAC first (See RBAC).
- **Business Risk 2 (RISK-004): The clinic's database password is in shared files.** Severity Medium. Anyone who can read the project files knows it, and it is baked into the packaged application.
  - Mitigation: Adopt Rule 4; supply the password at setup, and give the database account only the access needed.
- **Business Risk 3 (RISK-005): No network protection and no browser safeguards.** Severity Medium. Client contact details and visit notes can be read in transit.
  - Mitigation: Adopt Rule 5; confirm with the customer how the application is put in front of staff (open questions 1 and 4).
- **Business Risk 4 (RISK-006): The error page prints raw error text.** Severity Low (impact Medium, likelihood Low). Inferred, not exercised.
  - Mitigation: Adopt Rule 6 and test with an error text containing markup.
- **Business Risk 5 (RISK-007): The pet form accepts a supplied identifier.** Severity Medium. Inferred; a crafted submission could overwrite another pet.
  - Mitigation: Adopt Rule 2 and test with a foreign identifier.
- **Business Risk 6: The sign-in decision stalls.** Protection for RISK-002 cannot be finalised without it.
  - Mitigation: Raise it in the first planning workshop with RBAC.
- **Business Risk 7: Findings are treated as demonstration-only.** The extraction says the findings are acceptable in a demo; if the clinic reuses the application for real work they are not.
  - Mitigation: Ask the COO / business sponsor to confirm whether real clinic use is intended (open question 5).

## Appendix: Traceability to Technical Implementation
Commit: `dc4f7b7c1f878fde2995ed2733d22ba987b827dd`. Everything in this BRD comes from extracted knowledge; no source code was re-analysed. Technical terms (forgery protection, TLS, HSTS, CSP, headers, binder, `id`) appear only here.

| Claim | Source |
|---|---|
| Capability definition, owned risks RISK-002, 004, 005, 006, 007, owned rule OWN-005, boundaries with RBAC and Client Management | [capabilities/index.md](../../capabilities/index.md) |
| RISK-002: no CSRF protection on state-changing POSTs (inferred from absence) | [risk-gap/index.md](../../extraction/risk-gap/index.md), [security/index.md](../../extraction/security/index.md) |
| RISK-004: database credentials committed in `pom.xml` and readme; PostgreSQL superuser; overrides via `-D` properties or JNDI | [risk-gap/index.md](../../extraction/risk-gap/index.md), [security/index.md](../../extraction/security/index.md); code: [pom.xml:567-589](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/pom.xml#L567) |
| RISK-005: no TLS, HSTS, CSP or frame protection; database URLs without TLS options | [risk-gap/index.md](../../extraction/risk-gap/index.md), [security/index.md](../../extraction/security/index.md) |
| RISK-006: unescaped `${exception.message}` in the error view | [risk-gap/index.md](../../extraction/risk-gap/index.md); code: [exception.jsp:13](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/webapp/WEB-INF/jsp/exception.jsp#L13) |
| RISK-007: pet binder does not disallow `id` (inferred) | [risk-gap/index.md](../../extraction/risk-gap/index.md); code: [PetController.java:59-67](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/PetController.java#L59) |
| OWN-005: owner `id` cannot be bound from a request (confidence HIGH) | [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md); code: [OwnerController.java:48-51](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/OwnerController.java#L48) |
| Positive controls: bound query parameters in every persistence variant, input validation, escaped output in client views | [security/index.md](../../extraction/security/index.md) |
| Only inferred persona: clinic receptionist / front-desk staff; sample-application context | [business-intent/index.md](../../extraction/business-intent/index.md) |
| Record-changing pages (register/edit client, add/edit pet, record visit), data flows | [data-flow/index.md](../../extraction/data-flow/index.md) |
| Data held (client contact details, pets, visit notes) | [data-model/index.md](../../extraction/data-model/index.md) |
| Staff sign-in decision owned by RBAC | [BRD-rbac.md](../rbac/BRD-rbac.md) |

---
tags:
  - brd
  - capability/patient-management
---

# Business Requirements Document: Patient Management

> Source basis: sections 1-10 are based on extracted knowledge (see the Appendix); no repository source code was needed. Content is labelled as one of three kinds. **Extraction fact** means what the analysis of the current system found. **Customer input** means something a clinic stakeholder said; none was supplied for this capability. **Analysts' working framing** means our own proposal or interpretation, not yet agreed with the customer.

## 1. Executive Summary

Patient Management is how clinic staff add a pet (the clinic's patient) to an owner and later correct that pet's details. For each pet the system keeps its name, its animal type (chosen from a fixed list), its birth date and the owner it belongs to. It checks that the name and birth date are filled in, that the birth date is typed in the expected way, that a new pet has a type from the list, and that an owner does not get two new pets with the same name. A pet cannot be removed and cannot be moved to another owner. The capability matters because every visit the clinic records hangs off a pet record, so the quality of pet records sets the quality of the visit history.

Two things are deliberately not repeated here because other capabilities own them: the missing date-range check on the pet birth date (RISK-012: See Visit History), who may change a pet at all (RISK-003: See RBAC), and the protection of the pet's internal identifier against being overwritten (RISK-007: See Application Security). One question for the customer is raised in section 5 about clinical information that the system does not hold.

Key stakeholders: Front-desk staff, Front-desk lead, Lead vet, Practice managers, COO / business sponsor.

## 2. Business Capability Definition

- **Capability Name**: Patient Management
- **Business Domain**: Clinic patient records (Wave 1 - Working Client, Patient and Visit Records)
- **Primary Stakeholders**: Front-desk staff, Front-desk lead, Lead vet, Practice managers, COO / business sponsor
- **Business Objective**: Let staff register each animal under the right owner and correct its details, so that every visit can be tied to a specific animal.
- **Key Business Value**: Each owner's animals are individually identifiable (name, type, birth date), which makes the visit history meaningful. No revenue figures are stated in the extraction and none are claimed here.
- **Why this is separate from Client Management** (analysts' working framing): the owner (client) is the relationship with the person who pays and is contacted; the patient is the relationship with the animal that is treated. They are kept as two capabilities for that reason. They could be merged later (see capabilities/index.md, open question 8).
- **Features in scope** (extraction fact): Add Pet to Owner, Edit Pet. Maintaining the list of animal types is not a feature of the system today.

## 3. Business Workflows

- **Workflow 1: Add a pet to an owner**
  - Trigger: An owner brings an animal to the clinic that is not yet on file under that owner.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff opens the owner's record and chooses to add a new pet.
    2. The pet form shows the owner's name (read-only) and asks for the pet's name, birth date and type. The type is picked from a list shown in alphabetical order.
    3. Staff enters the name, picks a birth date (typed or chosen from a calendar, in the form year/month/day) and selects the type, then submits.
    4. If the name or birth date is empty, the date is not in the expected form, the type is missing or unknown, or this owner already has a pet with the same name (upper and lower case are treated as the same), the form is shown again with a message next to the problem and nothing is saved.
    5. Otherwise the pet is saved under that owner and staff return to the owner's record, where the new pet is listed.
  - Business Rules: Name required (PET-001). Type required for a new pet (PET-002) and must be one of the listed types (PET-006). Birth date required (PET-003) and typed as year/month/day (PET-005). No two pets of one owner may share a name, ignoring upper and lower case (PET-004); different owners may each have a pet with the same name. The pet belongs to exactly one owner (PET-007, PET-009). Types are offered alphabetically (PET-008).
  - Outcome: The animal is on file under its owner and visits can now be recorded for it.

- **Workflow 2: Edit a pet**
  - Trigger: Staff notice that a pet's name, birth date or type was entered wrongly or has changed.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. Staff opens the owner's record and chooses to edit one of the owner's pets.
    2. The pet form is shown with the current details.
    3. Staff changes the name, birth date or type and submits.
    4. If the name or birth date is empty or the date is not in the expected form, the form is shown again with a message and nothing is saved.
    5. Otherwise the changes are saved and staff return to the owner's record.
  - Business Rules: Name (PET-001) and birth date (PET-003, PET-005) are required as when adding. The "same name for one owner" check applies only when adding a pet; renaming an existing pet to a name another of the owner's pets already has is not stopped (PET-004). The type is required only when a pet is first added; when an existing pet is edited, the type is not checked again (PET-002). Whether this holds in every case on the edit page was not confirmed during the review and is flagged for confirmation.
  - Outcome: The pet record is corrected and everything that shows the pet (owner record, visit history) shows the new details.

- **Workflow 3: Choose a pet type** (supporting step inside Workflows 1 and 2)
  - Trigger: Staff reach the type selection on the pet form.
  - Primary Actors: Front-desk staff.
  - Steps:
    1. The form lists the available animal types in alphabetical order. At present the list holds cat, dog, lizard, snake, bird and hamster.
    2. Staff selects one type.
    3. A type that is not on the list cannot be saved.
  - Business Rules: The list is fixed reference information; staff cannot add, rename or remove a type in the system (PET-006, PET-008). The selected type must exactly match one of the available options, including upper and lower case.
  - Outcome: Every pet carries one type from an agreed list.

- **Not available today** (identified during review): staff cannot remove a pet and cannot move a pet to a different owner. A pet entered under the wrong owner stays where it is.

## 4. Business Rules and Constraints

All nine rules below are owned by this capability (extraction fact, rated HIGH confidence in the extraction). Extraction detail: [business-logic-rules/pets.md](../../extraction/business-logic-rules/pets.md).

- **PET-001 Pet name required**: A pet must have a name. Rationale: staff and owners identify an animal by name.
- **PET-002 Pet type required only for new pets**: A new pet must have a type; an existing pet is not re-checked for type.
- **PET-003 Pet birth date required**: A birth date must be given. The extraction found no check on whether it is in the past; that check belongs to Visit History (RISK-012: See Visit History).
- **PET-004 No duplicate pet name per owner**: When adding a pet, its name must differ (ignoring upper and lower case) from the owner's other pets. Rationale: staff pick the right animal by name on the owner's record. The check is not applied on edit.
- **PET-005 Birth date typed as year/month/day**: The birth date is accepted in one form only (for example 2015/02/12); other forms are rejected with a message.
- **PET-006 Pet type must match the list exactly**: The chosen type must be on the list; matching is exact including upper and lower case, and an unknown type is rejected.
- **PET-007 Pet is attached to one owner and saved**: A saved pet always belongs to the owner whose record staff came from, and staff return to that owner's record. The pet cannot be moved to another owner through the system.
- **PET-008 Pet types listed alphabetically**: Types are offered sorted by name.
- **PET-009 A pet must have an existing type and an existing owner**: A pet cannot be stored without both. This is also the reason Patient Management depends on Client Management.
- **Not owned here (See only)**: the missing check that the birth date is not in the future (RISK-012: See Visit History); whether the pet in a request really belongs to the owner in the request (RISK-003: See RBAC); protection of a pet's internal identifier from being overwritten (RISK-007: See Application Security).
- **Operational Constraint**: The extraction states no availability, volume or speed requirements for pets. Any such target is a customer decision (open item).

## 5. Current Capabilities and Gaps

- **What Works Well** (extraction fact):
  - Staff can add and edit pets from the owner's record in one short form each.
  - Name, birth date, type and per-owner name uniqueness are checked, with messages shown beside the problem field.
  - Pet types come from a fixed alphabetical list, so types are consistent.
  - Every pet is always tied to an owner and a type.
- **Identified Gaps** (extraction fact):
  - A pet cannot be removed and cannot be moved to another owner (PET-007).
  - Pet types cannot be maintained in the system; changing the list needs work outside the application (analysts' reading of the extraction; the extraction labels this as inferred).
  - The duplicate-name check does not apply when renaming a pet (PET-004).
  - The type match is case-sensitive (PET-006); a type is rejected if its capitalisation differs from the list.
  - Gaps tracked elsewhere: RISK-012 (See Visit History), RISK-003 (See RBAC), RISK-007 (See Application Security). This capability owns no risks.
- **QUESTION FOR THE CUSTOMER (not a finding)**: The system records only a pet's name, type, birth date and owner, plus the visit descriptions held by Visit History. It holds no diagnosis, treatment history or other clinical record. Is clinical information about a patient kept outside this system, and if so where and by whom? We have made no assumption about what the clinic keeps elsewhere. The answer decides whether Patient Management is expected to grow beyond identification of the animal. Suggested respondents: Lead vet, Practice managers.
- **Workarounds**: None are documented in the extraction for this capability. Whether staff currently work around the missing remove / change-owner functions (for example by re-entering a pet) is not known; this is an open question for Front-desk lead.

## 6. Stakeholder Requirements

No stakeholder statements about Patient Management were supplied. The items below are the analysts' working framing, to be confirmed with the named roles.

- **COO / business sponsor and practice managers**: Keep patient records reliable enough for the visit history to depend on them; confirm the answer to the clinical-information question in section 5; decide whether removing a pet or moving it to another owner is wanted.
- **Front-desk lead and front-desk staff**: Adding and editing a pet stays a single short form; messages tell staff clearly what to fix; confirm whether pets entered under the wrong owner or by mistake are a real problem today.
- **Lead vet**: State whether anything beyond name, type and birth date is needed to identify a patient, and whether clinical information is held elsewhere.

## 7. Future-State Vision

All items are analysts' working framing for discussion, not agreed scope.

- **Desired Capabilities**:
  - Keep adding and editing pets as today, with rules PET-001 to PET-009 preserved.
  - Decide with the customer whether to allow correction of a pet entered under the wrong owner (move) and removal of a pet entered in error, and under what conditions.
  - Decide whether the duplicate-name check should also apply on rename, and whether the type match should ignore upper and lower case.
  - Decide whether the list of types should be maintainable by staff.
  - Decide, after the answer to the clinical-information question, whether anything more about the patient should be recorded.
- **Business Outcomes**: Cleaner patient records, fewer wrongly attributed visits, and a recorded customer position on how far patient records should reach. No cost or revenue effect is claimed.
- **Timeline Considerations**: Wave 1, priority high (capability split, approved). Dependencies: Client Management (a pet belongs to an owner); decisions from RBAC and Application Security apply before changes to pet forms. Visit History depends on this capability.

## 8. Related Business Capabilities

- **Depends On**: Client Management (a pet belongs to an owner, PET-009); RBAC (who may change records; RISK-003: See RBAC); Application Security (RISK-007: See Application Security); Persistence and Data Platform (how records are stored).
- **Supports**: Visit History (a visit must belong to a pet); Web Shell and Localization (the pet form is shown inside the common layout and messages).
- **Integration Points**: None. The extraction found no external systems for this capability. The pet type list is reference information held within the clinic's own data.

## 9. Success Metrics and KPIs

Derived from this document's rules; none uses an invented volume, speed or date. Where a target needs a customer decision it is marked OPEN.

- **KPI 1 - Required fields enforced**: 100% of attempts to save a pet with an empty name or an empty birth date are rejected with a message and nothing is saved (PET-001, PET-003); checked by a repeatable test at release. The birth date range check (RISK-012) is accepted in Visit History: See Visit History KPI 3.
- **KPI 2 - Type enforced**: 100% of attempts to add a pet without a type or with a type not on the list are rejected (PET-002, PET-006); 100% of listed types can be selected and saved.
- **KPI 3 - Birth date format**: 100% of birth dates in year/month/day form are accepted and 100% of other forms are rejected with a message (PET-005).
- **KPI 4 - Duplicate names**: 100% of attempts to add a pet whose name matches (ignoring upper and lower case) another pet of the same owner are rejected; the same name under a different owner is accepted (PET-004).
- **KPI 5 - Owner link**: 100% of saved pets have exactly one owner and one type (PET-007, PET-009); 0 pets can be saved without them.
- **KPI 6 - Type list order**: the pet form shows types alphabetically in 100% of checks (PET-008).
- **KPI 7 - Open question closure**: the clinical-information question in section 5 has a named customer respondent and a recorded answer before any scope that extends patient records is planned; the date is OPEN, set by the customer.
- **KPI 8 - Decisions on removal, change of owner, rename check and type maintenance**: each has a recorded yes / no from the customer before work on it is planned; dates are OPEN.
- **Open item needing a customer decision**: staff satisfaction and time to add or edit a pet have no target and are not KPIs yet. The customer must decide who measures them and what threshold applies; until then they are not tracked.

## 10. Risks and Mitigation

This capability owns no risks (capability split, single-owner principle). The risks that touch it are held by their owners and are not restated here.

- **RISK-012** (date checks, including the pet birth date): See Visit History.
  - Mitigation: See Visit History.
- **RISK-003** (pet and owner ids not matched against each other): See RBAC.
  - Mitigation: See RBAC.
- **RISK-007** (pet identifier can be overwritten from a request): See Application Security.
  - Mitigation: See Application Security.

## Appendix: Traceability to Technical Implementation

Extraction documents:
- [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) (pet rules PET-001 to PET-009 in [pets.md](../../extraction/business-logic-rules/pets.md))
- [business-intent/index.md](../../extraction/business-intent/index.md) ([pets.md](../../extraction/business-intent/pets.md))
- [data-model/index.md](../../extraction/data-model/index.md)
- [data-flow/index.md](../../extraction/data-flow/index.md)
- [ui-ux/index.md](../../extraction/ui-ux/index.md) ([pets-visits.md](../../extraction/ui-ux/pets-visits.md): pet form)
- [risk-gap/index.md](../../extraction/risk-gap/index.md) (RISK-003, RISK-007, RISK-012 are owned elsewhere)
- [capabilities/index.md](../../capabilities/index.md) (ownership split, dependencies)

| Claim | Source |
|---|---|
| Pet rules PET-001 to PET-009 | [business-logic-rules/pets.md](../../extraction/business-logic-rules/pets.md) |
| Name, birth date, type checks | [src/main/java/org/springframework/samples/petclinic/web/PetValidator.java:41](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/PetValidator.java#L41) |
| Duplicate name check on creation only | [src/main/java/org/springframework/samples/petclinic/web/PetController.java:77](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/PetController.java#L77) |
| Type matched by exact name | [src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java:54](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/PetTypeFormatter.java#L54) |
| Pet requires type and owner | [src/main/resources/db/h2/schema.sql:46](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/resources/db/h2/schema.sql#L46) |
| Pet form and screens | [ui-ux/pets-visits.md](../../extraction/ui-ux/pets-visits.md) |
| No remove / move of pets; type list not maintainable | [business-intent/pets.md](../../extraction/business-intent/pets.md) and [capabilities/index.md](../../capabilities/index.md) |
| Clinical-information question | Analysts' question; no source states what the clinic keeps outside the system |
| Ownership of RISK-003, RISK-007, RISK-012 | [capabilities/index.md](../../capabilities/index.md) |

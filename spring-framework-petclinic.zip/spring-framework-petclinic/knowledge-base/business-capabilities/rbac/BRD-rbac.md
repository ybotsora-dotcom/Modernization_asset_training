---
tags:
  - brd
  - capability/rbac
---
# Business Requirements Document: RBAC

> **Nature of this document.** RBAC describes a **gap and a decision, not an existing feature**. The current system has no users, no login, no roles and no permission checks. Nothing in this capability is "working today" except the absence of restrictions. Content marked *proposed* or *open question* is not confirmed customer scope.

## 1. Executive Summary
The clinic's record-keeping application lets anyone who can reach it view and change all client (pet owner), pet and visit records, including owners' names, addresses and phone numbers. There is no concept of a user, a role or a permission anywhere in the system, and access governance has not been formally defined. This capability exists to close that gap: it records the business decision on whether login is wanted and which user roles exist, and it owns one concrete, fixable finding, namely that a pet or visit can currently be changed through an owner it does not belong to.

Key stakeholders: the COO / business sponsor (decision maker on login and roles), practice managers, and front-desk staff (the only user group the analysis infers).

Sources: this BRD is based on extracted knowledge only (no source-code re-analysis). See the Appendix.

## 2. Business Capability Definition
- **Capability Name**: RBAC
- **Business Domain**: Security and access governance (Wave 0 - Safe and Dependable Foundations)
- **Primary Stakeholders**: COO / business sponsor, practice managers, front-desk staff
- **Business Objective**: Decide and, once decided, enforce who is permitted to access or modify clinic business records.
- **Key Business Value**: Client personal data (names, addresses, telephone numbers) and the integrity of the owner-pet-visit relationship are protected from unintended access and change. The extraction rates the missing access control as High severity for any use beyond a demonstration. No revenue figures are stated in the extraction and none are claimed here.
- **Current state (extraction finding)**: no authentication (no sign-in), no role model (no user roles), no access segregation (no separation of who can see or change what).
- **Gap (analysts' working framing, to be confirmed with the customer)**: access governance is not formally defined.
- **Business decision required (analysts' working framing, to be confirmed with the customer)**: determine the required user roles, and whether login is wanted at all.

## 3. Business Workflows
This capability has no implemented workflow of its own. The workflows below describe (a) how access behaves today, (b) the decision to be taken, and (c) the proposed access-control behaviour.

- **Workflow 1: Open access to clinic records (current state, as-is)**
  - Trigger: Anyone who can reach the clinic application wants to look at or change a client, pet or visit record.
  - Primary Actors: Front-desk staff; any other person who can reach the application.
  - Steps:
    1. The person opens the application. No sign-in is requested.
    2. The person searches for, views, registers or edits clients, adds or edits pets, and records visits.
    3. The system accepts every action without asking who the person is or what they are allowed to do.
  - Business Rules: None. There are no access-control rules in the system.
  - Outcome: Every person with access to the application can see and change all records, including clients' contact details. The clinic cannot distinguish or restrict users.

- **Workflow 2: Decide the access model (proposed, requires customer decision)**
  - Trigger: The clinic wants an agreed answer on who may view and change records.
  - Primary Actors: COO / business sponsor, practice managers, front-desk staff representative.
  - Steps:
    1. The business decides whether staff must sign in at all.
    2. If sign-in is wanted, the business lists the user roles it needs. The only role the analysis infers is clinic receptionist / front-desk staff; any other roles must come from the customer (see open questions in Section 7).
    3. For each role, the business states which activities it may perform: find clients, register clients, edit clients, view client details, add pets, edit pets, record visits, view visit history, view the vet list.
    4. The decision is recorded.
  - Business Rules: No rules exist yet. Any permission rule produced here is new, not carried over.
  - Outcome: A signed-off statement of whether login is required, which roles exist and what each may do. If the answer is "no login", this capability reduces to Workflow 3 plus the recorded decision.

- **Workflow 3: Change a pet or visit only through its own owner (current gap and proposed rule)**
  - Trigger: Staff add a visit to, or edit, a pet while working from an owner's record.
  - Primary Actors: Front-desk staff.
  - Steps (today):
    1. Staff open an owner's record and choose to add a visit or edit a pet.
    2. The system does not check that the pet really belongs to that owner. An attempt that pairs a pet with the wrong owner is accepted.
    3. The visit or change is saved against the pet.
  - Steps (proposed):
    1. Staff choose to add a visit or edit a pet from an owner's record.
    2. The system confirms the pet belongs to that owner.
    3. If it does not, the system refuses the attempt and shows that the record was not found; nothing is saved.
  - Business Rules: Proposed rule: a pet or visit can only be changed through the owner it belongs to.
  - Outcome: The link between owners, pets and visits cannot be silently bypassed or mismatched.

## 4. Business Rules and Constraints
- **Rule 1 (none carried over)**: The system has zero authorization rules; this capability owns no existing rules.
- **Rule 2 (proposed, new)**: A pet or visit can only be changed through the owner it belongs to. Rationale: protects the integrity of clinic records; the extraction recommends it.
- **Rule 3 (proposed, depends on decision)**: Any role-based permissions follow the roles the customer confirms. None are defined here.
- **Operational Constraint**: The extraction states no availability, scale or speed requirements for access control, so none are specified. The access model chosen here also determines how staff stay signed in, which Application Security needs to know (see Section 8).
- **Scope boundary**: Protection against forms being submitted without the user's knowledge (RISK-002) is owned by another capability. See Application Security.

## 5. Current Capabilities and Gaps
- **What Works Well**: Nothing in access control exists to assess. Input checks on owner and visit entries exist elsewhere and are not part of this capability.
- **Identified Gaps**:
  - RISK-001: no sign-in (authentication) or permission checks (authorization); anyone can view and edit all records and client personal data (impact High, likelihood Medium).
  - Access governance is not formally defined: no decision on login, roles or per-role permissions.
  - RISK-003: pet and visit changes are not checked against the owner they belong to (impact Medium, likelihood High; any wrong pairing triggers it).
  - There is no way to tell who made a change, because users do not exist.
- **Workarounds**: None are documented in the extraction. Any informal practice (for example restricting who can reach the application by where in the clinic's network the application can be reached from) is unknown and must be confirmed with the customer.

## 6. Stakeholder Requirements
- **COO / business sponsor and practice managers**: Obtain a recorded decision on login and roles so dependent capabilities (Client Management, Patient Management, Visit History) can specify who may do what. Treat the ownership rule as a defined, testable requirement.
- **Business Users**: Front-desk staff need to keep finding clients, registering them and recording visits without added friction. Satisfaction targets are not stated in the extraction and are an open item for the customer.
- **Practice managers**: Need the decision on how staff sign in and stay signed in made early, because protection against forms being submitted without the user's knowledge depends on it. Any speed, availability or audit expectations for access control are not stated and must come from the customer.

## 7. Future-State Vision
- **Desired Capabilities** (proposed, subject to the decision): an agreed access model; if login is wanted, staff sign in and each role can use only the activities it is permitted; pets and visits can be changed only through their own owner.
- **Business Outcomes**: Client personal data is no longer open to anyone who can reach the application; record relationships stay consistent; the clinic can answer "who is allowed to do what".
- **Timeline Considerations**: The capability is in Wave 0 ("Safe and Dependable Foundations"), priority high, because later record-keeping capabilities depend on it. If the customer decides no login is wanted, the scope shrinks to the ownership check plus the recorded decision.

### Open questions for the customer
1. Is login wanted at all?
2. Beyond clinic receptionist / front-desk staff, which other roles exist, if any? (The extraction raises vets only as an example question; it infers no vet role. No other roles are assumed here.)
3. For each role, which activities may it perform (view, register, edit, record visits)?
4. Is a distinction needed between viewing records and changing them?
5. Does the clinic need to know who made a change (accountability)? Retention and erasure of client data are handled elsewhere.
6. Is the application reachable only from inside the clinic, or from outside?

## 8. Related Business Capabilities
- **Depends On**: None.
- **Supports**: Client Management, Patient Management and Visit History (they depend on the access decision). Application Security depends on the decision made here on how staff stay signed in.
- **Connections to other systems**: None. The system does not connect to any external system. If login is adopted, deciding where the list of staff accounts comes from would be a new decision.
- **Cross-references**: Patient Management and Visit History write only "See RBAC" for RISK-003. For protection against forms being submitted without the user's knowledge (RISK-002): See Application Security.

## 9. Success Metrics and KPIs
All targets are derived from this BRD's content and the documented findings. No volume or performance numbers are invented.

- **KPI 1: Access-model decision recorded.** Target: 1 signed-off decision covering login yes/no, the list of roles, and per-role permitted activities. Target date: **open item, to be set by the customer**.
- **KPI 2: Open customer questions answered.** Target: 6 of 6 questions in Section 7 answered or explicitly declared out of scope.
- **KPI 3: Ownership check enforced.** Target: 100% of attempts to add a visit to, or edit, a pet through an owner it does not belong to are refused and change nothing (testable with a mismatched owner-pet pair on both the pet-edit and visit-add activities).
- **KPI 4: Valid ownership pairs unaffected.** Target: 100% of actions through the correct owner continue to succeed (check that existing behaviour is unchanged).
- **KPI 5: Authorization rules in place.** Baseline 0 (documented). Target: if login is wanted, 100% of the record-changing activities listed in the decision are covered by a permission decision; the absolute number depends on the customer's decision and is an open item.
- **KPI 6: Anonymous change attempts (only if login is wanted).** Target: 0 record changes accepted without sign-in (testable by an attempt without signing in on each record-changing activity).
- **KPI 7: Findings closed.** Target: RISK-001 and RISK-003 both closed (from 2 open to 0) or formally accepted by the business with a recorded reason.
- **Open items needing customer decision**: target date for KPI 1; user satisfaction thresholds; any accountability (who-changed-what) target.

## 10. Risks and Mitigation
- **Business Risk 1 (RISK-001): No sign-in (authentication) or permission checks (authorization).** Anyone who can reach the application can read and change all client, pet and visit records, including clients' personal contact data. Severity High (impact High, likelihood Medium).
  - Mitigation: Obtain the access-model decision (Workflow 2); if login is wanted, implement role-based permissions for the confirmed roles and test that attempts without signing in are rejected.
- **Business Risk 2 (RISK-003): A pet or visit can be changed through an owner it does not belong to.** Severity High overall (impact Medium, likelihood High). Record relationships can be corrupted.
  - Mitigation: Adopt the ownership rule (Workflow 3) and verify mismatched pairs are refused.
- **Business Risk 3: The decision stalls.** Without a decision on login and roles, dependent capabilities cannot specify permissions, and Application Security cannot settle how staff stay signed in.
  - Mitigation: Put the six open questions to the customer in the first planning workshop and record the answers.
- **Business Risk 4: Roles are invented rather than confirmed.** Only a front-desk role is inferred by the analysis; building other roles would add scope without evidence.
  - Mitigation: Add roles only on customer confirmation.

## Appendix: Traceability to Technical Implementation
Commit: `dc4f7b7c1f878fde2995ed2733d22ba987b827dd`. Everything in this BRD comes from extracted knowledge; no source code was re-analysed.

| Claim | Source |
|---|---|
| Capability definition, owned risks (RISK-001, RISK-003), zero owned rules, split of RISK-002 | [capabilities/index.md](../../capabilities/index.md) |
| No authentication or authorization; open decision on login and roles; severity and likelihood | [risk-gap/index.md](../../extraction/risk-gap/index.md) (RISK-001 detail in the security risk report) |
| Pet and visit changes not checked against owner; severity and likelihood | [risk-gap/index.md](../../extraction/risk-gap/index.md) (RISK-003 detail and remediation roadmap in the security risk report) |
| Zero authorization rules in the 40-rule catalogue | [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) |
| Rule on owner id not checked when recording a visit | [business-logic-rules/index.md](../../extraction/business-logic-rules/index.md) (rule VIS-008, add-visit workflow; the rule is owned by Visit History, RISK-003 by RBAC) |
| Only inferred persona: clinic receptionist / front-desk staff | [business-intent/index.md](../../extraction/business-intent/index.md) |
| No password, session or user-account policies | [security/index.md](../../extraction/security/index.md) |
| Data flows for pet and visit changes | [data-flow/index.md](../../extraction/data-flow/index.md) |
| Code evidence cited by the extraction (visit entry point, pet entry point) | [src/main/java/org/springframework/samples/petclinic/web/VisitController.java:60](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/VisitController.java#L60), [src/main/java/org/springframework/samples/petclinic/web/PetController.java](https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/spring-framework-petclinic/blob/dc4f7b7c1f878fde2995ed2733d22ba987b827dd/src/main/java/org/springframework/samples/petclinic/web/PetController.java) |

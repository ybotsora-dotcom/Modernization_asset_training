# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

Spring Petclinic, maintained as a plain **Spring Framework** (XML config, not Spring Boot) sample using a classic
3-layer architecture: presentation (`web`) → service (`service`) → repository (`repository`). Packaged as a WAR,
run in Jetty/Tomcat.

## Build & run

```
./mvnw jetty:run-war                       # run locally (default profile: H2, jpa persistence)
./mvnw jetty:run-war -P MySQL              # run against MySQL (needs local MySQL, see readme.md)
./mvnw jetty:run-war -P PostgreSQL         # run against PostgreSQL
./mvnw jetty:run-war -Dspring.profiles.active=jdbc          # switch persistence impl at runtime
./mvnw jetty:run-war -Dspring.profiles.active=spring-data-jpa
./mvnw generate-resources -P css           # recompile petclinic.scss -> petclinic.css (Bootstrap)
./mvnw clean verify                        # full build + tests
mvn jib:build                              # build & push Docker image (springcommunity/spring-framework-petclinic)
```

App serves at http://localhost:8080/.

## Tests

```
./mvnw test                                                          # run all tests
./mvnw test -Dtest=ClinicServiceJdbcTests                             # single test class
./mvnw test -Dtest=ClinicServiceJdbcTests#shouldFindOwnersByLastName  # single test method
```

- `AbstractClinicServiceTests` holds the shared test logic for the service layer; `ClinicServiceJdbcTests`,
  `ClinicServiceJpaTests`, and `ClinicServiceSpringDataJpaTests` extend it, each pinning a different persistence
  profile via `@ActiveProfiles("jdbc"|"jpa"|"spring-data-jpa")`. When changing repository behavior, expect to
  verify it against all three.
- Web layer tests (`*ControllerTests`) use `@SpringJUnitWebConfig` against `mvc-core-config.xml` +
  `mvc-test-config.xml`, independent of the persistence profile.
- Default Maven profile is `H2` (in-memory, activated automatically); `HSQLDB`/`MySQL`/`PostgreSQL` are alternatives
  activated with `-P`.

## Architecture: three interchangeable persistence implementations

The defining structural feature of this codebase is that **every repository has three parallel implementations**,
selected by a Spring profile rather than by code change:

| Profile | Implementation package | Notes |
|---|---|---|
| `jpa` (default at runtime) | `repository/jpa` | plain JPA `EntityManager`, `@Transactional`/`@PersistenceContext` |
| `jdbc` | `repository/jdbc` | hand-written `JdbcClient`/`NamedParameterJdbcTemplate`, row mappers, `OneToManyResultSetExtractor` |
| `spring-data-jpa` | `repository/springdatajpa` | Spring Data JPA repository interfaces, wired via `<jpa:repositories>` |

Wiring lives in `src/main/resources/spring/business-config.xml`: each `<beans profile="...">` block component-scans
the matching implementation package (or declares the `EntityManagerFactory`/`transactionManager` beans it needs).
The active profile is set in code by `PetclinicInitializer.SPRING_PROFILE` (currently `"jpa"`) and can be overridden
with the `-Dspring.profiles.active=...` JVM option or a Maven `-P` profile (which only controls the *database*, not
the persistence API).

Repository **interfaces** (`OwnerRepository`, `PetRepository`, `VetRepository`, `VisitRepository`) live directly in
`repository/`, decoupled from any implementation — the `service` layer (`ClinicServiceImpl`) depends only on these
interfaces. When adding a repository method, add it to the interface first, then implement it in all three
`jdbc`/`jpa`/`springdatajpa` packages, then add a shared test case to `AbstractClinicServiceTests`.

## Database profiles vs. persistence profiles

Two independent axes are configured via Spring profiles, and it's easy to confuse them:

- **Maven `-P` profile** (`H2`/`HSQLDB`/`MySQL`/`PostgreSQL`, default `H2`) — picks the JDBC driver/URL and the
  `db.script` folder under `src/main/resources/db/<name>/{schema,data}.sql`, via placeholders resolved in
  `spring/data-access.properties`.
- **Spring profile** (`jpa`/`jdbc`/`spring-data-jpa`, default `jpa`) — picks which repository implementation
  package is active, per the table above.

Any combination of the two is valid (e.g. PostgreSQL + jdbc-style repositories).

## Web layer

XML-configured Spring MVC (`spring/mvc-core-config.xml`, `mvc-view-config.xml`). Views are JSPs with custom tags
under `src/main/webapp/WEB-INF/jsp/` and `WEB-INF/tags/`. Controllers in `web/` are thin and delegate to
`ClinicService`. Localized messages live in `src/main/resources/messages/messages*.properties` (en/de/es).

---
name: petclinic-risk-gap-context
description: Petclinic risk-gap run facts - no rule engine, ai aiRisks empty, validator invocation quirk
metadata:
  type: project
---

Petclinic has no database rule engine; `taskengine-inferred-mapping.md` intentionally absent, so raise no rule-engine risks. AI summary has an engineering harness only, `aiRisks` empty.

**Why:** the caller stated this explicitly in the 2026-11-11 Phase 3 run (21 risks, 3 files plus index).

**How to apply:** skip rule-engine and AI sections on re-runs. Run the schema validator as `python <plugin>/scripts/validate-schema.py <file> <schemaId>` WITHOUT `-I` (the `plugin-run` command is not on PATH and `-I` breaks its local import).

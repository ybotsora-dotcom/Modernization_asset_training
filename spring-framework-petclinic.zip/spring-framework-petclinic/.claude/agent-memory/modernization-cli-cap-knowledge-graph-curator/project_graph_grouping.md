---
name: project-graph-grouping
description: How the petclinic knowledge graph was grouped into 5 domain files and the tooling gotchas (mermaid CLI, schema validator) hit on 2026-11-11
metadata:
  type: project
---

Graph is split into 5 domain files (domain-model, application-architecture, experience-integration, business-rules-capabilities, governance-risk-operations), not by Owner/Pet/Visit/Vet, because extraction folders map cleanly onto layers and the 500-line cap held (max 323 lines).

**Why:** the business-logic-rules summary has 40 rules and risk-gap has 21 risks; per-entity domains would have split those across files and broken traceability. Rule/risk/security nodes are individual entities (security findings given synthetic ids SEC-01..09 since the security summary has none).

**How to apply:** generate files from a script (entities/relationships as data) so counts stay consistent; keep index diagram to the Owner path only (3 repository impls shown for Owner) to stay under 30 nodes. Gotchas: `mermaid_check.py` returns UNAVAILABLE (no chrome-headless-shell) - record as a gap; `validate-schema.py` must be run with cwd = the plugin scripts dir (else `schema_validator` import fails). CallMonitoringAspect -> SpringData repos is LOW (pointcut is `within(@Repository)`, Spring Data interfaces not annotated). AI summary has no crossRefs/aiRef, only the claude-code harness.

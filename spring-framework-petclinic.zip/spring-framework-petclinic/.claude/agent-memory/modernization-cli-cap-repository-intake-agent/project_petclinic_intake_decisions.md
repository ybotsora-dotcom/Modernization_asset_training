---
name: petclinic-intake-decisions
description: How spring-framework-petclinic was classified at intake and tooling quirks (plugin-run missing, validator invocation)
metadata:
  type: project
---

Repo classified SingleProject with one project `spring-framework-petclinic`: root pom has no `<modules>`; layers are Java packages, not Maven modules.

**Why:** Two orthogonal axes (Maven -P DB profile vs Spring profile jpa/jdbc/spring-data-jpa) look like "modules" but are config switches in pom.xml and business-config.xml.

**How to apply:** Do not split into per-persistence projects. The pom comment mentioning EhCache is stale (Caffeine is used).

Tooling: `plugin-run` is not on PATH in Git Bash. Validate with `py -3 <plugin>/scripts/validate-schema.py <file> <schemaId>` (without `-I`, which breaks its sibling import). `ai-sweep.py` could not be run via plugin-run.

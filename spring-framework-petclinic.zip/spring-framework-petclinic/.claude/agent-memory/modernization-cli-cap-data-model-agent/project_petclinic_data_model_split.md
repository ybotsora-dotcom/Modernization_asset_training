---
name: petclinic-data-model-split
description: How the petclinic data model was split and where schema evidence lives
metadata:
  type: project
---

Output split into two files: model-entities.md (JPA classes) and database-schemas.md (4 dialect script folders under src/main/resources/db). The three repository implementations (jpa/jdbc/springdatajpa) are one module.

**Why:** all share the same entities and schema; the SQL scripts are the authoritative DDL because no persistence.xml or hbm2ddl setting exists.
**How to apply:** on re-runs, diff the four schema.sql/data.sql sets (h2/hsqldb drop+recreate, mysql/postgresql idempotent; seed dates differ between h2/hsqldb and mysql/postgresql). `plugin-run` is not on PATH: run scripts from the plugin `scripts/` dir with `python` (not `-I`, which breaks the schema_validator import) for validate-schema.py.

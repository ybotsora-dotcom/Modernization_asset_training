---
name: petclinic-intent-basis
description: How business-intent was derived for spring-framework-petclinic (no rule engine) and tooling quirks
metadata:
  type: project
---

Business intent here is built from business-logic-rules rule IDs (OWN/PET/VIS/VET/PLT), not event pairs; domains = owners, pets, visits, vets, platform (15 capabilities).

**Why:** No rule engine exists; taskengine-inferred-mapping.md is deliberately absent. A visit has no vet (VIS-002), a point stakeholders dispute, so state it prominently.

**How to apply:** Reuse the same domain split and cite rule IDs. Validator: `plugin-run` is not on PATH and `python -I` fails (sibling import); run `python <plugin>/scripts/validate-schema.py <json> <schemaId>` instead. Avoid big bash heredocs with backticks/quotes; use the Write tool.

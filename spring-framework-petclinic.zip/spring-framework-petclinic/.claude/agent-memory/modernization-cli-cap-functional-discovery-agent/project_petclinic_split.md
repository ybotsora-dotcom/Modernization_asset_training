---
name: petclinic-module-split
description: How spring-framework-petclinic features were split and easy-to-miss entry points
metadata:
  type: project
---

Split into 2 modules: owners-pets-visits (3 controllers) and vets-and-platform (VetController, CrashController, `/` view-controller in mvc-core-config.xml, CallMonitoringAspect JMX, profile switch).

Easy to miss: `/` is an `<mvc:view-controller>` in XML, not Java. `VisitController.showVisits` returns view `visitList` with no JSP present.
`plugin-run` was unavailable; validator ran via `python <plugin>/scripts/validate-schema.py` (not with `-I`).

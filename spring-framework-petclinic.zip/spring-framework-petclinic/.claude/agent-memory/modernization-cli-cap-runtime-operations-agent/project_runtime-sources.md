---
name: petclinic-runtime-config-locations
description: Where runtime/deploy config really lives in spring-framework-petclinic (no Dockerfile; Jib + Maven profiles) and how to validate summary.json
metadata:
  type: reference
---

No Dockerfile/compose/k8s exist: image comes from the Jib plugin block in pom.xml; DB settings live in pom.xml Maven profiles and are injected into spring/data-access.properties by resource filtering. No scheduling, health, tracing; only JMX CallMonitoringAspect and logback console.

**Why:** the obvious deployment files are absent, so a run may waste time searching or invent them.
**How to apply:** go to pom.xml (profiles, jib, jetty), src/main/resources/spring/*.xml, logback.xml.

Validator: `plugin-run` is not on PATH here; run `py -3 <plugin>/scripts/validate-schema.py <json> <schemaId>` WITHOUT `-I` (the script imports sibling schema_validator). Also: bash heredocs containing apostrophes broke; use the Write tool for files.

---
name: petclinic-rule-locations
description: Where business rules live in spring-framework-petclinic and how validators were run when plugin-run was missing
metadata:
  type: project
---

Rules live in entity annotations (Owner, Person, Visit), hand-written web validators (PetValidator, PetTypeFormatter, duplicate-pet check in PetController), DDL constraints, and XML config (cache, profiles). No stored procedures, no rule engine, no authorization; so no taskengine-inferred-mapping.md, and index.md carries a "Rule-Engine Analysis" absence note.

The stakeholder-disputed question "does a visit require a vet" is answered no (VIS-002 in visits.md); caller wants file:line evidence for it every time.

**Why:** the caller flagged this dispute explicitly; the evidence is an absence (no vet field anywhere) so it must be listed exhaustively.
**How to apply:** on re-runs, re-grep for "vet" in Visit, VisitController, visit JSP and schema files first.

Tooling: `plugin-run` was not on PATH. Run `python <plugin>/scripts/validate-schema.py <json> <schemaId>` and `check-business-logic-rules.py <dir>` directly, without `-I` (validate-schema imports a sibling module).

---
name: petclinic-quality-runs
description: Tooling quirks and accepted-by-design findings for extraction-quality runs on spring-framework-petclinic
metadata:
  type: project
---

- `plugin-run` is not on PATH on this Windows host. Call scripts directly from the plugin cache `scripts/` dir (`python <scripts>/mermaid_check.py`, `check-ai-output.py --json`) and set `PYTHONPATH=<scripts>` for `validate-schema.py`, otherwise `schema_validator` import fails. Python cannot see Git-Bash `/tmp`; use a Windows temp path.
- No rule engine by design (taskengine mapping absent is correct); no completeness-report exists, so coverage is "not measured" for non-ai folders; ai has 0 sweep locations (coverage null/measured).
- Empty arrays (backgroundJobs, scheduledJobs, crossProjectDependencies, ai lists) are legitimate for this single-module app with no product AI.
- `CacheEvict` shows up as an unresolved class name only because the docs cite its absence; false positive.

- 2026-11-13 run: EOL table in risk-gap/operations.md rewritten; CHECK-06 judged resolved (score 99/A, 0 Warning, 4 Info). `.current-execution.json` absent so trace_id null. No completeness-report still.

**Why:** avoids re-discovering setup failures and re-raising accepted items.
**How to apply:** reuse the commands above; the lasting open item as of 2026-11-11 is the thin, inferred EOL table in risk-gap/operations.md.

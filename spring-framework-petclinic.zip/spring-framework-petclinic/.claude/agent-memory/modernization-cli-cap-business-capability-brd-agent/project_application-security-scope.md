---
name: application-security-scope
description: Application Security BRD scope, framing rules and source-link convention for petclinic capability BRDs
metadata:
  type: project
---

Application Security owns RISK-002/004/005/006/007 and rule OWN-005; RISK-001/003 are "See RBAC", RISK-019 "See Client Management". How staff stay signed in is an RBAC dependency.

**Why:** single-owner capability split; customer asked for no plan/estimates and plain business language (no session/token/TLS/CSP/header wording in body; technical terms only in the appendix).
**How to apply:** stakeholders are COO/sponsor, practice managers, front-desk lead, front-desk staff, lead vet only. Label extraction fact vs customer input vs analysts' framing; no customer input exists for this capability. KPIs use counts derivable from the BRD (5 record-changing pages, 2 database setups, 5 owned findings); mark the rest as open items. Source links use the repo remote URL with /blob/<commit>/ as RBAC did. Validator: `python .../scripts/validate-schema.py <json> capability-summary.v1`; trace_id from .claude/traceability/.current-execution.json goes in both top level and `_contract`.

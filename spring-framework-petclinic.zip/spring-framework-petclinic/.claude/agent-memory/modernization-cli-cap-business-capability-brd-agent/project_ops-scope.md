---
name: ops-scope
description: Operations, Observability and Delivery BRD scope: owns PLT-003 and RISK-008/009/017/018; technology names only in appendix
metadata:
  type: project
---

Operations BRD owns PLT-003, RISK-008, 009, 017, 018 only. RISK-016/021 and storage choices are "See Persistence and Data Platform"; RISK-001/003 are "See RBAC". No customer input exists for this capability, so all needs are labelled analysts' working framing.

**Why:** the customer forbids technology names in bodies and requires platform-independent requirements; no timing estimates.
**How to apply:** use a business-term to technology mapping in the appendix only. See [[rbac-scope]] for tooling quirks (validator run with python directly; trace_id inside `_contract`).

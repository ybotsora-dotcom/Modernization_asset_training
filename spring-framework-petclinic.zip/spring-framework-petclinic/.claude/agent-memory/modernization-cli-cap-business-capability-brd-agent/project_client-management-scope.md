---
name: client-management-scope
description: Client Management BRD scope, OD-1 retention decision framing, and no-customer-input labelling
metadata:
  type: project
---

Client Management owns OWN-001..004, 006..010, RISK-010, RISK-019. OWN-005 = See Application Security; OWN-009 consistency = See Persistence and Data Platform; access = See RBAC. RISK-019 is framed as OPEN DECISION OD-1 with decision owner unnamed, no legal obligations assumed.

**Why:** capability split gives single owners; extraction has no customer statements for owners, so sections 6/7 are labelled "analysts' working framing".
**How to apply:** do not invent customer positions or volumes (sample data is 10 owners only); avoid technology names (JPA, MySQL) in body where possible, though OWN-009 needs store names. Use a Read of the plugin script path scripts/validate-schema.py via python (no -I). trace_id from .claude/traceability/.current-execution.json.

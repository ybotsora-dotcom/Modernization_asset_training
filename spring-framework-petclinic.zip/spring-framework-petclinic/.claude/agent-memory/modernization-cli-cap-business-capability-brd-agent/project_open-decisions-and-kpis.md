---
name: open-decisions-and-kpis
description: How to handle customer stakeholder disagreements and KPI targets in petclinic capability BRDs
metadata:
  type: project
---

Customer disagreements (e.g. vet required on a visit) are recorded as an explicit OPEN DECISION in section 4 with both positions stated neutrally and the extraction fact (VIS-002) as current state; never pick a side. KPIs may not invent volumes or response times; use testable 100% conditions and mark customer-dependent targets as OPEN.

**Why:** caller instructed this for Visit History; capability split (knowledge-base/capabilities/index.md) assigns single owners, others write only "See <Capability>".

**How to apply:** for each BRD, take owned rules/risks from capabilities/index.md; reference non-owned ones with "See X" only. In capability-summary.json, `_contract` also requires `trace_id` (schema validator demands it inside `_contract`). Run validate-schema.py via python without -I (it imports a sibling module); `plugin-run` is not on PATH.

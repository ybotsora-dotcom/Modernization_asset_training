---
name: clinical-staff-scope
description: Clinical Staff Management BRD scope: read-only vet directory, owns VET-001..007 and RISK-013; open decisions OD-V1..V3
metadata:
  type: project
---

Clinical Staff Management owns VET-001 to VET-007 and RISK-013 only. It is a read-only directory with no management functions (new scope if wanted). Vet-to-visit link is "See Visit History"; VET-001 consistency across stores is "See Persistence and Data Platform". Open decisions: OD-V1 freshness, OD-V2 management wanted, OD-V3 vet-visit link.

**Why:** single-owner capability split; no customer statements about vets exist in the extraction.
**How to apply:** in sibling BRDs write only "See Clinical Staff Management" for vet rules. Same tooling quirks as [[rbac-scope]]; the validator ran fine with plain `python` and a trace_id in `_contract`.

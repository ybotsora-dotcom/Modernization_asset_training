---
name: patient-management-scope
description: Patient Management BRD scope: owns PET-001..009 only, no risks; clinical-record gap is a customer QUESTION
metadata:
  type: project
---

Patient Management owns PET-001 to PET-009 and no risks; RISK-012 (See Visit History), RISK-003 (See RBAC), RISK-007 (See Application Security) are "See" only. The "system holds no clinical record" point is raised as a customer question, never a finding.

**Why:** caller's single-owner instructions; no customer input existed for this capability, so stakeholder needs are labelled analysts' working framing.

**How to apply:** keep section 5/10 short; validator script lives at plugin scripts/validate-schema.py, run with python directly. See [[open-decisions-and-kpis]].

---
name: brd-business-language
description: Customer rules for petclinic BRD bodies - no technology names, no effort estimates, customer roles only
metadata:
  type: feedback
---

BRD bodies must be technology-free (no persistence/database/framework names; they appear only in the traceability appendix), use only the customer's roles (COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet), contain no timing or effort estimates, and label extraction fact vs customer input vs analysts' working framing.

**Why:** the customer requires requirements to survive a platform change; earlier BRDs were corrected on these points.
**How to apply:** for Persistence and Data Platform (owns PLT-001/002/005, VIS-007, RISK-014/015/016/020/021) write "See <Capability>" for OWN-009, VET-001, RISK-004, RISK-019. Validator works with plain `python .../scripts/validate-schema.py <json> capability-summary.v1`; `trace_id` goes in `_contract` too. See [[rbac-scope]].

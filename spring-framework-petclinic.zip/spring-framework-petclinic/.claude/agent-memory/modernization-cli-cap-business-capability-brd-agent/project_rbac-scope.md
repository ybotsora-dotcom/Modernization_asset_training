---
name: rbac-scope
description: RBAC BRD scope decisions and tooling quirks for the petclinic capability BRDs
metadata:
  type: project
---

RBAC owns only RISK-001 and RISK-003, zero rules; RISK-002 is "See Application Security". The BRD frames it as a gap and a decision. Only the front-desk role is inferred; other roles are listed as customer questions.

**Why:** the customer confirmed that framing, and the capability split is single-owner.
**How to apply:** in sibling BRDs write only "See RBAC" for RISK-003. KPIs must not invent numbers; mark them as open items for the customer.

Tooling: `plugin-run` is not on PATH. Run `python <plugin>/scripts/validate-schema.py <json> capability-summary.v1` without `-I`. `trace_id` is required inside `_contract` as well as at the top level. Long Bash heredocs failed to parse, so use the Write tool for files.

---
name: web-shell-scope
description: Web Shell and Localization BRD scope - owns PLT-004 only, no risks; RISK-006 is See Application Security
metadata:
  type: project
---

Web Shell and Localization (slug web-shell-experience) owns rule PLT-004 and NO risks; RISK-006 is written only as "See Application Security". The /oups error page is a deliberate demonstration, not a business function. Only the welcome heading uses the en/de/es wording; language selection is unverified.

**Why:** single-owner principle in knowledge-base/capabilities/index.md.
**How to apply:** keep sections 5 and 10 short; no invented risks; validate JSON with `python .../scripts/validate-schema.py <json> capability-summary.v1`. See [[project_rbac-scope]].

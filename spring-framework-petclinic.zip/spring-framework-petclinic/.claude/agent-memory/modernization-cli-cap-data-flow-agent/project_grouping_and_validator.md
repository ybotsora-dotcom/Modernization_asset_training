---
name: project-grouping-and-validator
description: How petclinic flows were grouped into docs and how to run the schema validator when plugin-run is missing
metadata:
  type: project
---

Petclinic flows are grouped by entity (owner, pet, visit, vet) plus an infrastructure file, not by layer, because the 3 parallel repository implementations (jpa/jdbc/spring-data-jpa) are described inside each flow.

**Why:** the persistence tier varies per profile, so per-layer docs would split one flow across files.
**How to apply:** keep per-variant steps inside each entity flow. There are no stored procedures, views or triggers in db/*/*.sql, so no SQL tier to trace.

Validator: `plugin-run` is not on PATH and `python -I` fails with ModuleNotFoundError (schema_validator import). Running `python <plugin>/scripts/validate-schema.py <json> <schemaId>` without `-I` works.
Heredocs containing apostrophes in Bash broke; use the Write tool for markdown.

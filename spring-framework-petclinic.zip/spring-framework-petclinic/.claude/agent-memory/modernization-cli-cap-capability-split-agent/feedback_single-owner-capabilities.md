---
name: single-owner-capabilities
description: User requires every rule/risk to have exactly one owning capability, others only "See <Capability>"; plain business wave wording; petclinic split decisions
metadata:
  type: feedback
---

Each rule, risk and requirement gets exactly ONE owning capability; other capabilities only reference it ("See <Capability>"), never restate it. Per-owner rule and risk tables must list each id once (petclinic: 40 rules, 21 risks).

**Why:** the user wants one source of truth per BRD to avoid contradictory interpretations in validation and stakeholder review.

**How to apply:** in every coverage list separate "Owned" from "See"; when splitting a risk across capabilities, assign it whole to one. Write wave objectives and "Why Wave N" as what the business gets at the end, with no "migrate/moved/rebuilt" wording (customer is not asking for a migration plan).

Petclinic approved decisions (2026-11-12): authorization (RBAC, incl. RISK-003 ownership check) is separate from Application Security; RISK-019 belongs to Client Management; RISK-012 whole to Visit History; OWN-009 and VET-001 owned by domain capabilities, Persistence and Data Platform only aligns them; Visits and Vets kept separate (VIS-002 dispute unresolved); vet capability named Clinical Staff Management but is read-only.

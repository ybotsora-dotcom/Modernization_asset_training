---
name: petclinic-architecture-run-notes
description: Tooling quirks and doc-splitting decision for architecture runs on spring-framework-petclinic
metadata:
  type: project
---

Single bounded domain: one file `petclinic.md` plus index is enough (about 150 lines); no need to split per controller.

Tooling: `plugin-run` is not on PATH in Git Bash. Call the scripts directly under the plugin `scripts/` dir with `python`. `validate-schema.py` fails with `-I` (cannot import sibling module); run without `-I`. `mermaid_check.py` returned UNAVAILABLE (chrome-headless-shell missing), so diagrams are marked unvalidated and status PARTIAL.

**Why:** avoids rediscovering these on the next run.
**How to apply:** go straight to direct script calls; expect PARTIAL unless Chrome for Mermaid is installed.

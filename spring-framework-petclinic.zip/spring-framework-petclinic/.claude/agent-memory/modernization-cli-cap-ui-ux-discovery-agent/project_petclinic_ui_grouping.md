---
name: project-petclinic-ui-grouping
description: How petclinic JSP screens were grouped into ui-ux docs and tooling gotchas
metadata:
  type: project
---

Screens grouped into owners.md, pets-visits.md, shell-and-vets.md (shell tags + welcome + vets + error), navigation.md.
**Why:** only 9 screens, all JSP under WEB-INF/jsp; visits live in jsp/pets/ (not a visits dir), welcome/exception have no controller (mvc:view-controller / exception resolver in mvc-core-config.xml).
**How to apply:** reuse grouping; note VisitController.showVisits returns missing view `visitList`.
Tooling: `plugin-run` is not on PATH; run scripts directly with `python -I <plugin>/scripts/validate-schema.py`. mermaid_check.py returned UNAVAILABLE (no headless Chrome).

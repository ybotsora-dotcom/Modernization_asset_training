---
name: no-product-ai
description: Petclinic has no product AI; only harness is root CLAUDE.md; stub-style output is correct
metadata:
  type: project
---
Repo has zero AI sweep hits; only engineering signal is CLAUDE.md (no .claude settings/agents/mcp).
**Why:** classic Spring XML petclinic. **How to apply:** write index.md + summary.json (product false, one claude-code harness), no area files. plugin-run missing in shell: run scripts from the plugin cache `scripts/` dir with plain python (not -I for validate-schema).

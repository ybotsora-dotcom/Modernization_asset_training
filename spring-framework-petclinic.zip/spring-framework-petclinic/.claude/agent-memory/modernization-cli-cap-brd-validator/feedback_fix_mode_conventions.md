---
name: fix-mode-conventions
description: User conventions for BRD fixes in this project - customer-role stakeholders, no estimates, plain language, separate Part B provenance
metadata:
  type: feedback
---

BRD stakeholders must be the customer's own roles (COO / business sponsor, practice managers, front-desk lead, front-desk staff, lead vet), never modernization-team roles. No timing/effort estimates ("quick win", "1-2 weeks"); keep wave and priority. Write in plain business language a practice manager can read. In the Fix Report, list user-directed changes under a separate "Part B" heading from validator findings.

**Why:** the customer asked for no plan or estimate; provenance of changes must be clear.
**How to apply:** when validating, flag team-role stakeholders, estimates and jargon; when fixing, never pick a side on OD-1 and never relabel extraction-only claims as "confirmed with the customer". validate-schema.py must run without `python -I` (it imports a sibling module).

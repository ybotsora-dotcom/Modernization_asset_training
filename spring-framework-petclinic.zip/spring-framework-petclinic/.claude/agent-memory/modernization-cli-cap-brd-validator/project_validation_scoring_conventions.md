---
name: validation-scoring-conventions
description: Scoring conventions used in the 9-BRD petclinic validation run (what counts as duplication, vague terms, severity of restated owned items)
metadata:
  type: project
---

With all 9 BRDs present, "See <Capability>" plus at most a one-clause gloss is not scored as duplication. Restating an owned requirement as a rule/objective/future capability in another BRD is scored: substantial (HIGH, -3) if it is a requirement, minor (MEDIUM, -1) if it is a behaviour description or duplicate KPI.
**Why:** the caller stressed single-owner rules and asked whether any owned requirement is stated in two BRDs. **How to apply:** keep this split on re-runs so scores stay comparable; the 2026-11-12 run gave Persistence and Data Platform the lowest dedup score (13/20) for restating RISK-004, VET-001, OWN-009, PLT-003 and retention.

Vague-term count: only Sections 3, 4, 6; skip "whether X should" question phrasing. KPIs with an OPEN threshold but a testable condition pass; only KPIs with no target at all are deducted.

The capability map (index.md, summary.json) was left stale (0/9 BRDs, brdStatus pending) after the BRDs were written; reported as LOW, not scored.

---
name: od1-vet-conflict-open
description: Visit History OD-1 (vet required on a visit?) is an intentionally unresolved stakeholder conflict; never mark RESOLVED
metadata:
  type: project
---

OD-1 in visit-history is an OPEN stakeholder conflict (front-desk lead vs lead vet). Marker [CONFLICT-RESOLUTION-NEEDED] inserted 2026-11-13; recorded in validation-summary.json crossBrdConflicts as CONF-VH-OD1 (status OPEN), scores untouched.

**Why:** user directed that it cannot be resolved from documents.
**How to apply:** in later runs treat OD-1 as a strength/open item, do not pick a side, do not set RESOLVED.

---
name: fix-run-wskpi-and-baselines
description: Second platform-neutral fix run (WS-K1, AS-P1, PDP-P1, CM-P1): where baselines live, what was left alone
metadata:
  type: feedback
---

Platform-neutral counts go into one "Current-state baseline (not a requirement)" bullet in Section 5 (Persistence) or inside the KPI line (Application Security); the JSON has no baseline field, so the baseline sentence is put in `summary` or the KPI target text. Appendix evidence rows with counts stay as traceability. Client Management OWN-008 was rewritten as a pointer to Persistence, not a baseline label.
**Why:** user wants requirements that survive platform standardisation without duplicating Persistence content. **How to apply:** check the JSON kpis list first; a KPI may exist in the BRD only (WS KPI 7 was). Issues in validation-summary.json carry no status until fixed; insert `"status": "RESOLVED"` after the id line for fixed ones only. Run validate-schema.py with `python` from bash; `-I` breaks its imports.

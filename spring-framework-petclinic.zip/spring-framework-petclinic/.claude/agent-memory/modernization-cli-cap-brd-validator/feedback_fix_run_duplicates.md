---
name: fix-run-duplicates-and-kpis
description: How the 2026-11-13 fix run resolved duplicates, unmeasurable KPIs and numbering in the petclinic BRDs
metadata:
  type: feedback
---

For duplicates, delete the restatement in the non-owner BRD and leave a bare "See <Owner> (ID)"; owner BRDs and ids are never changed. KPIs with no target become an explicit "Open item needing a customer decision" (who measures, what threshold) rather than a bullet or an invented number; remaining KPIs get numbered.
**Why:** the user's rule is reword, relocate, remove or cross-reference only, never invent. **How to apply:** after edits, update each capability-summary.json to match and validate with validate-schema.py (capability-summary.v1); add `status: RESOLVED` to issues in validation-summary.json (schema allows it). Extraction gives CallMonitoringAspect.java:37-77 but no line for tools-config.xml; say so rather than inventing one.

---
name: platform-neutral-fix-pattern
description: How platform-count rules/KPIs and "nothing destroyed" wording were fixed on 2026-11-13; plugin-run is not on PATH
metadata:
  type: feedback
---

Counts of storage variants/databases go out of requirements and KPI targets ("on 100% of the ways of storing data the clinic supports") and stay only as a bullet-level "Current-state baseline (not a requirement)" label, no product names. "Nothing destroyed / indefinitely" is qualified as application-function-only with a "See Persistence and Data Platform" pointer.
**Why:** user wants requirements that survive platform standardisation and no restatement of Persistence content. **How to apply:** sync JSON fields; mark all occurrences of an id RESOLVED in validation-summary.json via regex insert. `plugin-run` is not on PATH in this shell: run `python <plugin>/scripts/validate-schema.py <file> <schema-id>` from PowerShell.

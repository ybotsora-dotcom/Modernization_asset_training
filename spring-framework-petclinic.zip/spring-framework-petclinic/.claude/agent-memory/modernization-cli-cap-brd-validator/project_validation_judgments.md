---
name: project-validation-judgments
description: Scoring judgments for petclinic BRD validation (partial BRD coverage, customer-input labelling, schema tool invocation)
metadata:
  type: project
---

Only some of the 9 approved capabilities have BRDs at any time; the caller said missing BRDs are a portfolio-level wave-gap fact and must not lower the scores of existing BRDs.
**Why:** BRDs are generated incrementally. **How to apply:** list absent capabilities under waveGaps/portfolioNotes; leave the alignment score alone; set completeness PARTIAL.

Stakeholder positions (e.g. Visit History OD-1, does a visit need a vet) are customer input, not extraction evidence; a BRD that labels them as such and takes no side is a strength, not a conflict.

The grep for "as needed" matches "was needed" (false positive); check with -o before counting.

`plugin-run` is not on PATH here. Run `python <plugin>/scripts/validate-schema.py <json> brd-validation-summary.v1` without `-I` (it imports a sibling module).

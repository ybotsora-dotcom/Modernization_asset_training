---
name: revalidation-after-fix-pass-scoring-calls
description: Judgment calls made when re-validating the 9 petclinic BRDs after the fix pass (what counts as substantial, tension vs conflict, unscored findings)
metadata:
  type: project
---

On the post-fix re-run (2026-11-13), a stakeholder requirement in Section 6 that restates an owned ordering rule without "See" was scored substantial (HIGH, -3). A body sentence that contradicts another BRD only by scope (application functions vs platform behaviour) was scored as a MEDIUM wording tension (-1 each), not a conflict (-8).
**Why:** the caller wants single ownership judged strictly but a conflict means contradictory behaviour for the same scenario. **How to apply:** keep this split; deduct duplication and conflict points to both participating BRDs, as the agent spec says.

Findings with no formula term (storage-variant counts baked into rules/KPIs, incomplete RISK-014 difference list, provenance jargon) are reported with severity but no points.
**Why:** formulas are fixed for determinism. **How to apply:** do not invent new deduction terms.

Body vs appendix technology check: grep the project-profile stack terms, then compare hit line numbers with each BRD's `## Appendix` line. All nine bodies were clean of product names.

Second fresh run (same day, files already fixed): capability map now current (9/9), no HIGH items; remaining findings were minor restatements (PLT-004 generic error page, VIS-008/OWN-001 in Application Security, OWN-008 no-delete, RISK-019 audit in RBAC) scored -1 to restater AND canonical owner, platform counts MEDIUM only when a KPI target or rule text carries them (labelled "Current-state baseline" counts are not flagged), and Web Shell KPI 7 "not applicable" scored as a KPI with no target (-3). "stable" regex matches "testable" (false positive).
**Why:** keeps scores comparable between runs. **How to apply:** reuse these calls; verify each against current text first.

validate-schema.py runs with `python <plugin>/scripts/validate-schema.py <json> brd-validation-summary.v1` from the repo root (plugin-run not on PATH). Trace id comes from `.claude/traceability/.current-execution.json` field `trace_id`.

---
name: petclinic-integration-scope
description: Where integrations are configured in spring-framework-petclinic and what was judged out of scope
metadata:
  type: project
---

Integrations here are configured in XML (src/main/resources/spring/*.xml) and Maven profiles in pom.xml, not in Java. No outbound services, messaging or auth exist; only DB, cache and JMX contracts besides the MVC routes.

**Why:** Controllers are thin; the DB/profile switching (jdbc.url etc.) is injected via pom.xml into data-access.properties.
**How to apply:** Check the XML and pom profiles first; treat /oups and the demo controllers as low relevance. Routes without Spring Security are recorded as "none found".

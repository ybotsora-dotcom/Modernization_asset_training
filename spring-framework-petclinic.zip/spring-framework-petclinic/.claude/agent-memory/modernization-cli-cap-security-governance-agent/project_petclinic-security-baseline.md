---
name: petclinic-security-baseline
description: Petclinic has no security layer by design; where policy lives and how to run the schema validator on this machine
metadata:
  type: project
---

This repo has no authn/authz/CSRF/session policy at all (demo app). The only "policy" settings are DB credentials in pom.xml Maven profiles and logging/showSql config; report the password/session/lockout families as "not present" rather than hunting for them.

**Why:** confirmed by dependency and filter review in the 2026-11-11 run.
**How to apply:** start from pom.xml profiles, data-access.properties, datasource-config.xml, PetclinicInitializer.

Tooling: `plugin-run` is unavailable here; run `python <plugin>/scripts/validate-schema.py <json> extraction-security-summary.v2` WITHOUT `-I` (it imports a sibling module). The v2 schema requires overallRiskLevel, topRisks, recommendations, and per-module authMechanism/authzPattern/piiDataTypes and risk `description` (not `risk`/`details`).

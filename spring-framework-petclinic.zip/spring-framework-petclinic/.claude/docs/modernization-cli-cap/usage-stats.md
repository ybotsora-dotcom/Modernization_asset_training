# Token / cost stats

Token and dollar-cost stats for Claude Code sessions are computed **on demand from transcripts**
(`~/.claude/projects/**/*.jsonl`), not captured via hooks. Transcripts are written incrementally in
real time, so stats for the current, still-open session can be read at any moment — nothing needs to
be captured at session exit.

The collector is `${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py`. It is a standalone script with no
dependency on this repo beyond its own file, so it works identically here and in every target repo
the plugin is enabled in. Its unit tests live alongside it in `.claude/scripts/test_collect_stats.py`
(stdlib `unittest`, no pytest or fixtures, so the pair travels together):

```bash
bash .claude/scripts/run-python.sh .claude/scripts/test_collect_stats.py
```

---

## The developer contract

**What happens automatically, with no action from you:**

- The plugin ships `SessionStart`, `Stop`, and `SubagentStop` hooks (`.claude/hooks/hooks.json`, all
  running `${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py --refresh`) — see
  [Automatic refresh](#automatic-refresh) for their exact semantics.
- Those hooks refresh your **untracked, per-machine ledger** (`~/.claude/stats/...`) after every
  session start, every main-agent turn, and every subagent completion — not just once per session. It
  never touches a tracked file and `|| true` keeps a collector error from ever failing the action it's
  attached to.
- A `PostToolUse` hook on the `Bash` tool (`.claude/scripts/git-commit-report-hook.py`) inspects every
  bash command; when one is a `git commit`, it runs `--report` and stages (`git add`, never commits)
  the regenerated **tracked report** (`.claude/logs/summary.jsonl`) — see
  [Automatic report on commit](#automatic-report-on-commit). This covers every phase, discovery
  included, not just implementation-phase deliveries.

**What you must still do, and when:**

- The regenerated `summary.jsonl` is staged, not committed — include it in your next commit (or amend
  the one you're about to make) so the update actually lands. If you never commit again in that
  session, the staged change stays local.
- `bash .claude/scripts/run-python.sh .claude/scripts/collect-stats.py --report` by hand for any session whose cost you want
  reflected *before* your next commit, or in a repo without this plugin's hooks enabled.

**What happens if you never commit:** nothing breaks. Your ledger keeps accumulating in the background
regardless (the refresh hooks alone guarantee that much), but sessions with no subsequent commit stay
invisible to `summary.jsonl` — see [The machine-local boundary](#the-machine-local-boundary).

---

## Automatic refresh

`SessionStart`, `Stop`, and `SubagentStop` all run `--refresh` — covering session start, every
main-agent turn, and every subagent completion, so the ledger reflects each agent execution promptly
rather than waiting for the next session to begin.

`${CLAUDE_PLUGIN_ROOT}` is substituted by Claude Code at hook-invocation time to wherever the plugin
is currently installed/loaded, so the hook command needs no git plumbing and bakes no path into the
target repo. `${CLAUDE_PLUGIN_ROOT}` changes when the plugin updates; a session that had the plugin
loaded before an update keeps using the previous version's path until `/reload-plugins` runs — benign
here, since the old cache still holds a working `collect-stats.py` and the ledger it writes to is
keyed off the *target* repo, not the plugin cache.

**Worktree behaviour.** `repo_root()` resolves via `git rev-parse --git-common-dir`, which is
worktree-safe — from inside any worktree it resolves to the **main** repo root, so every worktree of
a repo shares one ledger. `discover_project_dirs()` globs `~/.claude/projects/<dashed-main-root>*`,
which matches worktree project dirs too (they nest at `<main-root>/.claude/worktrees/…`), each hit
confirmed by reading `cwd` out of a transcript so a coincidental prefix match can't slip through. A
refresh from *any* worktree therefore captures *every* worktree's sessions.

**Concurrent sessions.** `SessionStart`/`Stop`/`SubagentStop` can all fire from several worktree
sessions at once — and now far more often than a once-per-session cadence, since `Stop` fires on every
main-agent turn and `SubagentStop` on every subagent completion — all refreshing the same shared
ledger concurrently. `save_ledger()` writes atomically (a sibling temp file + `os.replace`, which is
atomic on POSIX), so a concurrent reader never observes a torn/partial file, regardless of how often
the hooks fire.

**Known limitation.** A worktree created *outside* the main repo root (`git worktree add /tmp/foo`)
does not match the `~/.claude/projects/<dashed-main-root>*` prefix glob, so its sessions go
uncounted. Pre-existing, orthogonal to the hooks' own correctness.

To opt out, remove the `SessionStart`/`Stop`/`SubagentStop` entries from `.claude/hooks/hooks.json`, or
disable the plugin. You can always run the refresh (or the report) by hand — from inside a Claude
Code session, in any repo the plugin is installed in — with:

```
/collect-stats            # refresh only
/collect-stats report     # refresh + rewrite .claude/logs/summary.jsonl + print the table
```

`${CLAUDE_PLUGIN_ROOT}` is a Claude Code substitution, not a real shell environment variable — it
only resolves inside a live session (hook commands, agent/command content). Pasting
`bash "${CLAUDE_PLUGIN_ROOT}/scripts/run-python.sh" "${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py" --refresh` into a plain terminal will fail
with "No such file or directory" because the variable is empty there. `/collect-stats` exists so you
never need to know or hardcode the plugin's actual on-disk cache path.

---

## Automatic report on commit

A `PostToolUse` hook matching the `Bash` tool (`.claude/scripts/git-commit-report-hook.py`) reads the
hook payload's `tool_input.command`, and if it looks like a `git commit` invocation (a regex tolerant
of flags like `-C`/`-m`, deliberately excluding lookalikes such as `git commit-graph`), it:

1. Runs `collect-stats.py --report`, which refreshes the ledger and rewrites `.claude/logs/summary.jsonl`
   (merged, per [The machine-local boundary](#the-machine-local-boundary), not overwritten).
2. Runs `git add .claude/logs/summary.jsonl` — staged, never committed. The regenerated report rides
   along with whichever commit you make next, rather than joining the commit that triggered the hook
   (a `PostToolUse` hook only runs *after* that commit already happened, so it can't retroactively join
   it).

This replaces "you must run `--report` by hand" for the common case: **any** commit — discovery-phase
or implementation-phase, on any branch — keeps the tracked report current, not just a merge to `main`
via `/archive-implemented` step 11 (which still runs its own `--report` too; redundant but harmless).
`is_git_commit()` in the hook script is unit-tested in
`.claude/scripts/test_git_commit_report_hook.py`, including that a `git commit` mention inside prose
or a heredoc body (not at the start of a shell command segment) is correctly ignored.

**Worktree guard.** `collect-stats.py` always targets the *main* repo root's `summary.jsonl` (one
shared tracked file), but each worktree has its own independent git index — staging that file from a
different worktree's checkout would land in the main worktree's index, not the one the commit just
happened in. The hook compares the commit's `cwd` (from the hook payload) against the main repo root
and skips entirely if they differ, mirroring why `/archive-implemented` step 11 only ever runs
post-merge on `main`.

**Failure mode.** Any error here — `collect-stats.py` failing, or `git add` refusing because the file
isn't tracked in a given target repo — is a warning on stderr, never a blocking error; it can't fail
the commit that already succeeded.

**Accepted trade-off vs. the retired `pre-commit`/`SubagentStop` hooks.** This repo previously tried
and retired hooks on both of those triggers (see
[The four defects this closes](#the-four-defects-this-closes)). What makes this different: `--report`'s
own write is a full-file rewrite of a *tracked* file, so firing it from many concurrent
commits/branches at once could still produce commit-to-commit noise or, in principle, a merge
conflict on `summary.jsonl` if two branches both stage-then-commit it around the same time. Staging
instead of auto-committing keeps this hook from ever creating a commit on its own, and a single `git
commit` is inherently sequential (one process, one working tree), so the practical exposure is limited
to the same kind of conflict any two branches touching the same tracked file could already produce —
resolved the normal way, at merge time.

---

## Two storage tiers

| Tier | Path | Tracked? | Purpose |
|---|---|---|---|
| Ledger | `~/.claude/stats/<dashed-repo-root>/sessions.jsonl` | no | Durable per-(session, agent, model) rows; outlives the 30-day transcript sweep |
| Report | `.claude/logs/summary.jsonl` | yes (here; each target's call) | Aggregated per-(session, model) rows, team-visible; regenerated deliberately |

The ledger lives outside the repo entirely, so an ordinary commit never dirties the worktree with
stats output. The report has ten fields per row — `session_id`, `session_name`, `git_branch`,
`model`, `cost_usd`, `input_tokens`, `output_tokens`, `cache_read`, `cache_write`,
`total_context_tokens`.

In *this* repo the report **is** tracked, because it is the only copy of the cost history that exists
off your machine: transcripts are swept after ~30 days and the ledger never leaves `~/.claude/`, so
without a committed `summary.jsonl` a lost disk means lost history. The rest of `.claude/logs/`
(notably the superseded `agent-stats-*.jsonl` hook format) stays ignored, which requires the
*contents* form of the pattern — git cannot re-include a file whose parent directory is excluded:

```gitignore
.claude/logs/*
!.claude/logs/summary.jsonl
```

A plugin never writes files outside its own root on load, so there is nothing to copy into a target —
`logs/summary.jsonl` only ever exists if that target repo's own maintainers choose to track it, with the
re-include pattern above in place. **`/plugin-init` checks this for you** (step 2): it reports whether
the file is actually trackable and offers to add the two lines, and — the case that otherwise passes
unnoticed — warns when the repo excludes a parent directory such as a bare `.claude/`, because a `!`
re-include can never rescue a file under an excluded ancestor. It never edits `.gitignore` without
asking. To check by hand at any time:

```bash
bash "${CLAUDE_PLUGIN_ROOT}/scripts/run-python.sh" "${CLAUDE_PLUGIN_ROOT}/scripts/check-gitignore-tracking.py"
```

Whether the report is committed is each target repo's call — if it is, the `git-commit-report-hook.py`
`PostToolUse` hook (see [Automatic report on commit](#automatic-report-on-commit)) keeps it current
after every commit, with `/archive-implemented` step 11 as a redundant-but-harmless safety net at
story-merge time. The trade-off to accept when tracking it: per-session dollar costs become visible to
anyone with repo access.

### What `session_name` may contain

`session_name` is the session's **git branch** — **never from the text you typed.** That matters
because this value is written into the ledger and copied from there into a *tracked* file: anything
landing in it is as public as the repo.

Three other names could go there, and all three are off together behind one flag, because all three
are your words:

| Source | Why it is not the default |
|---|---|
| First prompt, truncated to 60 chars | Prompts routinely contain customer names, absolute paths, and pasted content. |
| Session slug | **Not the safe option it looks like.** Claude Code builds the slug *from your first prompt* and appends a random pair: `we-have-a-customer-delightful-thacker`, `in-users-someone-workspace-acme-mode-synthetic-bubble`. Same exposure as the prompt, in a token that looks auto-generated. |
| Custom title | You wrote it, so it can name a client as readily as a prompt can. |

`--include-session-names` opts into all three, in that precedence order (title → slug → prompt →
branch). Leave it off for any repo whose history leaves your machine. The three hooks that run
`--refresh` never pass it, so on the command line enabling it means passing it by hand.

There is a second way in, and it exists precisely because the hooks take no arguments: setting the
environment variable `MODERNIZATION_CLI_CAPTURE_USER_TEXT` to `1`, `true`, `yes` or `on`
(case-insensitive) enables session names as though the flag had been passed. It is ORed into the flag,
so either alone is enough and neither switches the other off. Unlike the flag it *does* reach the
hooks — put it in your own repo's `.claude/settings.json`:

```json
{ "env": { "MODERNIZATION_CLI_CAPTURE_USER_TEXT": "1" } }
```

The same variable is the opt-in for storing your verbatim prompt in the traceability ledger
(`.claude/traceability/log.jsonl`; see the `prompt` property in
`${CLAUDE_PLUGIN_ROOT}/contract/v1/execution-context.schema.json`). That is deliberate — one switch
for "record my own words in files this repo commits", not one per subsystem — so turning it on for the
stats also turns on prompt capture in the ledger, and vice versa. Leave it unset, the default, and
neither file receives your full prose.

One exception holds even with the switch off: the ledger's `raw_args` keeps the text typed after the
command name, capped at 200 characters (`raw_args_truncated` marks a cut). For most stages that is a
track name or a flag, but for a command that takes prose — `/research`, `/add-features`,
`/resolve-open-questions`, the `fix-*` commands — those first 200 characters are your words, and they
are committed with the ledger. Keep client names, ticket text and secrets out of those arguments in a
repo whose history leaves your machine. The switch does not open this; it only lifts the cap.

A second one: every plugin-agent spawn's `agent_execution_started` row keeps its `description` (the short label the command gave the spawn), capped at 200 characters, home directory collapsed and secret-shaped text redacted. It is written by the command, not typed by you, but a command may build it from your inputs, so the same advice applies. The switch lifts that cap too, to 4000 characters.

Because names are persisted into the ledger at write time rather than recomputed at report time, the
flag only reaches transcripts that this pass actually reprocesses — and `--refresh` skips every
transcript older than the ledger's watermark. On an existing ledger it is therefore close to a no-op on
its own: every pre-existing row keeps the branch name it already has. Pair it with `--full` to re-derive
names for every transcript still on disk:

```bash
bash "${CLAUDE_PLUGIN_ROOT}/scripts/run-python.sh" "${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py" --report --full --include-session-names
```

Transcripts already swept after ~30 days can never be re-derived at all, with or without `--full`.

If a repo already has names like those in its stats, the flag alone does not remove them — names are
persisted in the ledger and merged forward, not recomputed. Clean both files with:

```bash
bash "${CLAUDE_PLUGIN_ROOT}/scripts/run-python.sh" "${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py" --sanitize-names
```

which resets **every** `session_name` to that row's branch, in the ledger and the report, leaving every
other field untouched. Unconditional on purpose: a prompt-derived slug is a whitespace-free single
token, indistinguishable by shape from a branch, so any "does this look like prose?" filter keeps the
very names you are trying to remove. Nothing is lost — `session_id` still identifies each row.

It rewrites the files in place only — anything already committed stays reachable in git history, so
decide separately whether that warrants rewriting history.

---

## The machine-local boundary

The ledger only ever contains sessions whose transcripts exist on *your* machine — Claude Code writes
transcripts locally, and they are never synced anywhere. `summary.jsonl` is therefore a merge: each
`--report` run takes whatever is currently in the file, overlays this machine's freshly computed
`(session_id, model)` rows on top (they win, since they are a live recompute), and keeps every row it
has no local transcript for untouched. So the tracked file is cumulative across whoever ran
`--report` and when, not a snapshot of one machine's view — no single run can truncate another
machine's sessions out of it.

If you don't see your own sessions in `summary.jsonl`, it's because nobody has run `--report` on a
machine that has your transcripts since those sessions happened. Run it on the machine where the
session ran, and commit the result.

---

## CLI

```bash
# Refresh the ledger only (fast, no repo writes) — what the SessionStart hook runs
bash .claude/scripts/run-python.sh .claude/scripts/collect-stats.py --refresh

# Refresh, rewrite .claude/logs/summary.jsonl, print a table
bash .claude/scripts/run-python.sh .claude/scripts/collect-stats.py --report

# Machine-readable summary
bash .claude/scripts/run-python.sh .claude/scripts/collect-stats.py --report --json

# Ignore the watermark and rescan every transcript
bash .claude/scripts/run-python.sh .claude/scripts/collect-stats.py --report --full

# One-time migration of legacy hook records (see below)
bash .claude/scripts/run-python.sh .claude/scripts/collect-stats.py --import-legacy .claude/logs
```

### Requirements

- **Python 3** — no third-party dependencies.
- A git repository (the repo root is resolved with `git rev-parse --git-common-dir`).

---

## How it works

- **Transcript discovery** — `git rev-parse --git-common-dir` locates the canonical repo root
  (worktree-safe: the common `.git` dir is shared by every worktree). Its dash-encoded form is
  globbed against `~/.claude/projects/`, and each match is confirmed by reading the `cwd` field out
  of one of its transcripts, so an unrelated sibling directory can't be picked up by a coincidental
  prefix match.
- **Row key** — `(session_id, agent_key, model)`. `<session>.jsonl` is `agent_key: "main-session"`;
  each `<session>/subagents/agent-*.jsonl` is its own row, with `agent` resolved from the sibling
  `.meta.json`'s `agentType` — so per-agent cost attribution survives, which is what the old
  `SubagentStop` hook existed for.
- **`agent_run_id` — the join key to the traceability ledger.** The same `.meta.json` also carries
  `toolUseId`, and a ledger row copies it verbatim into `agent_run_id`. That value is byte-identical
  to the `agent_run_id` recorded in `.claude/traceability/log.jsonl`, so a cost/token row can be joined to the
  trace row that produced it — which run spawned this agent, under which command execution, against
  which output. It is `None` for a `main-session` row (a session is not a spawn) and for a
  **Skill-tool launch**, whose sidecar records `name` instead of `toolUseId`; the trace ledger's
  `PreToolUse` hook only fires on `Agent`/`Task`, so those spawns never had a trace row to join to.
  `None` means "not a tool-call spawn", never "lost". Rows written before this field existed lack it
  entirely — read it with `row.get("agent_run_id")`, and `--refresh --full` re-derives it for every
  transcript still on disk. The collector imports nothing from the trace ledger; it stays copyable
  into a repo that has none.
- **The report is unchanged by this.** ``.claude/logs/summary.jsonl`` still carries exactly its ten fields
  (`session_id`, `session_name`, `git_branch`, `model` plus the six measured ones) — `agent_run_id`
  is a ledger-tier field only, and per-agent report attribution is a separate change.
- **Global message-id dedup** — transcripts are processed in ascending mtime order against one shared
  `seen_message_ids` set; a `message.id` counts only for the first transcript that contains it. This
  is what prevents `/resume`- and fork-induced double counting: a resumed or forked session replays
  history that was already billed once.
- **Branch attribution** — `git_branch` is the modal (most frequent) `gitBranch` across a
  transcript's entries, ties broken by first-seen.
- **Name attribution** — by default the `git_branch`, and nothing else; a ledger row for a transcript
  with no branch at all is named `""`, which the report then resolves to the branch of any subagent row
  for the same session, else `unknown`. The longer chain (`custom-title` → `slug` → first non-meta user
  prompt, truncated to 60 chars → `git_branch`) applies **only** under
  `--include-session-names`, or the `MODERNIZATION_CLI_CAPTURE_USER_TEXT` environment variable it is
  ORed with — see [What `session_name` may contain](#what-session_name-may-contain) for
  why it is opt-in.
- **Pricing** — a `PRICING` table in the script, USD per million tokens. Cache writes are charged at
  1.25× input (the default 5-minute TTL), cache reads at 0.1× input. Unknown models log
  `cost_usd: 0`, so add new model ids to that table when they ship.
- **Ledger merge** — `--refresh` only reprocesses transcripts whose mtime is newer than the ledger's
  watermark; `--full` forces a complete rescan. Rows for transcripts that are not reprocessed —
  including ones whose transcript has since aged out of the 30-day retention window — are preserved
  untouched.
- **Report merge** — `--report` never opens `summary.jsonl` with a clean slate; see
  [The machine-local boundary](#the-machine-local-boundary).

---

## The four defects this closes

The previous implementation (`stats-logger.py` on `SubagentStart`/`SubagentStop`/`SessionStart`/
`SessionEnd` hooks, aggregated by `aggregate-stats.py`) had four defects, all structural:

- **Duplicate rows** — `/clear` and `/resume` fire `SessionEnd` twice, producing byte-identical rows
  for the same session. Global message-id dedup removes the duplicated content at the source.
- **Empty `session_name`** — the old aggregator only resolved a name from a `custom-title` entry, so
  most rows were `""`. Falling back to the branch means the *report* never emits `""` (a session with no
  branch anywhere reports `unknown`), though a ledger row for a branchless transcript is still `""` —
  deliberately, so the report can fall through to a subagent row that does know the branch. The chain
  originally included the session's first prompt and the session slug, both of which put user prose into
  a tracked file; both are now opt-in behind `--include-session-names` / `MODERNIZATION_CLI_CAPTURE_USER_TEXT` (see
  [What `session_name` may contain](#what-session_name-may-contain)).
- **Records lost to timing** — `SessionEnd` fires *after* a commit, so a story's delivery session was
  never in the committed stats. Reading transcripts on demand removes the dependency on any exit-time
  event.
- **Wrong `git_branch`** — read point-in-time at exit, so a session that had already been
  squash-merged reported `main`. Attribution is now the modal branch across the transcript's own
  history.

---

## Migrating legacy hook records

`collect-stats.py --import-legacy <dir>` folds the previous `agent-stats-*.jsonl` records into the
ledger, tagged `source: "legacy-hook"`, aggregated by `(session_id, agent, model)` since the old
schema had no stable per-agent-instance identity.

**Only run it where the transcripts are gone.** If a session's transcript still exists (Claude Code
keeps them ~30 days), a plain `--refresh` recomputes that session from source and is strictly better
— it also *corrects* rows the old pricing table got wrong, whereas an import faithfully preserves
them. This toolkit's own two legacy logs were superseded that way rather than imported.

The import is order-independent and never double-counts:

- Rows for `agent: "main-session"` are collapsed by per-field **max** rather than summed, because the
  old hook wrote a cumulative snapshot of the whole transcript on every `SessionEnd` — a session that
  ended twice left two nested snapshots under the same key, and summing them double-counts. Subagent
  rows still **sum**: two rows with the same `(session_id, agent, model)` there are two genuinely
  separate runs, not snapshots of one.
- A legacy row is skipped outright when the ledger already holds a transcript-derived row for the
  same `(session_id, model)`. Key equality alone is not sufficient: a legacy subagent row's
  `agent_key` is the *agent type* (`general-purpose`) while a transcript row's is the per-instance
  `agent-<id>`, so the two never collide and the subagent would otherwise be counted twice.

> The last point is a deliberate divergence from the version of this collector in
> an earlier engagement repo, which documents "transcript rows win on key collision" but only achieves
> that for `main-session` rows. Keep the two in sync if that repo is updated.

Nothing runs the import for you — it is a deliberate one-time step you invoke by hand.

---

## Out of scope

Transcripts carry token counts but no dollar cost, so `collect-stats.py` keeps a local `PRICING`
table and computes cost itself. OpenTelemetry's `claude_code.api_request` event carries an
authoritative `cost_usd` and would remove the need for that table — a follow-up, not covered here.

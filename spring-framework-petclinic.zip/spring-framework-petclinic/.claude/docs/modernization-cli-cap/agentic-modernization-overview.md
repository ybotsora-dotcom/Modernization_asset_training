# Agentic Modernization

### From legacy code to running implementation — driven by a team of specialized AI agents

---

## The idea in one sentence

**Agentic modernization** uses a coordinated team of specialized AI agents to read a legacy codebase, reconstruct its business and technical knowledge, align it with stakeholders, design the target architecture, produce a staged execution-ready backlog — and then drive each story through to a merged implementation, turning months of manual discovery and planning into a **repeatable, auditable, days-long pipeline**.

The agents do the heavy lifting — reverse-engineering, analysis, and drafting. **People stay in control at every decision gate.**

---

## Why it matters

| Benefit | What it means for the business |
|---|---|
| ⚡ **Speed** | Compresses months of manual reverse-engineering and planning into a pipeline that runs in days. |
| 🧠 **Captures tribal knowledge** | Reconstructs business rules and intent directly from the code — not from the fading memory of the few people who still understand the system. |
| 🔗 **Full traceability** | Every epic and story traces back to a documented capability and the exact code that implements it. Auditable end to end. |
| 🚦 **Risk surfaced early** | Dedicated risk, security, and quality agents flag technical debt and gaps *before* budget is committed. |
| 🔁 **Repeatable & consistent** | The same rigorous method applies to every application in the portfolio. The pipeline is codebase-agnostic. |
| 👤 **Human control retained** | Agents analyze and draft; people approve the direction at each phase gate. |
| ✅ **Independently graded** | Four dedicated validator agents score the output of the phases that matter and can block progress — quality is measured, not asserted. |
| 🚀 **Carries through to code** | The pipeline no longer stops at a backlog: a spec-driven implementation stage takes a story to a merged branch. |
| 📚 **Living documentation** | Produces a searchable knowledge-base website serving both Product and Architecture teams. |

---

## The end-to-end flow

An eight-stage pipeline. Each stage is run by agents and confirmed by people before the next begins. Optional validator stages (amber) score the output and can send it back.

```mermaid
flowchart TD
    L["Legacy / Monolith Codebase"]:::src --> P1

    P1["<b>1 · Knowledge Extraction</b><br/>14 agents reverse-engineer architecture,<br/>data, business logic, UI and risk"]:::agent
    P1 --> Q{"Quality Gate<br/>score and grade"}:::gate
    Q -->|"score low"| FIX["fix-knowledge-extraction<br/>re-run the weak areas"]:::agent
    FIX --> Q
    Q -->|"passed"| P2

    P2["<b>2 · Capability Split</b><br/>group the system into capabilities<br/>and migration waves"]:::agent
    P2 --> R0(["Split approval"]):::human
    R0 --> P3

    P3["<b>3 · Business Alignment</b><br/>a Business Requirements Doc<br/>per business capability"]:::agent
    P3 --> V1{"BRD validation<br/>internal + external"}:::gate
    V1 --> R1(["Product and Architecture sign-off"]):::human
    R1 --> P4

    P4["<b>4 · Target-State Architecture</b><br/>design the future platform,<br/>stack and architecture style"]:::agent
    P4 --> V2{"Architecture validation<br/>format + coverage · READY/NOT-READY"}:::gate
    V2 --> R2(["Architecture approval"]):::human
    R2 --> P5

    P5["<b>5 · Transformation Planning</b><br/>phased, wave-based migration roadmap"]:::agent
    P5 --> R3(["Roadmap confirmation"]):::human
    R3 --> P6

    P6["<b>6 · Epic Backlog</b><br/>waves into epics"]:::agent --> P7
    P7["<b>7 · Story Intent</b><br/>epics into engineering-ready stories"]:::agent
    P7 --> V3{"Backlog validation<br/>coverage · READY/NOT-READY"}:::gate
    V3 --> R4(["Backlog approval"]):::human
    R4 --> P8

    P8["<b>8 · Implementation</b><br/>OpenSpec drives each story to a<br/>spec, a branch and a merge request"]:::impl
    P8 --> OUT

    OUT["Merged implementation<br/>+ living Knowledge Base site"]:::out

    classDef agent fill:#1d4ed8,stroke:#1e3a8a,color:#ffffff
    classDef gate fill:#b45309,stroke:#92400e,color:#ffffff
    classDef human fill:#047857,stroke:#065f46,color:#ffffff
    classDef src fill:#475569,stroke:#334155,color:#ffffff
    classDef impl fill:#be123c,stroke:#881337,color:#ffffff
    classDef out fill:#7c3aed,stroke:#5b21b6,color:#ffffff
```

🟦 Agent-run analysis · 🟧 Automated quality gate · 🟩 Human decision point · 🟥 Spec-driven implementation · 🟪 Final deliverables

### Side tracks that branch off the main pipeline

The eight stages above are the spine. Four **side tracks** hang off the knowledge base rather than sitting inside the chain — they are optional, independently re-runnable, and none of them is a prerequisite for the next stage. They exist because a modernization programme has to be *sold and steered*, not only planned: stakeholders need a working demo, leadership needs a progress story, and open questions need evidence-backed answers before a wave is committed.

```mermaid
flowchart LR
    KB[("Knowledge Base<br/>Stage 1 output")]:::kb

    KB --> RS["<b>/research</b><br/>deep, cited research note"]:::side
    KB --> DG["<b>/design-guide</b><br/>technology-agnostic style guide"]:::side
    KB --> DEMO["<b>/demo-plan</b><br/>demo-init → demo-scoped<br/>architecture → demo-flows"]:::side
    KB --> PR["<b>/progress-report</b><br/>slide-by-slide deck structure"]:::side

    RS -.->|"optional evidence"| DEMO
    RS -.->|"optional evidence"| P5["Stage 5<br/>Transformation Planning"]:::main
    DG -.-> DEMO
    DEMO -.-> PR
    DG -.-> PR

    BL["Stage 6–7 backlog"]:::main --> AF["<b>/add-features</b><br/>new scope into an existing backlog<br/>Draft stories only"]:::side
    AF --> BL

    classDef kb fill:#7c3aed,stroke:#5b21b6,color:#ffffff
    classDef side fill:#0369a1,stroke:#075985,color:#ffffff
    classDef main fill:#1d4ed8,stroke:#1e3a8a,color:#ffffff
```

Solid arrows are required inputs; dotted arrows are **optional** evidence one track offers another.

| Side track | When you reach for it | Where it attaches |
|---|---|---|
| **`/research`** | An open question that must be answered from evidence, not opinion — "which flows could we ship in two weeks, and what do they depend on?" | Reads the knowledge base. Its notes are read as evidence by `demo-init-planner` (flow selection) and `transformation-agent` (wave sequencing) — but never override their human approval gates. |
| **`/demo-plan`** | You need a runnable, presentable slice to prove the target architecture to stakeholders before the full programme is funded. | Chains `/demo-init` (scope + the flow approval gate), a **demo-scoped** target-state architecture under the `demo` track, then `/demo-flows`. Optionally `/design-guide`. |
| **`/design-guide`** | New UI must be visually indistinguishable from the legacy application. | Independent of the demo chain — runnable at any time. Feeds demo screens and the deck's mockup section. |
| **`/progress-report`** | Leadership needs a checkpoint on where the programme stands. | Reads across everything produced so far, including the demo plan and design guide. |
| **`/add-features`** | New scope arrives after the backlog exists. | Edits the existing backlog in place on a new branch. Hard rule: only `Draft` stories may be touched. |

### The demo track as a method

The order matters more than the commands do.

1. **Fix the scope against a budget before choosing flows.** `/research` is given the goal, the audience and
   what may be spent — weeks, engineers, stack — and asked which two to four end-to-end flows fit inside
   that. A demo scoped by ambition rather than by budget is the single most common way this track fails.
2. **Confirm the flow set with the client, then write the agreement back down.** The proposed flows go out
   for feedback; what comes back replaces them, in the research note itself, so the agents plan from what
   was agreed rather than from what was proposed.
3. **Generate at demo scale, under the `demo` track.** Architecture, roadmap and backlog all take the track
   as an argument, so the demo never overwrites programme artifacts and the two can be compared.
4. **Build just-in-time.** Story specifications are generated one epic at a time, ahead of the build rather
   than all at once — so what the client says while clicking lands in stories that are still `Draft`.
5. **Revise with `/add-features`, not by regenerating.** Scope moves during a demo. Adding to the backlog is
   an additive, Draft-only edit; regenerating the backlog under a team that is implementing it is not.

Capability split and BRDs are deliberately **not** part of this scoping: they describe the system, which
does not change because you are demoing part of it. The demo reads the programme's.

Waves themselves can also be sequenced for demonstrability — each delivery wave ending in something the
client can watch — but that is a direction you give the capability split, not a default it applies. Wave 0
stays scaffolding.

The demo track deserves one clarification, because two different things are named "demo". `knowledge-base/demo/` is the **flat** output folder of `/demo-init` and `/demo-flows` — there is one demo per repository. The `demo` **track** (`target-state/architecture/demo/`, `transformation/demo/`, `backlog/demo/`) is an orthogonal axis that scopes *programme* artifacts to a demo-sized subset without overwriting the full-programme versions. See [`artifact-manifest.md`](../docs/artifact-manifest.md) for the authoritative convention.

---

## How the agents work — the extraction "swarm"

The agents' role is most visible in **Stage 1**. Instead of one tool doing a shallow scan, a foundation agent first maps the repository, and then **specialized agents fan out and work in parallel** — each an expert in one lens (architecture, data, security, business rules, the user interface…). Their findings are then **synthesized into one knowledge graph** and **quality-checked** before anything downstream is allowed to proceed.

```mermaid
flowchart TB
    RI["<b>repository-intake-agent</b><br/>Phase 1 · maps the repository"]:::found
    RI --> A1 & A2 & A3 & A4 & A5 & A6

    A1["architecture<br/>discovery"]:::dom
    A2["functional<br/>discovery"]:::dom
    A3["data-model"]:::dom
    A4["data-flow"]:::dom
    A5["integration"]:::dom
    A6["ui-ux<br/>discovery"]:::dom

    B1["business<br/>logic-rules"]:::biz
    B2["security<br/>governance"]:::biz
    B3["runtime<br/>operations"]:::biz

    RI --> B1 & B2 & B3

    A1 & A2 & A3 & A4 & A5 & A6 --> J2(( )):::dot
    B1 & B2 & B3 --> J2
    J2 --> C1 & C2

    C1["business<br/>intent"]:::biz2
    C2["risk-gap"]:::biz2

    C1 & C2 --> KG["<b>knowledge-graph-curator</b><br/>synthesis"]:::syn
    KG --> QA["<b>extraction-quality-agent</b><br/>scores and grades — the gate"]:::qa
    QA --> KB[("Knowledge Base")]:::kb

    classDef found fill:#1d4ed8,stroke:#1e3a8a,color:#ffffff
    classDef dom fill:#dbeafe,stroke:#3b82f6,color:#1e3a8a
    classDef biz fill:#ede9fe,stroke:#8b5cf6,color:#4c1d95
    classDef biz2 fill:#f3e8ff,stroke:#a855f7,color:#4c1d95
    classDef dot fill:#94a3b8,stroke:#64748b,color:#ffffff
    classDef syn fill:#0f766e,stroke:#115e59,color:#ffffff
    classDef qa fill:#b45309,stroke:#92400e,color:#ffffff
    classDef kb fill:#7c3aed,stroke:#5b21b6,color:#ffffff
```

🔵 **Phase 2 — Domain analysis** (6 agents) and 🟣 **business & infrastructure** (3 agents): all nine depend only on Phase 1, so they fan out as a *single* parallel batch. 🟪 **Phase 3 — Intent & risk:** 2 agents that run *after* Phase 2, because they consume the rule-engine mapping it produces. Findings converge into synthesis and the quality gate.

The same orchestration pattern — **specialized agents + human gate** — repeats through alignment, architecture, planning, and backlog generation.

---

## The design principles behind the agents

Four rules shape every agent in the pipeline. They explain most of the "why is it built this way" questions.

### 1. The source code is read once, at the very start

Only the **Stage 1 extraction agents** are allowed to read the legacy codebase. Every downstream agent is explicitly forbidden from it and works **exclusively from the knowledge base**:

> `capability-split-agent` — *"You never read repository source code directly."*
> `target-state-architecture-agent` — *"You never inspect repository source code directly."*
> `transformation-agent` — *"You must NOT inspect repository source code directly."*
> `story-intent-agent` — *"You **never** inspect repository source code directly."*

This is deliberate. It forces every downstream claim to be traceable to an extracted, reviewed fact rather than to a fresh, unreviewed glance at the code — and it means fixing a wrong fact **once**, in the knowledge base, corrects everything built on it.

Two controlled exceptions exist, both narrow:

- **`business-capability-brd-agent`** may consult source *as a fallback to validate* an ambiguity, but must "never default to code-first analysis."
- **`design-guide-extractor`** reads UI source directly by design — it extracts *visual* facts (colours, type scale, spacing, component patterns) that are pixel-level detail no extraction agent captures, and it writes only a style guide, never a requirement or a plan.

### 2. Structured JSON is the contract between stages

Every agent writes a machine-readable `summary.json` beside its narrative Markdown, and the next stage consumes the JSON. The prose is for humans; the JSON is the interface. This keeps hand-offs cheap and lets a stage be re-run without re-reading hundreds of pages of Markdown.

### 3. Evidence beats assertion — confidence is earned, not claimed

The extraction agents operate under a **binding confidence rule**: a rule or behaviour earns `HIGH` confidence only when its *implementing body* has actually been read. Anything inferred from a name, a heading or a column title is `MEDIUM` at best, and an implementation that isn't in the repository is recorded as an explicit **source gap** rather than a confident guess. Load-bearing claims carry `file:line` citations.

### 4. Validators are external oracles, and they can say no

Four validator agents grade the output of the stages that matter. Critically, they are **separate agents from the ones that produced the work** — a stage cannot grade its own completeness. Two of them (`architecture-completeness-validator`, `backlog-validator`) emit a hard **READY / NOT-READY** verdict *independent of the numeric score*, so a single unmapped entity can block progress even when the percentage looks good. Validators are also forbidden from inventing content: they report and correct, they do not author.

**Model tiering:** most agents run on a mid-tier model; the single-purpose epic writer runs on the fastest tier because its brief is fully pre-assembled, and the research agent runs on the top tier because open-ended multi-source synthesis is the hardest judgment in the toolkit. Cost follows the difficulty of the judgment required.

---

## Why leadership can trust the output: full traceability

Nothing is invented in a vacuum. Every downstream artifact links back to evidence in the original code, so any decision can be defended in an audit or architecture review.

```mermaid
flowchart LR
    C["Source code<br/>and business rule"] --> KB["Knowledge Base<br/>fact"]
    KB --> CAP["Capability<br/>and wave"]
    CAP --> BRD["Capability<br/>BRD"]
    BRD --> ARCH["Target architecture<br/>decision"]
    ARCH --> EP["Epic"]
    EP --> ST["Engineering<br/>story"]
    ST --> SPEC["OpenSpec<br/>change"]
    SPEC --> MR["Merge<br/>request"]

    classDef n fill:#1e293b,stroke:#0f172a,color:#ffffff
    class C,KB,CAP,BRD,ARCH,EP,ST,SPEC,MR n
```

---

## The agents

The toolkit defines **35 specialized agents**. Each owns a single, well-defined responsibility, is told explicitly what it may and may not read, and hands a structured artifact to the next.

### Stage 1 — Knowledge extraction (14 agents)

*The only agents permitted to read the legacy source code.*

| Agent | The idea behind it | Key output |
|---|---|---|
| **repository-intake-agent** | A universal code analyzer that works "regardless of technology stack or build system." Runs first and alone, producing the map every other agent builds on — structure, stack, dependencies, modules, entry points. | Repository baseline |
| **architecture-discovery-agent** | An "elite software architect" reconstructing the design that was never written down: layers, components, service boundaries, module dependencies and coupling points, with diagrams. | Architecture map |
| **functional-discovery-agent** | The product view. Catalogs business-facing features, APIs, UI flows, commands and background jobs. Treats stored procedures and reporting queries as features in their own right, even with no controller or UI. | Feature inventory |
| **data-model-agent** | Reverse-engineers entities, schemas, relationships and **persistence ownership** — not just what the tables are, but which module owns them. | Data model |
| **data-flow-agent** | Traces how data *moves* and transforms across layers and services — the lineage view that a static schema cannot give you. | Data lineage |
| **integration-agent** | An "Integration Contract Analyst": every external and internal API, event, file and protocol boundary the system depends on or exposes. | Integration catalog |
| **ui-ux-discovery-agent** | Reverse-engineers the user interface for a *rebuild*: every screen, its controls and layout, and for each interaction the backend call and business rule it triggers, plus permission gating. Stack-agnostic — server-rendered or SPA. | Screen inventory |
| **business-logic-rules-agent** | The deepest reader in the swarm. Extracts business rules, decisions and workflows from the implementation — including SQL procedures, triggers and rule-engine configuration — and folds the concrete edge cases asserted by the test suite into the rule text. Bound by the confidence rule. | Rules catalog |
| **security-governance-agent** | Security mechanisms, access-control patterns, data sensitivity and governance risk — read from what the code actually enforces, not from policy documents. | Security report |
| **runtime-operations-agent** | How the thing actually runs: deployment model, runtime dependencies, configuration, scheduling and observability. | Operations report |
| **business-intent-agent** | Infers the *why* — business purpose, domains and capabilities — from structure, patterns and domain models. Runs after the rules agent so it can use the rule-engine operation list as its authoritative source. | Capability map |
| **risk-gap-agent** | Consolidates every other agent's findings into one prioritized risk register: technical debt, vulnerabilities, gaps. Synthesis, not fresh discovery. | Risk register |
| **knowledge-graph-curator** | Connects the parallel outputs into a single coherent graph, so relationships that no individual agent could see become visible. | Knowledge graph |
| **extraction-quality-agent** | The gate. A "critical-eye reviewer" that scores completeness, consistency and unresolved references — and is explicitly forbidden from modifying the files it judges. | Quality report + score |

### Stages 2–7 — Planning chain (13 agents)

*Knowledge-base only. None of these may read the legacy source.*

| Stage | Agent | The idea behind it | Key output |
|---|---|---|---|
| 2 · Split | **capability-split-agent** | Turns a pile of extracted facts into a *plan shape*: business capabilities grouped into migration waves, reconciled against independent oracles (feature list, module list, menu structure) so nothing is silently dropped. Iterates with the user until approved. | Capability + wave map |
| 3 · Alignment | **business-capability-brd-agent** | Translates technical reality into a business document Product can sign: objectives, workflows, rules, gaps, screens owned. Business language only — no class names or routes. | BRD (narrative + JSON) |
| 3.5 · Validation | **brd-validator** | An "elite BRD Quality Architect" scoring each BRD on alignment, structure, requirement clarity, acceptance-criteria quality and duplication. Runs in VALIDATE or FIX mode. | BRD scorecard |
| 4 · Architecture | **target-state-architecture-agent** | Designs the future platform, stack and style from the knowledge base plus the user's direction. Runs a **plan gate first** — never writes documents until the user confirms the plan. | Target-state architecture |
| 4.5 · Validation | **architecture-validator** | Checks *form*: completeness, frontmatter, placeholders, Mermaid validity, cross-document consistency. Anything it cannot actually run is marked `UNVERIFIED` and caps the grade rather than passing silently. | Format scorecard |
| 4.5 · Validation | **architecture-completeness-validator** | Checks *substance* — the coverage oracle. Every extracted entity and feature area must have a traceable Retain/Refactor/Retire/Defer disposition. One unmapped entity forces **NOT-READY**. Never invents design to fill a hole. | Coverage verdict |
| 5 · Planning | **transformation-agent** | Produces the phased, wave-based roadmap: sequencing, coexistence, contract evolution, rollback. Three-phase workflow — discovery and questions, then a high-level plan for confirmation, only then documents. | Transformation plan |
| 5 · Estimation | **team-estimation-agent** | Turns the confirmed roadmap into a commercial picture. Builds **one** Work Breakdown Structure, then staffs it three ways — cost-optimized, time-optimized, safe-and-realistic — using formal grade bands and PERT three-point estimation, with Gen-AI acceleration stated as an explicit assumption. Counts only the delivery team's headcount; customer SME time is tracked separately. Auto-chained after `transformation-agent`. | Three staffing + cost options |
| 6 · Backlog | **epic-backlog-agent** | A deliberately narrow, fast writer: one epic per invocation, from a pre-assembled brief plus two JSON files. Forbidden from reading anything not in its brief, from proposing wave structure, and from inventing scope. Runs on the fastest model tier. | One epic file |
| 7 · Stories | **story-intent-agent** | Refines an epic into self-contained story specifications — requirement intents, EARS statements, Gherkin scenarios, data contracts, open questions. Produces *specification intent* for a downstream spec step — explicitly *"not a code generator… not an implementation planner"* and not sprint tickets. | Story specs |
| 7.5 · Validation | **backlog-validator** | Grades epics and stories on structural completeness, dependency integrity, cross-item coherence, traceability and **coverage** — reconciling the backlog against the capability list, module list and screen inventory. Emits a hard READY/NOT-READY. | Backlog verdict |
| Utility | **knowledge-base-publisher** | A strictly data-only agent: regenerates the site's data files against a frozen scaffold and a JSON contract. Forbidden from touching HTML, CSS or JS — which is what makes the published site stable between runs. | Knowledge-base website |
| Utility | **skill-recommender** | Reads the confirmed target-state architecture and proposes verified Claude Code skills, plugins, MCP servers, and CLI tools matched to that stack, re-derived from the architecture on every run — no accumulating catalog. Community candidates must clear a hard quality bar (≥2000 GitHub stars, pushed within 6 months, not archived; first-party vendors exempt), with below-bar candidates listed alongside their measured star count. Splits output strictly by scope: a committed, project-scoped file and a gitignored, host-scoped file (the latter also covers a plugin-owned, stack-independent CLI ergonomics list). Proposes and saves only; never installs. | Tooling recommendations |

### Side tracks — research, demo, design and reporting (6 agents)

*The optional tracks described in [Side tracks that branch off the main pipeline](#side-tracks-that-branch-off-the-main-pipeline). Knowledge-base only, with one deliberate exception: `design-guide-extractor` reads UI source.*

| Track | Agent | The idea behind it | Key output |
|---|---|---|---|
| `/research` | **knowledge-base-research-agent** | A deep-research analyst for the corpus: decompose the question, gather evidence from multiple places, cross-check claims against each other, and separate *established* from *inferred* from *unknown*. Its one non-negotiable is a **clarify-first gate** — it never proceeds on a narrow, unconfirmed assumption. Top model tier. | Cited research note |
| `/demo-init` | **demo-init-planner** | Establishes the demo baseline before anyone builds anything: purpose, business summary, scope, candidate flows, target stack, out-of-scope, assumptions and risks — learning the stack from the knowledge base rather than assuming one. Emits JSON so every downstream demo agent consumes an approved, machine-readable scope. | Demo overview + `demo-findings.json` |
| `/demo-flows` | **demo-flow-describer** | One agent per approved flow, all in parallel. A business analyst writing for people who will *watch* the demo: **zero technical detail** — no endpoints, contracts, rule IDs or table names — and every screen labelled either *evolved from migrated …* or *new screen*, the latter requiring an explicit `New because:` justification so new scope can never sneak in unnoticed. | One presenter-ready flow document |
| `/design-guide` | **design-guide-extractor** | Extracts the *look and feel* as a technology-agnostic contract — palette, type scale, spacing, shape and elevation, component visual patterns, accessibility notes, and a full design-tokens table — so a new frontend can be visually indistinguishable from the legacy app without knowing its stack. | Style guide + design tokens |
| `/progress-report` | **progress-reporter** | Owns the canonical deck agenda — scope recap, codebase findings, target architecture, demo flows, demo-vs-final architecture, functional mockup — and reads across every knowledge-base artifact to fill it. **Reference implementation:** `/progress-report` spawns its own ad-hoc section and slide agents rather than calling this agent; when the two disagree, the command is what runs. | Slide-by-slide deck structure |
| `/add-features` | **add-features-analyst** | A backlog scout that is **read-only with respect to the backlog itself**. Before any edit, it writes schema-governed findings — duplicates, overlaps, contradictions, affected epics and waves, a per-story editability map, and a placement recommendation — and the command reads them straight back to drive its clarifying-questions gate. Separating the scan from the write is what makes it safe to add scope to a backlog people have already approved; the write itself then delegates new epic/story files to `epic-backlog-agent`/`story-intent-agent` rather than re-authoring their shapes. | `add-features-findings.json` + `.md` |

### Stage 8 — Implementation (commands + skills, not agents)

**Run `/recommend-tooling` once before the first `/new-story-spec`.** `skill-recommender` (a Utility agent in the planning-chain table above) reads the confirmed target-state architecture and proposes verified skills, MCP servers, and CLI tools matched to the actual target stack. Acting on its proposals — installing the ones that fit — hands implementation agents framework-idiomatic patterns and structural tools instead of plain-text search-and-edit, which both raises the quality of the code they produce and lowers the tokens spent per story, since a precise tool call replaces several exploratory reads.

Stage 8 is deliberately **not** agent-based. It orchestrates the [OpenSpec](https://github.com/Fission-AI/OpenSpec) CLI through commands and skills, so the spec-driven loop stays inspectable and re-runnable:

| Command | What it does |
|---|---|
| **`/new-story-spec`** | Picks an unblocked story, creates a branch, generates an OpenSpec proposal (`proposal.md`, `specs/`, `design.md`, `tasks.md`) grounded in the story, validates every story section is reflected, pushes and opens a merge request. |
| **`/new-story-impl`** | Implements every task in the change, validates completion, commits and pushes. Optionally runs a code review with auto-fix first. Resumable — re-running picks up from the story's current status. |
| **`/archive-implemented`** | Syncs the change's delta specs into the main specs, archives the change, sets the story to Done, squash-merges and deletes the branch. |

Backed by five `openspec-*` skills (`propose`, `apply`, `sync-specs`, `archive-change`, `explore`). Requires the `openspec` CLI; merge-request automation additionally uses the GitLab CLI, with a manual fallback when absent.

---

## What you get

- **A living knowledge base** of the legacy system — architecture, data, business rules, screens, risks — published as a searchable website for Product and Architecture teams.
- **A capability and wave map** that turns the system into a plan shape, reconciled against independent oracles.
- **Business Requirements Documents** per capability, ready for stakeholder alignment workshops, internally scored and optionally verified against external documentation.
- **A target-state architecture** with diagrams, tied to current-state reality and explicit modernization drivers — with a hard coverage verdict, not just a score.
- **A phased, wave-based transformation roadmap** that sequences the migration to control risk, plus **three costed staffing options** built on one shared work breakdown so they are genuinely comparable.
- **An execution-ready backlog** — epics and engineering-ready stories — graded for completeness, dependency integrity and coverage.
- **A spec-driven path to merged code**, story by story, with each change specified, implemented, reviewed and archived under version control.

And from the side tracks, on demand:

- **A demo plan** — an approved flow set, a demo-scoped target architecture, and a presenter-ready business description per flow, for proving the direction to stakeholders before the full programme is funded.
- **A technology-agnostic style guide** with design tokens, so new UI matches the existing application.
- **Cited research notes** answering the open questions that would otherwise be settled by opinion.
- **A stakeholder progress-report deck structure**, assembled from everything above.

---

<sub>Generated from the Modernization-CLI pipeline definition. Stages, agents and constraints reflect [`modernization.md`](modernization.md) and the agent definitions under `.claude/agents/`. Agent count and quoted constraints verified against the repository at the time of writing.</sub>

# Schema Reference — summary JSON properties by producer agent

This is the companion to [`artifact-manifest.md`](../docs/artifact-manifest.md), which is itself generated from
`.claude/contract/v1/phase-graph.json`. That graph — and its rendering — is the authority on
**paths** — which folder each stage writes to, what the file is named, who reads it downstream. This doc
is the authority on **contents** — for every `summary.json` (or similarly-named validation/quality JSON)
in the pipeline, which agent produces it, which schema file under `.claude/contract/schemas/` governs it, and what
every property in that schema means.

None of the schema files carry a JSON Schema `description` keyword on their properties (a handful use
`description` only as a field *name*, e.g. `finding.description`). The Description column below is
written from each property's name, type, enum values, and nesting — not copied from the schema source.

Nested object and array-of-object properties are flattened into the same table using dotted/bracket
paths (e.g. `technologies.languages`, `entities[].confidence`) rather than a sub-table per nesting level,
so each schema stays a single scannable table. "Required" reflects the schema's own `required` array at
that property's nesting level — a property can be required *within* its parent object while the parent
object itself is optional (this is called out explicitly where it happens).

## The `Used` column

Every property table below classifies each property by how its value is actually consumed:

- **Yes** — a specific downstream agent or command reads the value as documented input.
- **Use on site only** — no agent reads it, but [`site-field-map.json`](../contract/v1/site-field-map.json)
  declares it as the contract source of a field on the published knowledge-base site, so
  `knowledge-base-publisher` consumes it. The `Used by` cell names the `data-*.js` file(s) it feeds.
- **Possible** — ambiguous consumption: self-read by its own producer, a human-review gate,
  written-but-not-read-back, or a named consumer that reads a *different* artifact (e.g. a mirrored
  Markdown file) rather than this JSON field.
- **No** — no consumer at all, and no site field sources from it: evidence/reference or human-facing only.

`Use on site only` is derived from `site-field-map.json`, which records provenance for the *site* and is
not itself a gate — so it can only ever show that a field **is** consumed, never that no agent reads one.
Where a field turns out to have an agent consumer, it belongs in `Yes`.

## Schema index

The **Consumed by** column lists agents (or, in parentheses, the command driving the interaction where no
dedicated agent reads the file directly) that treat the summary as a documented input — not every agent that
happens to mention the file in a generic knowledge-base listing.

| Producer agent | Summary file (under `knowledge-base/`) | Schema | Consumed by |
|---|---|---|---|
| [`repository-intake-agent`](../agents/knowledge-extraction/repository-intake-agent.md) | `extraction/repository/summary.json` | [`extraction-repository-summary.v2`](#extraction-repository-summaryv2) | Every Phase 2–3a extraction agent: `architecture-discovery-agent`, `functional-discovery-agent`, `data-model-agent`, `data-flow-agent`, `integration-agent`, `ui-ux-discovery-agent`, `business-logic-rules-agent`, `security-governance-agent`, `runtime-operations-agent` |
| [`repository-intake-agent`](../agents/knowledge-extraction/repository-intake-agent.md) | `extraction/project-profile.json` | [`project-profile.v1`](#project-profilev1), [`project-profile.v2`](#project-profilev2) | `ui-ux-discovery-agent`, `integration-agent`, `extraction-quality-agent` (required); `brd-validator`, `architecture-validator`, `architecture-completeness-validator`, `progress-reporter` (optional, degrade gracefully if absent) |
| [`architecture-discovery-agent`](../agents/knowledge-extraction/architecture-discovery-agent.md) | `extraction/architecture/summary.json` | [`extraction-architecture-summary.v1`](#extraction-architecture-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent` |
| [`functional-discovery-agent`](../agents/knowledge-extraction/functional-discovery-agent.md) | `extraction/functional/summary.json` | [`extraction-functional-summary.v1`](#extraction-functional-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent`, `capability-split-agent`, `target-state-architecture-agent`, `architecture-completeness-validator` (feature-area reconciliation) |
| [`data-model-agent`](../agents/knowledge-extraction/data-model-agent.md) | `extraction/data-model/summary.json` | [`extraction-data-model-summary.v1`](#extraction-data-model-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent`, `architecture-completeness-validator` (entity reconciliation) |
| [`data-flow-agent`](../agents/knowledge-extraction/data-flow-agent.md) | `extraction/data-flow/summary.json` | [`extraction-data-flow-summary.v1`](#extraction-data-flow-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent` |
| [`integration-agent`](../agents/knowledge-extraction/integration-agent.md) | `extraction/integrations/summary.json` | [`extraction-integrations-summary.v1`](#extraction-integrations-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent` |
| [`ui-ux-discovery-agent`](../agents/knowledge-extraction/ui-ux-discovery-agent.md) | `extraction/ui-ux/summary.json` | [`extraction-ui-ux-summary.v1`](#extraction-ui-ux-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent` (frontend capability mapping), `demo-flow-describer` |
| [`business-logic-rules-agent`](../agents/knowledge-extraction/business-logic-rules-agent.md) | `extraction/business-logic-rules/summary.json` | [`extraction-business-logic-rules-summary.v1`](#extraction-business-logic-rules-summaryv1) | `business-intent-agent`, `risk-gap-agent` (Phase 3), `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent` |
| [`security-governance-agent`](../agents/knowledge-extraction/security-governance-agent.md) | `extraction/security/summary.json` | [`extraction-security-summary.v2`](#extraction-security-summaryv2) | `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent` (security requirements) |
| [`runtime-operations-agent`](../agents/knowledge-extraction/runtime-operations-agent.md) | `extraction/runtime-operations/summary.json` | [`extraction-runtime-operations-summary.v1`](#extraction-runtime-operations-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent`, `target-state-architecture-agent` (operational NFRs) |
| [`business-intent-agent`](../agents/knowledge-extraction/business-intent-agent.md) | `extraction/business-intent/summary.json` | [`extraction-business-intent-summary.v1`](#extraction-business-intent-summaryv1) | `capability-split-agent` (`traceability.businessIntentIndex`), `business-capability-brd-agent`, `knowledge-graph-curator`, `extraction-quality-agent` |
| [`risk-gap-agent`](../agents/knowledge-extraction/risk-gap-agent.md) | `extraction/risk-gap/summary.json` | [`extraction-risk-gap-summary.v1`](#extraction-risk-gap-summaryv1) | `capability-split-agent` (`traceability.riskGapIndex`), `business-capability-brd-agent`, `target-state-architecture-agent`, `knowledge-graph-curator`, `extraction-quality-agent` |
| [`knowledge-graph-curator`](../agents/knowledge-extraction/knowledge-graph-curator.md) | `extraction/knowledge-graph/summary.json` | [`extraction-knowledge-graph-summary.v1`](#extraction-knowledge-graph-summaryv1) | `extraction-quality-agent` |
| [`extraction-quality-agent`](../agents/knowledge-extraction/extraction-quality-agent.md) | `extraction/extraction-quality/summary.json` | [`extraction-quality-summary.v1`](#extraction-quality-summaryv1) | (`/knowledge-extraction` and `/fix-knowledge-extraction` commands — no dedicated downstream agent) |
| [`completeness-report-agent`](../agents/knowledge-extraction/completeness-report-agent.md) | `extraction/completeness-report/summary.json` | [`extraction-completeness-summary.v1`](#extraction-completeness-summaryv1) | (`/fix-knowledge-extraction` command; `knowledge-base-publisher` for `data-completeness.js` — no dedicated downstream agent) |
| [`ai-discovery-agent`](../agents/knowledge-extraction/ai-discovery-agent.md) | `extraction/ai/summary.json` | [`extraction-ai-summary.v1`](#extraction-ai-summaryv1) | `knowledge-graph-curator`, `extraction-quality-agent` (CHECK-12, CHECK-13), `completeness-report-agent`, `knowledge-base-publisher` (`data-ai.js`) |
| [`ai-cluster-tracer-agent`](../agents/knowledge-extraction/ai-cluster-tracer-agent.md) | `extraction/ai/clusters/<cluster>/partial.json` | [`ai-cluster-partial.v1`](#ai-cluster-partialv1) | `ai-merge-clusters.py` (validates and merges into `clusters/merged.json`); `ai-discovery-agent` (consolidates `merged.json`) |
| [`capability-split-agent`](../agents/capability-split-agent.md) | `capabilities/summary.json` | [`capability-index-summary.v1`](#capability-index-summaryv1) | `business-capability-brd-agent`, `brd-validator`, `target-state-architecture-agent`, `transformation-agent`, `epic-backlog-agent`, `story-intent-agent` |
| [`business-capability-brd-agent`](../agents/business-capability-brd-agent.md) | `business-capabilities/<slug>/capability-summary.json` | [`capability-summary.v1`](#capability-summaryv1) | `brd-validator`, `target-state-architecture-agent`, `epic-backlog-agent`, `story-intent-agent` |
| [`brd-validator`](../agents/brd-validator.md) | `business-capabilities/validation-summary.json` | [`brd-validation-summary.v1`](#brd-validation-summaryv1) | (`/fix-brd` command, and `brd-validator` itself in FIX mode) |
| [`target-state-architecture-agent`](../agents/target-state-architecture-agent.md) | `target-state/architecture/(<track>/)target-state-summary.json` | [`target-state-summary.v1`](#target-state-summaryv1) | `architecture-validator`, `architecture-completeness-validator`, `transformation-agent`, `team-estimation-agent`, `epic-backlog-agent`, `story-intent-agent`, `demo-flow-describer`, `progress-reporter` |
| [`architecture-validator`](../agents/architecture-validator.md) | `target-state/architecture/(<track>/)validation-summary.json` | [`architecture-validation-summary.v1`](#architecture-validation-summaryv1) | (`architecture-validator` itself in FIX mode; no other documented consumer) |
| [`architecture-completeness-validator`](../agents/architecture-completeness-validator.md) | `target-state/architecture/(<track>/)completeness-validation-summary.json` | [`completeness-validation-summary.v1`](#completeness-validation-summaryv1) | (`architecture-completeness-validator` itself in FIX mode; no other documented consumer) |
| [`transformation-agent`](../agents/transformation-agent.md) | `target-state/transformation/(<track>/)transformation-summary.json` | [`transformation-summary.v1`](#transformation-summaryv1) | `team-estimation-agent`, (`/create-epic-backlog` command, via an inlined Wave Context Summary — `epic-backlog-agent` itself does not read this file directly) |
| [`team-estimation-agent`](../agents/team-estimation-agent.md) | `target-state/transformation/(<track>/)team-estimate-options-summary.json` | [`team-estimate-options-summary.v1`](#team-estimate-options-summaryv1) | None — human-facing only |
| [`backlog-validator`](../agents/backlog/backlog-validator.md) | `target-state/backlog/(<track>/)validation-summary.json` | [`backlog-validation-summary.v1`](#backlog-validation-summaryv1) | (`backlog-validator` itself in FIX mode; no other documented consumer) |
| [`add-features-analyst`](../agents/add-features-analyst.md) | `target-state/backlog/(<track>/)add-features-findings.json` | [`add-features-findings.v1`](#add-features-findingsv1) | (`/add-features` command — drives its clarifying-questions gate and change set; no other documented consumer) |
| [`change-impact-agent`](../agents/change/change-impact-agent.md) | `changes/<changeId>/impact.json` | [`change-impact.v1`](#change-impactv1) | `change-story-agent`; `open-questions-agent` (harvests `openQuestions[]`); `/new-story-impl` (`testCommand`, `codeImpact[]`); `/archive-implemented` (`kbRefreshTargets[]`); `check-change-impact.py`, `check-change-story.py` |
| [`open-questions-agent`](../agents/open-questions-agent.md) | `extraction/open-questions.json` | [`open-questions-register.v1`](#open-questions-registerv1) | `open-questions-cli.py check` (the `/capability-split`/`/target-state-architecture` gates); `open-questions-applier` (APPLY mode) |
| [`open-questions-agent`](../agents/open-questions-agent.md) | `business-capabilities/open-questions.json` | [`open-questions-register.v1`](#open-questions-registerv1) | `open-questions-cli.py check` (the `/target-state-architecture`/`/create-epic-backlog` gates); `open-questions-applier` (APPLY mode) |
| [`open-questions-agent`](../agents/open-questions-agent.md) | `target-state/backlog/(<track>/)open-questions-epics.json` | [`open-questions-register.v1`](#open-questions-registerv1) | `open-questions-cli.py check` (the `/story-intent` gate); `story-intent-agent`, `epic-backlog-agent` (source-priority item 1a); `open-questions-applier` (APPLY mode) |
| [`open-questions-agent`](../agents/open-questions-agent.md) | `target-state/backlog/(<track>/)open-questions-stories.json` | [`open-questions-register.v1`](#open-questions-registerv1) | `open-questions-cli.py check` (the `/new-story-spec` gate, scoped per story); `open-questions-applier` (APPLY mode) |

---

## `_contract` (shared envelope)

Every table below ends with a `_contract` row rather than repeating these fields 26 times. `_contract` is
an additive top-level object — see [`docs/contract.md`](../docs/contract.md) for the full rationale — defined once
in [`.claude/contract/v1/envelope.schema.json`](../contract/v1/envelope.schema.json) and `$ref`'d
from every schema in this file.

| Property | Required | Description |
|---|---|---|
| `_contract.contractVersion` | Yes | Envelope shape version (currently `"1"`) — versions `_contract`'s own fields as a unit, independent of the schema's own `v1`/`v2` filename |
| `_contract.generatedBy` | Yes | Name of the producing agent, matching its `name:` frontmatter |
| `_contract.schemaId` | Yes | `$id` of the `.claude/contract/schemas/*.v1.schema.json` file this artifact targets |
| `_contract.generatedAt` | Yes | Date (`YYYY-MM-DD`) the artifact was generated |
| `_contract.completeness` | Yes | Object: `status` (`COMPLETE`/`PARTIAL`/`MINIMAL`) + optional `gaps` array |
| `_contract.completeness.status` | Yes | How much of the artifact's intended scope was covered |
| `_contract.completeness.gaps` | No | What was skipped or deferred; populated when `status` isn't `COMPLETE` |
| `_contract.confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` — artifact-level aggregate (lowest per-item confidence if this schema has one, else a direct self-assessment) |
| `_contract.trace_id` | Yes (nullable) | Same ULID as `execution-context.v1`'s `trace_id`/`command_run_id` — the command execution that produced this artifact, read from `.claude/traceability/.current-execution.json`; `null` if produced outside a tracked execution |

---

## `extraction-repository-summary.v2`

**Producer:** [`repository-intake-agent`](../agents/knowledge-extraction/repository-intake-agent.md) · **Schema:** `.claude/contract/schemas/extraction-repository-summary.v2.schema.json`

Baseline inventory of the repo's projects/modules and technology stack; read by every downstream extraction agent.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `repositoryType` | Yes | Enum: `Monorepo`, `SingleProject`, `Polyrepo` — overall repo layout classification | Yes | All Phase 2–3a extraction agents — informs module-split decisions |
| `projects` | Yes | Array of discovered projects/modules | Yes | All Phase 2–3a extraction agents — baseline structure every agent traverses |
| `projects[].name` | Yes | Project/module name | Yes | All Phase 2–3a agents — drives per-module output file naming/splitting |
| `projects[].location` | Yes | Path to the project root | Yes | All Phase 2–3a agents — where each agent starts codebase traversal |
| `projects[].buildSystem` | Yes | Build tool/system used (e.g. Maven, npm) | Yes | `runtime-operations-agent` |
| `projects[].primaryLanguage` | Yes | Dominant programming language | Yes | `runtime-operations-agent`, `integration-agent` |
| `projects[].modules` | Yes | Array of submodule names within the project | Yes | All Phase 2–3a agents — module breakdown drives per-module doc splitting |
| `projects[].entryPoints` | Yes | Array of entry-point files/classes | Yes | `architecture-discovery-agent`, `data-flow-agent`, `integration-agent` |
| `technologies` | Yes | Aggregated technology inventory across the repo | Yes | `integration-agent`, `runtime-operations-agent`, `security-governance-agent` |
| `technologies.languages` | Yes | Array of languages detected | Yes | `runtime-operations-agent`, `integration-agent` |
| `technologies.frameworks` | Yes | Array of frameworks detected | Yes | `runtime-operations-agent`, `security-governance-agent`, `integration-agent` |
| `technologies.databases` | Yes | Array of databases detected | Yes | `integration-agent`, `data-model-agent` |
| `technologies.buildTools` | Yes | Array of build tools detected | Yes | `runtime-operations-agent` |
| `technologies.cicd` | Yes | Array of CI/CD build systems detected (e.g. GitHub Actions, Jenkins, GitLab CI) | Yes | knowledge-base-publisher (Dashboard Source Analysis badges) |
| `analysisDate` | Yes | Date the intake analysis was performed | Use on site only | `knowledge-base-publisher` → `data-repository.js` |
| `projects[].type` | Yes | Enum: `Application`, `Library`, `Infrastructure` | Use on site only | `knowledge-base-publisher` → `data-repository.js` |
| `projects[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` — confidence in the discovered facts | Use on site only | `knowledge-base-publisher` → `data-repository.js` |
| `projects[].evidenceFiles` | Yes | Files supporting the discovered facts | Use on site only | `knowledge-base-publisher` → `data-repository.js` |
| `technologies.testing` | Yes | Array of testing frameworks/tools detected | Use on site only | `knowledge-base-publisher` → `data-repository.js` |
| `crossProjectDependencies` | Yes | Dependencies between discovered projects | Use on site only | `knowledge-base-publisher` → `data-repository.js` |
| `notablePatterns` | Yes | Notable architectural/coding patterns observed | Use on site only | `knowledge-base-publisher` → `data-repository.js` |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `project-profile.v1`

**Producer:** [`repository-intake-agent`](../agents/knowledge-extraction/repository-intake-agent.md) · **Schema:** `.claude/contract/schemas/project-profile.v1.schema.json`

Stack-neutral "what kind of project is this" machine contract — source roots, build-file globs, framework
markers, rule-engine entry points — so later agents read a stack-specific anchor here instead of hardcoding
one. Required inside `/knowledge-extraction` (gated by its Phase 1 reconcile check); optional and
gracefully-degrading for consumers outside the pipeline. Everything a consumer greps or iterates is a
literal array; prose survives only in `narrative`/`stackSummary`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `generated` | Yes | Date (`YYYY-MM-DD`) this profile's content was analyzed | No | Not used downstream (metadata/evidence only, mirrors `analysisDate`) |
| `projectName` | Yes | Repo/project name | No | Not used downstream (metadata only) |
| `stackSummary` | Yes | One-paragraph narrative — the only field allowed to be prose and quoted verbatim | Yes | `progress-reporter`/`/progress-report` (cover slide) |
| `stack.backend.present` | Yes | Whether a backend exists in this repository | Yes | `brd-validator` (rule-engine/stack checks skip cleanly when absent) |
| `stack.backend.languages` | Yes | Array of backend languages | No | Not used downstream (evidence only) |
| `stack.backend.frameworks` | Yes | Array of backend frameworks | No | Not used downstream (evidence only) |
| `stack.backend.externalServices` | Yes | Array of `{name, protocol, narrative}` for external services this app depends on | No | Not used downstream (evidence only) |
| `stack.backend.narrative` | Yes | Free text, especially why absent if `present` is false | No | Not used downstream (evidence only) |
| `stack.frontend.primaryFramework` | Yes | Single scalar UI framework | Yes | `brd-validator` (UI-framework check) |
| `stack.frontend.frameworks` | Yes | Fuller array of frontend frameworks/libraries | Yes | `ui-ux-discovery-agent` |
| `stack.frontend.architectureStyle` | Yes | e.g. NgModule, standalone components, MVC views | No | Not used downstream (evidence only) |
| `stack.frontend.narrative` | Yes | Free text | No | Not used downstream (evidence only) |
| `stack.databases.present` | Yes | Whether this repo owns a database | No | Not used downstream (evidence only) |
| `stack.databases.engines` | Yes | Array of database engines | No | Not used downstream (evidence only) |
| `stack.configMechanism.files` | Yes | Array of config files | No | Not used downstream (evidence only) |
| `stack.configMechanism.switchedBy` | Yes | Array of what switches config (build config, env var name, etc.) | No | Not used downstream (evidence only) |
| `stack.configMechanism.usesEnvironmentVariables` | Yes | Whether runtime env vars drive config | No | Not used downstream (evidence only) |
| `stack.configMechanism.settingKeys` | Yes | Array of literal config keys the app reads | No | Not used downstream (evidence only) |
| `sourceLayout.sourceRoots` | Yes | Array of top-level source directories (min 1 item — **not enforced by `schema_validator.py`**, see schema `$comment`) | Yes | `extraction-quality-agent` CHECK-04 (grep scope) |
| `sourceLayout.buildFileGlobs` | Yes | Array of project/build file globs | Yes | `extraction-quality-agent` CHECK-04 |
| `sourceLayout.multiModule` | Yes | Whether the repo is a multi-module/multi-project build | No | Not used downstream (evidence only) |
| `sourceLayout.excludeGlobs` | Yes | Globs extraction scans must skip (`node_modules/`, `dist/`, `knowledge-base/`, ...) | Yes | `extraction-quality-agent` (scan exclusions) |
| `ui.viewRoots` | Yes | Array of directories where screens/views live | Yes | `ui-ux-discovery-agent` |
| `ui.viewFileExtensions` | Yes | Array of view file extensions | Yes | `ui-ux-discovery-agent` |
| `ui.viewGlobs` | Yes | Ready-made globs matching view files | Yes | `ui-ux-discovery-agent` |
| `ui.clientTargets` | Yes | Free-string array of device/deployment targets | Yes | `ui-ux-discovery-agent` (client-target matrix) |
| `ui.routingConfigGlobs` | Yes | Globs matching routing config files | Yes | `ui-ux-discovery-agent` (routing configuration step) |
| `domains` | Yes | Array of `{name, kind, path?}` describing the repo's domain/module structure | Yes | `architecture-validator`, `architecture-completeness-validator` (domain-name validation; advisory only) |
| `domains[].kind` | Yes | Enum: `feature`, `referenceData`, `other` — advisory only, never a mandatory coverage demand | Yes | `architecture-completeness-validator` (suppresses false-positive unmapped findings) |
| `conventions.domainNaming.patterns` | Yes | Array of `{template, appliesTo}` naming patterns | No | Not used downstream (evidence only) |
| `conventions.frameworkMarkers` | Yes | Categorized object of literal source substrings (component/service/route/endpoint/httpClient/...) | Yes | `integration-agent` (cross-check for missing integrations) |
| `conventions.errorHandling` | Yes | Error/exception handling convention | Yes | `brd-validator` |
| `ruleEngine.present` | Yes | Whether a database-resident or code-embedded rule engine exists | Yes | `brd-validator` |
| `ruleEngine.kind` | Yes | Enum: `dbResident`, `codeEmbedded`, `none`, `other` | Yes | `brd-validator` |
| `ruleEngine.dispatchEntryPoints` | Yes | Array of dispatch entry points | No | Not used downstream (evidence only) |
| `ruleEngine.handlerResolutionTables` | Yes | Array of handler resolution table names | No | Not used downstream (evidence only) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `project-profile.v2`

**Producer:** [`repository-intake-agent`](../agents/knowledge-extraction/repository-intake-agent.md) · **Schema:** `.claude/contract/schemas/project-profile.v2.schema.json`

The current profile schema. It carries every property in [`project-profile.v1`](#project-profilev1) above, plus the required `ai` block (AI footprint detection: `ai.present`, `ai.product`, `ai.engineering`, `ai.excludeGlobs`) and the optional `docs` block below. Only the properties added for documentation intake are listed here.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `docs` | No | Documentation sources found in the repository (READMEs, doc sites, ADRs, specs, guides, API references). Omitted when none were inventoried | Yes | `ai-discovery-agent` — reads it to learn which flows and limits the docs claim, then confirms each in code; documentation is a guide, never evidence |
| `docs.sources` | Yes (within `docs`) | Array of documentation sources | Yes | `ai-discovery-agent` |
| `docs.sources[].path` | Yes | Path of the documentation file or folder | Yes | `ai-discovery-agent` |
| `docs.sources[].kind` | Yes | Enum: `readme`, `docs-site`, `adr`, `spec`, `guide`, `api-reference`, `other` | Yes | `ai-discovery-agent` |
| `docs.sources[].pages` | No | Approximate page count for a doc site or folder | No | Not used downstream (evidence only) |
| `docs.sources[].note` | No | Free-text note on what the source covers | No | Not used downstream (evidence only) |

---

## `extraction-architecture-summary.v1`

**Producer:** [`architecture-discovery-agent`](../agents/knowledge-extraction/architecture-discovery-agent.md) · **Schema:** `.claude/contract/schemas/extraction-architecture-summary.v1.schema.json`

Layering, component dependencies, and coupling map of the codebase.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `architecturalStyle` | Yes | Overall style label (e.g. "Layered", "Microservices") | Yes | `target-state-architecture-agent` (current-state baseline), `knowledge-graph-curator` |
| `layers` | Yes | Array of architectural layers found | Yes | `target-state-architecture-agent` |
| `layers[].name` | Yes | Layer name | Yes | `target-state-architecture-agent` |
| `layers[].responsibility` | Yes | What the layer is responsible for | Yes | `target-state-architecture-agent` |
| `layers[].components` | Yes | Component names belonging to the layer | Yes | `target-state-architecture-agent` |
| `layers[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Yes | `knowledge-graph-curator`, `extraction-quality-agent` |
| `componentDependencies` | Yes | Directed dependency edges between components | Yes | `target-state-architecture-agent`, `knowledge-graph-curator` |
| `componentDependencies[].from` | Yes | Dependent component | Yes | `target-state-architecture-agent`, `knowledge-graph-curator` |
| `componentDependencies[].to` | Yes | Depended-on component | Yes | `target-state-architecture-agent`, `knowledge-graph-curator` |
| `componentDependencies[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Yes | `knowledge-graph-curator`, `extraction-quality-agent` |
| `highCouplingAreas` | Yes | Areas flagged as tightly coupled | Yes | `extraction-quality-agent` (modernization-readiness signal) |
| `architecturalPatterns` | Yes | Recognized design/architecture patterns | Yes | `knowledge-graph-curator`, `target-state-architecture-agent` |
| `layers[].evidenceFile` | Yes | File supporting the layer's identification | No | Not used downstream (evidence/reference only) |
| `componentDependencies[].reason` | Yes | Why the dependency exists | Use on site only | `knowledge-base-publisher` → `data-architecture.js` |
| `violations` | Yes | Architectural rule violations found | Use on site only | `knowledge-base-publisher` → `data-architecture.js` |
| `diagramsGenerated` | Yes | Diagram file names produced alongside this summary | No | Not used downstream (evidence/reference only) |
| `layers[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-functional-summary.v1`

**Producer:** [`functional-discovery-agent`](../agents/knowledge-extraction/functional-discovery-agent.md) · **Schema:** `.claude/contract/schemas/extraction-functional-summary.v1.schema.json`

Business-facing functionality inventory: endpoints, workflows, jobs, per-module features.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `totalEndpoints` | Yes | Count of discovered API endpoints | Yes | `extraction-quality-agent` (coverage/stats checks) |
| `totalWorkflows` | Yes | Count of discovered workflows | Yes | `extraction-quality-agent` |
| `totalScheduledJobs` | Yes | Count of discovered scheduled/background jobs | Yes | `extraction-quality-agent` |
| `modules` | Yes | Per-module functional breakdown | Yes | `capability-split-agent`, `target-state-architecture-agent`, `architecture-completeness-validator` |
| `modules[].name` | Yes | Module name | Yes | `architecture-completeness-validator`, `target-state-architecture-agent` |
| `modules[].featureCount` | Yes | Number of features in the module | Yes | `capability-split-agent` |
| `modules[].apiEndpoints` | Yes | Endpoint identifiers exposed by the module | Yes | `architecture-completeness-validator`, `target-state-architecture-agent` |
| `modules[].keyFeatures` | Yes | The module's headline features | Yes | `architecture-completeness-validator` (feature-area reconciliation), `target-state-architecture-agent`, `capability-split-agent` |
| `modules[].overallConfidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Yes | `extraction-quality-agent`, `knowledge-graph-curator` |
| `keyCapabilities` | Yes | Top-level business capabilities identified | Yes | `capability-split-agent` (capability grouping input) |
| `modules[].userRoles` | Yes | Roles that can use the module | Use on site only | `knowledge-base-publisher` → `data-functional.js` |
| `backgroundJobs` | Yes | Background/scheduled job names | Use on site only | `knowledge-base-publisher` → `data-functional.js` |
| `modules[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-data-model-summary.v1`

**Producer:** [`data-model-agent`](../agents/knowledge-extraction/data-model-agent.md) · **Schema:** `.claude/contract/schemas/extraction-data-model-summary.v1.schema.json`

Entities, relationships, inheritance, and persistence ownership.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `entityCount` | Yes | Total number of entities discovered | Yes | `extraction-quality-agent`, `knowledge-graph-curator` |
| `entities` | Yes | Array of discovered entities | Yes | `target-state-architecture-agent`, `architecture-completeness-validator`, `knowledge-graph-curator` |
| `entities[].name` | Yes | Entity name | Yes | `architecture-completeness-validator` (reconciliation), `target-state-architecture-agent` |
| `entities[].tableName` | Yes | Backing table/collection name | Yes | `architecture-completeness-validator`, `target-state-architecture-agent` |
| `entities[].module` | Yes | Owning module | Yes | `architecture-completeness-validator` (reconciliation table's Module column) |
| `entities[].keyRelationships` | Yes | Relationships to other entities | Yes | `knowledge-graph-curator` (relationship mapping) |
| `entities[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Yes | `knowledge-graph-curator`, `extraction-quality-agent` |
| `entities[].persistenceOwner` | Yes | Component/module that owns persistence for this entity | Use on site only | `knowledge-base-publisher` → `data-entities.js` |
| `entities[].evidenceFile` | Yes | File supporting the entity's identification | No | Not used downstream (evidence/reference only) |
| `inheritanceHierarchies` | Yes | Class/entity inheritance trees | Use on site only | `knowledge-base-publisher` → `data-entities.js` |
| `inheritanceHierarchies[].baseClass` | Yes | Base class name | Use on site only | `knowledge-base-publisher` → `data-entities.js` |
| `inheritanceHierarchies[].children` | Yes | Subclass names | Use on site only | `knowledge-base-publisher` → `data-entities.js` |
| `ormFramework` | Yes | ORM/persistence framework used | Use on site only | `knowledge-base-publisher` → `data-entities.js` |
| `ddlStrategy` | Yes | How schema DDL is managed (e.g. migrations, auto-generated) | Use on site only | `knowledge-base-publisher` → `data-entities.js` |
| `migrationTool` | Yes | Migration tool name, or `null` if none detected | No | Not used downstream (no documented consumer) |
| `crossModuleReferences` | Yes | Entity references that cross module boundaries | Use on site only | `knowledge-base-publisher` → `data-entities.js` |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-data-flow-summary.v1`

**Producer:** [`data-flow-agent`](../agents/knowledge-extraction/data-flow-agent.md) · **Schema:** `.claude/contract/schemas/extraction-data-flow-summary.v1.schema.json`

Data movement paths across the system, plus caching and critical-path notes.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `flows` | Yes | Array of discovered data flows | Yes | `knowledge-graph-curator` (relationship synthesis), `extraction-quality-agent` (cross-boundary flow check), `target-state-architecture-agent` (Data Flow Design table), `demo-flow-describer` (operational process context) |
| `flows[].name` | Yes | Flow name | Yes | `target-state-architecture-agent` (Flow Name column) |
| `flows[].sourceType` | Yes | Enum: `HTTP`, `Database`, `Message`, `File`, `ExternalAPI` | Yes | `target-state-architecture-agent` (initiator/protocol inference) |
| `flows[].destinationType` | Yes | Enum: `Database`, `APIResponse`, `Message`, `File`, `Cache` | Yes | `target-state-architecture-agent` (Destination column) |
| `flows[].modulesInvolved` | Yes | Module names the flow passes through | Yes | `knowledge-graph-curator` (relationship mapping) |
| `flows[].isAsync` | Yes | Whether the flow is asynchronous | Yes | `target-state-architecture-agent` (sync vs. async integration-pattern decisions) |
| `flows[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Yes | `extraction-quality-agent` (confidence-vocabulary checks) |
| `flows[].evidenceFiles` | Yes | Files supporting the flow's identification | Yes | `extraction-quality-agent` (evidence-traceability checks) |
| `totalFlows` | Yes | Count of discovered data flows | Use on site only | `knowledge-base-publisher` → `data-flows.js` |
| `flows[].transformationSteps` | Yes | Number of transformation steps in the flow | Use on site only | `knowledge-base-publisher` → `data-flows.js` |
| `cachePatterns` | Yes | Caching patterns observed | Use on site only | `knowledge-base-publisher` → `data-flows.js` |
| `criticalPaths` | Yes | Critical/high-value data paths | Use on site only | `knowledge-base-publisher` → `data-flows.js` |
| `flows[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-integrations-summary.v1`

**Producer:** [`integration-agent`](../agents/knowledge-extraction/integration-agent.md) · **Schema:** `.claude/contract/schemas/extraction-integrations-summary.v1.schema.json`

Integration/contract catalog: internal APIs, external systems, message and file contracts.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `contracts` | Yes | Array of discovered integration contracts | Yes | `knowledge-graph-curator` (relationship synthesis), `extraction-quality-agent` (dependency inventory check), `target-state-architecture-agent` (Service Interaction / Integration Contracts table) |
| `contracts[].name` | Yes | Contract name | Yes | `target-state-architecture-agent` |
| `contracts[].provider` | Yes | Side that provides/exposes the contract | Yes | `target-state-architecture-agent` (Provider Service column) |
| `contracts[].consumer` | Yes | Side that consumes the contract | Yes | `target-state-architecture-agent` (Consumer Service column) |
| `contracts[].protocol` | Yes | Enum: `HTTP/REST`, `JDBC`, `MessageQueue`, `FileIO`, `gRPC`, `etc` | Yes | `target-state-architecture-agent` (Protocol column) |
| `contracts[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Yes | `extraction-quality-agent` (confidence-vocabulary checks) |
| `contracts[].evidenceFile` | Yes | File supporting the contract's identification | Yes | `extraction-quality-agent` (evidence-traceability checks) |
| `endpoints` | No | Per-route rows (`resource`, `method`, `path`, optional `action`/`auth`/`evidenceFile`) for every HTTP route; omitted when the repo exposes none | Use on site only | `knowledge-base-publisher` → `data-integrations.js` (`restEndpointList[]`, `restEndpoints`) |
| `externalDependencies` | Yes | Third-party/external systems depended on | Yes | `extraction-quality-agent` (decoupling-design signal) |
| `contractCount` | Yes | Count of discovered contracts | Use on site only | `knowledge-base-publisher` → `data-integrations.js` |
| `contracts[].payloadFormat` | Yes | Enum: `JSON`, `XML`, `SQL`, `Binary`, `etc` | No | Not used downstream (evidence/reference only) |
| `contracts[].modernizationRelevance` | Yes | Enum: `High`, `Medium`, `Low` | Use on site only | `knowledge-base-publisher` → `data-integrations.js` |
| `modernizationCandidates` | Yes | Integrations flagged as modernization candidates | Use on site only | `knowledge-base-publisher` → `data-integrations.js` |
| `contracts[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Use on site only | `knowledge-base-publisher` → `data-integrations.js` (AI badge) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-ui-ux-summary.v1`

**Producer:** [`ui-ux-discovery-agent`](../agents/knowledge-extraction/ui-ux-discovery-agent.md) · **Schema:** `.claude/contract/schemas/extraction-ui-ux-summary.v1.schema.json`

Screen inventory, navigation, and shared UI patterns across every client target.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `frontendParadigm` | Yes | UI paradigm (e.g. server-rendered views, SPA) | Yes | `target-state-architecture-agent` (target frontend/migration strategy) |
| `clientTargets` | Yes | Distinct client targets shipped (e.g. desktop, web, handheld) | Yes | `extraction-quality-agent` (device-target matrix check), `target-state-architecture-agent` (multi-target frontend scoping) |
| `domains` | Yes | Screens grouped by business domain | Yes | `knowledge-graph-curator`, `extraction-quality-agent` (screen-inventory completeness check), `target-state-architecture-agent` (`frontendCapabilities[]` derivation), `demo-flow-describer` (screen source for demo scenarios) |
| `domains[].name` | Yes | Domain name | Yes | `demo-flow-describer` (matches demo flow domains to UI domain groupings) |
| `domains[].screens` | Yes | Screens belonging to the domain | Yes | `target-state-architecture-agent` (`frontendCapabilities[]` derivation), `demo-flow-describer` (screen callouts in demo scenarios) |
| `domains[].screens[].name` | Yes | Screen name | Yes | `target-state-architecture-agent` (`screenOrRouteGroup`), `demo-flow-describer` |
| `domains[].screens[].sourceFile` | Yes | Source file implementing the screen | Yes | `target-state-architecture-agent` (`sourceModule` traceability) |
| `domains[].screens[].purpose` | Yes | What the screen is for | Yes | `demo-flow-describer` (scenario descriptions) |
| `domains[].screens[].clientTargets` | Yes | Which client targets this screen exists on | Yes | `extraction-quality-agent` (device-target matrix check) |
| `domains[].screens[].keyInteractions` | Yes | Key user interactions on the screen | Yes | `extraction-quality-agent` (UI-to-backend linkage check), `demo-flow-describer` (interaction steps) |
| `domains[].screens[].backendModules` | Yes | Backend modules the screen calls | Yes | `extraction-quality-agent` (UI-to-backend linkage check), `target-state-architecture-agent` (source-module → target-service mapping) |
| `navigationEntryPoints` | Yes | Top-level navigation entry points | Yes | `extraction-quality-agent` (navigation-flow diagram check), `target-state-architecture-agent` (target route-table structure) |
| `sharedPatterns` | Yes | UI patterns reused across screens | Yes | `extraction-quality-agent` (styling/layout pattern inventory check) |
| `thirdPartyControls` | Yes | Third-party UI controls/libraries used | Yes | `extraction-quality-agent` (styling/layout pattern inventory check) |
| `stylingApproach` | Yes | How styling is implemented (e.g. CSS framework, inline styles) | Yes | `extraction-quality-agent` (styling/layout pattern inventory check) |
| `totalScreens` | Yes | Count of discovered screens | Use on site only | `knowledge-base-publisher` → `data-ui.js` |
| `totalInteractions` | Yes | Count of discovered user interactions | Use on site only | `knowledge-base-publisher` → `data-ui.js` |
| `domains[].screenCount` | Yes | Number of screens in the domain | Use on site only | `knowledge-base-publisher` → `data-ui.js` |
| `domains[].screens[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-business-logic-rules-summary.v1`

**Producer:** [`business-logic-rules-agent`](../agents/knowledge-extraction/business-logic-rules-agent.md) · **Schema:** `.claude/contract/schemas/extraction-business-logic-rules-summary.v1.schema.json`

Extracted domain rules by category, plus cross-module rules and key workflows. Read by `business-intent-agent` and `risk-gap-agent` in Phase 3.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `rules[].governingSetting` | No | Optional — a config setting that governs the rule, if one exists | Yes | `business-intent-agent` (mirrored as `businessCapabilities[].governingSettings`) |
| `rules[].governingSetting.name` | Yes, if `governingSetting` present | Setting name | Yes | `business-intent-agent` |
| `rules[].governingSetting.default` | Yes, if `governingSetting` present | Default value | Yes | `business-intent-agent` |
| `rules[].governingSetting.options` | No | Allowed values for the setting | Yes | `business-intent-agent` |
| `keyWorkflows` | Yes | Key workflows the rules support | Yes | `extraction-quality-agent` (checks presence — "needed to map to target domain events") |
| `rules` | Yes | Array of individual extracted rules | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `totalRules` | Yes | Total number of extracted rules | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `rulesByCategory` | Yes | Rule counts per category | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `rulesByCategory.Validation` / `.Workflow` / `.Calculation` / `.Constraint` / `.Authorization` / `.StateTransition` / `.Configuration` | Yes | Number of rules in that category | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `rules[].id` | Yes | Rule identifier | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `rules[].name` | Yes | Rule name | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `rules[].type` | Yes | Enum matching the 7 categories above | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `rules[].affectedEntities` | Yes | Entities the rule affects | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `rules[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Use on site only | `knowledge-base-publisher` → `data-rules.js` |
| `crossModuleRules` | Yes | Rules that span multiple modules | No | Not used downstream (evidence/reference only) |
| `rules[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Use on site only | `knowledge-base-publisher` → `data-rules.js` (AI badge) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-security-summary.v2`

**Producer:** [`security-governance-agent`](../agents/knowledge-extraction/security-governance-agent.md) · **Schema:** `.claude/contract/schemas/extraction-security-summary.v2.schema.json`

Auth/authz mechanisms, PII handling, and governance risks by module.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `modules[].authMechanism` | Yes | Authentication mechanism used | Yes | `target-state-architecture-agent` (authn/authz model carry-forward) |
| `modules[].authzPattern` | Yes | Authorization pattern used | Yes | `target-state-architecture-agent` (authn/authz model carry-forward) |
| `modules[].piiDataTypes` | Yes | PII data types handled | Yes | `target-state-architecture-agent` (sensitive-data carry-forward) |
| `modules[].governanceRisks` | Yes | Governance risks identified in the module | Yes | `target-state-architecture-agent` (governance-risks carry-forward) |
| `modules[].governanceRisks[].description` | Yes | Risk description | Yes | `target-state-architecture-agent` |
| `modules[].governanceRisks[].severity` | Yes | Enum: `Critical`, `High`, `Medium`, `Low` | Yes | `target-state-architecture-agent` |
| `modules` | Yes | Per-module security posture | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `overallRiskLevel` | Yes | Enum: `Critical`, `High`, `Medium`, `Low` | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `modules[].name` | Yes | Module name | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `topRisks` | Yes | Top security risks across the system | No | Not used downstream (evidence/reference only) |
| `complianceGaps` | Yes | Compliance gaps identified | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `complianceGaps[].framework` | No | Named external standard/regulation, e.g. `OWASP`, `GDPR` | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `complianceGaps[].control` | No | Specific control/article within `framework` | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `complianceGaps[].description` | Yes | The gap itself | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `recommendations` | Yes | Remediation recommendations | Use on site only | `knowledge-base-publisher` → `data-security.js` |
| `modules[].governanceRisks[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Use on site only | `knowledge-base-publisher` → `data-security.js` (AI badge) |
| `complianceGaps[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-runtime-operations-summary.v1`

**Producer:** [`runtime-operations-agent`](../agents/knowledge-extraction/runtime-operations-agent.md) · **Schema:** `.claude/contract/schemas/extraction-runtime-operations-summary.v1.schema.json`

Deployment model, external runtime dependencies, scheduling, and observability.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `deploymentModel` | Yes | How the system is deployed | Yes | `target-state-architecture-agent` (deployment-model carry-forward) |
| `configurationSources` | Yes | Where runtime config comes from | Yes | `target-state-architecture-agent` (config-sources carry-forward) |
| `scheduledJobs` | Yes | Scheduled/background jobs | Yes | `target-state-architecture-agent` (scheduled-jobs carry-forward) |
| `scheduledJobs[].name` | Yes | Job name | Yes | `target-state-architecture-agent` |
| `scheduledJobs[].schedule` | Yes | Cron/schedule expression | Yes | `target-state-architecture-agent` |
| `observability` | Yes | Observability configuration | Yes | `target-state-architecture-agent` (observability carry-forward) |
| `observability.logging` | Yes | Logging setup | Yes | `target-state-architecture-agent` |
| `observability.metrics` | Yes | Metrics setup | Yes | `target-state-architecture-agent` |
| `observability.tracing` | Yes | Enum: `enabled`, `disabled` | Yes | `target-state-architecture-agent` |
| `observability.healthCheckEndpoint` | Yes | Health-check endpoint path | Yes | `target-state-architecture-agent` |
| `runtimePlatform` | Yes | Runtime platform/environment | Use on site only | `knowledge-base-publisher` → `data-runtime.js` |
| `externalServices` | Yes | External runtime dependencies | Use on site only | `knowledge-base-publisher` → `data-runtime.js` |
| `externalServices[].name` | Yes | Service name | Use on site only | `knowledge-base-publisher` → `data-runtime.js` |
| `externalServices[].type` | Yes | Enum: `Database`, `Cache`, `MessageBroker`, `ExternalAPI` | Use on site only | `knowledge-base-publisher` → `data-runtime.js` |
| `externalServices[].protocol` | Yes | Protocol used to reach the service | Use on site only | `knowledge-base-publisher` → `data-runtime.js` |
| `externalServices[].confidence` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Use on site only | `knowledge-base-publisher` → `data-runtime.js` |
| `externalServices[].evidenceFile` | Yes | File supporting the dependency's identification | Use on site only | `knowledge-base-publisher` → `data-runtime.js` |
| `runtimeProfiles` | Yes | Runtime/environment profiles (e.g. dev, prod) | No | Not used downstream (generic domain-folder read only) |
| `externalServices[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `scheduledJobs[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-business-intent-summary.v1`

**Producer:** [`business-intent-agent`](../agents/knowledge-extraction/business-intent-agent.md) · **Schema:** `.claude/contract/schemas/extraction-business-intent-summary.v1.schema.json`

Inferred business purpose, domains, and configurable capabilities. Consumes `business-logic-rules-agent`'s Phase-2 output.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `domains` | Yes | Business domains identified | Yes | `capability-split-agent` (primary capability/domain grouping input), `knowledge-graph-curator`, `extraction-quality-agent` (CHECK-06 domain-capability-list signal) |
| `domains[].name` | Yes | Domain name | Yes | `capability-split-agent` — Domain Mapping field |
| `domains[].entities` | Yes | Entity names in the domain | Yes | `knowledge-graph-curator` (candidate graph entities), `extraction-quality-agent` (CHECK-05 cross-file entity consistency) |
| `domains[].keyBusinessRules` | Yes | Key business rules for the domain | Yes | `capability-split-agent` — Key Business Rules bullets |
| `businessCapabilities` | Yes | Business capabilities identified | Yes | `extraction-quality-agent` (CHECK-02 non-empty/placeholder check only) |
| `userPersonas` | Yes | User persona names/descriptions | Yes | `capability-split-agent` — Stakeholders field; `business-capability-brd-agent` (generic knowledge-base read, no named-field citation) |
| `primaryBusinessIntent` | Yes | One-line statement of the system's core business purpose | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `industry` | Yes | Industry/sector | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `businessCapabilities[].name` | Yes | Capability name | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `businessCapabilities[].type` | Yes | Enum: `CRUD`, `Workflow`, `Reporting`, `Integration`, `Admin` | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `businessCapabilities[].configurable` | Yes | Whether the capability's behavior is configurable | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `businessCapabilities[].governingSettings` | Yes | Settings that govern this capability | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `businessCapabilities[].confidence` | Yes | Enum: `High`, `Medium`, `Low` | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `assumptions` | Yes | Assumptions made during inference | Use on site only | `knowledge-base-publisher` → `data-business-intent.js` |
| `businessCapabilities[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-risk-gap-summary.v1`

**Producer:** [`risk-gap-agent`](../agents/knowledge-extraction/risk-gap-agent.md) · **Schema:** `.claude/contract/schemas/extraction-risk-gap-summary.v1.schema.json`

Consolidated risk register with severity counts, quick wins, and strategic initiatives. Consumes `business-logic-rules-agent`'s Phase-2 output.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `risks` | Yes | Array of individual risks | Yes | `capability-split-agent` (CRITICAL findings drive wave priority), `business-capability-brd-agent` (BRD §10), `target-state-architecture-agent` (governance.md §10), `knowledge-graph-curator`, `extraction-quality-agent` (CHECK-06) |
| `risks[].title` | Yes | Risk title | Yes | `business-capability-brd-agent` (BRD §10 bullet titles); `target-state-architecture-agent` (governance.md §10 "Risk" column) |
| `risks[].impact` | Yes | Enum: `High`, `Medium`, `Low` | Yes | `capability-split-agent` (CRITICAL findings raise wave priority); `target-state-architecture-agent` (governance.md §10 "Impact" column) |
| `risks[].likelihood` | Yes | Enum: `High`, `Medium`, `Low` | Yes | `target-state-architecture-agent` (governance.md §10 "Likelihood" column) |
| `risks[].affectedModules` | Yes | Module names affected | Yes | `capability-split-agent` — filters Key Risks bullets per capability/wave |
| `totalRisks` | Yes | Total number of risks identified | Use on site only | `knowledge-base-publisher` → `data-risks.js` |
| `criticalCount` | Yes | Count of critical-impact risks | Use on site only | `knowledge-base-publisher` → `data-overview.js`, `data-risks.js` |
| `highCount` | Yes | Count of high-impact risks | Use on site only | `knowledge-base-publisher` → `data-overview.js`, `data-risks.js` |
| `mediumCount` | Yes | Count of medium-impact risks | Use on site only | `knowledge-base-publisher` → `data-overview.js`, `data-risks.js` |
| `risks[].id` | Yes | Risk identifier | Use on site only | `knowledge-base-publisher` → `data-risks.js` |
| `risks[].score` | Yes | Computed risk score | Use on site only | `knowledge-base-publisher` → `data-risks.js` |
| `risks[].category` | Yes | Enum: `architectural`, `technicalDebt`, `dependency`, `operational`, `security`, `performance`, `maintainability`, `ai` (from `extraction/ai/summary.json` `aiRisks[]`) | Use on site only | `knowledge-base-publisher` → `data-risks.js` |
| `quickWins` | Yes | Low-effort/high-value remediation ideas | Use on site only | `knowledge-base-publisher` → `data-overview.js`, `data-risks.js` |
| `strategicInitiatives` | Yes | Larger strategic remediation initiatives | Use on site only | `knowledge-base-publisher` → `data-overview.js` |
| `risks[].aiRef` | No | Optional AI cross-reference id (`ai:<kind>:<slug>`) into `extraction/ai/summary.json` | Yes | `knowledge-graph-curator` (AI edges), `extraction-quality-agent` (CHECK-12) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-knowledge-graph-summary.v1`

**Producer:** [`knowledge-graph-curator`](../agents/knowledge-extraction/knowledge-graph-curator.md) · **Schema:** `.claude/contract/schemas/extraction-knowledge-graph-summary.v1.schema.json`

Synthesized cross-agent entity/relationship graph with confidence distribution and unresolved gaps.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `entityCount` | Yes | Total entities in the graph | Yes | `extraction-quality-agent` — CHECK-10 requires `> 0` |
| `relationshipCount` | Yes | Total relationships in the graph | Yes | `extraction-quality-agent` — CHECK-10 requires `> 0` |
| `confidenceDistribution` | Yes | Counts of relationships by confidence tier | Yes | `extraction-quality-agent` — CHECK-10 reads `.high` |
| `confidenceDistribution.high` | Yes | Count of high-confidence relationships | Yes | `extraction-quality-agent` — CHECK-10 requires `> 0` |
| `keyEntities` | Yes | The most significant entities in the graph | Yes | `extraction-quality-agent` (CHECK-10 traceability cross-check); `business-capability-brd-agent` (wholesale summary.json read, no specific field cited) |
| `keyRelationships` | Yes | The most significant relationships in the graph | Yes | `extraction-quality-agent` (CHECK-10 traceability cross-check); `business-capability-brd-agent` (wholesale read) |
| `unresolvedGaps` | Yes | Gaps the curator could not resolve | Yes | `extraction-quality-agent` — CHECK-10 requires the field to exist (even if empty) |
| `confidenceDistribution.medium` | Yes | Count of medium-confidence relationships | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `confidenceDistribution.low` | Yes | Count of low-confidence relationships | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `keyEntities[].name` | Yes | Entity name | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `keyEntities[].type` | Yes | Entity type | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `keyEntities[].role` | Yes | Entity's role in the system | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `keyRelationships[].source` | Yes | Source entity | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `keyRelationships[].relationshipType` | Yes | Relationship type/label | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `keyRelationships[].target` | Yes | Target entity | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `keyRelationships[].confidence` | Yes | Enum: `high`, `medium`, `low` | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `architecturalInsights` | Yes | Synthesized architectural insights | Use on site only | `knowledge-base-publisher` → `data-knowledge-graph.js` |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-quality-summary.v1`

**Producer:** [`extraction-quality-agent`](../agents/knowledge-extraction/extraction-quality-agent.md) · **Schema:** `.claude/contract/schemas/extraction-quality-summary.v1.schema.json`

Quality gate report for the whole extraction phase — per-folder scores plus modernization-readiness signal gaps. Read by `/knowledge-extraction` and `/fix-knowledge-extraction`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `overallScore` | Yes | Overall extraction quality score | Yes | `/knowledge-extraction` — printed in the final "Quality Score: X / Grade: Y" line |
| `grade` | Yes | Enum: `A`, `B`, `C`, `D`, `F` | Yes | `/knowledge-extraction` — printed in the final "Quality Score: X / Grade: Y" line |
| `criticalCount` | Yes | Count of critical findings | Yes | `/fix-knowledge-extraction` — Step 1 exits early if `0` and `warningCount` is also `0` |
| `warningCount` | Yes | Count of warning findings | Yes | `/fix-knowledge-extraction` — same early-exit gate as `criticalCount` |
| `folderScores` | Yes | Object keyed by extraction folder name (e.g. `"repository"`); each value is that folder's score breakdown | Yes | `/fix-knowledge-extraction` — extracted in Step 1 |
| `folderScores.<folder>.score` | Yes | Folder's quality score | Yes | `/fix-knowledge-extraction` — Step 1 |
| `folderScores.<folder>.grade` | Yes | Folder's letter grade | Yes | `/fix-knowledge-extraction` — Step 1 |
| `folderScores.<folder>.critical` | Yes | Critical findings in the folder | Yes | `/fix-knowledge-extraction` — Step 1 |
| `folderScores.<folder>.warnings` | Yes | Warning findings in the folder | Yes | `/fix-knowledge-extraction` — Step 1 |
| `folderScores.<folder>.coverage` | No | Fraction (0–1) of the folder's source-side inventory actually cataloged, when measurable; `null` when not measured. The folder score is capped at `round(100 × coverage)` | Yes | `/fix-knowledge-extraction` — a low coverage is a re-run signal |
| `folderScores.<folder>.coverageStatus` | No | Enum: `measured`, `not-measured`. `not-measured` means the score reflects structure only and does not show the folder is complete | Yes | `/fix-knowledge-extraction` — Step 1 |
| `totalChecks` | Yes | Total number of checks run | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js`, `data-overview.js` |
| `infoCount` | Yes | Count of informational findings | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js` |
| `modernizationReadiness` | Yes | Assessment of what's ready vs. missing for downstream modernization steps | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js`, `data-overview.js` |
| `modernizationReadiness.wellDocumented` | Yes | Areas that are well covered | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js` |
| `modernizationReadiness.missingSignals` | Yes | Signals missing from the extraction | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js`, `data-overview.js` |
| `modernizationReadiness.missingSignals[].signal` | Yes | The missing signal | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js`, `data-overview.js` |
| `modernizationReadiness.missingSignals[].blockedDownstreamStep` | Yes | Downstream step this gap would block | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js`, `data-overview.js` |
| `modernizationReadiness.missingSignals[].suggestedInvestigation` | Yes | Suggested way to close the gap | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js`, `data-overview.js` |
| `topImprovements` | Yes | Prioritized list of recommended improvements | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js` |
| `topImprovements[].priority` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js` |
| `topImprovements[].action` | Yes | The recommended action | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js` |
| `topImprovements[].affectedFolders` | Yes | Extraction folders the action would improve | Use on site only | `knowledge-base-publisher` → `data-extraction-quality.js` |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-completeness-summary.v1`

**Producer:** [`completeness-report-agent`](../agents/knowledge-extraction/completeness-report-agent.md) · **Schema:** `.claude/contract/schemas/extraction-completeness-summary.v1.schema.json`

Scores the extraction corpus against deterministic code facts from a source-code-only `graphify` knowledge
graph, rather than the corpus's own internal consistency (that's `extraction-quality-summary.v1`'s job).
Optional stage — read by `/fix-knowledge-extraction` (if present) and `knowledge-base-publisher`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `overallScore` | Yes | Weighted-average completeness score, 0–100, over `scored` folders only. A placeholder `0` when `overallStatus` is `not-scored` — read `overallStatus` first | Yes | `/completeness-report` — printed in the final summary; `/fix-knowledge-extraction` — read if the stage's output exists |
| `generatedAt` | No | Date the report was generated | No | Not used downstream (evidence/reference only) |
| `graphSource` | No | Provenance of the graph the report was scored against | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `graphSource.tool` | No | Always `"graphify"` | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `graphSource.graphPath` | No | Path to the graph file, always `graphify-out/graph.json` | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `graphSource.nodeCount` | No | Node count in the scored graph | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `graphSource.edgeCount` | No | Edge count in the scored graph | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `graphSource.builtAtCommit` | No | Commit SHA the graph was built against | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `graphSource.scannedRoots` | No | `sourceLayout.sourceRoots` entries the graph was scoped to | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `graphSource.excludedPatterns` | No | The `--exclude` list the `graphify-source-graph` skill passed to `graphify extract` | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `accuracyOnlyAverage` | No | Mean `accuracyScore` over folders with `status` `accuracy-only`; reported beside `overallScore`, never blended into it. Omitted when no folder is accuracy-only | No | Not used downstream (evidence/reference only) |
| `domainScores` | Yes | Object keyed by extraction folder name (e.g. `"repository"`); each value is that folder's score breakdown | Yes | `/fix-knowledge-extraction` — read for folder-level triage when present |
| `domainScores.<folder>.score` | Yes | Combined domain score (`0.65 × accuracy + 0.35 × coverage`) | Yes | `/fix-knowledge-extraction` |
| `domainScores.<folder>.accuracyScore` | Yes | Pass A ratio-based accuracy score | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `domainScores.<folder>.coverageScore` | Yes | Pass B ratio-based coverage score | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `domainScores.<folder>.totalClaimsChecked` | Yes | Total verifiable claims checked in this domain | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `domainScores.<folder>.totallyWrong` | Yes | Count of `TOTALLY_WRONG` claims | Yes | `/fix-knowledge-extraction` — routed to DIRECT-EDIT |
| `domainScores.<folder>.inaccurate` | Yes | Count of `INACCURATE` claims | Yes | `/fix-knowledge-extraction` — routed to DIRECT-EDIT |
| `domainScores.<folder>.unsupportedStatements` | Yes | Count of `UNSUPPORTED` claims | Yes | `/fix-knowledge-extraction` — routed to AGENT-RERUN |
| `domainScores.<folder>.humanReviewItems` | Yes | Count of `HUMAN-REVIEW` claims | Yes | `/fix-knowledge-extraction` — listed, never auto-fixed |
| `domainScores.<folder>.missingItems` | Yes | Count of graph entities missing from this domain's extraction | Yes | `/fix-knowledge-extraction` — routed to AGENT-RERUN |
| `domainScores.<folder>.graphEntitiesForDomain` | No | Graph entity count mapped to this domain — the `coverageScore` denominator | No | Not used downstream (makes the score auditable) |
| `domainScores.<folder>.weight` | No | Domain weight applied to `overallScore` | No | Not used downstream (evidence/reference only) |
| `domainScores.<folder>.status` | No | Enum: `scored`, `accuracy-only`, `not-scored`, `insufficient-sample`. `not-scored` (0 claims checked) and `insufficient-sample` (fewer than `min(10, claims available)` checked) folders have placeholder `0` score fields; `accuracy-only` (claims verified, no graph entities to measure coverage) has a real `accuracyScore` and placeholder `0` for `score`/`coverageScore`. None of the three enters `overallScore`. Omitted means `scored` | Yes | `/fix-knowledge-extraction` — read before treating a folder's numbers as scores |
| `domainScores.<folder>.describedCount` | No | Entities for the domain that are described (named in prose, or in a table row specific to them; for `ai/`, cited by `ai/summary.json` evidence) | No | Not used downstream (makes `coverageScore` auditable) |
| `domainScores.<folder>.mentionOnlyCount` | No | Entities that appear only as a bare mention or in a boilerplate repeated-role table/list row; counted as not covered, but not as missing | No | Not used downstream (makes `coverageScore` auditable) |
| `totals` | Yes | Sum of the per-domain counts above | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `totals.totalClaimsChecked` | Yes | Total claims checked across all domains | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `totals.totallyWrong` | Yes | Total `TOTALLY_WRONG` count | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `totals.inaccurate` | Yes | Total `INACCURATE` count | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `totals.unsupportedStatements` | Yes | Total `UNSUPPORTED` count | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `totals.humanReviewItems` | Yes | Total `HUMAN-REVIEW` count | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `totals.missingItems` | Yes | Total missing-item count | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `actionPlan` | Yes | Prioritised list of fixes | Yes | `/completeness-report` — printed as "Top action items" |
| `actionPlan[].priority` | Yes | Enum: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW` | Yes | `/completeness-report` |
| `actionPlan[].folder` | Yes | Affected extraction folder | Yes | `/completeness-report` |
| `actionPlan[].description` | Yes | The recommended fix | Yes | `/completeness-report` |
| `wrongStatementsByDomain` | No | Per-domain wrong/inaccurate/unsupported/review findings | Yes | `/fix-knowledge-extraction` — triaged by `type` |
| `wrongStatementsByDomain[].folder` | Yes | Extraction folder | Yes | `/fix-knowledge-extraction` |
| `wrongStatementsByDomain[].items[].claim` | Yes | The claim text | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `wrongStatementsByDomain[].items[].type` | Yes | Enum: `TOTALLY_WRONG`, `INACCURATE`, `UNSUPPORTED`, `HUMAN-REVIEW` | Yes | `/fix-knowledge-extraction` — selects fix strategy |
| `wrongStatementsByDomain[].items[].correctValue` | Yes | The actual value found, or a `"— (does not exist)"` / `"— (unknown)"` sentinel | Yes | `/fix-knowledge-extraction` — DIRECT-EDIT replacement text |
| `wrongStatementsByDomain[].items[].evidence` | Yes | How the claim was verified/refuted | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `wrongStatementsByDomain[].items[].location` | Yes | Where the claim appears in the extraction | Yes | `/fix-knowledge-extraction` — DIRECT-EDIT target |
| `missingItemsByDomain` | No | Per-domain entities the graph found but extraction missed | Yes | `/fix-knowledge-extraction` — routed to AGENT-RERUN |
| `missingItemsByDomain[].folder` | Yes | Extraction folder | Yes | `/fix-knowledge-extraction` |
| `missingItemsByDomain[].items[].name` | Yes | Entity name | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `missingItemsByDomain[].items[].entityType` | Yes | Entity type (class, table, endpoint, etc.) | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `missingItemsByDomain[].items[].sourceLocation` | No | Source file/location | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `missingItemsByDomain[].items[].relationshipCount` | No | Graph degree — connectivity signal | Use on site only | `knowledge-base-publisher` → `data-completeness.js` |
| `missingItemsByDomain[].items[].importance` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Yes | `/fix-knowledge-extraction` — prioritises AGENT-RERUN order |
| `missingItemsByDomain[].items[].targetFolder` | Yes | Which extraction folder should cover this entity | Yes | `/fix-knowledge-extraction` — selects the owning agent to re-run |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `extraction-ai-summary.v1`

**Producer:** [`ai-discovery-agent`](../agents/knowledge-extraction/ai-discovery-agent.md) · **Schema:** `.claude/contract/schemas/extraction-ai-summary.v1.schema.json`

The AI layer of the system: providers, models, frameworks, agents, flows, tools, MCP servers, prompts, RAG pipelines, evaluation, guardrails, observability and the developer engineering harness, each an id-bearing item (`ai:<kind>:<slug>`) with `evidence` (`file:line` references) and `confidence`. Always written; `present: false` with empty arrays when no AI is detected. Required top-level keys: `present`, `scope`, the fifteen item arrays, `crossRefs`, `aiRisks`, `modernizationCandidates` and `_contract`. Only the optional **depth** properties are listed below; they are reconciled against `extraction/ai/sweep.json` (the deterministic output of `ai-sweep.py`) by `check-ai-output.py`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `flows[].steps` | No | Ordered step-level walk-through of a flow: what each component does, with which prompt and model, limits and failure handling | Possible | `check-ai-output.py` (`FLOW_STEPS_MISSING`) |
| `flows[].steps[].order` | Yes | 1-based position of the step | Possible | `check-ai-output.py` |
| `flows[].steps[].component` | Yes | Class or function that performs the step | Possible | `check-ai-output.py` |
| `flows[].steps[].action` | Yes | What the step does | Possible | `check-ai-output.py` |
| `flows[].steps[].evidence` | Yes | `file:line` references | Possible | `check-ai-output.py` |
| `flows[].steps[].promptRef` / `modelRef` | No | `ai:` ids of the prompt and model used by the step | Possible | `extraction-quality-agent` (CHECK-12) |
| `flows[].steps[].input` / `output` | No | What the step consumes and produces | No | Not used downstream (evidence only) |
| `flows[].steps[].limits` / `failureHandling` | No | Limits (timeouts, retries, caps) and what happens on failure | No | Not used downstream (evidence only) |
| `ragPipelines[].stages` | No | Stage-by-stage breakdown of the pipeline | Possible | `check-ai-output.py` (`RAG_STAGES_MISSING`, `UNDETERMINED_WITHOUT_SEARCH`) |
| `ragPipelines[].stages[].stage` | Yes | Enum: `ingestion`, `parsing`, `chunking`, `tokenization`, `embedding`, `indexing`, `query-planning`, `retrieval`, `fusion`, `expansion`, `rerank`, `filtering`, `context-assembly`, `generation`, `validation`, `citation`, `other` | Possible | `check-ai-output.py` |
| `ragPipelines[].stages[].implementation` | Yes | Class or function that implements the stage | Possible | `check-ai-output.py` |
| `ragPipelines[].stages[].parameters` | No | Real constants of the stage (similarity metric, k, topK, dimensions, tokenizer, overlap, fusion constant, rerank pool size). `null` means undetermined, never guessed | Possible | `check-ai-output.py` |
| `ragPipelines[].stages[].searched` | No | Places searched when a parameter is `null`; required in practice for every `null` | Possible | `check-ai-output.py` (`UNDETERMINED_WITHOUT_SEARCH`) |
| `ragPipelines[].stages[].evidence` | Yes | `file:line` references | Possible | `check-ai-output.py` |
| `configKeys` | No | Configuration keys that change AI behaviour | Possible | `check-ai-output.py` (`CONFIG_KEYS_MISSING`) |
| `configKeys[].key` | Yes | The configuration key | Possible | `check-ai-output.py` |
| `configKeys[].default` | No | Default value | No | Not used downstream (evidence only) |
| `configKeys[].scope` | Yes | Enum: `startup`, `runtime`, `profile`, `env` | No | Not used downstream (evidence only) |
| `configKeys[].affects` | Yes | What the key changes | No | Not used downstream (evidence only) |
| `configKeys[].profiles` | No | Object mapping profile name to value, for per-profile defaults | No | Not used downstream (evidence only) |
| `configKeys[].evidence` | Yes | `file:line` references | Possible | `check-ai-output.py` |
| `docFindings` | No | In-repo documentation claims about the AI parts, each checked against code | Possible | `extraction-quality-agent` (CHECK-14, `DOC_ONLY_CONFIRMED`) |
| `docFindings[].doc` | Yes | Path of the documentation file | Possible | `extraction-quality-agent` |
| `docFindings[].claim` | Yes | The claim the documentation makes | Possible | `extraction-quality-agent` |
| `docFindings[].verdict` | Yes | Enum: `confirmed`, `contradicted`, `unverified` | Possible | `extraction-quality-agent` |
| `docFindings[].codeEvidence` | No | `file:line` references in code that confirm or contradict the claim | Possible | `check-ai-output.py` (`DOC_ONLY_CONFIRMED`) |
| `docFindings[].note` | No | Free-text note | No | Not used downstream (evidence only) |
| `coverage` | No | Reconciliation of the deterministic sweep against the files the summary cites | Yes | `extraction-quality-agent` (CHECK-13), `check-ai-output.py` (`COVERAGE_MISMATCH`) |
| `coverage.sweepFile` | No | Path of the sweep file, default `knowledge-base/extraction/ai/sweep.json` | Possible | `check-ai-output.py` |
| `coverage.sweepFiles` | No | Number of distinct non-test files in the sweep's code classes | Yes | `check-ai-output.py` |
| `coverage.citedFiles` | No | How many of those files the summary cites in `evidence` | Yes | `check-ai-output.py` |
| `coverage.uncataloged` | No | Array of `{path, reason}` for sweep files deliberately not cataloged | Possible | `check-ai-output.py` (`UNCOVERED_FILES`) |

---

## `ai-cluster-partial.v1`

**Producer:** [`ai-cluster-tracer-agent`](../agents/knowledge-extraction/ai-cluster-tracer-agent.md) · **Schema:** `.claude/contract/schemas/ai-cluster-partial.v1.schema.json`

One entry-point cluster's slice of the AI layer, written to `extraction/ai/clusters/<cluster>/partial.json` during Phase 2b of the extraction stage. Phase-graph node `ai-cluster-trace` (`bespokeReconcile`, `coverageOptional`, `schema: null`): this is **not** a phase-graph schema target — it is validated by `ai-merge-clusters.py`, which is the per-cluster check, and the merged result is consumed by `ai-discovery-agent`. Flow, RAG, prompt and configuration items mirror the inline item shapes of [`extraction-ai-summary.v1`](#extraction-ai-summaryv1) (with no extra properties allowed) so an item is copied into `ai/summary.json` unchanged. Item ids are `ai:<kind>:<slug>`. Top-level `additionalProperties` is `false`, and so is every item shape except the `unresolved[]` entries. Required top-level keys: `cluster`, `flows`, `ragPipelines`, `prompts`, `configKeys`, `unresolved`, `filesRead` and `_contract`. **What is enforced:** `schema_validator.py` checks types, required keys, enums and `additionalProperties`, but not `pattern` or `maxLength` (the schema's own `$comment` says so), so the `ai:<kind>:<slug>` id format and the 300-character excerpt cap are the tracer's responsibility (checked by its final checklist and by `test_ai_cluster_schema.py`), not by the merge script.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `cluster` | Yes | The cluster name from `clusters/manifest.json`; must equal the file's directory name | Yes | `ai-merge-clusters.py` |
| `flows` | Yes | AI flows traced from this cluster's entry point (may be empty) | Yes | `ai-merge-clusters.py` → `ai-discovery-agent` |
| `flows[].id` / `name` | Yes | Item id (`ai:flow:<slug>`) and display name | Yes | `ai-merge-clusters.py` (duplicate ids across clusters are reported as conflicts) |
| `flows[].pattern` | Yes | Enum: `sequential`, `graph`, `supervisor`, `swarm`, `handoff`, `router`, `loop`, `other` | Possible | `ai-discovery-agent` |
| `flows[].nodes` | Yes | Array of `{id, label, agentId?}` | Possible | `ai-discovery-agent` |
| `flows[].edges` | Yes | Array of `{from, to, condition?}` | Possible | `ai-discovery-agent` |
| `flows[].steps` | Yes | Ordered walk-through: `order`, `component`, `action`, `evidence` required; `promptRef`, `modelRef`, `input`, `output`, `limits`, `failureHandling` optional | Yes | `check-ai-output.py` (after consolidation into `ai/summary.json`) |
| `flows[].entry` / `exits` / `stateSchema` / `mermaid` / `scope` | No | Entry node, exit nodes, state type, diagram source, and `product`/`engineering` scope | Possible | `ai-discovery-agent` |
| `flows[].evidence` | Yes | `file:line` references, each from an actual read | Yes | `check-ai-output.py` (coverage) |
| `flows[].confidence` | Yes | Enum: `confirmed`, `inferred` | Possible | `ai-discovery-agent` |
| `ragPipelines` | Yes | Retrieval and ingestion pipelines (may be empty) | Yes | `ai-merge-clusters.py` → `ai-discovery-agent` |
| `ragPipelines[].id` / `name` | Yes | Item id (`ai:rag:<slug>`) and display name | Yes | `ai-merge-clusters.py` (duplicate ids across clusters are reported as conflicts) |
| `ragPipelines[].evidence` | Yes | `file:line` references, each from an actual read | Yes | `check-ai-output.py` (coverage, after consolidation) |
| `ragPipelines[].confidence` | Yes | Enum: `confirmed`, `inferred` | Possible | `ai-discovery-agent` |
| `ragPipelines[].stages` | Yes | Stage-by-stage breakdown; each stage needs `stage` (same enum as `extraction-ai-summary.v1`), `implementation` and `evidence`; `parameters` holds the real constants (`null` means undetermined) and `searched` where they were looked for | Yes | `check-ai-output.py` (after consolidation) |
| `ragPipelines[].sources` / `loaders` / `chunking` / `embeddingModelId` / `vectorStore` / `retriever` / `reranker` / `generationModelId` / `ingestionTrigger` | No | Pipeline-level facts, same shapes as `extraction-ai-summary.v1` | Possible | `ai-discovery-agent` |
| `prompts` | Yes | Prompts used by this cluster's flows (may be empty) | Yes | `ai-merge-clusters.py` → `ai-discovery-agent` |
| `prompts[].id` / `name` | Yes | Item id (`ai:prompt:<slug>`) and display name | Yes | `ai-merge-clusters.py` (duplicate ids across clusters are reported as conflicts) |
| `prompts[].evidence` | Yes | `file:line` references, each from an actual read | Yes | `check-ai-output.py` (coverage, after consolidation) |
| `prompts[].confidence` | Yes | Enum: `confirmed`, `inferred` | Possible | `ai-discovery-agent` |
| `prompts[].kind` | Yes | Enum: `system`, `user-template`, `few-shot`, `other` | Possible | `ai-discovery-agent` |
| `prompts[].location` | Yes | Enum: `file`, `inline`, `db`, `remote-registry` | Possible | `ai-discovery-agent` |
| `prompts[].excerpt` | Yes | Short excerpt; the schema declares `maxLength` 300 and the validator enforces it (300 characters in total, including a trailing `…` when cut) | Possible | `ai-discovery-agent` |
| `prompts[].embedsBusinessRules` | Yes | Whether the prompt text states business rules | Possible | `ai-discovery-agent` |
| `prompts[].sourceFile` / `sourceLine` / `templating` / `variables` / `versioning` / `usedBy` / `detailAnchor` / `scope` | No | Where the prompt lives and how it is templated, versioned and used | Possible | `ai-discovery-agent` |
| `configKeys` | Yes | Configuration keys that change AI behaviour in this cluster (may be empty) | Yes | `ai-merge-clusters.py` → `ai-discovery-agent` |
| `configKeys[].key` | Yes | The configuration key | Possible | `check-ai-output.py` (after consolidation) |
| `configKeys[].scope` | Yes | Enum: `startup`, `runtime`, `profile`, `env` | No | Not used downstream (evidence only) |
| `configKeys[].affects` | Yes | What the key changes | No | Not used downstream (evidence only) |
| `configKeys[].default` / `profiles` | No | Default value (string, number, boolean or `null`); `profiles` maps a profile name to a value of the same types | No | Not used downstream (evidence only) |
| `configKeys[].evidence` | Yes | `file:line` references | Possible | `check-ai-output.py` (after consolidation) |
| `unresolved` | Yes | Seeds or chain links the tracer could not resolve, or hits that are not AI code. Each entry is `{path, line?, reason}` | Yes | `ai-discovery-agent` (becomes `coverage.uncataloged` or a follow-up trace) |
| `filesRead` | Yes | Repo-relative paths the tracer actually read | Possible | `ai-merge-clusters.py` (carried into `merged.json` as context; not used as citation) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `capability-index-summary.v1`

**Producer:** [`capability-split-agent`](../agents/capability-split-agent.md) · **Schema:** `.claude/contract/schemas/capability-index-summary.v1.schema.json`

The capability→wave map (`capabilities/summary.json`) — distinct from the per-capability BRD summary below.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `waves` | Yes | Array of waves | Yes | `target-state-architecture-agent` — reads full wave array in Discovery step 4 |
| `waves[].wave` | Yes | Wave number | Yes | `target-state-architecture-agent` — groups capability mapping by wave |
| `waves[].name` | Yes | Wave name | Yes | `target-state-architecture-agent` — read with wave object |
| `waves[].capabilities` | Yes | Capabilities assigned to the wave | Yes | `target-state-architecture-agent` — reads full capability array |
| `waves[].capabilities[].name` | Yes | Capability name | Yes | `target-state-architecture-agent` — capability-mapping table rows |
| `waves[].capabilities[].slug` | Yes | Kebab-case identifier | Yes | `target-state-architecture-agent` (to enumerate `business-capabilities/<slug>/`); pre-digested into `epic-backlog-agent`'s brief by the command |
| `waves[].capabilities[].complexity` | Yes | Enum: `simple`, `standard`, `complex` | Yes | `target-state-architecture-agent` — explicitly named in Discovery step 4 |
| `waves[].capabilities[].modernizationPriority` | Yes | Enum: `critical`, `high`, `medium`, `low` | Yes | `target-state-architecture-agent` — explicitly named ("priorities") in Discovery step 4 |
| `waves[].capabilities[].dependsOn` | Yes | Capability slugs this capability depends on | Yes | `target-state-architecture-agent` — explicitly named ("dependencies") in Discovery step 4 |
| `waves[].capabilities[].enables` | Yes | Capability slugs this capability enables | Yes | `target-state-architecture-agent` — explicitly named ("dependencies") in Discovery step 4 |
| `outputSplit` | Yes | Whether output was split into `wave-N.md` files (index.md exceeded 500 lines) | Possible | Self-read only, by `capability-split-agent` in Review/Update Mode |
| `waves[].objective` | Yes | Wave's objective | Possible | Not confirmed as read by name in any reviewed file |
| `waves[].capabilities[].businessIntent` | Yes | Capability's business intent | Possible | Not confirmed as read downstream |
| `waves[].capabilities[].domainMapping` | Yes | Domain names the capability maps to | Use on site only | `knowledge-base-publisher` → `data-capabilities.js` |
| `waves[].capabilities[].brdStatus` | Yes | Enum: `available`, `pending` | Possible | Not confirmed in reviewed files; likely an `/export-for-alignment` gate |
| `waves[].capabilities[].brdPath` | Yes | Path to the BRD, or `null` if not yet generated | Possible | Not confirmed in reviewed files |
| `crossCapabilityDependencies` | Yes | Dependencies between capabilities in different waves | Possible | Not confirmed as read downstream (evidence/reference only) |
| `project` | Yes | Project name | No | Not used downstream (evidence/reference only) |
| `status` | Yes | Overall status of the capability split | No | Not used downstream (evidence/reference only) |
| `generatedAt` | Yes | Generation timestamp | No | Not used downstream (evidence/reference only) |
| `totalCapabilities` | Yes | Total number of capabilities identified | Use on site only | `knowledge-base-publisher` → `data-capabilities.js` |
| `totalWaves` | Yes | Total number of waves | No | Not used downstream (evidence/reference only) |
| `capabilitiesWithBRDs` | Yes | Count of capabilities that already have a BRD | No | Not used downstream (evidence/reference only) |
| `waves[].sequencingRationale` | Yes | Why this wave is sequenced where it is | No | Not used downstream (human/review-only field) |
| `waves[].exitGate` | Yes | Condition that must be met to exit the wave | No | Not used downstream (human/review-only field) |
| `waves[].capabilities[].keyRisks` | Yes | Key risks for the capability | No | Not used downstream (evidence/reference only) |
| `waves[].capabilities[].stakeholders` | Yes | Stakeholders for the capability | No | Not used downstream (evidence/reference only) |
| `crossCapabilityDependencies[].from` | Yes | Dependent capability | No | Not used downstream (evidence/reference only) |
| `crossCapabilityDependencies[].to` | Yes | Depended-on capability | No | Not used downstream (evidence/reference only) |
| `crossCapabilityDependencies[].rationale` | Yes | Why the dependency exists | No | Not used downstream (evidence/reference only) |
| `openQuestions` | Yes | Open questions raised during the split | No | Not used downstream (human/review-only field) |
| `traceability` | Yes | Pointers back to the source extraction indexes | No | Not used downstream — producer's own audit trail |
| `traceability.businessIntentIndex` | Yes | Path to the business-intent extraction doc used | No | Not used downstream (evidence/reference only) |
| `traceability.functionalIndex` | Yes | Path to the functional extraction doc used | No | Not used downstream (evidence/reference only) |
| `traceability.riskGapIndex` | Yes | Path to the risk-gap extraction doc used | No | Not used downstream (evidence/reference only) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `capability-summary.v1`

**Producer:** [`business-capability-brd-agent`](../agents/business-capability-brd-agent.md) · **Schema:** `.claude/contract/schemas/capability-summary.v1.schema.json`

Per-capability BRD summary (`business-capabilities/<slug>/capability-summary.json`) — distinct from the capability→wave index above.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `domain` | Yes | Business domain the capability belongs to | Yes | `epic-backlog-agent`, `story-intent-agent`, `knowledge-base-publisher` read directly; `brd-validator` reads the equivalent via BRD `.md`, not this JSON |
| `businessObjective` | Yes | The capability's business objective | Yes | Same as `domain` — direct read by the three agents; `brd-validator` via BRD `.md` mirror |
| `businessRules` | Yes | Business rules governing the capability | Yes | `epic-backlog-agent`, `story-intent-agent` read directly, cited by rule ID; `brd-validator` via BRD `.md` mirror |
| `identifiedGaps` | Yes | Gaps identified in the current implementation | Yes | `epic-backlog-agent`, `story-intent-agent` read directly, cited as Gap IDs; `brd-validator` via BRD `.md` mirror |
| `modernizationOpportunities` | Yes | Modernization opportunities identified | Yes | `epic-backlog-agent`, `story-intent-agent`, `knowledge-base-publisher` read directly; `target-state-architecture-agent` broad read |
| `capabilityName` | Yes | Capability name | Possible | Not confirmed as read by any reviewed consumer |
| `summary` | Yes | Short summary of the capability | Possible | Not confirmed as read by any reviewed consumer |
| `primaryEntities` | Yes | Primary entity names involved | Possible | Not confirmed as read by any reviewed consumer |
| `workflows` | Yes | Key workflows for the capability | Possible | Not confirmed as read by any reviewed consumer |
| `workflows[].name` | Yes | Workflow name | Possible | Not confirmed as read by any reviewed consumer |
| `workflows[].trigger` | Yes | What triggers the workflow | Possible | Not confirmed as read by any reviewed consumer |
| `workflows[].outcome` | Yes | The workflow's outcome | Possible | Not confirmed as read by any reviewed consumer |
| `currentStatus` | Yes | Enum: `Active`, `Deprecated`, `Partial`, `Planned` | Possible | Not confirmed as read by any reviewed consumer |
| `stakeholderRequirements` | Yes | Requirements by stakeholder | Possible | Not confirmed as read by any reviewed consumer |
| `stakeholderRequirements[].stakeholder` | Yes | Stakeholder name/role | Possible | Not confirmed as read by any reviewed consumer |
| `stakeholderRequirements[].requirement` | Yes | The stakeholder's requirement | Possible | Not confirmed as read by any reviewed consumer |
| `futureStateVision` | Yes | Vision for the capability's future state | Possible | `target-state-architecture-agent` — broad read, field not individually named |
| `relatedCapabilities` | Yes | Names of related capabilities | Possible | Not confirmed as read by any reviewed consumer |
| `kpis` | Yes | Key performance indicators | Possible | Not confirmed as read by any reviewed consumer |
| `kpis[].metric` | Yes | Metric name | Possible | Not confirmed as read by any reviewed consumer |
| `kpis[].target` | Yes | Target value | Possible | Not confirmed as read by any reviewed consumer |
| `risks` | Yes | Risks associated with the capability | Possible | Not confirmed as read by any reviewed consumer |
| `risks[].title` | Yes | Risk title | Possible | Not confirmed as read by any reviewed consumer |
| `risks[].mitigation` | Yes | Mitigation approach | Possible | Not confirmed as read by any reviewed consumer |
| `traceability` | Yes | Claims traced back to their source | No | Not used downstream — producer's own audit trail |
| `traceability[].claim` | Yes | The claim made in the BRD | No | Not used downstream (evidence/reference only) |
| `traceability[].source` | Yes | Source document/evidence for the claim | No | Not used downstream (evidence/reference only) |
| `generatedDate` | Yes | Generation date | No | Not used downstream (evidence/reference only) |
| `generatedBy` | Yes | Agent that generated the BRD | No | Not used downstream (evidence/reference only) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `brd-validation-summary.v1`

**Producer:** [`brd-validator`](../agents/brd-validator.md) · **Schema:** `.claude/contract/schemas/brd-validation-summary.v1.schema.json`

The `brd-validator`'s own internal-quality report — distinct from the same-named `validation-summary.json` written by `architecture-validator` and `backlog-validator` elsewhere in the pipeline. Read by `/fix-brd`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `portfolioScore` | Yes | Overall portfolio score | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `portfolioGrade` | Yes | Overall portfolio letter grade | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `criticalCount` | Yes | Count of critical issues across all BRDs | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `highCount` | Yes | Count of high-severity issues | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `mediumCount` | Yes | Count of medium-severity issues | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `lowCount` | Yes | Count of low-severity issues | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `dimensions` | Yes | Portfolio-level score breakdown by dimension | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `dimensions.capabilityWaveAlignment.score` / `.max` | Yes | Score/max for capability↔wave alignment | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `dimensions.documentStructureCompleteness.score` / `.max` | Yes | Score/max for document structure completeness | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `dimensions.requirementClarityMeasurability.score` / `.max` | Yes | Score/max for requirement clarity & measurability | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `dimensions.acceptanceCriteriaQuality.score` / `.max` | Yes | Score/max for acceptance criteria quality | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `dimensions.noDuplicationNoConflicts.score` / `.max` | Yes | Score/max for absence of duplication/conflicts | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `waveGaps` | Yes | Wave-coverage gaps found (each item an object or a string) | Possible | Mirrored in `validation.md`; `/fix-brd` reads that markdown, not this JSON |
| `portfolioNotes` | Yes | Portfolio-level notes (each item an object or a string) | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `brds` | Yes | Per-BRD validation results | Possible | Not confirmed re-read by `/fix-brd` (it reads `validation.md` instead) |
| `brds[].id` | Yes | BRD identifier | Possible | Not confirmed re-read by `/fix-brd`; mirrored in `validation.md` |
| `brds[].title` | Yes | BRD title | Possible | Not confirmed re-read by `/fix-brd`; mirrored in `validation.md` |
| `brds[].slug` | Yes | BRD's capability slug | Possible | Not confirmed re-read by `/fix-brd`; mirrored in `validation.md` |
| `brds[].wave` | Yes | Wave the BRD's capability belongs to | Possible | Not confirmed re-read by `/fix-brd`; mirrored in `validation.md` |
| `brds[].capability` | Yes | Capability name | Possible | Not confirmed re-read by `/fix-brd`; mirrored in `validation.md` |
| `brds[].score` | Yes | BRD's individual score | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `brds[].grade` | Yes | BRD's individual letter grade | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `brds[].alignment` | Yes | Alignment assessment with the capability map | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `brds[].scoringBreakdown` | Yes | Per-dimension numeric scores for this BRD (same 5 dimensions as above) | Possible | Human-review only — not read by `/fix-brd`'s fix logic |
| `brds[].issues` | Yes | Issues found in this BRD | Possible | Mirrored in `validation.md` (`/fix-brd`'s actual source); this JSON is mutated by `brd-validator` FIX Step 4, not read to drive fixes |
| `brds[].issues[].id` | Yes | Issue identifier | Possible | Mutated (not read) by `brd-validator` FIX Step 4 to mark issues `RESOLVED` |
| `brds[].issues[].severity` | Yes | Enum: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW` | Possible | Mirrored in `validation.md`, which drives `/fix-brd` prioritization instead |
| `brds[].issues[].category` | Yes | Issue category | Possible | Mirrored in `validation.md`, which drives `/fix-brd` instead |
| `brds[].issues[].section` | Yes | BRD section the issue is in | Possible | Mirrored in `validation.md`, which drives `/fix-brd` instead |
| `brds[].issues[].description` | Yes | Issue description | Possible | Mirrored in `validation.md`, which drives `/fix-brd` instead |
| `brds[].issues[].recommendation` | Yes | Recommended fix | Possible | Mirrored in `validation.md`, which drives `/fix-brd` instead |
| `crossBrdDuplications` | Yes | Content duplicated across multiple BRDs (each item an object or a string) | Possible | Mirrored in `validation.md`; `/fix-brd` reads that markdown, not this JSON |
| `crossBrdConflicts` | Yes | Conflicting requirements found across BRDs (each item an object or a string) | Possible | Mirrored in `validation.md`; `/fix-brd` reads that markdown, not this JSON |
| `generated` | Yes | ISO date the report was generated | No | Not used downstream (evidence/reference only) |
| `capabilityMapPresent` | Yes | Whether `capabilities/summary.json` was found and used | No | Not used downstream (evidence/reference only) |
| `totalBrds` | Yes | Total number of BRDs validated | No | Not used downstream (evidence/reference only) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `target-state-summary.v1`

**Producer:** [`target-state-architecture-agent`](../agents/target-state-architecture-agent.md) · **Schema:** `.claude/contract/schemas/target-state-summary.v1.schema.json`

The target-state architecture decision record: platform/stack choices, capability disposition, migration phases, NFRs.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `targetPlatform` | Yes | Target hosting/cloud platform | Yes | `architecture-validator` (checks populated) |
| `architectureStyle` | Yes | Target architecture style (e.g. microservices) | Yes | `architecture-validator` (checks populated) |
| `backendTechnology` | Yes | Target backend technology/stack | Yes | `architecture-validator` (checks populated); `team-estimation-agent` (Gen AI stack-fit judgment); `backlog-validator` (epic stack-contradiction check) |
| `frontendTechnology` | Yes | Target frontend technology/stack | Yes | `team-estimation-agent` (Gen AI stack-fit judgment); `backlog-validator` (epic stack-contradiction check) |
| `hostingModel` | Yes | Target hosting model | Yes | `architecture-validator` (checks populated) |
| `migrationStrategy` | Yes | Overall migration strategy | Yes | `architecture-validator` (checks populated) |
| `targetServices` | Yes | Names of target services | Yes | `architecture-validator` (checks populated); `architecture-completeness-validator` (event/message-contract reconciliation); `backlog-validator` (epic stack-contradiction check) |
| `capabilitiesMapped` | Yes | Current-state capabilities mapped to their target disposition | Yes | `architecture-validator` (checks populated); `architecture-completeness-validator` (verifies non-empty/reconciled); `epic-backlog-agent`/`/create-epic-backlog` (iterates directly) |
| `capabilitiesMapped[].capability` | Yes | Capability name | Yes | `epic-backlog-agent`; `architecture-completeness-validator` (reconciliation spot-check) |
| `capabilitiesMapped[].treatment` | Yes | Enum: `Retain`, `Refactor`, `Replace`, `Retire` | Yes | `epic-backlog-agent`; `architecture-completeness-validator` (data-ownership disposition check) |
| `capabilitiesMapped[].targetService` | Yes | Target service the capability maps to | Yes | `epic-backlog-agent`; `architecture-completeness-validator` (data-ownership check) |
| `migrationPhases` | Yes | Migration phases | Yes | `architecture-validator` (checks populated); feeds `/create-epic-backlog`'s inlined Wave Context Summary |
| `knowledgeBaseSourcesUsed` | Yes | Knowledge-base documents consulted | Yes | `architecture-validator` (checks non-empty as a traceability check) |
| `architectureDecisions` | Yes | Key architecture decisions | Yes | `architecture-validator` (verifies non-empty, IDs cross-referenced in `.md`); `architecture-completeness-validator` (verifies non-empty) |
| `architectureDecisions[].id` | Yes | Decision identifier | Yes | `architecture-validator` (cross-referenced against `governance.md` mentions) |
| `architectureDecisions[].title` | Yes | Decision title | Yes | `architecture-validator` (cross-referenced against `governance.md` mentions) |
| `frontendCapabilities` | Yes | Frontend screen/route mapping | Yes | `architecture-completeness-validator` (checks presence when Section 7.5 has real content) |
| `architectureDecisions[].decision` | Yes | The decision made | Use on site only | `knowledge-base-publisher` → `data-target-state.js` |
| `frontendCapabilities[].screenOrRouteGroup` | Yes | Screen or route group name | Possible | `architecture-completeness-validator` (presence check only, not per-field) |
| `frontendCapabilities[].sourceModule` | Yes | Source (current-state) module | Possible | Not used downstream beyond the array-presence check |
| `frontendCapabilities[].targetRoute` | Yes | Target route | Possible | Not used downstream beyond the array-presence check |
| `generatedDate` | Yes | Generation date | Use on site only | `knowledge-base-publisher` → `data-target-state.js` |
| `generatedBy` | Yes | Agent that generated the document | No | Not used downstream (evidence/reference only) |
| `integrationPattern` | Yes | Target integration pattern | Yes | `backlog-validator` (epic stack-contradiction check, HIGH); `architecture-validator` (target-stack consistency) |
| `databaseStrategy` | Yes | Target database strategy | Yes | `architecture-validator` (target-stack consistency); `architecture-completeness-validator` (cross-schema-query constraint, HIGH if MD-only) |
| `openRisks` | Yes | Open risks for the target architecture | No | Not used downstream (evidence/reference only) |
| `assumptions` | Yes | Assumptions made | Use on site only | `knowledge-base-publisher` → `data-target-state.js` |
| `outOfScope` | Yes | Items explicitly out of scope | Use on site only | `knowledge-base-publisher` → `data-target-state.js` |
| `nonFunctionalRequirements` | Yes | Non-functional requirements | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.performanceTargets` | Yes | Performance targets | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.capacityAssumptions` | Yes | Capacity assumptions | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.availability` | Yes | Availability target | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.configSecretsManagement` | Yes | Config/secrets management approach | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.backupDR` | Yes | Backup & disaster-recovery plan | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.backupDR.rpo` | Yes | Recovery Point Objective | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.backupDR.rto` | Yes | Recovery Time Objective | No | Not used downstream (evidence/reference only) |
| `nonFunctionalRequirements.backupDR.backupStrategy` | Yes | Backup strategy | No | Not used downstream (evidence/reference only) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `architecture-validation-summary.v1`

**Producer:** [`architecture-validator`](../agents/architecture-validator.md) · **Schema:** `.claude/contract/schemas/architecture-validation-summary.v1.schema.json`

Scored validation report for a target-state architecture document set. Distinct from the same-named files written by `brd-validator` and `backlog-validator`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `issues` | Yes | Individual validation issues | Possible | **Not** re-read by `architecture-validator` FIX mode — Step 1 explicitly reads `validation.md` (Markdown) for open issues, not this JSON array, despite `/validate-architecture`'s doc claiming otherwise |
| `issues[].id` | Yes | Issue identifier | Possible | Same FIX-mode note as `issues` above |
| `issues[].file` | Yes | File the issue is in | Possible | Same FIX-mode note as `issues` above |
| `issues[].line` | Yes | Line number, or `null` if not line-specific | Possible | Same FIX-mode note as `issues` above |
| `issues[].severity` | Yes | Enum: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW` | Possible | Same FIX-mode note as `issues` above |
| `issues[].dimension` | Yes | Dimension the issue belongs to | Possible | Same FIX-mode note as `issues` above |
| `issues[].description` | Yes | Issue description | Possible | Same FIX-mode note as `issues` above |
| `issues[].recommendation` | Yes | Recommended fix | Possible | Same FIX-mode note as `issues` above |
| `generated` | Yes | ISO date the report was generated | No | Not used downstream (evidence/reference only) |
| `track` | Yes | Track name, or `"flat layout"` if no track was used | No | Not used downstream (human-facing) |
| `totalScore` | Yes | Overall validation score | No | Not used downstream (human-facing) |
| `grade` | Yes | Enum: `A`, `B`, `C`, `D`, `F` | No | Not used downstream (human-facing) |
| `gradeUncapped` | Yes | Enum: `A`, `B`, `C`, `D`, `F` — grade before any capping rule is applied | No | Not used downstream (human-facing) |
| `criticalCount` | Yes | Count of critical issues | No | Not used downstream (human-facing) |
| `highCount` | Yes | Count of high-severity issues | No | Not used downstream (human-facing) |
| `mediumCount` | Yes | Count of medium-severity issues | No | Not used downstream (human-facing) |
| `lowCount` | Yes | Count of low-severity issues | No | Not used downstream (human-facing) |
| `unverifiedDimensions` | Yes | Dimension names that could not be scored | No | Not used downstream (human-facing) |
| `dimensions` | Yes | Score breakdown across 6 dimensions | No | Not used downstream (human-facing) |
| `dimensions.fileCompleteness.score` / `.max` / `.status` | Yes | File completeness dimension (`status` enum: `scored`, `unverified`) | No | Not used downstream (human-facing) |
| `dimensions.frontmatterMetadata.score` / `.max` / `.status` | Yes | Frontmatter/metadata dimension | No | Not used downstream (human-facing) |
| `dimensions.contentCompleteness.score` / `.max` / `.status` | Yes | Content completeness dimension | No | Not used downstream (human-facing) |
| `dimensions.mermaidDiagramValidity.score` / `.max` / `.status` | Yes | Mermaid diagram validity dimension | No | Not used downstream (human-facing) |
| `dimensions.crossDocumentConsistency.score` / `.max` / `.status` | Yes | Cross-document consistency dimension | No | Not used downstream (human-facing) |
| `dimensions.sourceTraceability.score` / `.max` / `.status` | Yes | Source traceability dimension | No | Not used downstream (human-facing) |
| `mermaidResults` | Yes | Per-diagram Mermaid validation results | No | Not used downstream (human-facing) |
| `mermaidResults[].file` | Yes | File containing the diagram | No | Not used downstream (human-facing) |
| `mermaidResults[].blockIndex` | Yes | Index of the Mermaid code block within the file | No | Not used downstream (human-facing) |
| `mermaidResults[].type` | Yes | Diagram type | No | Not used downstream (human-facing) |
| `mermaidResults[].syntaxValid` | Yes | Whether the Mermaid syntax is valid | No | Not used downstream (human-facing) |
| `mermaidResults[].drawioCompatible` | Yes | Whether the diagram is draw.io-compatible | No | Not used downstream (human-facing) |
| `mermaidResults[].verified` | Yes | Whether the diagram was actually verified | No | Not used downstream (human-facing) |
| `filesEvaluated` | Yes | Files included in the evaluation | No | Not used downstream (human-facing) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `completeness-validation-summary.v1`

**Producer:** [`architecture-completeness-validator`](../agents/architecture-completeness-validator.md) · **Schema:** `.claude/contract/schemas/completeness-validation-summary.v1.schema.json`

Substance/coverage check reconciling the target-state architecture against the extraction — not a manifest-tracked producer row, but written alongside `architecture-validator`'s output.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `verdict` | Yes | Enum: `READY`, `NOT-READY` | Possible | Human gate for `/create-epic-backlog` go/no-go decision, not machine-read by another agent |
| `unmappedEntities` | Yes | Extracted entities with no disposition in the architecture | Possible | **Not** re-read by `architecture-completeness-validator` FIX mode — Step 1 reads `completeness-validation.md` (Markdown) for open findings, not this JSON array |
| `unmappedEntities[].entity` | Yes | Entity name | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `unmappedEntities[].tableName` | Yes | Backing table name | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `unmappedEntities[].module` | Yes | Owning module | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `unmappedFeatures` | Yes | Extracted feature areas with no disposition in the architecture | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `unmappedFeatures[].module` | Yes | Module name | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `unmappedFeatures[].keyFeatures` | Yes | Unmapped key features in the module | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `missingExtractionFolders` | Yes | Extraction folders checked for read coverage | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `missingExtractionFolders[].folder` | Yes | Folder name | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `missingExtractionFolders[].onDisk` | Yes | Whether the folder exists on disk | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `missingExtractionFolders[].readReceipt` | Yes | Enum: `READ`, `SKIPPED`, `MISSING` | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `missingExtractionFolders[].finding` | Yes | Finding for this folder | Possible | Same "not re-read in FIX mode" note as `unmappedEntities` above |
| `backlogFitnessFindings` | Yes | Findings from the backlog-fitness check (item shape not constrained by the schema) | Possible | Not used downstream (human-facing; FIX mode reads the Markdown report instead) |
| `planGateFindings` | Yes | Findings from the plan-gate audit (item shape not constrained by the schema) | Possible | Not used downstream (human-facing; FIX mode reads the Markdown report instead) |
| `generated` | Yes | ISO date the report was generated | No | Not used downstream (human-facing) |
| `track` | Yes | Track name | No | Not used downstream (human-facing) |
| `score` | Yes | Overall completeness score | No | Not used downstream (human-facing) |
| `grade` | Yes | Letter grade | No | Not used downstream (human-facing) |
| `dimensions` | Yes | Score breakdown across 5 dimensions | No | Not used downstream (human-facing) |
| `dimensions.entityCoverageReconciliation.score` / `.max` | Yes | Entity coverage reconciliation dimension | No | Not used downstream (human-facing) |
| `dimensions.featureAreaCoverageReconciliation.score` / `.max` | Yes | Feature-area coverage reconciliation dimension | No | Not used downstream (human-facing) |
| `dimensions.upstreamExtractionCompletenessGate.score` / `.max` | Yes | Upstream extraction completeness gate dimension | No | Not used downstream (human-facing) |
| `dimensions.backlogFitness.score` / `.max` | Yes | Backlog fitness dimension | No | Not used downstream (human-facing) |
| `dimensions.planGateAudit.score` / `.max` | Yes | Plan gate audit dimension | No | Not used downstream (human-facing) |
| `severityCounts` | Yes | Issue counts by severity | No | Not used downstream (human-facing) |
| `severityCounts.high` / `.medium` / `.low` | Yes | Count at that severity | No | Not used downstream (human-facing) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `transformation-summary.v1`

**Producer:** [`transformation-agent`](../agents/transformation-agent.md) (`/transformation-roadmap`) · **Schema:** `.claude/contract/schemas/transformation-summary.v1.schema.json`

Confirmed modernization roadmap: waves, scope, dependencies, coexistence/rollback strategy. Read by `create-epic-backlog` and `team-estimation-agent`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `waves` | Yes | Array of waves | Yes | `create-epic-backlog` (Phase 1 Step 1, primary wave source), `team-estimation-agent` (WBS Level 1) |
| `waves[].number` | Yes | Wave number | Yes | `create-epic-backlog`, `team-estimation-agent` |
| `waves[].name` | Yes | Wave name | Yes | `create-epic-backlog`, `team-estimation-agent` |
| `waves[].scope` | Yes | Wave scope | Yes | `create-epic-backlog` (Discovery Summary / Wave Context Summary) |
| `waves[].dependencies` | Yes | Wave dependencies | Yes | `create-epic-backlog` (cross-wave dependency extraction) |
| `waves[].keyDeliverables` | Yes | Wave's key deliverables | Yes | `create-epic-backlog` (Wave Context Summary), `team-estimation-agent` (WBS Level 2 deliverables) |
| `capabilitiesMigrated` | Yes | Capability names covered by this roadmap | Yes | `team-estimation-agent` (WBS Level 2 deliverable sourcing) |
| `coexistenceStrategy` | Yes | How old and new systems coexist during migration | Yes | `create-epic-backlog` (read directly in Phase 1 Step 1) |
| `rollbackApproach` | Yes | Rollback approach | Yes | `create-epic-backlog` (read directly in Phase 1 Step 1) |
| `modernizationApproach` | Yes | Overall modernization approach | No | Not used downstream (narrative context only) |
| `status` | Yes | Enum: `DRAFT`, `IN_REVIEW`, `APPROVED` | No | Not used downstream (approval gate is human-facing) |
| `totalWaves` | Yes | Total number of waves | No | Not used downstream (redundant with `waves.length`) |
| `keyRisks` | Yes | Key risks for the roadmap | No | Not used downstream (no documented consumer reads this field) |
| `openQuestions` | Yes | Open questions | No | Not used downstream (`team-estimation-agent` maintains its own `openQuestions`; no consumer reads this one) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `team-estimate-options-summary.v1`

**Producer:** [`team-estimation-agent`](../agents/team-estimation-agent.md) (`/transformation-roadmap`) · **Schema:** `.claude/contract/schemas/team-estimate-options-summary.v1.schema.json`

Single shared Work Breakdown Structure plus three commercially distinct staffing/cost options (Cost-Optimized, Time-Optimized, Safe & Realistic), PERT-estimated. No downstream agent consumes this file — it's for humans.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `options[].waves[].workPackages[].scheduledStartDay` | Yes | Scheduled start day (offset) | Possible | Feeds the Mermaid Gantt chart at generation time, not re-read afterward |
| `options[].waves[].workPackages[].scheduledEndDay` | Yes | Scheduled end day (offset) | Possible | Feeds the Mermaid Gantt chart at generation time, not re-read afterward |
| `options[].waves[].workPackages[].onCriticalPath` | Yes | Whether the work package is on the critical path | Possible | Feeds the Mermaid Gantt chart at generation time, not re-read afterward |
| `project` | Yes | Project name | No | Not used downstream (human-facing only) |
| `generatedAt` | Yes | Generation timestamp | No | Not used downstream (human-facing only) |
| `generatedBy` | Yes | Agent that generated the document | No | Not used downstream (human-facing only) |
| `sourceRoadmap` | Yes | Path to the transformation roadmap this estimate is built from | No | Not used downstream (human-facing only) |
| `status` | Yes | Enum: `DRAFT`, `IN_REVIEW`, `APPROVED` | No | Not used downstream (human-facing only) |
| `gradeBandLegend` | Yes | Legend defining the consulting grade codes (A3–F2) used throughout | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `gradeBandLegend[].code` | Yes | Grade code (e.g. `A3`) | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `gradeBandLegend[].title` | Yes | Role title for the grade | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `gradeBandLegend[].band` | Yes | Seniority band | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `gradeBandLegend[].typicalExperience` | Yes | Typical years of experience for the grade | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `wbs` | Yes | The single Work Breakdown Structure shared by all three options | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].wbsId` | Yes | Work-package identifier | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].waveNumber` | Yes | Wave number the work package belongs to | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].waveName` | Yes | Wave name | No | Not used downstream (human-facing only) |
| `wbs[].deliverable` | Yes | Deliverable the work package produces | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].workPackage` | Yes | Work package name | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].description` | Yes | Work package description | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].complexityTier` | Yes | Enum: `S`, `M`, `L`, `XL` | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].type` | Yes | Enum: `CAPABILITY`, `INTEGRATION_AND_TESTING`, `DEPLOYMENT_CUTOVER`, `SHADOW_RUN` | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].dependsOnWbsIds` | Yes | Other `wbsId`s this work package depends on | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `wbs[].confidenceSignal` | Yes | Enum: `HIGH`, `MEDIUM`, `LOW` | Use on site only | `knowledge-base-publisher` → `data-wbs.js` |
| `programmeGovernance` | Yes | Programme-level governance roles (shared across options) | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `programmeGovernance[].grade` | Yes | Grade code | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `programmeGovernance[].role` | Yes | Role title | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `programmeGovernance[].allocationFte` | Yes | FTE allocation | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `programmeGovernance[].costed` | Yes | Whether this role is included in the costed estimate | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `programmeGovernance[].notes` | Yes | Notes | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `options` | Yes | The three commercial options | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `options[].optionId` | Yes | Enum: `cost-optimized`, `time-optimized`, `safe-realistic` | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `options[].name` | Yes | Option display name | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `options[].objective` | Yes | Option's objective | No | Not used downstream (human-facing only) |
| `options[].genAiReliance` | Yes | Enum: `AGGRESSIVE`, `MODERATE`, `CONSERVATIVE` — assumed Gen-AI acceleration reliance | No | Not used downstream (human-facing only) |
| `options[].waves` | Yes | Per-wave staffing for this option | No | Not used downstream (human-facing only) |
| `options[].waves[].number` | Yes | Wave number | No | Not used downstream (human-facing only) |
| `options[].waves[].name` | Yes | Wave name | No | Not used downstream (human-facing only) |
| `options[].waves[].serviceCompanyTeam` | Yes | Service company's own delivery team for the wave (the only headcount counted in the estimate) | No | Not used downstream (human-facing only) |
| `options[].waves[].serviceCompanyTeam.totalHeadcount` | Yes | Total headcount for the wave | No | Not used downstream (human-facing only) |
| `options[].waves[].serviceCompanyTeam.roles` | Yes | Roles staffing the wave | No | Not used downstream (human-facing only) |
| `options[].waves[].serviceCompanyTeam.roles[].grade` | Yes | Grade code | No | Not used downstream (human-facing only) |
| `options[].waves[].serviceCompanyTeam.roles[].role` | Yes | Role title | No | Not used downstream (human-facing only) |
| `options[].waves[].serviceCompanyTeam.roles[].count` | Yes | Number of people at this grade/role | No | Not used downstream (human-facing only) |
| `options[].waves[].serviceCompanyTeam.roles[].notes` | Yes | Notes | No | Not used downstream (human-facing only) |
| `options[].waves[].customerSideSMEs` | Yes | Customer-side SME involvement for the wave — tracked separately since customer staff time isn't part of the service company's estimate | No | Not used downstream (human-facing only) |
| `options[].waves[].customerSideSMEs[].role` | Yes | SME role | No | Not used downstream (human-facing only) |
| `options[].waves[].customerSideSMEs[].involvement` | Yes | Nature/level of involvement | No | Not used downstream (human-facing only) |
| `options[].waves[].customerSideSMEs[].durationWeeks` | Yes | Duration of involvement in weeks | No | Not used downstream (human-facing only) |
| `options[].waves[].customerSideSMEs[].riskIfUnavailable` | Yes | Risk if this SME is unavailable | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages` | Yes | Per-work-package PERT estimate for this option/wave | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages[].wbsId` | Yes | Work package identifier (references `wbs[].wbsId`) | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages[].assignedGrades` | Yes | Grade codes assigned to the work package | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages[].pertEffortPersonDays` | Yes | PERT three-point effort estimate | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages[].pertEffortPersonDays.optimistic` / `.mostLikely` / `.pessimistic` / `.expected` / `.stdDev` | Yes | PERT effort values (person-days) | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages[].pertDurationDays` | Yes | PERT three-point duration estimate | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages[].pertDurationDays.optimistic` / `.mostLikely` / `.pessimistic` / `.expected` / `.stdDev` | Yes | PERT duration values (days) | No | Not used downstream (human-facing only) |
| `options[].waves[].workPackages[].confidenceLevel` | Yes | Enum: `LOW`, `MEDIUM`, `HIGH` | No | Not used downstream (human-facing only) |
| `options[].waves[].waveRollup` | Yes | Wave-level PERT rollup | No | Not used downstream (human-facing only) |
| `options[].waves[].waveRollup.pertEffortPersonDays.expected` / `.stdDev` | Yes | Rolled-up wave effort | No | Not used downstream (human-facing only) |
| `options[].waves[].waveRollup.pertDurationDays.expected` / `.stdDev` | Yes | Rolled-up wave duration | No | Not used downstream (human-facing only) |
| `options[].waves[].waveRollup.confidenceLevel` | Yes | Enum: `LOW`, `MEDIUM`, `HIGH` | No | Not used downstream (human-facing only) |
| `options[].waves[].tradeoffNotes` | Yes | Trade-off notes for this wave under this option | No | Not used downstream (human-facing only) |
| `options[].programmeRollup` | Yes | Programme-level rollup for the option | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.totalEffortPersonDays.expected` / `.stdDev` | Yes | Total programme effort | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.totalDurationDays.expected` / `.stdDev` | Yes | Total programme duration | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.programmeGovernanceEffortPersonDays` | Yes | Governance effort (person-days) | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.peakServiceCompanyHeadcount` | Yes | Peak headcount reached | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.peakGradeMix` | Yes | Grade codes present at peak headcount | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.relativeCostIndex` | Yes | Relative cost index vs. the other options | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.riskProfile` | Yes | Risk profile summary | No | Not used downstream (human-facing only) |
| `options[].programmeRollup.chooseIfNotes` | Yes | Guidance on when to choose this option | No | Not used downstream (human-facing only) |
| `options[].optionFile` | Yes | Path to this option's markdown file | No | Not used downstream (human-facing only) |
| `comparisonFile` | Yes | Path to `team-estimate-comparison.md` | No | Not used downstream (human-facing only) |
| `assumptions` | Yes | Assumptions made | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `openQuestions` | Yes | Open questions | Use on site only | `knowledge-base-publisher` → `data-estimates.js` |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `add-features-findings.v1`

**Producer:** [`add-features-analyst`](../agents/add-features-analyst.md) · **Schema:** `.claude/contract/schemas/add-features-findings.v1.schema.json`

The read-only backlog-impact scan for `/add-features` — duplicates, contradictions, affected epics/waves, per-story editability, and a placement recommendation. The `/add-features` command reads this back in the same run to drive its clarifying-questions gate and change set; the companion `add-features-findings.md` is the human-readable narrative shown alongside it.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `generatedAt` | Yes | Date (`YYYY-MM-DD`) the scan was performed | No | Not used downstream (metadata only) |
| `backlogRoot` | Yes | Resolved backlog root the analyst scanned | No | Not used downstream (metadata only) |
| `track` | No | Track name, if the backlog root carried one | No | Not used downstream (metadata only) |
| `feature.description` | Yes | Feature description as given to the analyst, verbatim | No | Not used downstream (evidence only) |
| `feature.restatement` | Yes | One-paragraph restatement of the requested functionality | No | Not used downstream (human-facing only) |
| `counts.*` | Yes | Summary counts (stories/epics scanned, duplicates, related stories, contradictions, open questions, blocking open questions) | No | Not used downstream (human-facing only) |
| `duplicates[].path` / `.status` / `.editable` / `.overlapDescription` | Yes | Existing story/epic the feature duplicates or strongly overlaps, its lock status, and what overlaps | Yes | `/add-features` (Step 5 `AskUserQuestion` gate) |
| `duplicates[].recommendedAction` | Yes | Enum: `extend`, `new-story`, `skip`, `supersede` | Yes | `/add-features` (Step 5) |
| `relatedStories[]` | Yes | Adjacent stories and their relationship to the feature | Yes | `/add-features` (Step 5, informs placement) |
| `contradictions[].conflictsWith` / `.impact` | Yes | The specific requirement/constraint conflicted with, and what must be reconciled | Yes | `/add-features` (Step 5 `AskUserQuestion` gate) |
| `affectedEpics[].businessCapability` | Yes (nullable) | Feeds the delegated `epic-backlog-agent` brief's `BRD Reference` when extending an existing epic | Yes | `/add-features` (Step 8) |
| `affectedEpics[].nextFreeStoryNumber` | Yes | Next unused `story-NN` number within that epic | Yes | `/add-features` (Step 7, story numbering) |
| `placementRecommendation.bestFit` | Yes | Enum: `existing-epic`, `new-epic`, `already-covered` — the last value drives the Step 6 stop-early path | Yes | `/add-features` (Step 5, Step 6) |
| `placementRecommendation.newEpic.nextFreeEpicNumber` | Yes when `bestFit` is `new-epic` | Next unused `epic-NN` number within the target wave | Yes | `/add-features` (Step 7, Step 8) |
| `placementRecommendation.proposedStories[]` | Yes | Proposed new stories (title, scope, blockers) | Yes | `/add-features` (Step 5 confirmation, Step 10 story-intent briefs) |
| `placementRecommendation.aggregateUpdatesNeeded` | Yes | Aggregate/index files that must be kept in sync | Yes | `/add-features` (Step 12) |
| `editabilityMap[]` | Yes | Every relevant story/epic's status and Draft-only editability | Yes | `/add-features` (hard-rule enforcement) |
| `openQuestions[].ownerRole` | Yes | Enum: `Product`, `Architecture`, `Engineering`, `Security`, `DevOps`, `Operations` — same role tags used elsewhere in the backlog | No | Human-facing; round-trips losslessly if later escalated into an open-questions register |
| `openQuestions[].blocking` | Yes | True means `/add-features` must not build a change set until this is answered | Yes | `/add-features` (Step 5 gate) |
| `lockedItemWarnings[]` | Yes | LOCKED items that would ideally change but can't be edited | No | Human-facing only (final summary's "Recommended follow-ups") |
| `filesScanned[]` | Yes | Every file globbed or read — the evidence base for this scan | No | Not used downstream (evidence only) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `change-impact.v1`

**Producer:** [`change-impact-agent`](../agents/change/change-impact-agent.md) (node `change-impact`, command `/propose-change`) · **Schema:** `.claude/contract/schemas/change-impact.v1.schema.json`

Where one change request lands in the live code: the behaviours it touches and with what disposition, how well they are tested, what must be pinned by characterization tests first, and which extraction files go stale once it lands. Written to `knowledge-base/changes/<changeId>/impact.json`, with the human view in `impact.md`. Semantic invariants a schema cannot express (every `file:line` exists, a `refactor` contains only `preserve` behaviours, characterization covers every partial or uncovered preserve/change behaviour) are checked by `check-change-impact.py`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `changeId` | Yes | `YYYY-MM-DD-<slug>`; equals the name of the directory `impact.json` sits in | Yes | `check-change-impact.py`; `change-story-agent` (story identity); `/new-story-impl`, `/archive-implemented` (change lookup) |
| `changeType` | Yes | Enum: `feature`, `behaviour-change`, `refactor` | Yes | `check-change-impact.py` (refactor-is-preserve-only rule); `change-story-agent` |
| `intent` | Yes | The change request as given | Yes | `change-story-agent` (Change Intent) |
| `briefKind` | Yes | Enum: `intent`, `epic` (`epic` is reserved for the planned programme path) | Possible | `change-impact-agent` itself |
| `sizing` | Yes | Enum: `change`, `programme` - `programme` when more than 3 capabilities or more than 40 impacted files | Yes | `/propose-change` (checkpoint warning); `/fix-knowledge-extraction --change` (escalation to agent re-run) |
| `dependencySource` | Yes | Enum: `graphify`, `grep` - where dependents came from; `grep` means reach may be incomplete | Yes | `impact.md` summary; the human reviewer at the checkpoint |
| `testCommand` | Yes (nullable) | Shell command that runs the project's test suite from the repo root; `null` when none could be found | Yes | `/new-story-impl` (pin-first pass and preservation check) |
| `kbAnchors[].path` / `.section` | Yes | Knowledge-base file and heading where the change was located | Yes | `change-story-agent` (Traceability) |
| `kbAnchors[].capability` | No | Capability the anchor belongs to | Yes | Sizing (distinct capability count) |
| `codeImpact[].file` / `.line` | Yes | Repo-relative file and a line that was seen | Yes | `check-change-impact.py` (existence); `/new-story-impl` (scope-drift comparison) |
| `codeImpact[].symbols` | Yes | Symbols at that location | No | Human-facing (impact report) |
| `codeImpact[].role` | Yes | Enum: `direct` (the change edits it), `dependent` (calls or imports it) | No | Human-facing (impact report) |
| `codeImpact[].confidence` | Yes | Enum: `confirmed-in-code`, `kb-only`, `inferred` | Possible | Human-facing; `inferred` items become open questions |
| `behaviours[].id` | Yes | `B-NN` | Yes | `change-story-agent`; `check-change-story.py` (Traceability row) |
| `behaviours[].description` | Yes | The behaviour in one sentence | Yes | `change-story-agent` (Current Behaviour) |
| `behaviours[].disposition` | Yes | Enum: `preserve`, `change`, `add`, `remove` | Yes | `check-change-impact.py`; `change-story-agent` (Requirement Intents, Behaviour Preservation) |
| `behaviours[].before` / `.after` | No | Old and new behaviour; `before` for `change`/`remove`, `after` for `change`/`add` | Yes | `change-story-agent` (Current and Target Behaviour) |
| `behaviours[].coverage` | Yes | Enum: `covered`, `partial`, `none` | Yes | `check-change-impact.py` (characterization coverage rule) |
| `behaviours[].tests[]` | Yes | Existing tests that exercise the behaviour, as `{file, name?}`; real files only | Yes | `change-story-agent` (Behaviour Preservation) |
| `behaviours[].confidence` | Yes | Enum: `confirmed-in-code`, `kb-only`, `inferred` | Possible | Human-facing |
| `typeConflicts[].behaviourId` / `.reason` | Yes | A behaviour whose disposition contradicts the change type (e.g. a non-`preserve` behaviour in a refactor) | Yes | `/propose-change` (checkpoint: reclassify or split) |
| `contracts[].kind` | Yes | Enum: `api`, `db`, `event`, `file`, `ui` | Yes | `change-story-agent` (Architecture & Contract Intents) |
| `contracts[].name` / `.note` | Yes | Contract touched and why | Yes | `change-story-agent` |
| `contracts[].verdict` | Yes | Enum: `compatible`, `breaking` - `breaking` implies an expand/contract story split | Yes | `change-story-agent` (story split); `/fix-knowledge-extraction --change` (escalation) |
| `characterization[].behaviourId` | Yes | The behaviour to pin | Yes | `check-change-impact.py`; `change-story-agent` (Characterization Plan) |
| `characterization[].what` / `.seam` / `.suggestedLocation` | Yes | What to pin, the test seam to use, and where to put the test | Yes | `change-story-agent` (Characterization Plan) |
| `characterization[].newSeam` | No | True when no test harness exists yet for this layer | Yes | `change-story-agent` (separate characterization story) |
| `kbRefreshTargets[].path` / `.reason` | Yes | Extraction files that go stale once the change lands | Yes | `/archive-implemented` step 8.5 and `/fix-knowledge-extraction --change` (the refresh) |
| `backlogCollisions[].storyPath` / `.overlap` | Yes | Open migration stories touching the same capability or files | Yes | `/propose-change` (checkpoint warning) |
| `risks[].description` / `.severity` | Yes | Risk and its severity (`High`, `Medium`, `Low`) | Yes | `change-story-agent` (Risks) |
| `openQuestions[].question` | Yes | Anything left `inferred` or otherwise unresolved | Yes | `change-story-agent` (Open Questions); `open-questions-agent` (`changes` scope harvest) |
| `openQuestions[].ownerRole` | Yes | Enum: `Product`, `Architecture`, `Engineering`, `Security`, `DevOps`, `Operations` | Yes | `change-story-agent` (`[<ownerRole>]` prefix) |
| `openQuestions[].blocking` | Yes | True when a wrong guess would change what gets built | Yes | `/resolve-open-questions changes` gate on `/new-story-spec` |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

`knowledge-base/changes/<changeId>/refresh.json` (written by `/archive-implemented` step 8.5 or `/fix-knowledge-extraction --change`, never by the impact agent) is declared as an optional write of the same node: `{changeId, status: done | pending, generatedAt, targets[]: {path, action: direct-edit | agent-rerun | skipped, reason}}`.

---

## `backlog-validation-summary.v1`

**Producer:** [`backlog-validator`](../agents/backlog/backlog-validator.md) · **Schema:** `.claude/contract/schemas/backlog-validation-summary.v1.schema.json`

Structural/coherence validation of the epic+story backlog. Distinct from the same-named files written by `architecture-validator` and `brd-validator`.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `generated` | Yes | ISO date the report was generated | Possible | Not used downstream — `backlog-validator` FIX mode reads `validation.md` (Markdown) for open issues, not this JSON |
| `issues` | Yes | Individual validation issues | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].id` | Yes | Issue identifier | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].file` | Yes | File the issue is in | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].section` | Yes | Section the issue is in | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].severity` | Yes | Enum: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW` | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].dimension` | Yes | Dimension the issue belongs to | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].description` | Yes | Issue description | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].recommendation` | Yes | Recommended fix | Possible | **Not** re-read by `backlog-validator` FIX mode — Step 1 reads `validation.md` (Markdown) for open issues, not this JSON array |
| `issues[].status` | No | Set to `RESOLVED` by FIX mode on each fixed issue; absent on initial VALIDATE-mode output | Possible | Written (not read) by `backlog-validator` FIX mode — an output marker, not a consumed input |
| `track` | Yes | Track name | No | Not used downstream (human-facing only) |
| `totalScore` | Yes | Overall validation score | No | Not used downstream (human-facing only) |
| `grade` | Yes | Enum: `A`, `B`, `C`, `D`, `F` | No | Not used downstream (human-facing only) |
| `criticalCount` | Yes | Count of critical issues | No | Not used downstream (human-facing only) |
| `highCount` | Yes | Count of high-severity issues | No | Not used downstream (human-facing only) |
| `mediumCount` | Yes | Count of medium-severity issues | No | Not used downstream (human-facing only) |
| `lowCount` | Yes | Count of low-severity issues | No | Not used downstream (human-facing only) |
| `dimensions` | Yes | Score breakdown across 5 dimensions | No | Not used downstream (human-facing only) |
| `dimensions.epicCompleteness.score` / `.max` | Yes | Epic completeness dimension | No | Not used downstream (human-facing only) |
| `dimensions.storyCompleteness.score` / `.max` | Yes | Story completeness dimension | No | Not used downstream (human-facing only) |
| `dimensions.dependencyIntegrity.score` / `.max` | Yes | Dependency integrity dimension | No | Not used downstream (human-facing only) |
| `dimensions.crossItemCoherence.score` / `.max` | Yes | Cross-item coherence dimension | No | Not used downstream (human-facing only) |
| `dimensions.traceabilitySourceAlignment.score` / `.max` | Yes | Traceability/source-alignment dimension | No | Not used downstream (human-facing only) |
| `waves` | Yes | Per-wave summary | No | Not used downstream (human-facing only) |
| `waves[].wave` | Yes | Wave identifier | No | Not used downstream (human-facing only) |
| `waves[].epicCount` | Yes | Number of epics in the wave | No | Not used downstream (human-facing only) |
| `waves[].storyCount` | Yes | Number of stories in the wave | No | Not used downstream (human-facing only) |
| `waves[].readmePresent` | Yes | Whether the wave's `README.md` is present | No | Not used downstream (human-facing only) |
| `waves[].issues` | Yes | Wave-level issue descriptions | No | Not used downstream (human-facing only) |
| `filesEvaluated` | Yes | Files included in the evaluation | No | Not used downstream (human-facing only) |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

---

## `open-questions-register.v1`

**Producer:** [`open-questions-agent`](../agents/open-questions-agent.md) (SCAN mode) · **Schema:** `.claude/contract/schemas/open-questions-register.v1.schema.json`

Durable store for one scope's (`extraction`/`brd`/`epics`/`stories`) open-questions register — written only
by the `/resolve-open-questions` command, never by an agent directly writing over a prior version. The
paired `open-questions*.md` is human-authoritative for answers; this JSON is what `open-questions-cli.py
check` (the Step 0.5 gate) reads. See `docs/gaps/OPEN_QUESTIONS_RESOLUTION.md` for the full design.

| Property | Required | Description | Used | Used by |
|---|---|---|---|---|
| `scope` | Yes | Enum: `extraction`, `brd`, `epics`, `stories` | Yes | `open-questions-cli.py` (path/gate resolution) |
| `track` | No | Track segment, present only for `epics`/`stories` when one was resolved | Yes | `open-questions-cli.py` (path resolution via `phase_graph.apply_track`) |
| `generated` | Yes | Date (YYYY-MM-DD) the register was last written by SCAN | No | Human-facing only |
| `renderMode` | Yes | Enum: `all`, `blocking-only` — which Markdown fill-in surface was rendered | No | `open-questions-agent` (re-render on the next SCAN) |
| `harvest.rawItemCount` | Yes | Total raw harvest items for this scope before dedup/exclusion | Yes | `open-questions-cli.py verify` — Σ`occurrences[]` + `excludedCount` + `appendixCount` must equal this |
| `harvest.excludedCount` | Yes | Raw items dropped by the hard exclusion list | Yes | `open-questions-cli.py verify` (same invariant) |
| `harvest.appendixCount` | Yes | Unmarked assumptions SCAN judged not load-bearing, routed to `assumptionsAppendix[]` instead of a full question | Yes | `open-questions-cli.py verify` (same invariant, plus `len(assumptionsAppendix[]) == appendixCount`) |
| `assumptionsAppendix[].path` / `.line` / `.verbatim` | Yes | One raw unmarked-assumption item, Markdown-only visibility, never a fill-in question | Yes | `open-questions-cli.py verify`; rendered into the register Markdown's "Assumptions presented as fact" table |
| `counts.*` | Yes | Recomputed status/blocking tallies (`total`, `blocking`, `open`, `answered`, `applied`, `deferred`, `acceptedRisk`, `needsClarification`, `blockedLocked`, `superseded`) | Yes | `open-questions-cli.py verify` cross-checks against a live recompute from `questions[]` |
| `clearance.status` | Yes | Enum: `CLEAR`, `BLOCKED` — register-wide, independent of any `--wave`/`--epic`/`--story` slice | Yes | `open-questions-cli.py check` (register-wide summary; the gate itself recomputes a slice-scoped clearance) |
| `clearance.blockingOpenIds` | Yes | `OQ-NNNN` ids currently blocking, register-wide | Yes | Same as `clearance.status` |
| `questions[].id` | Yes | `OQ-NNNN`, unique and gapless, never renumbered on a re-run | Yes | `open-questions-cli.py parse`/`check`; residual pointer bullets (`[Resolved OQ-NNNN …]`); `story-intent-agent`/`epic-backlog-agent` citations; `- **Related ADRs:**` |
| `questions[].question` | Yes | Canonicalized question text (the Markdown block's `**Question**:` line) | Yes | `open-questions-cli.py check` (gate output); the register Markdown |
| `questions[].kind` | Yes | Enum: 7 values — see the SCAN agent's taxonomy table | Yes | `open-questions-applier` (kind → patch-target mapping) |
| `questions[].ownerRole` | Yes | Enum: `Product`, `Architecture`, `Engineering`, `Security`, `DevOps`, `Operations` | Yes | Markdown owner-grouped sections; round-trips losslessly with a story's `- [Role]` tag |
| `questions[].blocking` | Yes | Whether this question gates `open-questions-cli.py check` | Yes | `open_questions.compute_clearance`/`check_clearance` |
| `questions[].status` | Yes | Enum: 8 values — `Open`, `Answered`, `Applied`, `Deferred`, `Accepted-Risk`, `Needs-Clarification`, `Blocked-Locked`, `Superseded` | Yes | Gate clearance; `backlog-validator` 2f/3g staleness checks |
| `questions[].whyItMatters` | Yes | Consequence of leaving the question open | No | Rendered into the Markdown block only |
| `questions[].evidence[].path` / `.line` / `.quote` | Yes | Real, checkable citation grounding the question | No | Rendered into the Markdown block only |
| `questions[].occurrences[].path` / `.line` / `.artifactKind` / `.verbatim` | Yes | Every raw harvest item this canonical question absorbed | Yes | `open-questions-cli.py verify` (path/line existence, Σ invariant); `open-questions-applier` (which files/lines to patch) |
| `questions[].occurrences[].section` | No | Heading the occurrence was found under | No | Human-facing only |
| `questions[].proposals[].ref` / `.text` / `.recommended` / `.consequence` | Yes | 2–4 mutually exclusive options, exactly one `recommended` | Yes | `open-questions-cli.py verify` (count/exactly-one invariant); `open-questions-cli.py parse` (`chosenProposal` resolution) |
| `questions[].answer.*` | No | `text`/`chosenProposal`/`answeredBy`/`answeredOn`/`source` — only ever originated by a human via the Markdown, never by SCAN | Yes | `open-questions-applier` (what to promote); `verify`'s anti-fabrication cross-check (`source: human` must have a filled Markdown block) |
| `questions[].resolution.*` | No | `promotedTo[]`/`filesChanged[]`/`appliedOn`/`adrRef`/`residualPointer`/`escalatedTo` — written by the command after APPLY, never by SCAN or the applier directly | No | Human-facing audit trail; `story-intent-agent` cites `adrRef` |
| `_contract` | Yes | see [shared envelope](#_contract-shared-envelope) | No | n/a — provenance/trust metadata, not a downstream data dependency |

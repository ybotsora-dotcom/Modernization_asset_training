# Installation

Modernization-CLI is distributed exclusively as a **Claude Code plugin**. `.claude/` at the root of
this repository *is* the plugin root — there is no installer, no copy step, and no separate payload
to keep in sync. Installing means enabling the plugin from the marketplace; updating means pulling
the latest plugin version.

For a high-level summary see the [README](../../README.md#installation); this document is the complete
reference.

## Installing from the marketplace

The plugin is listed in the internal marketplace (`plugins-marketplace`), which vendors no code
itself — only a `git-subdir` entry pointing at this repository's `.claude/`. From a Claude Code
session with that marketplace registered:

```
/plugin install modernization-cli-cap
```

or, for local development against a checkout of this repo without going through the marketplace:

```bash
claude --plugin-dir /path/to/modernization-cli/.claude
```

Both `${CLAUDE_PLUGIN_ROOT}` (resolved to the plugin's installed/loaded location) and the target
repository's own working directory are then available to every agent and command — see
[`CLAUDE.md`](../../CLAUDE.md#plugin-root-vs-project-root--the-claude_plugin_root-convention) for the
toolkit-root-vs-project-root split every path in this toolkit follows.

## Host requirements — run `/plugin-init` first

Every command and skill refuses to run until `/plugin-init` has passed on this machine for the
installed plugin version. It checks for, and tells you how to install:

| Tool | Minimum | Needed for |
|---|---|---|
| Git Bash (Windows only) | — | every hook and command |
| Python | 3.10 | every script and hook |
| git | — | branches, commits, tracking checks |
| Node.js | 22 | chat widget, `npx` |
| openspec | — | optional — asked (Defer/Skip acknowledges the loss); `/new-story-spec`, `/new-story-impl`, `/archive-implemented` |
| graphify | — | `/completeness-report` |
| pandoc | — | optional — asked (Defer/Skip acknowledges the loss); `/parse-docx` |
| mermaid-cli (`mmdc` or `npx`) | — | `/validate-mermaid`, `/validate-architecture` |
| `glab` or `gh` | — | optional — asked; MR/PR creation and merge |
| Docker | — | optional — asked (Defer/Skip acknowledges the loss); `/chat-serve` default mode and the vendored `run.sh` |

It never installs anything. Re-run it after every plugin update (the marker is version-keyed).

### Windows

Claude Code picks its shell at startup, and which terminal you launched it from does not matter.
What matters is whether it can find **Git Bash**. Without Git Bash it switches to PowerShell mode,
and then no plugin hook or script can run. Fixes:

- Install full Git for Windows: `winget install Git.Git`. MinGit and the Git bundled with GitHub
  Desktop or IDEs do not include Git Bash.
- Or, if Git Bash is installed somewhere Claude Code does not look, set `CLAUDE_CODE_GIT_BASH_PATH`
  to its `bash.exe`.
- Watch for WSL: in PowerShell mode `bash` may resolve to `C:\Windows\System32\bash.exe`. The
  plugin detects this and says so.
- **Restart Claude Code** after either fix, then run `/plugin-init`.

### Troubleshooting: the gate itself is broken

If the host gate blocks everything and `/plugin-init` cannot fix it, start Claude Code with
`MODERNIZATION_CLI_SKIP_HOST_GATE=1` in its environment to bypass every host check, and report the
problem. Remove it once fixed — it disables the gate entirely.

### Troubleshooting: gathering diagnostics for support

If the plugin support team asks for more information about your environment, run
`python3 <plugin-folder>/scripts/host_check.py diagnose` from the repository root and send them the
output. It is read-only and changes nothing. They may also ask for `.claude/tooling/host-check.json`,
which records details of the machine `/plugin-init` last ran on; it is not committed to git.

## Getting a local copy of the docs

The plugin ships this manual and its companion docs, but installing the plugin does not by itself
put them anywhere inside the target repository — Claude Code resolves them from
`${CLAUDE_PLUGIN_ROOT}`, not a copied location. Run:

```
/plugin-init
```

once after installing, and again after each `/plugin update`, to get a local, browsable copy at
`.claude/docs/modernization-cli-cap/` in the target repository. The same command also migrates any
orphaned pre-plugin agent-memory directories — see the migration note below.

## Requirements

- **Python 3.10+** — used by the pipeline's helper scripts. On Windows, install Python and confirm
  from Git Bash that at least one of `python3`, `python`, or `py -3` runs Python 3.10+. The plugin's
  `scripts/run-python.sh` selects a working interpreter; a Windows App Execution Alias that merely
  appears on `PATH` is not sufficient.
- **Git for Windows / Git Bash on Windows** — launch Claude Code from Git Bash so its Bash tool and
  the plugin's shell hooks use that environment. WSL, MSYS2, and `rsync` are not required. Run
  `python -c 'import sys; print(sys.version)'` or `py -3 -c 'import sys; print(sys.version)'`
  before starting a session. Shell completion is optional; source the installed plugin's
  `scripts/contract-completion.bash` in an interactive Git Bash session if desired.
- **Node.js** — needed for `/publish-knowledge-base` and `/chat-serve --local`. Its one dependency,
  `ajv`, auto-installs (`npm ci --ignore-scripts`) the first time the plugin loads, because
  `.claude/package.json` + `.claude/package-lock.json` sit at the plugin root — no manual step.
- **Docker Desktop** — needed for `/chat-serve --docker` and for a recipient running the vendored
  chat bundle. `--local` does not need Docker.
- **`openspec`** on `PATH`, with an initialized `openspec/` project root in the target repo
  (`openspec/changes/`, `openspec/specs/`, `openspec/config.yaml`) — required only by the three
  implementation commands (`/new-story-spec`, `/new-story-impl`, `/archive-implemented`). Run
  `openspec init` in the target repo first; it also generates the `opsx:*` commands and
  `openspec-*` skills those three commands invoke, which this plugin does not bundle.

`graphify` is needed only for `/completeness-report`; `glab` is needed only for GitLab-related
workflows. Check any stage-specific CLI from the same Git Bash session before invoking that stage.

## Migrating a repo installed with the old copy-based installer

`install-kb-agents.py` — which used to copy `.claude/` into a target repository — has been retired.
Claude Code resolves **project-level** components (`<target>/.claude/agents/`, `<target>/.claude/commands/`,
etc.) before plugin-provided ones, so a repo still carrying the old installed payload will **silently
shadow the plugin**: enabling the update does nothing, because the stale project-level copy keeps
winning. If a target repo was ever installed into with `install-kb-agents.py`, clean it up once:

```bash
# in the previously-installed target repo
rm -rf .claude/agents .claude/commands .claude/skills .claude/scripts \
       .claude/site-templates .claude/site-schemas .claude/site-contract.json \
       .claude/contract .claude/git-hooks .claude/docs

# keep: .claude/agent-memory/  .claude/logs/summary.jsonl  .claude/settings*.json

# and remove the stats pre-commit block from .git/hooks/pre-commit
# (look for the marker comment "claude-code stats collector")
```

`knowledge-base/` is untouched by this cleanup — it is the deliverable the pipeline produced, not
installer payload. After cleanup, enable `modernization-cli-cap` from the marketplace as above.

Keeping `.claude/agent-memory/` means the directories written by the old project-level agents stay
under their bare names (`.claude/agent-memory/<agent-name>/`), while Claude Code's built-in
agent-memory feature namespaces the now-installed plugin agents as
`.claude/agent-memory/modernization-cli-cap-<agent-name>/` — so the old memory is orphaned, not
picked up automatically. Run `/plugin-init` after enabling the plugin; its Step 0 renames any
bare-named directory to the namespaced form whenever that's unambiguous (i.e. the namespaced
directory doesn't already exist for that agent). If both already exist for the same agent — for
example because the plugin agent has already run once since install — it leaves both alone and
reports the conflict for you to reconcile by hand.

## Propagating updates

Updating the plugin (`/plugin update modernization-cli-cap`, or pulling the marketplace's latest
`sha`) is the only propagation step — there is nothing to re-run against target repositories, except
`/plugin-init` again if you keep a local doc copy and want it refreshed to the new version.
`${CLAUDE_PLUGIN_ROOT}` changes when the plugin updates; any Claude Code session that had it loaded
before the update keeps resolving hook commands against the previous version's path until you run
`/reload-plugins`. This is benign for the stats hook (see [`usage-stats.md`](usage-stats.md)) since
it only touches the target repo's own ledger, not the plugin cache.

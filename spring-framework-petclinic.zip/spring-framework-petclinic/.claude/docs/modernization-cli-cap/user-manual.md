# Modernization-CLI — Operating Manual

**A complete guide to running a legacy-system modernization with a team of AI agents.**

**Who this is for:** architects, delivery and project managers, and anyone who needs to understand or run this process. No prior knowledge of the asset is assumed. If you are new to this, read Part 0 first — it makes the business case, lists the issues the asset solves and what you get by using it, then covers the vocabulary and the shape of the approach before any commands appear. **If you are about to run your first engagement, read the [Cookbook](#cookbook) — the whole process told as one engagement, with the decisions you will face along the way.**

---

## Contents

| Part | What it covers |
|---|---|
| **Part 0 · Orientation** | The business case, the issues it solves, what you get, the approach, what an agent is, glossary |
| **Cookbook** | One engagement told end to end, for an architect new to modernization: mobilising in the client's environment, extraction, the technical and product review streams, how the BRDs are split, BRDs, target architecture, the demo track, the proposal and delivery, plus research at any stage — with what to look at, the decision points, and the re-runs at each step |
| **Part I · How the process works** | The loop every stage follows, re-runs, human review, working with the customer, the agent map |
| **Part II · Phase 1 — Current State** | Knowledge extraction and business capabilities |
| **Part III · Phase 2 — Target State & Proposition** | Decide what to build, sequence it into waves, size it, optionally demo it |
| **Part IV · Phase 3 — Implementation** | Break each wave into epics and stories, then build it story by story |
| **Part V · Reference** | The published site, SME input by gate, cost, troubleshooting, quick card |
| **Part VI · Technical Documentation** | The asset itself: installation, configuration, architecture, supported environments, catalog entry |

---

# Part 0 — Orientation

## 0.1 The business case

This is a **reusable modernization asset** — 37 specialized agents, 35 commands, 8 shared skills and 10 quality gates — that installs into any legacy codebase and turns it into an **engineering-ready modernization plan**: a knowledge base, business requirements the customer can sign, a target architecture, a phased roadmap, and a sized backlog.

> **The proposition in one line:** weeks of agent-led analysis replace months of manual discovery — and you keep every artifact.

**Six ways it pays off:**

| Value | What it means concretely |
|---|---|
| **Speed** — discovery in days, not quarters | The reading and drafting that occupies an analyst team for months runs as a parallel agent swarm, and re-runs at will when the code moves. |
| **Understanding** — a system you can explain again | Tribal knowledge and buried rules become a searchable knowledge base and a published website non-technical stakeholders can actually read (§0.8). |
| **Commercial** — a number you can defend | Waves → epics → stories, each traceable to a capability and a business rule, so the estimate rests on an itemized scope instead of a guess. |
| **Alignment** — documents the business signs | Business requirements per capability, written in the customer's language, give Product and Architecture a single artifact to agree on. |
| **Assurance** — evidence, not assertion | Independent validators score every stage, unknowns are recorded as explicit gaps rather than confident guesses, and a human signs each of the 10 gates. |
| **Reuse** — an asset, not a one-off | Repository-agnostic and installed per engagement. Everything it produces lives as Markdown and JSON in your repo — yours to keep, edit and re-run. |

**Where the value lands, by role:**

| Who | What they get out of it |
|---|---|
| **Client / steering group** | A scoped, staged and costed proposition instead of an open-ended "replace the system" ask — plus a published site proving what was found |
| **Product** | Business requirements per capability, and a capability map showing what the system does before deciding what to keep |
| **Architecture** | A documented current state, a target-state architecture with diagrams, and a validated gap between the two |
| **Delivery / PM** | A phased roadmap with a wave-level work breakdown to size and sell, then an epic-and-story backlog per wave, exportable straight to Jira as `epics.csv` |
| **Engineering** | Stories that carry their own context, and specifications kept in step with the code as it is merged |

**What it is not.** It is not an automatic rewrite, and it does not remove the need for judgement. It removes the *manual archaeology* — reading, cataloguing and writing down — so the expensive people spend their time deciding rather than discovering.

## 0.2 Issues it solves

A legacy system is one that still runs the business but that nobody fully understands any more. Each of the problems that creates has a specific answer in this asset.

| The issue | What the asset does about it |
|---|---|
| **The documentation is gone, wrong, or was never written** — what exists describes a version from years ago | Documentation is **regenerated from the code itself**, not from memory — and regenerated again whenever the code moves, so it cannot drift silently (stage 1.1) |
| **The people who built it have left** — what remains is *tribal knowledge* that disappears with them | Fourteen specialist agents reconstruct that knowledge into a written, searchable base. The remaining experts are asked to **confirm findings rather than recall them** — a far cheaper use of scarce SME time (§5.2) |
| **The rules are buried in the code** — how a discount is calculated, when an order is blocked, written down nowhere | A dedicated agent extracts business rules, including those hidden in database procedures, triggers and rule tables, each with a confidence level and a pointer to the implementation |
| **Nobody dares change it** — any modification risks breaking something invisible | Integrations, data ownership and cross-cutting relationships are mapped explicitly, so the blast radius of a change is visible before it is made |
| **Nobody can size the work** — "what would it cost to replace this?" is answered with a guess | The system is decomposed into capabilities → waves with stated scope and deliverables, so the proposition estimate works from an itemized scope (stage 2.3) — and tightens into epics and stories as each wave enters delivery (stage 3.1) |
| **Product and engineering argue from different documents** | One business requirements document per capability, generated from the same knowledge base the architecture is built on, and signed by both sides at a single gate (gate 1.3) |
| **Analysis is slow, expensive and stale on arrival** — months of analyst time before a line of new code | The reading and drafting runs in hours as a parallel agent swarm, is cheap enough to re-run, and every stage is graded by an independent validator before a human signs it off |

## 0.3 What you get by using it

The point is not the documents — it is what the documents let you do. Each capability below arrives at a specific gate, and each is described at the size it actually is.

**What you can do that you could not before:**

| Capability | What it actually is | Available from |
|---|---|---|
| **Answer questions about the system with a source attached** | A searchable knowledge base covering architecture, data model, data flow, integrations, screens, business rules, security and runtime operations. Every finding carries a **confidence level and a pointer to the code that justifies it**, so a reader can check the claim rather than trust it | Gate 1.1 |
| **See what nobody knows, not just what is known** | Unknowns are first-class output: `source gap` where the implementation is not in the repository, `Unresolved Items` where a validator refused to guess, `REVIEW REQUIRED` where a gap was recorded rather than closed. Each needs a named owner before a gate closes | Gate 1.1 |
| **Show the work to people who will never open the repository** | A self-contained static website, hostable on an internal server, SharePoint, Pages or a shared drive with no server or database of its own. Republish at any point; it is also the fastest way to onboard a new engineer or supplier. **Turning on the chat widget changes that** — answering questions needs a running backend, so it is a separate deployment decision (§5.1) | any time, from Phase 1 |
| **Split the estate into fundable pieces** | The extracted facts grouped into business capabilities and migration waves, each with a stated business intent — the structure everything downstream is organized by | Gate 1.2 |
| **Give Product something it can actually sign** | One business requirements document per capability in business language, scored by an independent validator | Gate 1.3 |
| **Compare current and target state on paper** | A target-state architecture with C4 diagrams, plus an explicit **disposition for every extracted entity and feature area** — carried over, replaced, deferred or retired. A second validator checks that nothing extracted was silently dropped, and can hard-block | Gate 2.1 |
| **Sequence the migration without a big bang, and size it** | A wave-based roadmap that states, per wave, its scope and key deliverables, how old and new coexist, and how to roll back. That wave breakdown is the work breakdown the proposition is estimated from | Gate 2.2 |
| **Show a working version before anyone commits** | An optional demo track: a handful of client-chosen flows built for real, with a clickable mockup styled from the client's own design language. It changes the proposition conversation more than any document does | any time in Phase 2 (§2.0) |
| **Load the plan into your tracker and parallelize it** | Waves → epics → stories with a dependency graph, exported as `epics.csv`. Stories are self-contained, so any engineer can take any unblocked story; the dependency order does the coordination | Gate 3.1, per wave |
| **Implement with a paper trail, and keep docs in step** | Per story: branch → specification → merge request → human review → merge, with the master specifications updated at close-out. Story status doubles as a resume point, so an interrupted run continues instead of repeating work | Phase 3 |
| **Change your mind cheaply** | Every command is re-runnable by design: fixers touch only affected areas, the backlog has a mode for editing a few epics, and `/new-story-impl` resumes where it stopped. Correcting a fact in Phase 1 and re-running downstream is a normal working pattern, not a restart | any time (§1.2) |
| **Know what the run cost** | Tokens, cost, model, duration and errors are logged per agent automatically and aggregated by a script — so the next engagement can be quoted from measurements rather than impressions | any time (§5.3) |

**Properties of the output that matter in practice:**

- **Everything is plain Markdown and JSON inside your repository** — no proprietary format, no hosted store. It reviews and diffs in a merge request like any other change.
- **Diagrams are Mermaid text, not images** — version-controlled, editable, and syntax-checked by `/validate-mermaid`.
- **The `summary.json` files are the machine contract between stages** — which is why later stages stay cheap and consistent, and why a missing one is worth checking for.
- **It is repository-agnostic** — the agents are told what to look for, not what technology to expect, and the installer is safe to re-run as the asset is updated.

**Where it stops — read this before promising anything:**

- **It does not own the commercial number.** It *does* produce a work breakdown and three PERT-estimated staffing options (Stage 2.3) — but those are calibrated against a generic model, not your delivery history. Deciding which option you propose, and standing behind the price, stays with people.
- **It does not rewrite the system for you.** Phase 3 builds one story at a time, and every merge request still needs a human code review — *or* you hand the backlog to the **Software Factory** asset, which takes automated implementation from there. Either way this asset stops at an engineering-ready backlog; what builds from it is a separate decision (Part IV).
- **A passing score is not proof of completeness.** Validators check form, and coverage of what *was* extracted. Only a person notices the capability nobody extracted at all (§1.3).
- **Confidence levels are evidence markers, not guarantees.** `HIGH` means an agent read the implementing code; anything inferred from naming is `MEDIUM` at best and deserves SME confirmation.
- **It cannot document what is not in front of it.** External services, binaries and database objects outside the repository are recorded as gaps — correctly — and closing them takes a human.
- **Output quality tracks input quality.** The project profile is the single biggest lever, and **two or three passes over Phase 1 is normal**, not a sign of failure.
- **It costs real money and real review time.** Extraction dominates the cost and scales with the size of the codebase; the human review at each gate is the part that cannot be compressed.

## 0.4 What this approach does instead

It uses a **team of specialized AI agents** to do the reading and drafting — reconstructing the system's knowledge from the code itself — while **people stay in control of every decision**.

The core idea in one line:

> **Agents analyze and draft. People decide and approve.**

Nothing is generated and silently accepted. The process is a series of **gates**: at each one, an automated validator scores the work, a human reviews it for completeness, and only then does the next stage begin.

**What makes this trustworthy rather than a black box:**

| Principle | What it means in practice |
|---|---|
| **The source code is read once, at the very start** | Only Phase 1 agents may read the code. Everything afterwards works from the written-down knowledge. So if a fact is wrong, you fix it **once** and every later document inherits the correction. |
| **Evidence beats assertion** | An agent may only mark a rule as `HIGH` confidence if it actually read the code that implements it. Anything guessed from a name is `MEDIUM` at best. If the implementation isn't in the repository at all, it is recorded as an explicit **gap** — never as a confident guess. |
| **The graders are not the authors** | Separate validator agents score the work. A stage cannot mark its own homework. One of them can hard-block the whole process. |
| **Everything is traceable** | Every story traces back to an epic, to a capability, to a business rule, to the exact code that implements it. Any decision can be defended in an audit. |

## 0.5 What is an "agent"?

An **agent** is a specialized AI worker with exactly one job.

Instead of one general-purpose assistant doing everything shallowly, this asset defines **37 narrow specialists**. Each one:

- has a **single responsibility** — "find every screen in the user interface", "catalogue every external integration";
- is told **explicitly what it may and may not read** — most are forbidden from reading source code;
- produces a **structured document** that the next agent consumes.

Think of it as a consulting team where each person is a genuine expert in one discipline, they all work from the same brief, and their outputs are stapled together in a defined order — except they work in parallel and finish in hours rather than months.

**The "swarm".** The clearest example is Phase 1. One agent maps the repository first. Then nine agents fan out **simultaneously**, in one batch — one studying architecture, one data, one the user interface, one the business rules, and so on. The AI components follow as their own step, with one agent per entry point. Two more build on their findings — one inferring business intent, one consolidating risk — and finally one agent stitches everything into a single connected picture. A quality agent grades the result.

**You do not manage agents individually.** You type one command; it orchestrates its agents, runs them in the right order, waits for them, checks that each produced its files, and re-runs any that failed. Your job is to review what comes out.

## 0.6 The three phases

```mermaid
flowchart LR
    A["<b>PHASE 1</b><br/>CURRENT STATE<br/><br/><i>What exists today?</i>"]:::p1
    B["<b>PHASE 2</b><br/>TARGET STATE<br/>& PROPOSITION<br/><br/><i>What will we build,<br/>in what order,<br/>how big is it?</i>"]:::p2
    C["<b>PHASE 3</b><br/>IMPLEMENTATION<br/><br/><i>Build it,<br/>story by story</i>"]:::p3
    A --> B --> C
    classDef p1 fill:#00857d,stroke:#00655f,color:#ffffff
    classDef p2 fill:#0070ad,stroke:#005281,color:#ffffff
    classDef p3 fill:#5c2d91,stroke:#421f69,color:#ffffff
```

| Phase | Plain-language purpose | Main deliverable | Who leads |
|---|---|---|---|
| **1 · Current State**<br/>*(Knowledge Extraction and Business Capabilities)* | Work out what the system actually does today, and write it down in language the business can read | A searchable knowledge base + a business requirements document per capability | Architect, handing to Product |
| **2 · Target State & Proposition** | Decide what the replacement looks like, in what order to build it, and how big the job is | Target architecture + phased roadmap carrying the wave-level work breakdown + estimates (+ an optional demo) | Architect + PM |
| **3 · Implementation** | Break each wave into epics and stories, then turn each story into reviewed, merged code | An implementation backlog + working software + specifications kept in step with it | Engineering |

**Phases are sequential; you cannot usefully skip one.** Phase 2 reads Phase 1's output. Phase 3 reads Phase 2's. Skipping ahead produces confident-looking documents built on nothing.

## 0.7 The artifacts it produces

| Deliverable | Where it lives | Who uses it |
|---|---|---|
| **A published knowledge-base website** | `knowledge-base/site/` | Everyone — see §0.8 |
| Current-state knowledge base | `knowledge-base/extraction/` | Architects, engineers |
| A capability and wave map | `knowledge-base/capabilities/` | Product, PM |
| Business Requirements Documents | `knowledge-base/business-capabilities/` | Product, stakeholders |
| Target-state architecture with diagrams | `knowledge-base/target-state/architecture/` | Architecture board |
| Phased migration roadmap **with the wave-level work breakdown** | `knowledge-base/target-state/transformation/` | PM, steering group |
| A clickable UI mockup and design system (demo track) | `ui-mockup/` in the implementation repo | Product, stakeholders, front-end |
| Implementation backlog (epics → stories) | `knowledge-base/target-state/backlog/` | PM, delivery teams |
| A spreadsheet ready to import into Jira | `.../backlog/epics.csv` | PM |
| Merged code + living specifications | your repo + the SDD framework’s spec store | Engineering |

## 0.8 The published site — how everyone else sees this work 🌐

Most of the output above is Markdown and JSON sitting in a repository. That is fine for engineers and useless for everybody else.

**One command turns all of it into a browsable website:**

```
/publish-knowledge-base
```

It produces a self-contained static site at **`knowledge-base/site/index.html`** — just files, no server or database needed. Open it in a browser, or host it anywhere that serves static files (an internal web server, SharePoint, GitHub/GitLab Pages, a shared drive).

Every page also carries a **chat widget**, and publishing builds the search index it uses and drops a copy of the chat backend into `knowledge-base/chat-widget/`. The widget stays dormant until someone starts that backend — so the site remains a pile of static files, and the chat is an opt-in second deployment with its own requirements (§5.1).

**The site is organized for two audiences:**

| Audience | What they find |
|---|---|
| **Product team** | Business capabilities, features, APIs, data — the "what does this system do" view |
| **Architecture team** | Structure, modules, dependencies, risks — the "how is it built" view |
| **Anyone looking at the AI layer** | An **AI** section — AI Overview, Agents & Flows, Prompts, Retrieval (RAG), Engineering Harness — shown only when extraction found AI. Each prompt links to its extraction write-up and to the exact line in the source, pinned to the analysed commit |

**Practical advice**

- **Publish after every gate.** It takes one command. Stakeholders then always have a current view and stop asking for status decks.
- **This is your proposition document.** At the end of Phase 2, the site *is* the thing you walk a client or steering group through — architecture, roadmap, and backlog, all navigable and cross-linked.
- **It is safe to re-run.** The site's layout is frozen; the command only regenerates the data behind it. Re-publishing never breaks the site or changes its structure.
- **Send a link, not attachments.** It replaces the pile of documents that would otherwise be emailed around and immediately go stale.

## 0.9 Glossary

Terms used throughout this manual. Skim it now; come back when you hit an unfamiliar word.

| Term | Meaning |
|---|---|
| **Agent** | A specialized AI worker with one job and explicit rules about what it may read (§0.5) |
| **Knowledge base** | The `knowledge-base/` folder — every document the process produces |
| **Extraction** | Phase 1's reading of the source code to reconstruct what the system does |
| **Capability** | A chunk of business functionality, named in business terms ("Order Management", not "OrderService.cs") |
| **Wave** | A group of capabilities migrated together, in sequence. Wave 0 first, then Wave 1, and so on |
| **BRD** | *Business Requirements Document* — describes one capability in business language, with no technical jargon. The document Product signs off |
| **Target state** | The design of the replacement system: platform, technology, structure |
| **Roadmap / transformation plan** | The phased plan for getting from current to target without breaking the business |
| **WBS** | *Work Breakdown Structure* — the hierarchical breakdown of the work. Its top level, **waves with scope and key deliverables**, comes out of the transformation stage (2.2) and is what the proposition is estimated from; epics and stories refine it wave by wave in Phase 3 |
| **Epic** | A large unit of work — a whole workstream, weeks of effort. Not a single task |
| **Story** | A small, self-contained specification a team can implement and test on its own |
| **Gate** | A checkpoint with written pass/fail criteria. You do not proceed until it passes |
| **Validator** | An agent whose only job is to grade another agent's output |
| **Disposition** | The decision recorded for each existing thing: **Retain**, **Refactor**, **Retire**, or **Defer** |
| **Source gap** | Something the system clearly does, whose implementation is **not in the repository**. Needs a human to explain it |
| **SME** | *Subject Matter Expert* — a person who knows how the business actually works |
| **Confidence (HIGH/MEDIUM)** | How well-evidenced a finding is. `HIGH` = the implementing code was actually read |
| **Strangler fig** | A migration pattern: the new system gradually takes over from the old, piece by piece, instead of a single switch-over |
| **Coexistence** | The period where old and new run side by side, and the rules that keep them consistent |
| **Demo track** | The optional parallel path in Phase 2: a few client-chosen flows built for real, with a clickable mockup, to show rather than describe the proposition. Opens with `/research` to fix scope against a budget, and the flow set is confirmed with the client before anything is generated (§2.0) |
| **Track** | An optional folder segment (`demo`) under the three `target-state/` folders, passed as an argument, that keeps a scoped run's architecture, roadmap and backlog apart from the programme's. Capabilities and BRDs take no track — they are shared |
| **Demoable wave** | A delivery wave that ends in something the client can watch. Not the default — the capability split optimises risk and dependency order unless you ask for it (§1.3). Wave 0 is exempt: scaffolding has no business value by design |
| **Design system** | A short document capturing the client's own fonts, type scale, colours and spacing, derived from their existing product or website, so generated screens look like theirs |
| **C4 diagram** | A standard way of drawing software architecture at four zoom levels (context, container, component, code) |
| **Mermaid** | A text format for diagrams. Diagrams are written as text so they can be version-controlled and validated |
| **EARS / Gherkin** | Structured formats for writing requirements (`WHEN… THEN…`) and test scenarios (`Given/When/Then`) precisely enough to be unambiguous |
| **SDD framework** | *Spec-Driven Development* — the approach used in Phase 3, where each story first becomes a formal specification and the specification then drives the code. Any SDD framework can fill this role; the pipeline is not tied to one |
| **MR / PR** | *Merge Request* / *Pull Request* — the proposal to merge new code, and the place it gets reviewed |
| **`summary.json`** | The machine-readable file each stage writes for the next stage to read. Prose is for humans; this is the interface between stages |
| **Change request** | One feature, behaviour change or refactor on the live system, handled by `/propose-change` under `knowledge-base/changes/<id>/` instead of the migration backlog |
| **Characterization test** | A test that pins what the code does today, written and passed on unmodified code before a change, so what should not change can be proven |

---

## 0.10 Choosing a strategy

Not every engagement is a migration. Before running the pipeline, decide which of the seven common strategies you are actually pursuing: Retain, Retire, Rehost, Replatform, Refactor, Rebuild or Repurchase. The toolkit reduces them to two questions:

| Axis | Choices |
|---|---|
| **Direction** | *Migrate* (move to a new stack) or *evolve* (stay on the current stack) |
| **Scale** | *Programme* (waves, roadmap, estimates) or *change* (one request at a time) |

Migrating as a programme is the pipeline this manual describes. Evolving one change at a time is the [change-request stage](#change-requests--evolving-the-live-system-in-place), which needs the extraction only. Evolving as a planned programme is **Planned**, not yet available. The full decision guide, with a Supported or Planned label on every path, is in [`modernization-strategies.md`](modernization-strategies.md).

---

# Cookbook

**One engagement, told from start to finish.** This part is for an architect running their first modernization, usually on a client's premises and to a client's rules. It follows one engagement from the first conversation to the first merged story. At each step it covers what you run, what to open first, which decisions are yours, and what to do when something comes out wrong.

It adds no rules of its own. Every step links to the section that owns the detail — read the Cookbook once end to end, then work from the phase parts.

**How each chapter reads:**

| Block | What it tells you |
|---|---|
| **What you run** | The commands for that step, in order |
| **What to look at** | The files to open first, and in which order — so your review time goes where the problems usually are |
| **Decision point** | A choice the pipeline will not make for you. Each one names the options and the usual answer |
| **If it goes wrong** | The symptom you will see, and the re-run that fixes it |

## The route in one picture

You install the asset into a legacy repository and run three phases. Each phase writes into `knowledge-base/`, and the next phase reads it — **the folder is the handover, not a meeting**. Solid arrows are the main line and carry their gate; dotted arrows are the optional demo track and the per-story loop.

```mermaid
flowchart LR
    subgraph P1["PHASE 1 · CURRENT STATE — the only phase that reads code"]
        direction TB
        A00["<b>Stage 0 · Ch. 1</b><br/>host readiness on this machine<br/>/plugin-init"]:::h
        A0["<b>Ch. 1 · Mobilise</b><br/>access, material, people<br/>in the client's environment"]:::h
        A1["<b>Ch. 2–4 · /knowledge-extraction</b><br/>a 14-agent swarm reconstructs<br/>what the system does today,<br/>then two review streams:<br/>technical and product<br/><i>two or three passes is normal</i>"]:::a
        A2["<b>Ch. 5 · /capability-split</b> ★<br/>how the BRDs are split —<br/>agreed with the client,<br/>then grouped into waves"]:::a
        A3["<b>Ch. 6 · /export-for-alignment</b><br/>one BRD per capability —<br/>the client signs these"]:::p
        A00 -->|"Gate 0"| A0 -->|"Gate 1.0"| A1 -->|"Gate 1.1"| A2 -->|"Gate 1.2"| A3
    end
    subgraph P2["PHASE 2 · TARGET STATE — knowledge base only, no code is read"]
        direction TB
        B1["<b>Ch. 7 · /target-state-architecture</b><br/>design the replacement"]:::a
        B2["<b>Ch. 9 · /transformation-roadmap</b><br/>waves, work breakdown<br/>and three estimate options"]:::a
        B3["<b>Ch. 9 · Propose</b><br/>human judgement<br/><i>a range, not a point</i>"]:::h
        D1["🎬 <b>Ch. 8 · DEMO TRACK</b> — optional, parallel<br/>/research → /demo-plan → build it<br/><i>no gate of its own</i>"]:::d
        B1 -->|"Gate 2.1"| B2 -->|"Gate 2.2"| B3
        B1 -.->|"scope a demo"| D1
        D1 -.->|"shown, not described"| B3
    end
    subgraph P3["PHASE 3 · IMPLEMENTATION — one wave, then one story, at a time"]
        direction TB
        C1["<b>Ch. 10 · /create-epic-backlog</b> + <b>/story-intent</b><br/>refine ONE wave into<br/>epics and stories"]:::a
        C2["<b>Ch. 10 · /new-story-spec</b> → <b>/new-story-impl</b><br/>→ <b>/archive-implemented</b><br/>one story, spec to merged code"]:::i
        C1 -->|"Gate 3.1"| C2
        C2 -.->|"next story · next wave"| C1
    end
    P1 ==>|"Gate 1.3"| P2 ==>|"Gate 2.3 · client signs"| P3
    classDef a fill:#0070ad,stroke:#005281,color:#ffffff
    classDef p fill:#00857d,stroke:#00655f,color:#ffffff
    classDef h fill:#5c2d91,stroke:#421f69,color:#ffffff
    classDef i fill:#b5372a,stroke:#8b2a20,color:#ffffff
    classDef d fill:#8a6d1f,stroke:#6a5317,color:#ffffff
```

Two commands sit outside the sequence and run at any point. `/publish-knowledge-base` turns whatever exists so far into a browsable website ([§0.8](#08-the-published-site--how-everyone-else-sees-this-work)) — run it after every gate; it is what you show the client instead of a status deck. `/research` answers any question you want extra knowledge on — business flows, candidate technologies, competitor features — as a cited note later stages can use ([Research](#research--extra-knowledge-at-any-stage)).

**Every step runs the same five-step loop** — run → validate → fix → human review → gate ([§1.1](#11-the-core-loop)). Two things people get wrong on day one:

- **A good score is not a passed gate.** The issue list beneath the score is the part you act on, and the human review after it is mandatory ([§1.3](#13-automated-scores-do-not-prove-completeness--humans-do)).
- **Every command takes direction.** Re-run a stage *with your own instructions* about what was missed. That is the main way you steer the pipeline.

## Chapter 1 — Mobilise in the client's environment

*Stage 0 & Stage 1.0 · led by the architect · before any agent runs*

The engagement starts with a kick-off, not with extraction. Most of what goes wrong later can be traced to something settled — or not — this week: what you were given, where the work runs, and who on the client side can answer questions.

**What you run**

```
<the system's own build>         # e.g. dotnet build · mvn package · gradle build · npm run build
                                 # — build the source you were given, BEFORE anything else
/plugin install modernization-cli-cap
/plugin-init
/parse-docx <file>.docx          # once per Word document you were handed
uv tool install graphifyy        # required for /completeness-report (Chapter 2) —
                                 # installs the graphify CLI it builds its code graph with
```

**What to look at**

1. **The build — build the source code first, before any agent runs.** Run the system's own build over exactly what you were given. A tree that compiles is the best evidence you have that the code is complete; a tree that does not names its own gaps — the missing project, the unresolvable package, the library nobody handed over. Every build error is either material to ask for now or a gap to record; finding the same gap through a puzzling hole in the extraction costs a day instead of minutes ([Stage 1.0](#stage-10--setup)).
2. **The supporting sources.** Database schema and procedures, configuration, scheduling definitions, rule tables and reference data. They are routinely left out of a handover because nobody thinks of them as source.
3. **The converted Word documents** — tables especially. A garbled table produces confident, wrong extraction rather than an error.

> **Decision point — may the client's source code be sent to the model API?** During Phase 1 the source is sent to the model API. Phases 2 and 3 read only the knowledge base, and every artifact stays in the repository ([§6.5](#65-supported-environments)). **Get that approved in writing before extraction**, by whoever owns the client's security policy. It is the one question that can stop the engagement on day one.

> **Decision point — whose machine, and whose repository?** The asset runs locally on each person's machine and needs only outbound access to the model API. Decide whether that is a client laptop, a client virtual desktop or your own machine. Put the knowledge base in a **shared repository from day one**, and keep any client-specific changes to agents on their own branch ([§1.4](#14-running-this-with-a-team)).

> **Decision point — who on the client side answers questions?** Put a name against every role in [§1.5](#15-working-with-the-customer) — business SME, system SME, data owner, product owner — and book their time now. The most common cause of a stalled engagement is a two-week wait for the one person who knows why something works the way it does.

> **Decision point — feed the client's documentation in, or hold it back?** Holding it back and using it to *check* what the agents found is often worth more. Every mismatch is a finding: either extraction missed something, or the documentation is out of date.

**If it goes wrong**

| You see | Do this |
|---|---|
| The build fails on a module you were not given | Write it on the gap list and ask for it now — do not wait for extraction to find it |
| Material keeps arriving in instalments | Normal. Run extraction on what you have; the gap list it produces is your lever for the next request |
| The plugin seems to do nothing | Stale copy-installed agents in the repository are shadowing it — see [§6.1](#61-installation-and-deployment) |

## Chapter 2 — Read the system

*Stages 1.1–1.2 · led by the architect · the most expensive step, and the one you repeat*

One person runs extraction and everyone else waits for it — two people running it in parallel only doubles the cost. Fourteen agents read the code in five ordered phases and a fifteenth grades the result ([Stage 1.1–1.2](#stage-1112--knowledge-extraction-and-quality-gate)). Expect the first pass to score in the mid-80s. The fix loop is what takes it higher. Once the grade is clean, the human review splits into two streams that run in parallel: technical (Chapter 3) and product (Chapter 4).

**What you run**

```
/knowledge-extraction
/fix-knowledge-extraction            # repeat until the grade is roughly B
/completeness-report                 # required — checks every claim against a code graph
/fix-knowledge-extraction            # folds the completeness findings in
/resolve-open-questions extraction
/publish-knowledge-base
```

**What to look at, in this order**

1. **`extraction/extraction-quality/index.md`** — the quality report, before any extraction document. Grade, critical issues, and the four cross-checks a human would not think to run: CHECK-04 (references to things that do not exist), CHECK-05 (contradictions between documents), CHECK-07 (diagrams that do not render) and CHECK-08 (broken links). They tell you *where* to look ([the fifteen checks](#what-the-quality-agent-checks)).
2. **`extraction/project-profile.json`** — what the first agent concluded about the project. Anything unusual that it missed — work dispatched from a rule table, a folder layout that breaks convention — goes in here, and then you re-run the agents it affects ([the project profile](#the-project-profile--your-single-biggest-quality-lever)).
3. **`extraction/risk-gap/index.md`** — usually the first genuinely new insight for the client, and a good first checkpoint conversation.
4. **`extraction/completeness-report/index.md`** — once you have run it. `TOTALLY_WRONG` and `INACCURATE` claims first, then the entities the code graph found that no extraction folder mentions.
5. **The source-gap list, and the open-questions register.** Together they make your first batch of SME questions — take them to one session, not five emails ([§5.2](#52-sme-input--when-you-need-a-human-expert)).

> **Decision point — is extraction good enough to build on?** The bar is grade **B or better, zero critical issues, and a human completeness review** — which is what Chapters 3 and 4 are ([Gate 1.1](#stage-1112--knowledge-extraction-and-quality-gate)). Do not accept a C: no later stage re-reads the code, so every error here is inherited downstream.

> **Decision point — when to run the completeness report?** It is not optional — the quality grade only proves the knowledge base is consistent with itself, not that it is true. Run it **once the grade is roughly B**: earlier, it duplicates what the fix loop would catch; later, you have started building on unchecked claims. Its findings go straight back into `/fix-knowledge-extraction`. If the client's environment will not allow the `graphify` CLI, record that as an exception at Gate 1.1.

**If it goes wrong**

| You see | Do this |
|---|---|
| Grade C or below | Usually missing input, not a broken agent. Check what you failed to supply — most often the database — then re-run |
| An agent missed a whole area | Re-run that one agent with a note naming what it missed |
| The same mistake comes back every pass | Write the fact into the project profile, or edit the agent definition, then re-run that agent. Hand-correcting the same error twice means the instructions need fixing |
| Two agents contradict each other | Re-run with a directive naming the contradiction — it marks something genuinely unclear in the code |
| A database export turns up in week three | Drop it in, re-run the affected agent, re-validate. A re-run, not a restart |

## Chapter 3 — Review the technical stream

*Part of Gate 1.1 · architect or tech lead, then reviewed with the client's system SME, data owner and operations lead · runs alongside Chapter 4*

Once extraction is clean, the review splits by **direction**: one person takes the technical side, another the product side, and the two streams run in parallel ([§1.4](#14-running-this-with-a-team)). This stream answers one question: **is the reconstructed system the real system?** Everything Phase 2 designs is built on these folders, and nothing after Phase 1 reads the code again.

**What you run**

Nothing new. You read, compare against what you know, and re-run single agents where something is missing. Use the published site for the walk-through with the system SME — people correct a claim on screen far more readily than they answer an abstract question.

**What to look at, folder by folder**

| Folder | Open | Check it against |
|---|---|---|
| `extraction/architecture/` | `index.md` — architectural style, the C4 context diagram, the per-domain layers and coupling points | Your own sketch of the system. A component you know exists but is not on the diagram is a gap |
| `extraction/data-model/` | `index.md` — entity count, the ER diagram, which module owns each table | **The real number of database tables.** Same ballpark, or material is missing — usually the database itself |
| `extraction/data-flow/` | `index.md` — the critical paths | One business transaction you know, traced end to end: where the data comes in, how it changes, where it lands |
| `extraction/integrations/` | `index.md` — every contract and the external-dependency summary | **Every external system you know of.** An integration missing here will have no coexistence answer at Stage 2.2 |
| `extraction/functional/` | the per-module files — APIs, background jobs, commands | The API list and the scheduled jobs the operations team runs |
| `extraction/ui-ux/` | **The legacy application's existing UI, as it is today** — not the future UI. `index.md` holds the screen inventory, the navigation diagram, and the client-target matrix where there is more than one front end; then `navigation.md` | **The real screens of the legacy application.** Open it, or ask a user for a tour, and count. The most commonly under-extracted area — and the record of the behaviour the replacement has to cover |
| `extraction/security/` | `index.md` — overall risk level and top risks | How access control is actually enforced, not how it is documented |
| `extraction/runtime-operations/` | `index.md` — deployment model, configuration, scheduling | What the operations team tells you actually runs in production |
| `extraction/ai/` | `index.md` — product AI and engineering AI side by side, inventory counts, top AI risks; then the area files (providers, agents and flows, tools and MCP, prompts, RAG, evals, harness), and from Phase 2b `flows-<cluster>.md` / `rag-<cluster>.md` plus `clusters/` (manifest, merged result, per-cluster partials) | Every model, agent, prompt and MCP server the team knows about. On a system with no AI it holds a one-line "No AI components detected" — that is correct, not a gap, and it does not count against the grade |
| `extraction/knowledge-graph/` | `index.md` — the system diagram and the confidence distribution | Relationships that cross folders. A cluster with almost no `HIGH` findings is where to spend SME time |

On the UI specifically: this folder documents **the current, legacy UI only** — what exists today, extracted from the old code. It says nothing about how the future UI should look; that is decided later, in the target architecture and, on the demo track, in the clickable mockup the client agrees. Review it as a record of today's behaviour: pick one legacy screen you know well and check that its buttons lead to the backend calls you would expect. That interaction-to-backend linkage is what lets a new front-end team reproduce the behaviour on a new stack.

**Review it with the client's SMEs**

Your own review finds what is missing. Only the client's people can confirm what is *right* — why the code is shaped like this, what is genuinely dead, and what runs in production. Gate 1.1 is approved by the architect **with SME confirmation on the gap list** ([who approves what](#sign-off-practices)).

| Folder | Review it with | What only they can confirm |
|---|---|---|
| `architecture/`, `functional/`, `ui-ux/` | **System SME** — often the last remaining maintainer | Undocumented conventions, what is dead code, how parts that look unreachable are actually invoked. For the UI, a walk-through by someone who uses it daily |
| `data-model/`, `data-flow/` | **Data owner / DBA** | The data model as it really is, which behaviour lives in the database, ownership, volumes and data quality |
| `integrations/` | **System SME**, plus the owners of the external systems where you can reach them | Which interfaces are still live, who consumes them, and which contracts cannot change |
| `runtime-operations/`, `security/` | **Operations / infrastructure** | Deployment reality, environments, scheduled jobs, how access is really granted — and what genuinely cannot change |

How to run those sessions so they are short and useful ([Using SME time well](#using-sme-time-well)):

- **Prepare one batch per session.** The source-gap list, the `MEDIUM` findings that matter, the low-confidence clusters in the knowledge graph, and the open questions from `/resolve-open-questions extraction`. One list, one meeting — not five emails.
- **Ask evidenced questions, not open ones.** *"This procedure is never called from the code — is it invoked from a scheduler?"* takes two minutes. *"How does billing work?"* takes an hour and produces nothing you can act on.
- **Show it on the published site.** People correct a claim on screen far more readily than they answer an abstract question.
- **Record answers where the agents will read them.** A fact that changes how the code should be read goes into the project profile, followed by a re-run of the affected agent. An answer to a registered open question goes into the register, then `/resolve-open-questions extraction --apply`. An answer that lives only in meeting notes is lost.
- **Write down who confirmed what, and when.** The gap list needs a named owner per item before Gate 1.1 closes.

> **Decision point — supply the missing material, or proceed with a recorded gap?** Every count that comes up short means either a missing input or an agent that missed something. If the material exists, ask for it now; it will be a re-run later. If it does not — an external service, a binary, a database you will never be given — record it as a gap **with an owner**, so it arrives at Stage 2.1 as a known unknown rather than a surprise.

> **Decision point — reproduce the screens, or redesign them?** Settle this with the product owner before Stage 2.1, because it changes the front-end part of the architecture and the size of every UI story. Like-for-like behaviour with modern styling is the lowest-risk default, and the UI/UX extraction is built for it. A redesign is a product decision, and it needs its own design effort that this asset does not supply.

> **Decision point — should the new screens look like the client's product?** If yes, run **`/design-guide`**. It writes `knowledge-base/design-guide.md` — fonts, type scale, colours, spacing and component patterns taken from the existing UI source — and does not depend on the demo track. Pair it with a clickable mockup kept in `ui-mockup/`, and tell the implementation agents to match those screens ([Stage 2.0 · Step 4](#step-4--design-system-and-a-clickable-ui-only-demo), [Show the UI before you build it](#show-the-user-interface-before-you-build-it)).

**If it goes wrong**

| You see | Do this |
|---|---|
| Far fewer entities than tables | The database schema or procedures were not supplied. Get them, then re-run `data-model-agent` |
| Far fewer screens than the real application | Re-run `ui-ux-discovery-agent` with a note naming the screens or the UI technology it missed. If the UI framework is unusual, record it in the project profile first |
| Screens listed, but no backend calls against the buttons | The interaction-to-backend linkage is missing — CHECK-06 flags it as a thin modernization signal. Re-run the agent with that as the directive |
| An external system you know of is not listed | Re-run `integration-agent` naming it. If the connection is made from configuration rather than code, write that into the project profile first |
| Architecture and data model disagree about who owns an entity | Re-run both with a directive naming the contradiction — it marks something genuinely unclear in the code |

## Chapter 4 — Review the product stream

*Part of Gate 1.1 · product owner or business analyst, with the business SME · runs alongside Chapter 3*

The product stream answers a different question: **did the agents understand what the system is *for*, and which rules it enforces?** Do this validation yourself before any client-side expert sees it. Agents reconstruct what the code *does*; only people can say what is deliberate, what is an accident, and what nobody uses any more ([§1.5](#15-working-with-the-customer)). This is the material the capability split and the BRDs are built from, so a mistake here reaches the documents the client signs.

**What you run**

Nothing new — reading, and single-agent re-runs. The published site is the easiest way to walk a business SME through it.

**What to look at, in this order**

1. **`extraction/business-intent/index.md`** — the system's business purpose, its domains, the user personas and the inferred capabilities. Read it as the client would describe their own system. If it reads like a description of the code rather than of the business, the capability split will too.
2. **The feature list.** Before opening `extraction/functional/`, write down the application's top ten features from memory. Then check that every one is present.
3. **`extraction/business-logic-rules/index.md`** — the rule count by category and the key workflows. Then open the per-module files for the areas the client cares most about.
4. **Validate the evidence yourself.** Pick three to five rules marked `HIGH` and open the code they cite. If they do not match, nothing else marked `HIGH` can be trusted either. Rules marked `MEDIUM` were inferred from names — list the important ones for the SME.
5. **`business-logic-rules/taskengine-inferred-mapping.md`** — present only when the system dispatches work from a rule table or configuration. If you know the system works that way and the file is missing, the most important rules are probably missing too. If it does not, the index should say so.
6. **`extraction/risk-gap/index.md`**, read for business risk — the risks the client will recognise as their own pain.

> **Decision point — which rules are deliberate?** Not every behaviour in the code is a requirement. Some are workarounds, some are bugs everyone learned to live with, and some serve a process that no longer exists. Take the doubtful ones to the business SME as **evidenced questions** — *"the code blocks the order when X and Y; is that deliberate?"* — not open ones. Whatever is decided drives the BRDs, so record the answer in the knowledge base, not in meeting notes.

> **Decision point — whose vocabulary?** If the business intent uses the code's names rather than the client's, fix that before the capability split, not after. Put the client's terms into the project profile and re-run `business-intent-agent`, or carry them straight into the feedback loop of Chapter 5.

**If it goes wrong**

| You see | Do this |
|---|---|
| A feature from your top ten is missing | Re-run `functional-discovery-agent` naming it, then `business-intent-agent`, which builds on its output |
| Rules you know exist are missing | Usually the rules live in the database — stored procedures, triggers, rule tables. Supply the export and re-run `business-logic-rules-agent` |
| Procedures look like dead code | A rule engine calls them from configuration. Write that into the project profile and re-run — the textbook case in [the project profile](#the-project-profile--your-single-biggest-quality-lever) |
| The business intent reads like a technical description | Re-run `business-intent-agent` with the client's own description of the system as the directive |
| A `HIGH` rule does not match the code it cites | Report it as a finding. Re-run the agent for that module, then spot-check twice as many rules on the next pass |

## Chapter 5 — Decide how the BRDs are split

*Stage 1.3 ★ · product owner and architect together, after a session with the client · the highest-leverage decision*

**Each capability becomes one BRD.** The capability split decides how the requirements will be packaged for sign-off: which documents exist, what each one covers, and who on the client side owns each one. Waves then group those capabilities for delivery. Everything downstream is organised by this split — BRDs, architecture, roadmap, estimate, epics — so an hour here saves days later ([Stage 1.3](#stage-13--capability-split-)).

A split derived purely from the code will be technically correct and still wrong for the client: the BRDs will cut across their organisation, and they will use names nobody recognises. So **talk to the client before you run the command**, and bring what you learn into it as input.

**The session with the client — four questions**

| Ask | Why it matters | What you feed into the split |
|---|---|---|
| **What language do you use for your own business?** The names of processes, products, sites and teams | The BRD titles and capability names are the words the client will read and sign. Language alignment is not the goal of the split, but a split in the code's vocabulary will not be signed | Their terms, pasted into the feedback: *"they call it core and site-specific — split on that"* |
| **Can you share documents?** Process maps, an organisation chart, a product catalogue, service descriptions, existing requirement documents | They show how the client already divides the business. Pointing the agent at one is faster and more accurate than describing it | The document itself: *"split it the way this describes"*. Convert Word files with `/parse-docx` first |
| **How would you like the BRDs split?** By business process, by product line, by organisational owner, by user group — or core vs site-specific | The BRDs are reviewed and signed by client people. A split that matches how they are organised gets reviewed; one that does not gets passed around | The chosen organising principle, stated as an instruction |
| **Who signs each one?** | A BRD with no obvious owner stalls at Gate 1.3 | A named owner per capability — if two owners need to sign one BRD, that is a hint it should be two |

**Principles for a good BRD split** — use them to judge each proposal round:

- **One accountable owner per BRD.** If nobody on the client side can sign it alone, the boundary is wrong.
- **Readable in one sitting, reviewable in one workshop.** A capability too big to walk through in a session should be split; one too small to fill a page should be merged.
- **Minimal overlap between BRDs.** The same workflow in two BRDs becomes a duplication finding at validation, and a contradiction later. Every behaviour has one BRD that owns it; the others refer to it ([what the BRD validator checks](#what-the-brd-validator-checks)).
- **Nothing orphaned.** Every feature area found in extraction belongs to some capability, so it will be covered by some BRD.
- **Deliverable as a unit.** Each capability has to sit inside one wave, so it cannot be so large that no wave can hold it.

**What you run**

```
/capability-split
```

It proposes, you give feedback, and it shows the full proposal again each round. **Nothing is written until you say "approve".** The session's answers are your feedback: the client's terms, their documents, the organising principle and the owners. Expect two or three rounds.

**What to look at**

1. **The capability list, read as a list of future BRDs.** For each one: could you name its client owner? Would it make a sensible workshop agenda? Does its scope overlap with another?
2. **The names.** Would the client recognise every capability and wave name?
3. **Orphans.** Every feature area found in extraction belongs to some capability.
4. **Wave 0.** It should be scaffolding only — infrastructure, security, test coverage, observability. If anything in Wave 0 depends on a later wave, the order is wrong.
5. **After approval:** `capabilities/index.md` for people, and `capabilities/summary.json` for the stages that follow. Confirm the JSON exists — `/export-for-alignment` reads it to offer the BRD list, and Stages 2.1 and 3.1 read it too.

> **Decision point — the organising principle.** Process, product line, organisational owner, user group, or core vs site-specific. The client's answer beats the agent's default every time, because it is the client who will read and sign the result. If they have no preference, choose the one that gives each BRD a single owner.

> **Decision point — must every wave end in something the client can watch?** If the client expects a demo at the end of each delivery wave, **you have to ask for it here**, in the feedback loop. The agent's default order is risk and dependency, which happily produces waves that each end in infrastructure. Wave 0 is exempt. The exact wording to paste is in [Ask for demoable waves](#ask-for-demoable-waves--say-it-out-loud).

> **Decision point — how many waves?** As many as the team you actually have can deliver. Six waves may be ideal on paper and undeliverable with three developers.

**If it goes wrong**

| You see | Do this |
|---|---|
| The names do not match how the client talks | Paste their vocabulary into the feedback, or point at one of their documents |
| A capability has two or three plausible client owners | Split it along the owners' boundaries, so each BRD has one |
| Two capabilities describe the same workflow | Merge them, or say which one owns the workflow — the BRD validator will flag the duplication otherwise |
| The client did not share documents | Proceed on their verbal answers and record the organising principle in the feedback; ask again when they review the first BRDs |
| You approved, and the target architecture later shows the waves are wrong | Re-run `/capability-split` — the second run offers review / modify / regenerate — then re-run and re-validate Stages 2.1 and 2.2. See [Re-runs](#re-runs--going-back-is-normal-work) |

## Chapter 6 — Requirements the business signs

*Stage 1.4 🟩 · product-owned · ends Phase 1*

One Business Requirements Document per capability, in business language with no technology in it — because it may end up driving a rebuild on a completely different stack ([Stage 1.4](#stage-14--business-requirements--product)).

**What you run**

```
/export-for-alignment                # no name: offers every capability, in batches of up to 10
/validate-brd
/fix-brd                             # corrections from the validation report
/fix-brd-readiness                   # strips technical coupling — always, before Phase 2
/validate-brd                        # confirm the score moved
/resolve-open-questions brd
/publish-knowledge-base
```

**What to look at**

1. **`business-capabilities/validation.md`** — the portfolio grade, then the duplication and conflict findings. Two BRDs specifying the same behaviour differently is the finding that causes trouble in delivery ([what the validator checks](#what-the-brd-validator-checks)).
2. **One BRD, read as a non-technical stakeholder would read it.** If they would need a translator, it is not finished.
3. **The gaps, risks and future-state sections.** These drive the workshop agenda — they are where the discussion happens.
4. **`business-capabilities/open-questions.md`** — its blocking questions gate both Stage 2.1 and the backlog. Clear them now rather than finding the stop later.

> **Decision point — workshop, or review by email?** Workshop. Send the BRDs ahead of time and drive the agenda from their gaps and risks. Review by email gets silence, and silence is not a sign-off ([Sign-off practices](#sign-off-practices)).

**If it goes wrong**

| You see | Do this |
|---|---|
| A BRD exposes something extraction never captured | Back to Chapter 2 — re-run the affected extraction agent, then regenerate that one BRD. `/export-for-alignment '<capability>'` touches only that capability |
| Class names or table names in the body | `/fix-brd-readiness`, then re-validate |
| A BRD is regenerated after sign-off | The earlier approval no longer applies. Say so and get it signed again — it is cheap now and expensive later |

## Chapter 7 — Design the target

*Stage 2.1 · led by the architect, approved by the architecture board · the only hard stop*

The agent designs the replacement from the knowledge base plus **direction you supply** — it does not choose the client's technology strategy ([Stage 2.1](#stage-21--target-state-architecture)).

**What you run**

```
/brainstorm-target                         # optional — pressure-test the direction first
/target-state-architecture
/validate-architecture
/validate-architecture-completeness
/validate-architecture --fix               # then re-validate both
/validate-architecture-completeness --fix
```

**What to look at, in this order**

1. **The plan, before anything is written.** The agent asks up to five questions, then shows a document plan and writes nothing until you confirm. Read it — correcting the plan costs far less than correcting a finished architecture.
2. **The read receipt** in the traceability appendix: every knowledge-base folder marked `READ` or `SKIPPED — <reason>`. It is the fastest way to spot a whole area that was ignored. Check `ui-ux/` by name.
3. **`target-state/architecture/completeness-validation.md`** — the **READY / NOT-READY** verdict. It overrides the score: a single unmapped entity makes it NOT-READY.
4. **The dispositions.** The validator confirms that every entity has a decision. Only you can spot a `Retire` on something the business depends on, or `Defer` used as a dumping ground.
5. **`target-state/architecture/validation.md`** — any check marked `UNVERIFIED` never ran. Fix the tooling and re-validate; do not bank that score.

> **Decision point — the six inputs.** Platform and hosting, technology stack, architecture style, migration strategy, primary drivers, and what is out of scope ([the six decisions](#before-you-start--the-six-decisions)). Hold a one-hour decision meeting with the client's enterprise architect and operations lead **before** running anything. Finding out halfway through the run that nobody has decided the hosting model wastes the whole stage.

> **Decision point — no client available to decide?** Common in pre-sales. Ask for a modernization options study first — minimal intervention, partial re-platforming, full re-platforming — pick one scenario, and hand it to the command as your direction. `/brainstorm-target` then argues the choice against the extraction evidence and records it as ADRs. **Label the result as your opinion in the proposition**, not the client's.

> **Decision point — do the waves still fit?** Designing the target often shows that the wave split is wrong. If it does, go back to Chapter 5 now. It is cheap before epics exist and expensive after.

**If it goes wrong**

| You see | Do this |
|---|---|
| NOT-READY despite a high score | Good news — it found a gap before you planned on it. Map the item, or record an explicit `Defer` **with an owner and a date** |
| Grade capped at B, with `UNVERIFIED` | A validator's tooling (usually the Mermaid CLI) was missing. Install it and re-validate |
| A blocking open question stops the run | Answer it with `/resolve-open-questions <scope> --interactive`, then `--apply`, then retry ([§5.4](#54-troubleshooting)) |

## Chapter 8 — Show, don't tell: the demo track 🎬

*Stage 2.0 · optional, runs alongside Chapters 7 and 9 · no gate of its own*

A small, working, clickable version of the future system, built **while the proposition is still being written**, so the client decides from something they can use. It also tests the technology early: you find out whether the target stack works for this domain before anyone commits to it ([Stage 2.0](#stage-20--the-demo-track--optional-run-in-parallel-)).

> **Decision point — build a demo at all?** Build one when the client needs convincing, when the target stack is unproven for this domain, or when the decision-makers do not read architecture documents. Skip it when the proposition is a like-for-like re-platform the client already believes in. Budget it in days, not weeks — its value is the feedback, and the feedback arrives at the first showing.

**What you run, in order** — five moves, and the order matters

1. **Scope it.** Research the flows against a budget, then take them to the client:
   ```
   /research <goal, audience, business outcome — and the budget as numbers: N weeks, N engineers, stack>
   /demo-plan <domains · stack · audience · timeline · out of scope> --design-guide
   ```
2. **Show the UI first — clickable HTML, no code.** Build a UI-only mockup of every approved flow in `ui-mockup/`, styled from `design-guide.md`, and walk the client through it until they agree the screens and the flow ([Steps 4–5](#step-4--design-system-and-a-clickable-ui-only-demo)). Nothing else is generated until they do.
3. **Plan it on the demo track:**
   ```
   /transformation-roadmap demo
   /create-epic-backlog demo
   /resolve-open-questions epics demo
   ```
4. **Generate stories, one epic at a time** — in the analysis repository, where the knowledge base and its gates live:
   ```
   /story-intent demo/wave-01/epic-01
   ```
5. **Link or copy into the implementation repository, enforce, then build there.** The demo is built in a separate repository. **Copy** each epic's stories into `knowledge-base/target-state/backlog/demo/` there — the implementation commands write status into them and commit it with the code. **Link or copy** the demo target architecture, `design-guide.md`, `ui-mockup/` and the flow descriptions. Add standing rules to its `CLAUDE.md`: follow the architecture, match the mockup, use only the design guide's styles, no screens that were not agreed ([Step 8](#step-8--link-or-copy-the-plan-into-the-implementation-repository-and-enforce-it)). Then, in the implementation repository:
   ```
   /new-story-spec … → /new-story-impl … → /archive-implemented
   /add-features "<what the client asked for after the first showing>"
   ```
   And from the analysis repository, once the stories are copied back: `/publish-knowledge-base demo`.

**What to look at**

1. **`research/<slug>.md`** — the proposed flows, each with what it proves *and what it does not*. If a flow does not fit the budget, it should not be on the list.
2. **The flow table `/demo-init` prints** — the one machine-enforced gate in the run. Nothing downstream happens until you approve it. Add, drop, merge, rename or re-rank here.
3. **`demo/demo-overview.md` and `demo/business-flow/flow-NN-*.md`** — presenter-ready business descriptions, with no technical detail. You can rehearse the showing from these.
4. **The clickable screens in `ui-mockup/`, with the client** — do they look like the client's product, and does each flow run the way their users work? This is the review that matters most on the demo track: it is the last point where changing the flow costs hours rather than days.
5. **The implementation repository, before the first story** — are the stories at `knowledge-base/target-state/backlog/demo/`, are the architecture, mockup and design guide present, and do the `CLAUDE.md` rules point at them by path?
6. **`target-state/architecture/demo/` against the programme architecture.** Comparing the two shows the client exactly what the demo does and does not prove.

> **Decision point — is the UI agreed?** Only when the client has clicked through every flow and said yes to the screens, in writing. Until then, change the mockup — not the backlog. Generating epics and stories against screens the client has not seen means rewriting them after the first showing.

> **Decision point — which flows?** The client's call, not yours. Take the list to them **before generating anything**. They will add one, drop one and re-rank the rest — that is the point of asking. If the change is material, re-run `/research` or amend the note, so the evidence the agents read matches what was agreed.

> **Decision point — the scope moves mid-build.** It will: the client sees the first flow and asks for something next to it. Use `/add-features`, not a re-run of the backlog. It scans for duplicates first, asks which track to change, and edits only `Draft` stories on a new branch.

**If it goes wrong**

| You see | Do this |
|---|---|
| The proposed demo is far too big | The budget was given as adjectives. Re-run `/research` with weeks and people as numbers |
| `/create-epic-backlog demo` refuses to run | Capabilities and BRDs are shared, not demo-scoped — Phase 1 must exist first ([What a track scopes](#what-a-track-scopes--and-what-it-does-not)) |
| Generated screens ignore the mockup | Check the `CLAUDE.md` rules exist in the implementation repository and name `ui-mockup/` by path. Then have the specification redo its task breakdown against it |
| `/new-story-spec` cannot find the story in the implementation repository | Stories must sit at exactly `knowledge-base/target-state/backlog/demo/` there. Copy them to that path, then retry |
| Story statuses in the analysis repository are out of date | Expected — the implementation repository's copy is the live one. Copy the stories back before publishing |
| The client changes the UI after stories exist | Update the mockup first — in one place if it is linked, in both if copied — then run `/add-features` in the implementation repository. It edits only `Draft` stories |
| Someone extrapolates demo velocity across the programme | Stop them. The demo deliberately skipped the hard parts — **a demo is not an estimate** |

The track argument is not uniform across commands — `/story-intent` takes a path prefix and `/validate-backlog` takes the track before the wave. Keep [the argument table](#programme-run-vs-demo-run--the-same-commands-different-arguments) open while you run it.

## Chapter 9 — Sequence, size and propose

*Stages 2.2–2.3 · architect and PM, then the client · ends Phase 2*

`/transformation-roadmap` produces the phased roadmap — the wave-level work breakdown — and **automatically chains `team-estimation-agent`**. That agent staffs the same breakdown three ways: Cost-Optimized, Time-Optimized, and Safe & Realistic, each PERT-estimated against formal grade bands ([Stage 2.2](#stage-22--transformation-roadmap-and-work-breakdown), [Stage 2.3](#stage-23--estimation-and-proposition--human-decision--agent-assisted)).

**What you run**

```
/transformation-roadmap
/generate-estimate-excel             # the rate-calculator workbook, verified against the JSON
/progress-report                     # optional — a steering-committee deck structure
/publish-knowledge-base
```

**Have these answers ready — no agent can infer them:** migration constraints and any fixed deadline, team topology, the client's risk appetite, and anything out of scope.

**What to look at**

1. **`target-state/transformation/migration-waves.md`** — every wave has a scope and key deliverables, not just a name and a position. Every capability appears in exactly one wave.
2. **The rollback strategy.** Walk through one wave's rollback out loud with the delivery team. If it cannot be described in plain steps, it does not exist.
3. **`coexistence-strategy.md`** — every integration found in Phase 1 needs an answer for the period when both systems are live. This is where real programmes fail.
4. **`wbs.md` and `team-estimate-comparison.md`** — the three options side by side. No currency figures means no per-band rate card was found in the knowledge base; the agent reports that rather than inventing rates.

> **Decision point — the migration strategy.** Gradual replacement, phased cut-over, or old and new running in parallel. Each produces different waves, different deliverables and a different backlog. The agent asks; the client decides.

> **Decision point — which option do you propose, and at what number?** The agent supplies the options. You **calibrate them against your own delivery history**, decide whether you believe the Gen-AI acceleration assumptions for this client, and make the high-severity risks a visible contingency line. The proposition is a **range**, because it is estimated from wave scope, not stories. Say so, and narrow it wave by wave as each backlog is built.

**What you walk the client through at Gate 2.3:** the target architecture (READY), the roadmap with rollback, the estimate with its assumptions, exclusions and contingency, the Phase 1 risk register, the demo if you built one — **shown, not described** — and the published site, which is what you present from ([Gate 2.3](#-gate-23-checklist--proposition-sign-off-ends-phase-2)).

**If it goes wrong**

| You see | Do this |
|---|---|
| Roadmap waves disagree with the capability split | Reconcile now. Re-run `/capability-split` if the split is what is wrong, then the roadmap |
| The client challenges a line of the estimate | Show the WBS line and the PERT range behind it. That traceability is why the estimate is built on a breakdown |
| Deferred items from Stage 2.1 are not in the estimate | Estimate each one, or exclude it explicitly in writing. Deferred work is not free |

## Chapter 10 — Deliver, one wave and one story at a time

*Stages 3.1–3.4 · engineering, with PM and product on the backlog*

Once the proposition is signed, delivery starts with the first wave only. Refining wave 4 while wave 1 is being built wastes the work, because wave 1 will change your mind about wave 4 ([Part IV](#part-iv--phase-3--implementation)).

> **Decision point — which repository?** Modernizing in place: carry on in the existing repository. Re-platforming onto a new stack: **a new repository** that carries `target-state/` and the plan, while the old repository keeps the current-state knowledge. Decide this **before** generating the backlog, so it is generated where it will be worked ([Decide first](#decide-first-which-repository-does-phase-3-happen-in)).

> **Decision point — who builds it?** The same backlog can go to the story-by-story SDD loop in this manual, to the Software Factory asset for automated implementation, or to an ordinary delivery team using the Jira-ready `epics.csv`. Nothing upstream changes. What changes is who reviews the code ([Gate 3.1 is a hand-off point](#gate-31-is-a-hand-off-point-not-only-a-checkpoint)).

**What you run, per wave**

```
/resolve-open-questions epics        # before the epics — one open question here reaches every story
/create-epic-backlog
/story-intent wave-01
/validate-backlog wave-01
/resolve-open-questions stories
```

**Then, per story**

```
/new-story-spec                      # picks an unblocked story, opens a merge request with the spec
/new-story-impl <branch-name>        # implements it; resumes where it stopped
/archive-implemented                 # updates the master specs, merges, closes the story
```

**What to look at**

1. **The epic proposal, before approving it** — especially the *coverage gaps* (deliverables with no matching BRD) and the cross-wave dependencies.
2. **`backlog/plan.md` and `epics.csv`** — the plan the PM loads into the tracker.
3. **Each epic's `STORIES-PLAN.md`** — the story split you approve. The stories are generated to match it exactly.
4. **`backlog/validation.md`** — structure, dependencies and traceability back to capabilities and rules ([what it checks](#what-the-backlog-validator-checks)).
5. **Every merge request** — a human code review per story is Gate 3.2. If a UI story ignores the mockup, send it back.

> **Decision point — re-baseline the estimate.** When a wave's stories exist, replace that wave's estimate with the bottom-up roll-up and tell the client the range narrowed, and why. It is the honest follow-through on the range you proposed.

**If it goes wrong**

| You see | Do this |
|---|---|
| A few epics need changing | `/create-epic-backlog` Update Mode touches only 1–3 epics — do not regenerate the wave |
| New scope arrives mid-wave | `/add-features` — `Draft` stories only; anything locked becomes a follow-up for a person to decide |
| The wave is the wrong shape to build | Back to Chapter 5. This is the expensive loop-back — see below |
| An implementation command refuses to run | Not on `main`, or uncommitted changes. Commit or stash, then switch to `main` |

## Research — extra knowledge, at any stage

*Any stage · anyone on the team · no gate*

Every chapter above will leave you with questions the pipeline was not built to answer: how a business flow really hangs together, whether a candidate technology suits this system, what comparable products offer that this one lacks. **`/research` turns a question like that into a cited note in the knowledge base**, where later stages and people can use it. It is not a step in the sequence — run it whenever you want knowledge you intend to use further on.

**What you run**

```
/research <the question — plus the goal, the audience, and the decision it will inform>
```

It **always asks clarifying questions first** — scope, interpretation, the documents to include, the claims to check — and it does not research until you have answered. It then writes one note to `knowledge-base/research/<slug>.md`. Each run writes a new note; earlier notes are never overwritten.

**What it works from — know this before you trust a note**

| Source | How it is used |
|---|---|
| **The knowledge base** | The primary source: extraction, capabilities, BRDs, earlier research notes |
| **Documents you supply** | Analyst reports, vendor documentation, competitor product sheets, the client's strategy papers. Give the paths, and say whether they **override** the knowledge base or are just inputs |
| **The source code** | A fallback, used only to close a specific gap, and cited to the line |
| **The web** | **Background only** — how a named platform or framework works, what a market generally offers. Marked as external, and never used as a fact about the client's system |

**When to use it — and where the note goes next**

| When | Example question | Where the note is used |
|---|---|---|
| After extraction (Chapters 2–4) | *"How does an order move from capture to invoice, which rules touch it, and where are the gaps?"* | Your SME sessions, and the product stream review |
| Before the capability split (Chapter 5) | *"Which business flows share data or depend on each other so tightly that one BRD should own them?"* | Pass the note's path into the `/capability-split` feedback |
| Before the target architecture (Chapter 7) | *"Compare these two candidate stacks against our integrations, data volumes and the client's team skills"* | Pass the path as part of your direction to `/target-state-architecture`, or argue it out with `/brainstorm-target` |
| While writing BRDs or the target (Chapters 6–7) | *"Which features do comparable products offer that this system lacks?"* — with the competitor material supplied | The future-state discussion in the BRD workshop. Label competitor findings as external in anything the client reads |
| Before the roadmap (Chapter 9) | *"Which flows should be modernized first, in what order, and what depends on what?"* | Read **automatically** by `/transformation-roadmap` as a directed input to wave membership and sequencing |
| Scoping the demo (Chapter 8) | The budget-bound flow proposal | Read **automatically** by `/demo-init` |
| Reporting | — | `/progress-report` uses a note's headline answer and gaps; `/publish-knowledge-base` gives research its own page on the site |

**What to look at**

1. **The headline answer and its confidence** — High, Medium or Low for each finding.
2. **The citations.** Open two or three. Anything that carries no knowledge-base or document citation is background, not evidence.
3. **The gaps section.** What the knowledge base cannot answer. Those become SME questions or material to ask for.

> **Decision point — research, or ask an SME?** Research works from what is written down. If the answer is only in someone's head, the note will come back mostly gaps — which is still useful, because it tells you exactly what to ask. Use `/research` to prepare an evidenced question, and the SME to answer it.

> **Decision point — research, or a decision?** `/research` gathers and grades evidence. It does not choose for you. When the question is *which* option to pick — a stack, a pattern, a migration strategy — take the note into `/brainstorm-target`, which argues the choice against the evidence and records it as ADRs.

**If it goes wrong**

| You see | Do this |
|---|---|
| The note is mostly gaps | The knowledge base does not hold the answer. Supply documents, or take the gaps to an SME |
| The answer is generic | The question was too broad. Re-run with the goal, the audience and the decision it has to support |
| Web material reads like fact about the client's system | Challenge it — it should be marked as external background. Re-run with that correction |
| A decision was made that contradicts an existing note | Agents that read the note treat it as evidence. Re-run `/research` or amend the note, so it matches what was agreed |

## Re-runs — going back is normal work

The phases are sequential, but **going back is normal work, not failure**. Every command notices what already exists and adapts rather than starting over ([§1.2](#12-agents-can-be-run-as-many-times-as-you-need)).

```mermaid
flowchart RL
    B1["<b>Stage 2.1</b><br/>Target architecture"]:::a
    B2["<b>Stage 2.2</b><br/>Roadmap"]:::a
    C1["<b>Stage 3.1</b><br/>Backlog for a wave"]:::a
    A1["<b>Stage 1.1</b><br/>Extraction"]:::a
    A2["<b>Stage 1.3</b><br/>Capability split ★"]:::a
    A3["<b>Stage 1.4</b><br/>BRDs"]:::p
    A3 -.->|"a BRD exposes a gap in what was extracted"| A1
    B1 -.->|"the waves do not fit the architecture"| A2
    C1 -.->|"the wave is the wrong shape to build"| A2
    A2 ==>|"re-run it — then re-run and re-validate 2.1 and 2.2<br/>on the new wave shape"| B2
    classDef a fill:#0070ad,stroke:#005281,color:#ffffff
    classDef p fill:#00857d,stroke:#00655f,color:#ffffff
```

What a change costs depends on how far downstream you have got:

| When you change your mind | What has to be re-done |
|---|---|
| A fact in extraction, before the capability split | Re-run that one agent, re-validate. Nothing downstream exists yet — this is nearly free |
| **Wave shape, after the architecture exists** | Re-run `/capability-split`, then re-run and re-validate **architecture and roadmap** — both read `capabilities/summary.json` |
| Wave shape, after epics exist | All of the above, **plus re-deriving that wave's backlog**. This is the expensive one — it is why Gate 1.2 is marked ★ |
| Demo or backlog scope, mid-build | `/add-features` — scans for duplicates first and edits only `Draft` stories, on a new branch |

**Habits that keep re-runs cheap:**

- **Prefer targeted re-runs.** One extraction agent, one BRD, 1–3 epics in Update Mode. A full regeneration also throws away reviews people already did.
- **Fix the cause, not the output.** A fact written into the project profile reaches every agent. A hand-edited document reaches no one.
- **Re-sign after a material change.** A regenerated stage voids its earlier approval. Say so and get it again.
- **Start a fresh session between stages.** Everything a stage needs is on disk. A long session compacts its own memory, and the agent quietly stops opening the documents.

## Three rules explain the rest

1. **Only Phase 1 agents read source code.** Everything downstream works from the knowledge base alone. Fix a wrong fact once, in Phase 1, and every later document inherits the correction.
2. **`summary.json` is the contract between stages.** Prose is for humans; the JSON is the machine interface. When it is missing, the *next* stage degrades quietly — confirm it exists.
3. **Planning stops at the wave until delivery starts.** The proposition is signed on waves (stage 2.2). Epics and stories are produced per wave, as that wave enters delivery (stage 3.1) — refining wave 4 while wave 1 is still being built throws the work away.

The full agent map — all 37 agents, the stage each runs in, and where each gate sits — is [§1.6](#16-the-37-agents-and-the-stages-they-run-in).

## Where to go next

| If you want… | Go to |
|---|---|
| Why this exists and what it replaces | [§0.1 The business case](#01-the-business-case) |
| The vocabulary — capability, wave, gate, disposition | [§0.9 Glossary](#09-glossary) |
| How to steer agents, and what validators actually check | [Part I](#part-i--how-the-process-works) |
| The full re-run table, command by command | [§1.2 Agents are re-runnable](#12-agents-can-be-run-as-many-times-as-you-need) |
| Who you need from the client, and when | [§1.5 Working with the customer](#15-working-with-the-customer) |
| To start running it | [Part II · Stage 0](#stage-0--host-readiness-plugin-init) |
| One page to keep open while you work | [§5.6 Quick reference card](#56-quick-reference-card) |

---

# Part I — How the process works

## 1.1 The core loop

Every stage in all three phases follows the same five steps. **Steps 3–5 are not optional.**

```
   ┌──────────────────────── re-run as often as needed ───────────────────┐
   ▼                                                                      │
┌────────┐   ┌──────────┐   ┌───────┐   ┌────────────┐   ┌──────┐        │
│ 1 RUN  │──▶│2 VALIDATE│──▶│ 3 FIX │──▶│ 4 HUMAN    │──▶│5 GATE│──▶ next│
│ agents │   │automated │   │ loop  │   │ COMPLETE-  │   │pass/ │  stage │
│        │   │  score   │   │       │   │ NESS REVIEW│   │fail  │        │
└────────┘   └──────────┘   └───────┘   └────────────┘   └──────┘        │
                                 │                           │           │
                                 └────── re-validate ────────┴───────────┘
```

| Step | What happens | Who does it |
|---|---|---|
| **1 · Run** | You type one command; its agents generate the artifacts. **On a re-run you can also tell it what was missed or should be improved** | Operator |
| **2 · Validate** | A validator agent checks **quality and completeness** — not just a score — and lists the specific issues it found | Automated |
| **3 · Fix** | Run the fixer, then **re-validate**. Repeat until the issues are closed | Automated |
| **4 · Human completeness review** | A person checks the output is *actually complete* against what they know exists | Architect / PM / SME |
| **5 · Gate** | Apply the written exit criteria. Pass → next stage. Fail → back to step 1 or 3 | Architect / PM |

### Step 1 takes direction, not just a command

Every stage can be re-run **with your own instructions about what is missing or wrong**. That is the main way a human steers the pipeline — you are not limited to accepting whatever the first pass produced.

- **Name the problem directly.** Fix commands accept an explicit description (*"this document duplicates the workflow that belongs in that one"*) and treat it as the priority instruction, rather than only working from the validation report.
- **Describe a targeted change.** `/create-epic-backlog` Update Mode takes a change request and touches only the affected epics.
- **Point out what an agent missed.** Re-run a single extraction agent with a note about what to look for — a subsystem it skipped, a folder of procedures it never opened.
- **Give an agent more context permanently.** Write the fact into the [project profile](#the-project-profile--your-single-biggest-quality-lever) so every agent sees it, or edit the agent definition itself. Then re-run just that agent. Fixing the instructions beats hand-correcting the same error twice.
- **Reject and re-shape a proposal.** `/capability-split` and `/story-intent` both loop on your feedback until you approve.

### What "validate" actually covers

A validator is not a spell-checker producing a number. Across the pipeline they check **completeness** (is anything missing?), **consistency** (do the documents agree with each other?), **traceability** (can every claim be traced to its source?) and **coverage** (does every extracted thing have a decision recorded against it?). The score is a summary of that work — **the issue list beneath it is the part you act on.**

**Every validate step in this manual lists the checks it actually runs**, with their weights and what a failure means — [extraction](#what-the-quality-agent-checks) (fifteen checks), [BRDs](#what-the-brd-validator-checks), architecture ([form](#what-the-form-validator-checks) and [coverage](#what-the-completeness-validator-checks)), and the [backlog](#what-the-backlog-validator-checks). Read the relevant table before arguing with a score: most disputes turn out to be about what was being measured.

**Grades mean the same thing everywhere:**

| Grade | Score | Interpretation |
|---|---|---|
| **A** | 90–100 | Good. Proceed after human review |
| **B** | 75–89 | Acceptable. Read the issues first |
| **C** | 60–74 | Not good enough. Fix before proceeding |
| **D / F** | < 60 | Something is fundamentally wrong — usually missing input, not a bad agent |

> ⚠️ **The single most common mistake is treating a good score as a passed gate.** It is not. See §1.3.

## 1.2 Agents can be run as many times as you need

Nothing here is one-shot. **Re-running is the normal way to work**, not error recovery. Every command notices what already exists and adapts rather than starting from scratch.

| Command | What happens when you re-run it |
|---|---|
| `/plugin update modernization-cli-cap` | Safe to repeat — pulls the latest version whenever the asset updates |
| `/knowledge-extraction` | Re-runs the full pipeline; single agents can also be re-run alone |
| `/fix-knowledge-extraction` | Run repeatedly; exits immediately if nothing is wrong; only re-runs affected areas |
| `/capability-split` | Second run offers review / modify / regenerate instead of starting over |
| `/export-for-alignment` | Per capability — re-run regenerates just that one; naming none offers a batched re-run across all capabilities |
| `/validate-*` | Any number of times. **Always re-validate after a fix** |
| `/fix-brd`, `/fix-brd-readiness`, `--fix` | Apply corrections, then re-validate to confirm the score moved |
| `/target-state-architecture` | Re-run regenerates; the approval gate fires again |
| `/transformation-roadmap` | Re-run regenerates; the approval gate fires again |
| `/create-epic-backlog` | **Update Mode** — targeted changes to 1–3 epics without touching the rest |
| `/story-intent` | Skips epics already done; only re-runs what is incomplete |
| `/new-story-impl` | Resumes from where it stopped; never repeats completed work |
| `/research` | Each run writes its own note — earlier notes are never overwritten |
| `/demo-plan` | Idempotent by step: skips the demo architecture if it already exists, re-does the flow documents |
| `/demo-init` | Re-scopes an existing demo; the flow approval gate fires again |
| `/demo-flows` | Per flow — `/demo-flows flow-02` rewrites just that description |
| `/design-guide` | Regenerates the style guide from the current UI source |
| `/add-features` | Repeatable; each run overwrites its own findings scan, then only edits `Draft` stories |

**Practical advice**

- **Iterate Phase 1 until it is genuinely good.** It is the foundation of everything and the *only* phase that reads source code. Two or three passes is normal, not a sign of failure.
- **New information arriving late is a re-run, not a restart.** A database export turns up in week three? Drop it in, re-run the affected agent, re-validate.
- **Prefer targeted re-runs to full regeneration.** Cheaper, faster, and it does not invalidate reviews people already did.
- **Start a fresh session between stages.** This is not housekeeping — it is a quality control. Everything a stage needs is already in the files on disk, so nothing is lost by clearing. What you avoid is the failure mode where a long session compacts its own memory and the agent quietly **stops opening the documents altogether**, working from a summary of a summary instead. Clear between stages, every time.

## 1.3 Automated scores do not prove completeness — humans do

A validator checks what can be checked mechanically. It cannot know what the system is *supposed* to contain.

| A validator can tell you | Only a human can tell you |
|---|---|
| Every required section is present | Whether the content is *right* |
| Every entity has a disposition recorded | Whether that disposition is *sensible* — e.g. a `Retire` on something business-critical |
| The diagram syntax is valid | Whether the diagram describes the real system |
| 47 capabilities are documented | That a 48th exists and nobody extracted it |
| A check could not be run | Whether that matters |

**Three markers exist purely to hand work back to a person. Collect them after every validation run:**

| Marker | Where it appears | What it means |
|---|---|---|
| **source gap** | Extraction output | The implementation is not in the repository. Needs an SME or a missing file |
| **`Unresolved Items (require stakeholder input)`** | Validation reports | The validator refused to guess |
| **`REVIEW REQUIRED`** | Architecture documents after a fix run | A gap was *recorded*, **not closed**. Needs an owner |

> A `Defer` decision added automatically records a gap; it does not resolve it. Never pass a hard gate on deferred items that have no owner and no date.

## 1.4 Running this with a team

The asset runs **locally, on each person's machine** — there is no central server. Work is shared the ordinary way, through a repository. That shapes how you divide it up.

| Stage | How to divide it |
|---|---|
| **Extraction** | **One person runs it. Everyone else waits.** There is nothing to gain from two people running it simultaneously — it is simpler and cheaper for one person to run it and share the result |
| **After extraction** | Split by **direction**: one person takes the product side (capabilities, BRDs), another the technical side (architecture, risk). There is a lot of material and it divides cleanly |
| **Demo track** (§2.0) | Runs **alongside** the main Phase 2 work, usually one person on the mockup and demo build while another takes the end-state architecture and roadmap |
| **Backlog** (stage 3.1) | Split by **wave** — different people can generate different waves in parallel |
| **Implementation** | Split by **epic** if the team is small — it is the simplest way for two people not to collide. With more engineers, split by **story**: each takes either a story assigned to them or any unblocked story from the backlog, and the dependency graph keeps them apart |

Two supporting habits: use a **shared repository** for the knowledge base from day one, and keep project-specific changes to agents on **their own branch**, so you can decide later what is worth contributing back to the asset and what was only ever relevant to this client.

## 1.5 Working with the customer

Agents reconstruct what the code *does*. Only people on the customer side can tell you what it is *for*, what is deliberate, and what matters. This section covers who you need from them, how to use their time well, and what a sign-off has to mean.

### Who you need from the customer side

You rarely get one "the SME". You need different kinds of knowledge at different gates, and identifying who holds each in week one is part of mobilization.

| Role | What only they can answer | Needed at |
|---|---|---|
| **Business SME / process owner** | Why the system behaves as it does · which behaviours are deliberate and which are accidents · what is actually used in anger, and what nobody has touched in years | Gates 1.1, 1.3 — heaviest in Phase 1 |
| **System SME** — often the last remaining maintainer | Why the code is shaped like this · undocumented conventions and local idioms · what is genuinely dead · how the parts that look unreachable actually get invoked | Gate 1.1, and the [project profile](#the-project-profile--your-single-biggest-quality-lever) |
| **Data owner / DBA** | The data model as it really is · what behaviour lives in the data layer rather than the code · ownership, retention, volumes and data quality | Gates 1.0, 1.1 |
| **Product owner / business sponsor** | Priorities · what is strategically important · the vocabulary the business actually uses · **which flows are worth demoing** | Gates 1.2, 1.3, and Stage 2.0 |
| **Enterprise / solution architect** | Target platform constraints · standards already mandated · decisions taken elsewhere you must live with | Gate 2.1 |
| **Operations / infrastructure** | Deployment reality · environments · what genuinely cannot change | Gates 2.1, 2.2 |
| **Delivery manager** | Timeline · team topology · risk appetite · release constraints | Gate 2.2 |

> **These are roles, not people — and certainly not headcount.** One person routinely covers several: on a long-lived system the last remaining maintainer is usually the DBA as well, and the process owner is often the business sponsor. That is normal, and it makes scheduling easier — but it also makes that person a single point of failure, so book them early and do not spend their time on questions someone else could answer. The reverse happens too: on a large estate one role can be spread across several people, one per subsystem, and then you need all of them. Map the roles onto the people you actually have and **put a name against every row**; what matters is that no row is empty, not that you found seven different people.

> **Name them, and get their time booked, before Phase 1 starts.** The commonest cause of a stalled engagement is not a technical problem — it is a two-week wait for the one person who knows why something works the way it does.

### Using SME time well

SME time is the scarcest resource in the engagement, and this method is designed to protect it. **You are not asking them to explain the system — the agents already reconstructed it.** You are asking them to confirm, correct, and fill specific holes.

- **Never ask an open question when you can ask an evidenced one.** *"How does pricing work?"* costs an hour and produces a vague answer. *"The code applies this discount only when the account is corporate and the order exceeds a threshold — we cannot find anything handling renewals. Is that deliberate?"* costs two minutes and produces a fact you can act on.
- **Batch questions per gate, do not drip-feed.** Every validation run gives you a ready-made list: **source gaps**, `Unresolved Items`, `REVIEW REQUIRED`. Take that list to one session rather than sending five separate emails.
- **Show, don't ask.** Publish the site and walk them through it. People correct a concrete claim on screen far more readily than they answer an abstract question — *"no, that's wrong, it only applies to wholesale"* is worth more than any interview.
- **Book a standing slot.** A recurring weekly session beats ad-hoc requests, which always slip.
- **Record answers where they will be used, not in minutes.** An answer that lives only in a meeting note is lost. Put it into the knowledge base, or into the project profile if it changes how agents should read the code.
- **Come with the evidence attached.** Cite the file, the procedure, the screen. It lets the SME correct you precisely instead of arguing from memory.

### Communication practices

- **Speak their vocabulary.** This is what [Stage 1.3](#stage-13--capability-split-) is for. Once the capability and wave names match how the customer talks, every later conversation stops being a translation exercise.
- **Report progress in their terms** — capabilities covered, waves planned, gates passed. Not agents run or commands executed. They do not care how the sausage is made and telling them invites the wrong conversation.
- **Send a link, not attachments.** The published site is always current; an emailed document is stale the moment you attach it.
- **When you need slides rather than a link** — a steering committee readout, a workshop opener — build them from the same source instead of writing a deck by hand. `/progress-report` assembles the deck *structure*; the slide tooling turns it into a deck. See [§5.7](#57-decks-and-presentations-from-the-knowledge-base).
- **Always label confidence.** Distinguish, out loud and in writing, between *this is verified in the code*, *this is inferred*, and *this is a gap we need you to close*. Presenting all three with equal certainty is how you lose credibility the first time one turns out wrong.
- **Be straightforward about what is AI-generated and what a human checked.** Say that agents drafted it and name who reviewed it. Volunteering this pre-empts the "is this just machine output?" objection far better than being asked.
- **Keep a running decisions log** — decision, who made it, when, and what it was based on. Phase 2 in particular accumulates choices that people will later ask to have justified.
- **Do not let silence block you.** If an answer does not arrive, proceed on a **stated assumption**, write it into the document, and flag it at the next gate. An assumption on the record is recoverable; a stalled engagement is not.

### Sign-off practices

Gates are only meaningful if the approval at the end of them is real.

| Practice | Why |
|---|---|
| **Sign off the artifact, not the meeting** | "We discussed it and everyone seemed happy" is not a sign-off. Name the document and the version |
| **Record a named person and a date** | "The business approved" is not traceable. A person and a date is |
| **Separate *approval of content* from *approval to proceed*** | At Gate 1.2 you are approving the wave structure, not asserting every capability is perfectly described. Being explicit about which one you are asking for prevents both false confidence and needless delay |
| **Never treat silence as approval** | If it is not written down, it did not happen — and it will be disputed at exactly the wrong moment |
| **Attach caveats rather than hiding them** | A sign-off with three recorded open items is healthy. An unrecorded reservation is a dispute waiting to happen |
| **Re-sign after material change** | If you regenerate a stage after sign-off, the previous approval is void. Say so and get it again — cheaply, now |
| **Nothing passes with unowned items** | Every `REVIEW REQUIRED`, deferred disposition and open source gap needs a named owner and a date before the gate closes |

**Who approves what:**

| Gate | Approver |
|---|---|
| 1.1 · Extraction | Architect, with SME confirmation on the gap list |
| 1.2 · Capability structure | **Product owner and architect together** |
| 1.3 · Business sign-off | Product and architecture, customer side |
| 2.1 · Architecture | Architecture board / enterprise architect |
| 2.2 · Roadmap and work breakdown | Delivery manager and architecture |
| 2.3 · Proposition | **Client or steering group** — the commercial decision |
| 3.1 · Backlog, per wave | PM, product and tech lead |
| 3.2 · Per story | Human code review on the merge request |

## 1.6 The 37 agents and the stages they run in

Every stage **on the main line** follows the same loop — **run → validate → fix → human gate** — and none starts before the previous one is signed off. Two things deliberately sit outside that line:

- **The demo track (2.0) is parallel, not a step.** It runs alongside stages 2.1–2.3, borrows their commands at a smaller scope, and has no gate of its own — its output is evidence you bring to Gate 2.3, not a prerequisite for it.
- **The backlog (3.1) repeats per wave, not once.** It belongs to Phase 3 because it is implementation planning: you refine a wave into epics and stories as that wave enters delivery, then run the build loop over its stories. Phase 2 signs off on waves; Phase 3 turns one wave at a time into work.

**Gate numbers match stage numbers everywhere except Phase 1**, where stage 1.3 closes at gate 1.2 and stage 1.4 at gate 1.3.

```mermaid
flowchart TD
    subgraph P1["PHASE 1 · CURRENT STATE — 19 agents · the only phase that reads code"]
        direction TB
        S00["<b>Stage 0 · Host readiness</b> — human, no agents<br/>/plugin-init"]:::h
        S10["<b>Stage 1.0 · Setup</b> — human, no agents<br/>enable plugin · /parse-docx"]:::h
        S11["<b>Stage 1.1 · Knowledge extraction</b> — 14-agent swarm<br/>intake → 9 domain+business+infra (one parallel batch) → AI discovery 2b (scripts, up to 10 tracers per message, consolidation) → 2 intent/risk → graph<br/>/knowledge-extraction"]:::a
        S12["<b>Stage 1.2 · Quality grade</b> — extraction-quality-agent<br/>/fix-knowledge-extraction"]:::q
        S12X["<b>Completeness report</b> — once the grade is roughly B · completeness-report-agent<br/>checks every claim against a graphify code graph<br/>/completeness-report → /fix-knowledge-extraction"]:::q
        S13["<b>Stage 1.3 · Capability split</b> — capability-split-agent<br/>/capability-split"]:::a
        S14["<b>Stage 1.4 · Business requirements</b> — BRD agent + brd-validator<br/>/export-for-alignment · /validate-brd · /fix-brd"]:::p
        G00{{"Gate 0"}}:::g
        G10{{"Gate 1.0"}}:::g
        G11{{"Gate 1.1 · Extraction — mandatory human review"}}:::g
        G12{{"Gate 1.2 · Capability structure"}}:::g
        G13{{"Gate 1.3 · Business sign-off — ends Phase 1"}}:::g
        S00 --> G00 --> S10 --> G10 --> S11 --> S12 --> S12X --> G11 --> S13 --> G12 --> S14 --> G13
        G11 -.->|"not ready"| S11
        S12X -.->|"findings → fix loop"| S12
    end

    subgraph P2["PHASE 2 · TARGET STATE &amp; PROPOSITION — 5 agents + a 3-agent optional demo track · knowledge base only"]
        direction TB
        S20["<b>Stage 2.0 · Demo track</b> — OPTIONAL · runs alongside 2.1–2.3 · no gate<br/>/research → /demo-plan → the demo track of 2.2, 3.1 and 3.2"]:::d
        S21["<b>Stage 2.1 · Architecture</b> — target-state-architecture-agent<br/>+ architecture-validator + architecture-completeness-validator"]:::a
        S22["<b>Stage 2.2 · Roadmap + work breakdown (L1 waves)</b><br/>transformation-agent · /transformation-roadmap"]:::a
        S23["<b>Stage 2.3 · Estimation</b> — HUMAN, no agent"]:::h
        G21{{"Gate 2.1 · Architecture — can hard-block"}}:::g
        G22{{"Gate 2.2 · Roadmap and work breakdown"}}:::g
        G23{{"Gate 2.3 · Proposition — ends Phase 2"}}:::g
        S21 --> G21 --> S22 --> G22 --> S23 --> G23
        S21 -.->|"scope a demo"| S20
        S20 -.->|"client feedback + a working demo"| G23
    end

    subgraph P3["PHASE 3 · IMPLEMENTATION — 3 agents on the backlog (per wave), then commands (per story)"]
        direction TB
        S31["<b>3.1 Backlog</b> — epic-backlog-agent + story-intent-agent<br/>+ backlog-validator · /create-epic-backlog · /story-intent<br/><i>one pass per wave</i>"]:::a
        G31{{"Gate 3.1 · Backlog, per wave"}}:::g
        S32["<b>3.2 Spec</b> — /new-story-spec"]:::i
        S33["<b>3.3 Build</b> — /new-story-impl"]:::i
        S34["<b>3.4 Close</b> — /archive-implemented"]:::i
        G32{{"Gate 3.2 · human code review, per story"}}:::g
        S31 --> G31 --> S32 --> S33 --> S34 --> G32
        G32 -.->|"next unblocked story"| S32
        G32 -.->|"next wave"| S31
    end

    P1 --> P2 --> P3
    PUB["🌐 knowledge-base-publisher — /publish-knowledge-base, any time"]:::u
    P1 -.-> PUB
    P2 -.-> PUB

    classDef a fill:#0070ad,stroke:#005281,color:#ffffff
    classDef p fill:#00857d,stroke:#00655f,color:#ffffff
    classDef q fill:#a35f00,stroke:#7d4900,color:#ffffff
    classDef h fill:#5c2d91,stroke:#421f69,color:#ffffff
    classDef i fill:#b5372a,stroke:#8b2a20,color:#ffffff
    classDef u fill:#4f6779,stroke:#3a4e5c,color:#ffffff
    classDef d fill:#8a6d1f,stroke:#6a5317,color:#ffffff
    classDef g fill:#e8f0f6,stroke:#adc5d6,color:#0f2230
```

🟦 Agent analysis · 🟩 Product-owned · 🟧 Quality gate · 🟪 Human-only step, no agent · 🟨 Optional demo track · 🟥 Implementation command · ⬜ Human gate

Six agents sit outside the numbered main line: `knowledge-base-publisher` (the site, any time), `knowledge-base-research-agent` (`/research`), `progress-reporter` (`/progress-report`), `add-features-analyst` (`/add-features`), and the `open-questions-agent` / `open-questions-applier` pair that runs the cross-cutting gate between stages.

### Agents that run outside the phases

| Agent | Run by | What it does |
|---|---|---|
| `knowledge-base-publisher` | `/publish-knowledge-base` | Regenerates the site's data files against a frozen scaffold. Forbidden from touching HTML, CSS or JS — which is why re-publishing never breaks the site |
| `knowledge-base-research-agent` | `/research` | A cited research note from the knowledge base. Always clarifies the question before researching; never proceeds on an unconfirmed assumption |
| `progress-reporter` | — (reference) | Owns the canonical progress-deck agenda. `/progress-report` spawns its own section and slide agents rather than calling it; **when the two disagree, the command is what runs** |
| `add-features-analyst` | `/add-features` | A read-only scan for duplicates, overlaps and contradictions before any backlog edit. Separating the scan from the write is what makes it safe to add scope to an approved backlog |
| `open-questions-agent` | `/resolve-open-questions` | The SCAN half. Turns a deterministic harvest of recorded unknowns into a classified, de-duplicated register with a recommended option each. Never authors an answer |
| `open-questions-applier` | `/resolve-open-questions --apply` | The APPLY half. Promotes answers into the artifacts they decide. Add-only, `Draft`-only for stories, and it verifies every file it touches |

**The open-questions pair is a gate, not a utility.** Every artifact records what it could not determine; left alone those unknowns are inherited silently, and a guess made in extraction becomes a requirement in a BRD. Gated commands call the `check-open-questions` skill as their step 0.5 and refuse to run while a **blocking** question is unanswered.

**Three rules explain this flow:**

1. **Only Phase 1 agents read source code.** Every Phase 2 and Phase 3 planning agent is forbidden from it and works exclusively from the knowledge base. Fix a wrong fact once, in Phase 1, and everything downstream inherits the correction.
2. **`summary.json` files are the contract between stages.** Prose is for humans; the JSON is the machine interface. A missing JSON makes the *next* stage degrade quietly — always confirm it exists.
3. **Planning stops at the wave until delivery starts.** The proposition is built and signed on waves with stated scope and deliverables (stage 2.2). Epics and stories are produced per wave as that wave enters delivery (stage 3.1) — refining wave 4 while wave 1 is still being built throws the work away.

---

# Part II — Phase 1 · Current State (Knowledge Extraction and Business Capabilities)

> **Purpose in one line:** work out what the system actually does today, and write it down in language the business can read.

**Deliverable:** a validated knowledge base plus a signed-off BRD per capability.
**Leads:** Architect, handing to Product at stage 1.4.

## Agents in this phase

| # | Agent | What it does | Writes to |
|---|---|---|---|
| **1.1 — Discovery swarm** — *the only agents that read source code* | | | |
| 1 | `repository-intake-agent` | Maps structure, technology, dependencies, entry points. Runs first and alone | `extraction/repository/` |
| 2 | `architecture-discovery-agent` | Reconstructs the design nobody wrote down: layers, components, boundaries | `extraction/architecture/` |
| 3 | `functional-discovery-agent` | Catalogues features, APIs, screens, background jobs | `extraction/functional/` |
| 4 | `data-model-agent` | Entities, schemas, relationships, and which module *owns* each table | `extraction/data-model/` |
| 5 | `data-flow-agent` | How data moves and changes as it crosses the system | `extraction/data-flow/` |
| 6 | `integration-agent` | Every external and internal connection: APIs, events, files, protocols | `extraction/integrations/` |
| 7 | `ui-ux-discovery-agent` | Every screen, its controls, and what each button actually triggers | `extraction/ui-ux/` |
| 8 | `business-logic-rules-agent` | The deepest reader: rules from code, **database procedures, triggers, rule tables** | `extraction/business-logic-rules/` |
| 9 | `security-governance-agent` | Access control, sensitive data, governance risk — as actually enforced | `extraction/security/` |
| 10 | `runtime-operations-agent` | How it runs: deployment, configuration, scheduling, monitoring | `extraction/runtime-operations/` |
| 11 | `ai-discovery-agent` | The AI layer: model providers, agents and multi-agent flows, tools and MCP servers, prompts, RAG pipelines, evals and guardrails, developer AI harnesses. Runs when intake found AI, or when you ask for it in the prompt (e.g. `/knowledge-extraction run ai discovery also`); when intake found none and you did not ask, Phase 2b and this agent are skipped and a "no AI detected" stub is written instead. When it runs, it starts with the deterministic AI sweep (any language), saved as `extraction/ai/sweep.json`. Documents how it works, not just what exists: traced call graphs, flow steps, RAG stages with their real constants, prompts, configuration keys. Uses the repository's own docs as a guide, never as evidence. Since Phase 2b it consolidates the per-entry-point traces that `ai-cluster-tracer-agent`s write into `extraction/ai/clusters/`, rather than tracing everything itself | `extraction/ai/` |
| 12 | `business-intent-agent` | Infers the *why* — business purpose, domains, capabilities | `extraction/business-intent/` |
| 13 | `risk-gap-agent` | Consolidates everyone's findings into one prioritized risk register | `extraction/risk-gap/` |
| 14 | `knowledge-graph-curator` | Connects the parallel findings so cross-cutting relationships become visible | `extraction/knowledge-graph/` |
| **1.2 — Quality gate** | | | |
| 15 | `extraction-quality-agent` | Grades the work above. **Forbidden from editing what it judges** | `extraction/extraction-quality/` |
| 16 | `completeness-report-agent` | Checks extraction claims against a deterministic `graphify` code graph, not just internal consistency | `extraction/completeness-report/` |
| **1.3 — Structuring** | | | |
| 17 | `capability-split-agent` | Groups the facts into business capabilities and migration waves | `capabilities/` |
| **1.4 — Business documentation** 🟩 | | | |
| 18 | `business-capability-brd-agent` | Translates technical reality into a document Product can sign | `business-capabilities/<slug>/` |
| 19 | `brd-validator` | Scores each BRD on five dimensions | `business-capabilities/validation*` |

---

## Stage 0 · Host readiness (`/plugin-init`)

### What this stage does

Confirms this machine has every tool the plugin's hooks and commands need before any other stage runs — once per machine, and again after every plugin update.

### Step 1 — Run

```
/plugin-init
```

**Required.** Every other command and skill refuses to run until this has passed on this machine
for the installed plugin version — run it once right after installing, again after every
`/plugin update`, and on every new machine or OS user. It checks the host for the tools below, asks
about the optional ones (Git hosting CLI, OpenSpec, Docker, pandoc — choosing Defer or Skip is your confirmation that you understand what each one costs you), copies the operator docs into `.claude/docs/modernization-cli-cap/`,
checks `.gitignore`, and writes the marker `.claude/tooling/host-check.json` only once everything
required is present. It never installs anything — it tells you what to install and gives the exact
command.

| Tool | Minimum | Needed for |
|---|---|---|
| Git Bash (Windows only) | — | every hook and command |
| Python | 3.10 | every script and hook |
| git | — | branches, commits, tracking checks |
| Node.js | 22 | chat widget, `npx` |
| openspec | — | optional — asked (Defer/Skip acknowledges the loss); `/new-story-spec`, `/new-story-impl`, `/archive-implemented` |
| graphify | — | `/completeness-report` |
| pandoc | — | optional — asked (Defer/Skip acknowledges the loss); `/parse-docx` |
| mermaid-cli (`mmdc` or `npx`) | — | `/validate-mermaid`, `/validate-architecture` |
| `glab` or `gh` | — | optional — asked; MR/PR creation and merge |
| Docker | — | optional — asked (Defer/Skip acknowledges the loss); `/chat-serve` default mode and the vendored `run.sh` |

**What you lose without the three optional tools.** `/plugin-init` will not record a deferral or skip for OpenSpec, Docker or pandoc until it has shown you exactly what stops working and you have chosen *Defer — I understand this will be missing* or *Skip — I understand this will be missing*:

| Tool | What is missing if it is not installed |
|---|---|
| openspec | `/new-story-spec`, `/new-story-impl`, `/archive-implemented` cannot run — a backlog story cannot be turned into an OpenSpec proposal, implemented or archived. Everything up to and including `/story-intent` is unaffected |
| Docker | `/chat-serve` must be run with `--local`, and the vendored `knowledge-base/chat-widget/run.sh` bundle cannot be used from a plain terminal on this machine. Nothing else is affected |
| pandoc | `/parse-docx` cannot convert Word `.docx` files, so any `.docx` input must be converted to Markdown by hand before extraction. Nothing else is affected |

Choosing *Install now* needs no confirmation but keeps the marker unwritten until the tool is present. A *Defer* is asked again on the next run; a *Skip* is remembered for this machine until you run with `--reconsider`.

**On Windows**, Claude Code needs to find Git Bash or every plugin hook and script is unreachable —
install full Git for Windows (`winget install Git.Git`; MinGit and IDE-bundled Git do not include
Git Bash) or point `CLAUDE_CODE_GIT_BASH_PATH` at an existing `bash.exe`, then restart Claude Code
and run `/plugin-init` again. See [§5.4](#54-troubleshooting) for the escape hatch if the gate itself is broken.

### ✅ Gate 0 checklist
- [ ] `/plugin-init` run on this machine for the installed plugin version
- [ ] Every required tool present: Python 3.10+, git, Node.js 22+, graphify, mermaid-cli (Git Bash too, on Windows)
- [ ] The optional tools (`glab`/`gh`, openspec, Docker, pandoc) answered, installed or knowingly skipped — a Defer or Skip on openspec, Docker or pandoc acknowledges what will be missing
- [ ] Marker `.claude/tooling/host-check.json` written

---

## Stage 1.0 · Setup

### What this stage does

Enables the asset as a plugin against the repository you want to modernize, and gathers the raw material the agents will read.

### Step 1 — Install

The asset is a Claude Code **plugin** (`modernization-cli-cap`) — there is no copy step. From a
Claude Code session in the target repository, with the internal marketplace registered:

```
/plugin install modernization-cli-cap
```

For local development against a checkout of the toolkit itself, load it directly instead:

```bash
claude --plugin-dir /path/to/modernization-cli/.claude
```

Updating later is `/plugin update modernization-cli-cap` — there is nothing to re-run against the
target repository; the plugin's components simply refresh to the latest version.

> ⚠️ If the target repository still carries agents/commands copied in by the old, retired
> `install-kb-agents.py` installer, those **project-level** files take precedence over the plugin and
> silently shadow it — enabling the plugin does nothing until the stale copy is removed. See
> `.claude/user-docs/installation.md` in the toolkit repo for the one-time cleanup.

> Host readiness (`/plugin-init`) is now its own [Stage 0](#stage-0--host-readiness-plugin-init) — run it before this stage.

### Step 2 — Gather source material

**This single step sets the quality ceiling for the entire engagement.** Agents can only read what is in the repository.

| Material | Why it matters |
|---|---|
| Application source code | The baseline |
| **Database schema, stored procedures, functions, views, triggers** | Business rules very often live *only* here. In database-centric systems, handing over application code without the database means systematically missing half the logic |
| **Rule-engine configuration / decision tables / spreadsheet exports** | Some systems decide what to do by looking up rows in a database table rather than in code. Without that export, agents can see that *something* runs but not *what* |
| Existing documentation | Word documents are converted to Markdown by `/parse-docx` — see below |

Suggested convention (**not enforced by the asset**): put supplied material under `docs/source-material/` with a short README saying what each file is and how current it is. There is no dedicated folder for this, so a predictable location makes "what did we actually give it?" answerable later.

#### Word documents: always converted, never read raw

Clients hand over a lot of `.docx` — specifications, interface documents, process descriptions, requirement catalogues. Those are never read in their raw form. `/parse-docx` converts them to clean Markdown, preserving tracked changes, tables (including merged cells) and embedded images.

**This happens either way.** An agent that encounters a Word document during a run can invoke the conversion itself; you can also run it yourself up front over everything you were given. Doing it up front is worth the few minutes when you have a stack of documents, because you can then read and sanity-check the converted output before any agent relies on it.

It matters for two reasons, and both are worth understanding:

| | |
|---|---|
| **Cost** | A `.docx` is a compressed archive of XML, not a document. Handing one to an agent raw burns a great many tokens on markup that carries no meaning. Converted Markdown is a fraction of the size for the same content. |
| **Quality** | This is the bigger one. Word tables — especially with merged cells — degrade badly when read naively, and tables are exactly where specifications keep their most valuable content: field definitions, status transitions, rule matrices, interface contracts. Proper conversion preserves that structure, so the agent reads a real table instead of a jumble of cell fragments. Images and tracked changes survive too. |

Garbled tables do not produce an obvious error; they produce confident, wrong extraction. Converting first is the cheapest quality safeguard in Phase 1.

### Practical advice

- **Start with a code completeness and buildability check.** Before running anything, establish that what you received is actually the whole system. The fastest objective test is to **try to build it**. A tree that compiles is good evidence the code is complete; a tree that does not names its own gaps for you. Check specifically:
  - every referenced project, module or package in the solution/manifest is actually present in the tree;
  - dependencies resolve — no packages pulled from a registry you cannot reach;
  - nothing references a library, assembly or shared component that was not handed over;
  - build and configuration files are included, not just source files.

  Work that list *before* extraction. Discovering a missing module through a build error takes minutes; discovering it through a puzzling gap in the extraction output takes a day.

- **Then chase the supporting sources** — the things that are not application code but still carry behaviour: database schema and procedures, configuration, deployment and scheduling definitions, rule or decision tables, seed and reference data, and existing documentation. These are where the logic that "isn't in the code" actually lives, and they are routinely left out of a handover because nobody thinks of them as source.

- **Expect material to arrive in waves, not all at once.** A client typically hands over more each time you can show them something concrete is missing. The gap list extraction produces is your lever — it turns "please send us everything" into "your code calls these 40 procedures and we cannot see 12 of them."

- **Client documentation is a cross-check, not necessarily an input.** You do not have to feed existing documentation into extraction. It is often more valuable held back and used to *verify* the result: does what the agents found match what the documentation claims? Mismatches are findings in their own right — either extraction missed something, or the documentation is stale.

- **Write down what you know is missing.** That list becomes your first set of SME questions at Gate 1.1.

- **Do not wait for perfect material.** Run extraction with what you have; the gaps it reports tell you precisely what to chase.

### ✅ Gate 1.0 checklist
- [ ] Plugin enabled for the target repository (no stale copy-installed `.claude/agents|commands|skills` shadowing it)
- [ ] Application source present
- [ ] **The source tree builds** — or every build failure is understood and traced to a named gap
- [ ] Every referenced project, module or package is present; dependencies resolve
- [ ] Nothing references a library or component that was not handed over
- [ ] Supporting sources present: database schema and procedures, configuration, deployment and scheduling definitions, rule or decision tables, reference data
- [ ] Word documents converted to Markdown, and the converted output spot-checked — tables especially
- [ ] Known gaps in supplied material written down
- [ ] `graphify` CLI installed (`uv tool install graphifyy`) — the completeness report at Stage 1.1 needs it

---

## Stage 1.1–1.2 · Knowledge Extraction and Quality Gate

### What this stage does

Fourteen agents read the codebase and write down everything they can establish about it (plus an on-demand fan-out of AI cluster tracers in Phase 2b, one per entry point). A fifteenth grades the result.

**This is the most expensive stage in the process.** Budget for two or three passes.

### Step 1 — Run

```
/knowledge-extraction
```

The command runs the agents in five ordered phases (AI discovery runs as Phase 2b, between 2 and 3) and waits for each to finish:

| Phase | Agents | Run how |
|---|---|---|
| 1 · Foundation | repository intake | alone, first |
| 2 · Domain, business & infrastructure | architecture · functional · data-model · data-flow · integration · ui-ux · business rules · security · runtime operations | **9 in parallel** |
| 2b · AI discovery | AI cluster tracers (one per entry point) · ai-discovery consolidation | **up to 10 in parallel per batch**, then 1 |
| 3 · Intent & risk | business intent · risk-gap | **2 in parallel** |
| 4 · Synthesis | knowledge graph | alone |
| 5 · Quality | extraction quality | alone |

All nine Phase 2 agents depend only on Phase 1, so they run as one batch (the concurrency ceiling is ten, so one slot is free); AI discovery runs afterwards as Phase 2b, and Phase 3 runs after both because it depends on what they produce. After each phase the command checks on disk that every agent produced its files, and re-runs any that failed silently.

Each agent writes its own folder, an index, and per-domain files capped at 500 lines. The AI layer is the one subject two kinds of agent look at: `ai-discovery-agent` owns the AI-native view in `extraction/ai/`, while the others record the same code through their own lens — an LLM provider as an integration, a rule written inside a prompt as a business rule — and tag that entry with an `aiRef` id pointing at the AI item, so the knowledge graph and the site can link the two. `ai-discovery-agent` always starts with a deterministic, multi-language sweep of the code (Java/Kotlin, .NET, Go, Python, JavaScript/TypeScript) and saves the hit list as `extraction/ai/sweep.json`; that list is both its checklist and the denominator that CHECK-13 and the completeness report measure it against. It then traces call graphs instead of describing components in isolation (since Phase 2b the per-entry-point tracing is done by `ai-cluster-tracer-agent`s and `ai-discovery-agent` consolidates it), so each flow carries ordered steps, each RAG pipeline its stages with the real constants (similarity metric, *k*, chunk and overlap sizes, fusion and rerank settings), and prompts, configuration keys and per-profile observability defaults are recorded too. The repository's own documentation (the profile's `docs.sources`) is read first as a guide to what *should* exist, then every claim is confirmed in code — documentation alone never makes an item `confirmed`, and a contradiction between the docs and the code is recorded in `docFindings`. That cap is deliberate: the more an agent has to produce in one go, the more its quality degrades — smaller files in a predictable structure are both better written and easier for the next stage to consume.

**Phase 2b — AI discovery, in detail.** Nothing extra is run: `/knowledge-extraction` does these steps between Phase 2 and Phase 3, but only when repository-intake found AI (`ai.present` in `project-profile.json`) or you ask for it in the prompt, for example `/knowledge-extraction run ai discovery also`. Otherwise Phase 2b and `ai-discovery-agent` are skipped and a "no AI detected" stub is written, so a repository with no AI pays nothing for this phase. You can also say "skip AI discovery" to leave it out of a repository where intake did find AI. Scripts first sweep the repository for AI code; then, when `graphify` is installed, they group the hits into clusters by entry point (a controller, listener, job or CLI) using graphify's call graph (test files are never entry points; code reached from many entry points forms shared `platform` clusters, split by directory when large), and cut each cluster's code down to the methods on its call chains with graphify's own tree-sitter grammars (Java, Python, JavaScript/TypeScript, C# and Go; other languages are read whole). One `ai-cluster-tracer-agent` per cluster then traces that cluster's flows, retrieval pipelines, prompts and configuration keys — up to ten at a time, with more clusters run in further batches. A script validates and merges the results (a cluster that fails validation is re-run at most twice, then handed to `ai-discovery-agent`), and `ai-discovery-agent` consolidates: it adds the inventory (providers, models, tools, guardrails, observability, engineering harness), the documentation findings and the risks, and writes `ai/summary.json`. A repository with no AI, or no usable cluster, skips the fan-out and `ai-discovery-agent` traces as before. Code slices are raw source, so they are written to an owner-only folder in the machine's temporary directory (emptied at the start of each run), never to `knowledge-base/`. New files under `extraction/ai/`: `clusters/manifest.json`, `clusters/merged.json`, `clusters/<cluster>/partial.json`, `flows-<cluster>.md` and `rag-<cluster>.md`.

**No new tool is required, and graphify only makes this step faster.** If graphify is missing, or its call graph cannot be read, the step still runs — with directory-based clusters and whole-file reads — but more slowly; if only graphify's Python interpreter or its tree-sitter grammars are unavailable, clusters stay entry-point based and the tracers read whole files instead of slices. Whenever something is degraded, the command prints one warning block **before the first tracer starts** (so you can cancel, fix and re-run) and repeats it in the closing summary. What each code means and what to do:

| Code | Severity | What it means | What to do |
|---|---|---|---|
| `GRAPHIFY_MISSING` | high | graphify is not installed (not on `PATH`), so there is no call graph and no tree-sitter grammars | Install graphify (uv tool install graphifyy), then re-run knowledge extraction. |
| `GRAPH_UNAVAILABLE` | high | graphify is installed but its call graph could not be read | Rebuild the source graph (graphify-source-graph with --refresh), then re-run knowledge extraction. |
| `GRAPHIFY_INTERPRETER_NOT_FOUND` | high | graphify's Python interpreter could not be located, so slicing is off | Install graphify with uv (uv tool install graphifyy) or put its launcher on PATH, then re-run knowledge extraction. |
| `TREE_SITTER_IMPORT_FAILED` | high | graphify's interpreter was found but tree-sitter would not load there | Reinstall graphify (uv tool install --reinstall graphifyy), then re-run knowledge extraction. |
| `GRAPH_STALE` | medium | the call graph was built at a different commit, or files referenced by clusters have changed since | Rebuild the source graph (graphify-source-graph with --refresh), then re-run knowledge extraction. |
| `ENTRY_POINTS_NOT_FOUND` | medium | no entry points were recognised in the call graph | No action needed unless the repository does have entry points; then widen the planner's entry-point pattern. |
| `NO_GRAMMAR_FOR_LANGUAGE` | medium | some AI-relevant files are in a language the slicer has no grammar rule for | Add the language to the slicer's table (one row and one test fixture). |
| `PARSE_ERRORS` | low | some files could not be parsed cleanly | None required; fix the syntax errors if they are unexpected. |
| `UNSLICEABLE_LINES` | low | some chain lines sit outside any function or method the slicer recognises | None required. |
| `SLICER_FAILED` | medium | the slicer stopped unexpectedly | Re-run; if it repeats, report the detail shown with this warning. |
| `CLUSTER_FALLBACK` | high | a cluster failed after retries and was handed to `ai-discovery-agent` | Re-run knowledge extraction; if it repeats, inspect the cluster's partial.json errors. |
| `UNVALIDATED_LANGUAGE` | info | slicing used a language other than Java; only Java has been validated against a benchmark | None required. |

### The project profile — your single biggest quality lever

The first agent writes a small shared file, `knowledge-base/extraction/project-profile.json`, describing **what kind of project this is**: the stack, where the source lives, build-file patterns, naming conventions, framework markers, and — critically — any indirection an agent could not infer by reading the code, such as work dispatched from configuration or data rather than called directly.

**Three extraction agents read it before doing anything — the UI/UX, integration, and quality agents — and so do all three validators plus the progress-report deck.** Since `project-profile.v2` it also carries an **`ai` block** — whether the repository contains product AI, developer AI tooling, or neither, with the evidence — which `ai-discovery-agent` starts from; intake detects it with a signals-only source sweep across more ecosystems than build files alone, and records the documentation it found (README, doc site, ADRs, specs) in an optional `docs.sources` block. The same `ai` block lists this toolkit's own footprint (`knowledge-base/`, agent memory, traceability) so the analysis never reports the analysis tooling as part of the system. It is the one place where a fact you write once reaches the whole downstream chain.

It is **JSON against a strict schema**, not free-form prose: anything an agent greps or iterates — source roots, build-file globs, framework markers, rule-engine entry points — is a literal array of tokens, and narrative survives only in the `narrative` and `stackSummary` fields. Stage 1 hard-stops before Phase 2 if the file is missing or fails validation, so a bad profile is caught immediately instead of quietly poisoning six agents. If you edit it by hand, re-check it:

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/validate-schema.py knowledge-base/extraction/project-profile.json project-profile.v1
```

This matters far more than its size suggests. Agents are deliberately written to be stack-neutral, so wherever an agent would otherwise guess at a source directory or a framework marker, it takes the value from the profile instead. Get the profile right and every agent starts from the truth. Leave it thin and each agent re-derives — and sometimes mis-derives — the same facts.

**Treat it as a living file you deliberately improve.** The most effective working pattern:

1. Run extraction.
2. Find something an agent missed or got wrong.
3. Ask *why* it missed it — usually a convention it could not have guessed.
4. **Write that fact into the project profile.**
5. Re-run just that agent.

The classic example: a codebase with hundreds of stored procedures that appear never to be called from application code, because a rule engine invokes them from database configuration. An agent reading only the code concludes they are dead. One paragraph in the profile — *this system dispatches through a rule engine; procedures are invoked from configuration, not from code* — changes what every agent concludes from that point on.

Anything genuinely unusual about the project belongs here: unconventional folder layouts, naming conventions, a subsystem that looks abandoned but is not, a component reused from another product. It is also where you record what you were **not** given, so agents stop hunting for material that does not exist.

### Step 2 — Validate

The stage finishes by printing a score and grade. Grade **B or better** to proceed.

#### What the quality agent checks

Fifteen checks run on every pass. Each finding is logged with its check ID, a severity — **Critical** (fix before anything downstream runs) · **Warning** · **Info** — and the exact folder and file, so the report tells you where to look rather than just how bad it is. Scores are reported per folder as well as overall. When no AI was detected, the `ai/` folder is left out of the overall score, so a system without AI is not graded down for it.

| Check | What it verifies | Worst severity |
|---|---|---|
| **CHECK-01** Folder completeness | All 14 extraction folders exist, each with `index.md`, at least one domain file and `summary.json`. `ui-ux/` must also carry `navigation.md` and a navigation diagram; `knowledge-graph/` must carry a diagram. A folder with fewer than 3 files, or a near-empty index, is flagged too | Critical |
| **CHECK-02** Summary JSON schema | Every `summary.json` parses, has its required keys, and contains no `"unknown"` / `"TBD"` / empty placeholders in fields that should have been populated | Critical |
| **CHECK-03** Frontmatter | Every extraction `.md` opens with YAML frontmatter carrying a `tags:` list | Warning |
| **CHECK-04** Unresolved references | Classes, modules, libraries and external systems named in the docs but absent from the source tree, the build files, or the integrations inventory — i.e. things an agent may have invented or misread | Warning |
| **CHECK-05** Cross-file entity consistency | The same entity is named the same way in `data-model/`, `architecture/` and `knowledge-graph/`, and does not appear in one folder while missing from another where it is expected | Warning |
| **CHECK-06** Modernization readiness | Fifteen named downstream signals are present and not thin: stack with versions · EOL flags · dependency inventory · schema summary · business event list · auth model · deployment topology · capability list · coupling hotspots · cross-boundary data flows · and five UI signals (screen inventory, interaction-to-backend linkage, navigation diagram, device matrix, styling inventory). Each miss names the downstream step it blocks | Warning |
| **CHECK-07** Mermaid validity | Every diagram block is actually rendered through the Mermaid CLI — not eyeballed. A non-zero exit is reported with the parser's own error | Critical |
| **CHECK-08** Broken links | Every relative Markdown link resolves to a file on disk | Warning |
| **CHECK-09** File size | No extraction `.md` exceeds the 500-line cap | Warning |
| **CHECK-10** Knowledge-graph coverage | Entities and relationships are non-zero, some findings are `HIGH` confidence, the `unresolvedGaps` field exists, and every folder is traceable to at least one node or edge in the graph | Warning |
| **CHECK-11** Dispatch-mapping integrity | Where the system dispatches work from data or configuration rather than direct calls, the mapping file the Phase 3 agents consume must exist with its confidence vocabulary. If the index states no such mechanism was found, the check passes — its absence is intentional | Critical |
| **CHECK-12** AI cross-reference integrity | Skipped when no AI was detected. Otherwise every `aiRef` tag on another folder's entry, and every cross-reference the AI summary makes, resolves; flow edges point at real nodes; each model provider has a matching integration contract; each prompt that embeds a business rule has that rule in `business-logic-rules/` | Critical |
| **CHECK-13** AI coverage | Runs `check-ai-output.py`, which compares what `ai/summary.json` cites against `ai/sweep.json`, the deterministic sweep of AI code locations. Flags sweep files nobody described, fewer prompts than the sweep found, missing configuration keys, RAG pipelines without stages, flows without steps, undetermined parameters with no record of where they were searched, and a folder that claims to be complete or empty while AI code exists. Escalates to Critical below 60% coverage or on those last overclaims. Without a `sweep.json` the result is "not measured", never a pass | Critical |
| **CHECK-14** Documentation as evidence | Every folder: a claim marked `confirmed` / `HIGH` whose only evidence is a documentation file (`README*`, `CLAUDE.md`, `AGENTS.md`, anything under `docs/`) is unverified, because documentation states intent, not behaviour. Exempt: the developer engineering harness, where the file is the artifact | Warning |
| **CHECK-15** Boilerplate inventories | Every folder: a table or bullet list of 8 or more rows where most share the same description, or rows with spliced, broken quoting. Such lists contain every name and describe none. Three or more flagged files in one folder is a Critical for that folder | Critical |

**How a folder is scored.** Each folder starts at 100 and loses 20 per Critical, 5 per Warning and 2 per Info. Deductions alone reward thin output — fewer claims means fewer findings — so wherever coverage can be measured the score is **capped by it**: `min(deduction score, 100 × coverage)`. For `ai/` the coverage comes from CHECK-13; for the other folders it comes from the completeness report, counting only entities that are *described*, not bare name mentions. Where neither exists the report prints **not measured** beside the folder and adds a caveat under the headline: that score reflects structure only and does not show the folder is complete. (On a Java/Spring AI target the quality gate once graded 99.3/A and the completeness report 100/100 while the `ai/` folder was missing its prompts, flows and key algorithm constants — both measured structure and name presence only.) A structural 100 never means "complete".

**Where to start reading.** Go to the quality report first, not the extraction documents. CHECK-04, CHECK-05, CHECK-07 and CHECK-08 are cross-checks a human would not think to run — broken references, contradictions between documents, diagrams that do not render — and they tell you *where* to look before you read anything in full. CHECK-13 to CHECK-15 point at output that is thin rather than wrong — undescribed code, claims backed only by documentation, inventories that name everything and explain nothing.

### Step 3 — Fix loop

```
/fix-knowledge-extraction        # repeat until it reports nothing to fix
```

It sorts every problem into either a **direct edit** or an **agent re-run**, applies both, re-grades, and shows a before/after comparison.

The split follows a simple rule, and it is worth knowing so you can predict what it will do:

| Symptom | Treatment |
|---|---|
| A typo, a stale value, a diagram that does not render | **Direct edit.** No agent needs to run again |
| Content is missing, or an agent clearly skipped something | **Re-run that agent** |
| **Two agents contradict each other** — one asserts something another never confirmed | **Re-run with a directive** naming the contradiction: *"these two disagree about X — check it"* |

That last case is the one people miss. A contradiction between agents is not noise; it is the knowledge base telling you something is genuinely unclear in the code, and it is worth resolving before anything downstream builds on it.

Two things to know: it **does not ask for confirmation** — it prints its plan and proceeds. And it **exits immediately** if there is nothing wrong. Anything it lists as *not fixable* is work for a human.

**If an agent keeps missing the same thing, change the agent, not just the output.** Adding context to the project profile is the first move; editing the agent definition itself to give it more guidance is entirely legitimate, and then you re-run only that agent. Repeatedly hand-correcting the same class of error is a sign the instructions need fixing, not the document.

**What to expect from the numbers.** A first extraction pass in the mid-80s is a normal, healthy result — not a failure. The fix loop is what takes it to the high 90s. Plan for it rather than treating the first score as the verdict.

### Step 4 — Completeness report: check the claims against the code

```
/completeness-report
/fix-knowledge-extraction        # folds its findings in
```

**Run it once the fix loop has the grade at roughly B** — normal quality, not the final score. Run earlier and it spends its effort on errors the quality agent would have caught anyway; skip it and everything downstream is built on claims nobody checked against the code.

The quality agent checks the extraction **against itself** — internal consistency, completeness of structure, cross-file agreement. It cannot tell you whether a claim is actually *true*. This step can: it builds (or reuses) a source-code-only knowledge graph with the third-party `graphify` CLI, then checks every checkable claim in the extraction documents against that graph, classifying each miss as `TOTALLY_WRONG` (fabricated), `INACCURATE` (real entity, wrong detail), `UNSUPPORTED` (unverifiable either way), or `HUMAN-REVIEW` (ambiguous), and separately lists entities the graph found that no extraction folder mentions. Each folder gets a status: **scored**, **not scored** (nothing was checkable: no claims checked, or no entities) or **insufficient sample** (fewer than the minimum of 10 or the number available were checked). Only scored folders enter the overall score; the others are shown as "—", never as 100, and when no folder can be scored the overall result is "not scored". Coverage separates entities that are *described* from those that are *mention-only* (a bare link, or a row in a repeated-role table); only the first counts as covered. For `ai/` the entities come from `sweep.json`, not the graph, and the report adds an `ai.md` file. It never edits the extraction folders it checks, and it never builds the graph on a poisoned index — a graph indexing `knowledge-base/` or `.claude/` is rejected and rebuilt.

**Then run the fix loop again.** `/fix-knowledge-extraction` reads `extraction/completeness-report/summary.json` and folds its findings in alongside the quality report's, routing `TOTALLY_WRONG`/`INACCURATE` items to direct edits and missing entities to agent re-runs. Re-run `/completeness-report` afterwards to confirm the findings are closed. `HUMAN-REVIEW` items go on the SME list.

**It is required before Gate 1.1.** It needs the `graphify` CLI on `PATH` (`uv tool install graphifyy`), so install it at Stage 1.0 — see the prerequisites table in §6.1. If the client's environment will not allow it, record that as an explicit exception at Gate 1.1: the extraction has then only been checked against itself.

### How to read confidence levels

| Level | Means | What to do |
|---|---|---|
| `HIGH` | The implementing code was actually read | Trust it |
| `MEDIUM` | Guessed from a name or heading | Spot-check the important ones |
| **source gap** | The implementation is not in the repository | **Ask an SME, or find the missing file** |

### Practical advice

- **Let it run.** This stage takes a while and does not need supervision. Start it and go do something else.
- **Read the risk register early.** `extraction/risk-gap/` is often the first genuinely new insight the client sees — it makes a strong early checkpoint conversation.
- **Do not accept a C.** Every later phase inherits these facts, and none of them will re-read the code. Fixing it later is far more expensive than fixing it now.
- **A low grade usually means missing input, not a broken agent.** Check what you failed to supply before re-running anything.
- **Publish the site now** (`/publish-knowledge-base`) — it is the first tangible thing to show stakeholders.

### ✅ Gate 1.1 checklist — human completeness review ⚠️ mandatory

**Structural**
- [ ] All 14 output folders exist, each with its index and summary files
- [ ] The command reported no failed agents

**Coverage — check against your own knowledge, not the score**
- [ ] Write down the app's top 10 known features from memory. Are all present?
- [ ] Number of entities found vs. real number of database tables — same ballpark?
- [ ] Number of screens found vs. actual screens. *This is the most commonly under-extracted area*
- [ ] Every external system you know about appears in the integrations list
- [ ] If the system is driven by a rules table, the rule-engine mapping file exists; if it is not, the index explicitly says so

**Evidence quality**
- [ ] Pick 3–5 rules marked `HIGH`, open the code they cite, confirm they match
- [ ] Read the source-gap list. Is it the list you would expect? Surprises mean missing material
- [ ] **Completeness report run** once the grade reached roughly B, and its findings folded in with `/fix-knowledge-extraction`
- [ ] No `TOTALLY_WRONG` or `INACCURATE` finding left open; every missing entity extracted or explained

**Gate**
- [ ] Grade **B or better**, zero critical issues
- [ ] Every source gap has an owner: material to be supplied, or a documented decision to proceed without it

**Fail →** supply material and re-run the affected agents, or re-run the fixer.

---

## Stage 1.3 · Capability Split ★

### What this stage does

Turns a pile of technical findings into a **plan shape**: the system expressed as a list of business capabilities, grouped into migration waves that will be delivered in sequence.

**Each capability becomes one BRD at [Stage 1.4](#stage-14--business-requirements--product)**, so the split decides how the requirements are packaged for sign-off — which documents exist, what each covers, and who on the client side owns each one. Agree the organising principle with the client before running it; the [Cookbook](#chapter-5--decide-how-the-brds-are-split) sets out the questions to ask.

> **Open-questions gate.** If you have run `/resolve-open-questions extraction` and it left any
> **blocking** question unanswered, this command stops before doing any work. Answer the question (or
> mark it `NOT-BLOCKING`/`DEFER`) and re-run `/resolve-open-questions extraction --apply`, then retry.
> If you have never run that command, this gate always passes — nothing changes for you. See
> [§5.4 Troubleshooting](#54-troubleshooting).
>
> **Two ways to answer, and you pick per run.** `/resolve-open-questions <scope>` reports the count
> (`Blocking: N of M`) and then offers either to walk you through the questions in conversation — the
> proposals become choices, three at a time, grouped by who owns them — or to hand you the register file
> to fill in yourself. Neither is the fallback: a handful of questions is faster answered in
> conversation, a register of forty is better read in full in an editor. `--interactive` re-enters that
> walkthrough later over a register that already exists (add `--ids OQ-0012,OQ-0031` for specific ones),
> so an interrupted session picks up where it stopped and never re-asks what is already answered.
> Answering is not applying, in either mode: the gate stays shut until `--apply` has promoted the
> decision into the artifacts. And you can run the command bare — `/resolve-open-questions` on its own
> asks which scope you mean, showing each one's register and how much of it is still open.

### Step 1 — Run

```
/capability-split
```

The agent proposes a structure, you give feedback, and it re-displays the **complete updated proposal** each round. **Nothing is written to disk until you say "approve".**

Give feedback on: wave names and objectives · capability names · which wave each capability belongs to · complexity and priority ratings · capabilities to add, merge, or split · how many waves you want.

#### Speaking the client's language — part of getting the split right

A split derived purely from the code will be *technically* correct and still wrong, because it will not match how the client talks about their own system. Part of this stage is fixing that, and the way you fix it is to **feed the client's vocabulary in**:

- **Their names for things.** If they call it "core" and "site-specific", split on core and site-specific — not on whatever the module structure implies.
- **Their documents.** Point at a document they gave you and say *"split it the way this describes."*
- **Their structural expectations.** "They treat this part as shared and reused across products, and this other part as specific to one product" is exactly the kind of instruction that belongs here.

Everything downstream inherits these names — architecture, roadmap, epics, stories. Getting the vocabulary right here is what makes every later conversation with the client straightforward instead of a translation exercise.

#### Ask for demoable waves — say it out loud

If the client expects to see something working at the end of each delivery wave, **you have to ask for that here**. The agent's own sequencing rules optimise risk and dependency order — foundation enablers first, then the high-risk capabilities, then their dependents — and say nothing about what a stakeholder can watch. Left alone they will happily hand you a Wave 1, a Wave 2 and a Wave 3 that each end in infrastructure.

**Wave 0 is the exception, and that is correct.** Scaffolding comes first — infrastructure, shared plumbing, security, test coverage, observability — and it has no clear business value by design. The requirement applies **from Wave 1 onward**.

There is no flag for this. It goes into the feedback loop before you approve, in the same breath as wave names and assignments:

```
Wave 0 is scaffolding — infrastructure, security, test coverage, observability — and does not
need to be demoable. From Wave 1 onward, every wave must end in something we can demo to the
client: a user-facing flow through UI, business rules and data, not an internal enabler. For
each of those waves, name what we would show at the end of it and which business outcome it
proves. Where an enabler is needed for a wave's demo, put it in that wave rather than
deferring it. If a capability cannot contribute to a showable slice, say so and justify where
you have placed it.
```

Then read the re-displayed proposal against it: every wave from 1 on has a named demo and a business outcome, no delivery wave is purely technical, and each wave is an end-to-end vertical slice rather than a horizontal layer. Wave 0 is judged on whether it unblocks Wave 1, not on demoability.

Fix this here or pay for it later. `capabilities/summary.json` is the capability→wave map that both [Stage 2.1](#stage-21--target-state-architecture) and [Stage 3.1](#stage-31--the-implementation-backlog) read, so wave shape propagates through everything downstream. Re-shaping waves after epics exist means re-running this stage and re-deriving the backlog from it.

> **This is not the demo track.** Demoable waves mean the programme itself shows value every wave. The [demo track](#stage-20--the-demo-track--optional-run-in-parallel-) is a separate, much smaller run done up front to win the decision. Different problems — you can use both.

### Step 2–3 — Validate / fix

There is no automated validator here. **The back-and-forth proposal loop *is* the validation** — use it properly rather than approving the first draft.

### Practical advice

- **Do this in a room with the Product Owner.** It is a business-structure decision wearing technical clothing. Do not do it alone.
- **Wave 0 should be foundational** — infrastructure, scaffolding, shared plumbing. If something in Wave 0 depends on a later wave, the sequence is wrong.
- **Sanity-check against the team you actually have.** Six waves may be optimal on paper and undeliverable with three developers.
- **Expect two or three rounds.** Approving the first proposal is usually a sign nobody read it carefully.

> ★ **This is the highest-leverage gate in the whole process.** The structure decided here flows into the architecture, the roadmap, the work breakdown, and the estimates. An hour of attention here saves days later.

### ✅ Gate 1.2 checklist
- [ ] Every capability your stakeholders would name is present
- [ ] Every feature area found in extraction maps to some capability — nothing orphaned
- [ ] Wave 0 is genuinely foundational; nothing in it depends on a later wave
- [ ] Complexity and priority ratings match the architect's judgement
- [ ] The number of waves is deliverable by the real team
- [ ] **Product Owner and architect both approve**

---

## Stage 1.4 · Business Requirements 🟩 PRODUCT

### What this stage does

Produces one **Business Requirements Document** per capability — a description of what that part of the system does, written in business language, with no code references. This is the document Product signs off, and the source for all later stories.

### Step 1 — Run, per capability or all at once

```
/export-for-alignment '<capability-name>'
```

Omit the name and it reads the capability map, offers you the full list, and — with your
confirmation — fans out one BRD agent per capability in batches of up to 10, all launching
simultaneously within a batch, instead of one capability at a time.

BRDs must be **business language and technology-neutral** — they may end up driving a rebuild on a completely different technology stack, so class names, database columns, and product names do not belong in them.

### Step 2 — Validate

```
/validate-brd
```

Scores every BRD out of 100 across five weighted dimensions.

#### What the BRD validator checks

| Dimension | Points | What it checks |
|---|---|---|
| **Capability and wave alignment** | 20 | The frontmatter capability tag matches the Section 2 capability definition · the capability exists in the capability map · the BRD maps to a delivery wave · every "Related Business Capabilities" reference resolves to a real BRD. If the capability map is missing entirely it records one portfolio-level critical issue rather than zeroing the dimension — the BRDs are not punished for a missing input |
| **Document structure completeness** | 20 | All ten mandatory sections are present — Executive Summary · Business Capability Definition · Business Workflows · Business Rules and Constraints · Current Capabilities and Gaps · Stakeholder Requirements · Future-State Vision · Related Business Capabilities · Success Metrics and KPIs · Risks and Mitigation — plus the traceability appendix |
| **Requirement clarity and measurability** | 25 | Vague language in requirements and rules — *fast*, *easy*, *user-friendly*, *should* where it means *shall*, *etc.*, *as needed*, *where appropriate* — and requirement clusters carrying no identifier and no appendix trace |
| **Acceptance criteria quality** | 15 | Every KPI in Success Metrics states a measurable target — a number, a percentage, a time bound or a clearly testable condition. A BRD with no measurable criteria anywhere is a high finding |
| **No duplication, no conflicts** | 20 | Portfolio-level: near-identical workflows or rules across BRDs · the same behaviour specified twice · **contradictory behaviour for the same scenario**. Each duplication is reported with the BRD nominated to own it — cross-references between BRDs are fine, copies are not |

### Step 3 — Fix loop — two different fixers, used in order

| Command | What it does | When to use it |
|---|---|---|
| `/fix-brd` | Applies corrections **from the validation report** | After validation flags issues |
| `/fix-brd-readiness` | Strips out technical coupling — rewords, relocates, demotes. **Never adds requirements** | Before the BRDs drive stories on a new technology stack |

Then **re-run `/validate-brd`** and confirm the score actually moved.

**Optional — external accuracy check.** `/validate-brd` checks *internal* consistency; it cannot tell you whether a claim is factually true. Where the system has authoritative external documentation — a vendor product guide, a published API reference, a regulatory specification — a second, product-specific verifier pass is worth building:

1. **Verify** each BRD claim against the external documentation, using source code only as a tie-breaker where the docs are silent.
2. **Trace the gaps**: for anything the docs describe but the BRD omits, check whether extraction ever captured it.

Step 2 is the valuable one — it surfaces functionality that exists in the code but was **missed during extraction**. Feed those findings back to `/fix-knowledge-extraction` and re-run Gate 1.1. Skip this where no authoritative external documentation exists.

### Practical advice

- **Batch them.** Generate all BRDs, then validate all of them, then fix. Switching per capability wastes time.
- **The readability test is the real test.** Give one BRD to someone with no technical background. If they need a translator, it is not finished.
- **Run a workshop, not a review-by-email.** Send BRDs ahead and drive the agenda from their gaps, risks, and opportunities sections — those are the parts that generate discussion.
- **Always run `/fix-brd-readiness` before Phase 2.** Technical coupling that survives into the BRD will propagate into every story built from it.
- **Publish the site before the workshop** — stakeholders can browse capabilities instead of opening files.

> **Open-questions gate.** Once every BRD is drafted, run `/resolve-open-questions brd` to catch flagged
> assumptions before they harden into architecture. This register's blocking questions gate both
> [Stage 2.1](#stage-21--target-state-architecture) and [Stage 3.1](#stage-31--the-implementation-backlog)
> (`/create-epic-backlog`) — clear it here rather than discovering the stop later.

### ✅ Gate 1.3 checklist — ends Phase 1
- [ ] Every capability has a BRD, or a written decision not to write one
- [ ] A non-technical stakeholder can read one unaided
- [ ] No class names, routes, table names, or product names in the body
- [ ] Gaps and risks match known business pain
- [ ] Every "requires stakeholder input" item has an owner
- [ ] Portfolio grade **B or better**, zero critical issues
- [ ] `/fix-brd-readiness` has been run
- [ ] **Product and Architecture have signed off**
- [ ] 🌐 Site published and shared

---

# Part III — Phase 2 · Target State & Proposition

> **Purpose in one line:** decide what the replacement looks like, in what order to build it, and how big the job is.

**Deliverable:** the proposition — target architecture, phased roadmap with the work breakdown, and estimates. Optionally, a working demo (§2.0).
**Leads:** Architect + PM.

> **No agent in this phase reads source code.** They work only from the Phase 1 knowledge base. If something here is wrong, the fix belongs back in Phase 1.

## Agents in this phase

| # | Agent | What it does | Writes to |
|---|---|---|---|
| **2.0 — Demo track** 🎬 *(optional, parallel — see [Stage 2.0](#stage-20--the-demo-track--optional-run-in-parallel))* | | | |
| — | `demo-init-planner` | Establishes the demo baseline: purpose, scope, candidate flows, target stack — learned from the knowledge base, not assumed | `demo/demo-overview.md` + `demo-findings.json` |
| — | `demo-flow-describer` | One per approved flow, in parallel. A presenter-ready business description with **zero technical detail** | `demo/business-flow/` |
| — | `design-guide-extractor` | Extracts the existing app's look and feel as technology-agnostic design tokens. The one Phase 2 agent that reads source — UI source only | `design-guide.md` |
| — | `knowledge-base-research-agent` | `/research` — a cited evidence note used to scope the demo against a stated budget. Clarifies before it researches | `research/<slug>.md` |
| **2.1 — Architecture** | | | |
| 20 | `target-state-architecture-agent` | Designs the future platform and structure from the knowledge base plus your direction. **Presents a plan first** — writes nothing until you confirm | `target-state/architecture/` |
| 21 | `architecture-validator` | Checks **form**: completeness, diagrams, internal consistency | `validation*` |
| 22 | `architecture-completeness-validator` | Checks **substance** — that nothing extracted was forgotten. Can hard-block | `completeness-validation*` |
| **2.2 — Roadmap and work breakdown** | | | |
| 23 | `transformation-agent` | Phased migration roadmap **and the wave-level work breakdown**: scope and deliverables per wave, sequencing, coexistence, rollback | `target-state/transformation/` |
| 24 | `team-estimation-agent` | **Auto-chained** after the roadmap. Builds one WBS, then staffs and PERT-estimates it three ways — cost-optimized, time-optimized, safe & realistic | `target-state/transformation/` |
| **2.3 — Estimation** | | | |
| — | *(no new agent)* | You calibrate agent 24's options against your own delivery history and **own the commercial number** | your proposition |

> **The epic-and-story backlog is not built here.** Waves, their scope and their deliverables are the work breakdown Phase 2 needs. Turning a wave into epics and stories is implementation planning, and it opens Phase 3 — see [Stage 3.1](#stage-31--the-implementation-backlog).

---

## Stage 2.0 · The demo track — optional, run in parallel 🎬

### What this stage does

Builds a small, working, clickable version of the future system while the proposition is still being written — so the client decides from something they can use rather than from a document.

It is optional, but it changes the conversation more than any document in this phase does. It also front-loads the technology risk: you find out whether the target stack actually works for this domain before anyone commits to it.

**It is a parallel track, not a phase of its own.** It reuses the same commands as the main path, scoped down to a handful of flows. It is numbered 2.0 because it starts early and runs across the whole phase — but its first real step needs a decided target stack, so in practice it begins once [Stage 2.1](#stage-21--target-state-architecture) has a direction (or once the options study below has picked a scenario), and it should be showable by the Gate 2.3 proposition.

### Step 1 — Research the scope and the budget

Do not start by picking flows. Start by writing down what the demo has to prove and what you are allowed to spend on it — the second half is what keeps the answer buildable.

```
/research We are scoping a demo of the modernized system for <client>.
Goal: <what the demo must prove, and to whom>.
Business outcome they should see: <...>.
Budget: <N> weeks calendar, <N> engineers, target stack <...>.
Propose 2–4 end-to-end flows that fit that budget, ranked by business value. For each:
the business outcome it demonstrates, the screens involved, its dependencies on the
other flows, and what it does NOT prove.
```

Writes `knowledge-base/research/<slug>.md`. It needs nothing but Phase 1, so you can run it the moment extraction is done.

**State the budget as numbers, not adjectives.** "A small demo" gets you a proposal for a small system. "Three weeks, two engineers" gets you three flows.

Step 3 passes this note's **path** to the planning agent, which reads it in full as evidence — so it keeps its confidence grades and citations instead of being flattened into a prompt.

### Step 2 — Confirm the scope with the client 🟪 HUMAN STEP

Take the proposed flow set to the client **before generating anything**. They will add one, drop one and re-rank the rest — that is the point of asking.

Then bring the agreed set back into the repository: if the change is material, re-run `/research` or amend the note, so the evidence the machine reads matches what was actually agreed. A note that contradicts the agreed scope will quietly argue for the wrong flows all the way down the chain.

See [§1.5](#15-working-with-the-customer) for how to run that conversation and what to get in writing.

### Step 3 — Run the demo chain

```
/demo-plan Domains: order capture, fulfilment. Stack: Azure, .NET, React.
Audience: client CTO and operations leads. Timeline: 3 weeks to the showing.
Out of scope: EDI, billing, historical data migration. --design-guide
```

Five dimensions, and it asks for whatever you leave out: **domains · target stack · audience · timeline · out of scope**.

The chain is `/demo-init` (scope and flow approval) → a demo-scoped target architecture in `target-state/architecture/demo/` → `/demo-flows` (a presenter-ready business description per flow) → `/design-guide`, if you passed `--design-guide`.

> **The flow table is the one machine-enforced gate in this run.** `/demo-init` prints the proposed flows and stops. Approve, or say what to change — add, drop, merge, rename, re-rank — and it patches both `demo-findings.json` and the overview document so the two cannot diverge. Nothing downstream runs until you approve.

Idempotent by step: re-running skips the architecture when `architecture/demo/` already exists. Each piece is also runnable alone — `/demo-init` to re-scope, `/demo-flows flow-02` to rewrite one description, `/design-guide` whenever.

`knowledge-base/demo/` is deliberately flat: one demo per repository.

### Step 4 — Design system and a clickable, UI-only demo

```
/design-guide
```

Writes `knowledge-base/design-guide.md` — a technology-agnostic style guide taken from the existing application's own UI: fonts, type scale, colour palette, spacing, component patterns. **This is what makes the demo look like *their* product**, and it visibly changes how seriously stakeholders engage with it.

Then write a screen-by-screen inventory for the approved flows — what each screen shows, what it does, what it calls — and feed that plus the design guide into a design or prototyping tool. The output is plain HTML screens you can click through: **UI only, no backend, no generated code.** Put them in a dedicated folder, `ui-mockup/`. Expect several rounds; the first pass is never the one you show.

**Build this before any epic or story exists.** A clickable mockup costs hours to change; a backlog written against the wrong screens costs days, and code written against them costs more.

### Step 5 — Agree the UI/UX and the flows with the client 🟪 HUMAN STEP

Walk the client through every approved flow in the clickable mockup, screen by screen, as the user would. This is where they tell you what the flow should really look like — a missing field, a step in the wrong order, a screen their users would never use.

- **Change the mockup, not a document.** Iterate on the screens until the client agrees them. People react to something they can click far more precisely than to a flow description.
- **Get the agreement in writing** — the screens and the flow, by name and version, as for any sign-off ([§1.5](#15-working-with-the-customer)).
- **Feed what changed back.** If a flow changed materially, update the flow description (`/demo-flows flow-NN`) so the knowledge base matches what was agreed.

The agreed mockup becomes the target every epic, story and line of front-end code is written against. **Do not generate the backlog until it is agreed.**

### Step 6 — Demo-scoped roadmap and epics

From here on, every command takes `demo` as an argument. Same commands as the programme, different track:

```
/transformation-roadmap demo
/create-epic-backlog demo
/resolve-open-questions epics demo
/validate-backlog demo
```

Each one reads the `demo` track of every stage that has one — `/create-epic-backlog demo` reads `architecture/demo/` and `transformation/demo/`, never the flat programme versions, and the two backlogs never mix. **Two stages are the exception.** The [capability split](#stage-13--capability-split-) and the [BRDs](#stage-14--business-requirements--product) are shared rather than tracked, so the demo reads those flat — and gates on them: `/create-epic-backlog demo` requires `knowledge-base/capabilities/`, and `/story-intent demo/…` requires that *and* the flat BRDs. Both must already exist from Phase 1 before the demo backlog will run. See [What a track scopes](#what-a-track-scopes--and-what-it-does-not).

### Step 7 — Generate stories incrementally, not all at once

Stories are generated here, in the analysis repository, where the knowledge base and every gate `/story-intent` checks already exist. You do not need stories for every epic before you start building. **The epic is the unit:**

```
/story-intent demo/wave-01/epic-01     # one epic
/story-intent demo/wave-01             # a whole wave
/story-intent                          # lists every epic that has no stories yet
```

Generate the first epic's stories, copy them across (Step 8), build them, show them, then generate the next epic. Stories written after the client has seen something working are better stories — and the feedback lands in stories that are still `Draft`, where it is free to apply.

What you cannot do is half-generate a single epic: `/story-intent` reconciles the files it wrote against that epic's `STORIES-PLAN.md` and re-spawns until they match. All of one epic, or none of it.

`/validate-backlog demo` is happy with epics that have no stories yet — none of its twenty checks requires them. An unfinished backlog is a normal state here, not a gap.

### Step 8 — Link or copy the plan into the implementation repository, and enforce it

The demo is built in a **separate implementation repository**, not in the analysis repository that holds the knowledge base ([Decide first](#decide-first-which-repository-does-phase-3-happen-in)). The implementation agents can only follow what is in the repository they run in, so the stories, the target architecture and the UI/UX guides have to be there too — linked or copied.

| What | Where it lands in the implementation repository | Link or copy |
|---|---|---|
| **Stories** and their epics — `knowledge-base/target-state/backlog/demo/`, including `open-questions-stories.*` if you ran `/resolve-open-questions stories demo` | **Exactly** `knowledge-base/target-state/backlog/demo/` — the implementation commands look for stories at that path | **Copy.** `/new-story-spec`, `/new-story-impl` and `/archive-implemented` write each story's status into its file and commit it with the code, on the story's branch. A linked file would change in the other repository, outside those commits |
| **Target architecture** — `knowledge-base/target-state/architecture/demo/` | The same path, so references inside the stories still resolve | **Link or copy** — read only |
| **UI/UX guides** — `knowledge-base/design-guide.md`, the agreed screens in `ui-mockup/`, and the flow descriptions in `knowledge-base/demo/` | The same paths | **Link or copy** — read only. A link (a git submodule of the analysis repository, or a symlink to a checkout beside it) keeps one version when the client changes the UI. A copy is simpler and freezes exactly what was agreed |

Copy each epic's stories as soon as `/story-intent` has written them. **From then on, the implementation repository's copy is the live one** — statuses change there, and `/add-features` runs there. If you publish the demo site from the analysis repository, copy the stories back first so it shows current statuses.

Install the plugin in the implementation repository too, and meet the Phase 3 [prerequisites](#prerequisites).

**Then enforce it in the implementation repository's `CLAUDE.md`.** Agents do not reliably consult the architecture, the mockup or the design guide unless told to, every time. A standing instruction does that:

```markdown
## Demo implementation rules
- Stories live in knowledge-base/target-state/backlog/demo/. Work them only through
  /new-story-spec → /new-story-impl → /archive-implemented.
- Follow the target architecture in knowledge-base/target-state/architecture/demo/.
  Do not introduce components, services or technologies it does not name.
- Before specifying or implementing any story that touches the UI, open the matching
  screen in ui-mockup/ and match its layout, fields and navigation. If no screen
  matches, stop and say so.
- Take every font, colour, spacing and component style from knowledge-base/design-guide.md.
  Do not introduce new styles.
- The flows agreed with the client are described in knowledge-base/demo/. Do not add
  screens, fields or steps that are not in the mockup; propose them with /add-features.
```

This measurably improves the generated code — the front end most of all — because the agent works from a concrete target instead of a written description. Agents will still occasionally forget; when a specification ignores the mockup or the architecture, say so and have it redo the task breakdown.

### Step 9 — Build the demo

Ordinary Phase 3, pointed at the demo track, **run in the implementation repository**:

```
/new-story-spec knowledge-base/target-state/backlog/demo/wave-01/epic-01-<slug>/stories/story-01-<slug>.md
/new-story-impl <branch-name>
/archive-implemented
```

The track name becomes the first segment of the branch, so demo work is obvious in the branch list. The open-questions gate here is **per story**, so one story with an unresolved question never blocks the others.

### Step 10 — Revise the scope mid-build with /add-features

Demo scope moves — the client sees the first flow and asks for something adjacent. That is `/add-features`, not a re-run of `/create-epic-backlog`:

```
/add-features Add a shift-handover summary screen to the fulfilment flow, showing open orders per line.
```

- **It scans before it writes.** An analyst sweeps the backlog for duplicates, overlaps and contradictions and writes its findings to `add-features-findings.json`/`.md`, and you are asked about each one before anything changes.
- **It asks which track** when both a demo and a programme backlog exist. It never scans one and writes to the other.
- **New epics and stories are delegated**, not hand-authored by the command — the same `epic-backlog-agent`/`story-intent-agent` `/create-epic-backlog` and `/story-intent` use, so a story `/add-features` creates matches whatever those agents currently produce.
- **It is Draft-only.** `Active`, `In Progress`, `Ready For Review`, `Done` — every non-Draft story is locked. A change that would need one is reported as a follow-up for a human to decide, never applied.
- **Run it in the implementation repository** — its copy of the stories is the live one, so that is where it can see which stories are still `Draft`.
- **It needs a clean tree on `main`** and works on its own branch.

### Step 11 — Publish

```
/publish-knowledge-base demo
```

One track per publish, run from the analysis repository — copy the stories back from the implementation repository first, so the site shows their current statuses. The site explains the plan, the mockup shows the result; together they are the proposition.

### What a track scopes — and what it does not

`demo` is a folder segment under `target-state/`, so only what lives there can be scoped:

| Artifact | Demo-scoped? | Where it lives |
|---|---|---|
| Target architecture | **Yes** | `architecture/demo/` |
| Roadmap, work breakdown, estimates | **Yes** | `transformation/demo/` |
| Epics and stories | **Yes** | `backlog/demo/` |
| Epic and story open questions | **Yes** | inside `backlog/demo/` |
| Published site | **Yes** | one track per publish |
| Capability split | No — shared | one split per repository |
| BRDs and BRD validation | No — shared | one BRD set per capability |
| Extraction and BRD open questions | No — shared | the track argument is rejected for those scopes |
| Demo overview, flow descriptions, design guide | No — flat | one demo and one style guide per repository |

The shared ones are shared deliberately: capabilities and BRDs describe **the system**, and the system does not change because you are demoing part of it. The demo reads the programme's, and there is no demo-scoped variant of either.

### Programme run vs demo run — the same commands, different arguments

The argument shape is not uniform, and that is what people get wrong:

| Stage | Programme (the default) | Demo track |
|---|---|---|
| Architecture | `/target-state-architecture` | `/target-state-architecture demo` |
| Validate architecture | `/validate-architecture` | `/validate-architecture demo` |
| Roadmap | `/transformation-roadmap` | `/transformation-roadmap demo` |
| Epics | `/create-epic-backlog` | `/create-epic-backlog demo` |
| Stories | `/story-intent wave-01` | `/story-intent demo/wave-01` — a **path prefix**, not a separate argument |
| Validate backlog | `/validate-backlog wave-01` | `/validate-backlog demo wave-01` — track **first**, then wave |
| Open questions | `/resolve-open-questions epics` | `/resolve-open-questions epics demo` — scope first, then track |
| Add a feature | `/add-features "…"` | `/add-features "…"` — **it asks** which track; you never pass one |
| Publish | `/publish-knowledge-base` | `/publish-knowledge-base demo` |
| BRDs, capability split | `/export-for-alignment <capability>` · `/capability-split` | no track — the same shared artifacts serve both |

Omit the argument and you get the flat programme path, every time. There is no global "demo mode": each command is told individually which track it is working in.

### Practical advice

- **A demo is worth days, not weeks.** Its value is the feedback, and the feedback arrives on the first showing. Scope it so it fits in that budget.
- **Scope is a budget — put the numbers in the research prompt.** Weeks and people. Without them the agent proposes a demo you cannot build in the time you have.
- **Generate stories just ahead of the build.** Then client feedback lands in stories that are still `Draft`, where `/add-features` can act on it.
- **Say what it is.** A demo built on three flows is a demo. Presenting it as a slice of the finished product invites a scope conversation you cannot win later.
- **Demo and end-state are two runs of the same commands, deliberately kept apart.** Comparing the two document sets is useful in its own right — it shows the client what the demo does and does not prove.
- **Feed the feedback back.** What the client says while clicking is Phase 1 and Phase 2 input: it corrects BRDs, changes dispositions, and adds scope nobody had written down. Route it there rather than parking it in a meeting note.
- **Publish the demo alongside the site.** The site explains the plan; the demo shows the result. Together they are the proposition.

---

## Stage 2.1 · Target-State Architecture

### What this stage does

Designs the replacement system: what platform it runs on, what it is built with, and how it is structured. It works from the current-state knowledge plus **direction you supply** — the agent does not choose your technology strategy for you.

### Before you start — the six decisions

The command will ask for anything you leave out. Decide these with the client in advance:

1. **Target platform and hosting** — cloud provider or on-premise; containers, serverless, managed services
2. **Technology stack** — backend language and framework, frontend technology
3. **Architecture style** — microservices, modular monolith, serverless, event-driven, hybrid
4. **Migration strategy** — gradual replacement, phased, or single switch-over; any fixed deadlines or budget limits
5. **Primary drivers** — what this is *for*: cost, scale, speed of change, compliance
6. **Out of scope** — anything explicitly excluded

> **No client available to answer these?** There is a reliable pattern for this, and it is worth knowing because it also works for pre-sales and internal assessments.
>
> Ask for a modernization options study *before* the architecture: point it at both the extracted knowledge base **and** the code, and ask what is worth modernizing and how. It typically returns a spectrum — minimal intervention (security fixes, dependency currency) · partial re-platforming with meaningful structural change · full re-platforming — with trade-offs for each. Pick one, then hand that scenario to `/target-state-architecture` as your direction; it will generate the target state and capability mapping from it.
>
> This produces a genuinely usable proposition with no client input at all. Just be honest about what it is: the result reflects *an* opinion rather than the client's. **Label it as such in the proposition.**

> **Open-questions gate.** This stage is gated on **both** `/resolve-open-questions extraction` and
> `/resolve-open-questions brd` — a blocking question left open in either register stops the run before
> it starts. Never run before either register exists.

### Step 1 — Run

```
/target-state-architecture
```

Three phases: **Explore** (up to five clarifying questions) → **Plan** (it reads the knowledge base and shows you a document plan — *writing nothing until you confirm*) → **Write**.

The agent records a **read receipt** for every knowledge-base folder — either `READ` with the files it opened, or `SKIPPED` with a reason. **This is your main evidence that nothing was ignored.**

### Step 2 — Validate: run BOTH validators

They check completely different things and are not interchangeable.

| Command | Checks | Key behavior |
|---|---|---|
| `/validate-architecture` | **Form** — are the documents complete, consistent, and are the diagrams valid? | If a check *could not run*, it is marked `UNVERIFIED` rather than silently passed. One such check caps the grade at **B**; two or more cap it at **C** |
| `/validate-architecture-completeness` | **Substance** — does every single thing found in Phase 1 have a decision recorded against it? | Emits a hard **READY / NOT-READY** verdict |

#### What the form validator checks

| Dimension | Points | What it checks |
|---|---|---|
| **File completeness** | 20 | Every expected document is present with no gaps in the sequence, `summary.json` exists, and diagrams are where the track's convention puts them |
| **Metadata quality** | 15 | Named tracks must carry both the plain-text metadata block (`#` title, **Generated**, **Part of**) and a YAML frontmatter block (`status`, `generated`, `source`, `tags`); numbered tracks need frontmatter only. A missing frontmatter block is one deduction per file, not one per field |
| **Content completeness** | 20 | Placeholders left behind (`TBD`, `TODO`, `FIXME`, `[INSERT…]`) · headings with no body under them · minimum depth per key file: at least 3 sections in the overview, 2 named domains, 1 external system, 2 waves, 3 risk entries |
| **Mermaid diagram validity** | 25 | Every diagram — standalone `.mmd` files and blocks embedded in the prose — is rendered through the Mermaid CLI. The largest single dimension, because a broken diagram is invisible until someone opens the document |
| **Cross-document consistency** | 10 | Six rules: architecture-decision IDs are referenced in the prose · the target stack named in the JSON appears in the documents · external systems in the context view also appear in the integration view · domain names match across documents · wave numbers match the capability map · risk IDs are unique. **Any rule whose input is missing is marked `UNVERIFIED`, which caps this dimension at 6/10** — a check that could not run never scores as a pass |
| **Source traceability** | 10 | Every knowledge-base source the architecture claims to have used resolves to a file on disk, and the capability map is among them |

#### What the completeness validator checks

This is the coverage oracle, and it is scored proportionally rather than by deduction — the first two dimensions are literally *how much of what you extracted made it into the target design*.

| Dimension | Points | What it checks |
|---|---|---|
| **Entity coverage reconciliation** | 30 | Every entity in the data-model summary must be traceable to a named target service with a **Retain / Refactor / Retire / Defer** treatment, directly or through its owning capability. Scored as 30 × (mapped ÷ total) |
| **Feature-area coverage reconciliation** | 30 | Every module in the functional summary must map to a target capability with a disposition. Checked at module level, not endpoint level — **this is the check that catches an entire subsystem silently missing from the target design.** Also 30 × (mapped ÷ total) |
| **Upstream extraction completeness gate** | 15 | Every extraction folder on disk carries a `READ` receipt or a `SKIPPED — <reason>` with a reason that holds up. `ui-ux/` is checked by name as the known blind spot: present but unread is a high finding; genuinely absent must be acknowledged as a gap in the frontend section |
| **Backlog fitness** | 15 | The JSON — not the prose — carries what the backlog stage will actually read: a non-empty capability list, the architecture decisions, event contracts, data-ownership rules and the database strategy. **Load-bearing design that exists only in Markdown is a high finding**, because the next stage will not see it |
| **Plan-gate audit** | 10 | The plan file exists and records both the confirmed document plan and the knowledge-base gap list — evidence the plan gate happened rather than being skipped |

> **How the verdict is decided, independent of the score:** a *single* high finding in the first three dimensions — one unmapped entity, one unmapped feature area, one extraction folder neither read nor justified — forces **NOT-READY**. **READY** requires zero high findings there and at most one across the last two. A polished 92/100 with one unmapped entity is still NOT-READY.

**On `UNVERIFIED`:** a report reading `Score: 94/100 — Grade: B (capped from A: Mermaid Diagram Validity UNVERIFIED)` means the diagram check never ran. Fix the tooling and re-validate — do not bank the 94.

**On the verdict:** every entity and every feature area found in Phase 1 must carry a **Retain / Refactor / Retire / Defer** decision. A *single* item with no decision, or a single knowledge-base folder the architect never read, forces **NOT-READY** — regardless of the score. A polished 92/100 with one unmapped entity is still NOT-READY.

> **This is the only hard stop in the entire process.** It exists because building a backlog on an architecture that forgot part of the system is how modernization programmes silently lose scope. Respect it.

### Step 3 — Fix loop

```
/validate-architecture --fix
/validate-architecture-completeness --fix
```

Then **re-validate both**. The completeness fixer will add an explicit `Defer` or a `REVIEW REQUIRED` note — it will **never invent design** to fill a hole.

### Practical advice

- **Hold a one-hour decision meeting before running anything.** The six inputs are business and strategy decisions; discovering mid-run that nobody has decided the hosting model wastes the whole stage.
- **Run it more than once, on purpose.** This stage is not a single shot. Two common scopes are a *demo* architecture — a handful of flows, optimized for showing something working quickly — and the *end-state* architecture. They produce genuinely different document sets: the demo version goes low-level on the chosen flows, while the end-state version concentrates on system context, integration and data architecture. Generating both and comparing them is a legitimate and useful way to work — see [Stage 2.0](#stage-20--the-demo-track--optional-run-in-parallel-) for the whole demo track.
- **You can talk to it before committing.** Ask it to lay out the options and trade-offs first, rather than asking for a finished architecture straight away. It will ask you questions back.
- **Read the read receipt first.** It is the fastest way to spot that a whole area was skipped. Check the user-interface folder by name — it is the most common blind spot.
- **Check dispositions for sense, not just presence.** The validator confirms a decision exists. Only you can spot a `Retire` on something the business depends on, or `Defer` being used as a dumping ground.
- **A NOT-READY verdict is good news.** It found something before you built a plan on it.

### ✅ Gate 2.1 checklist
- [ ] **Completeness verdict is READY** — not merely a high score
- [ ] Every knowledge-base folder shows `READ`, or `SKIPPED` with a reason you accept
- [ ] User-interface folder specifically confirmed as read
- [ ] Dispositions reviewed for sense: no surprise `Retire`, no `Defer` dumping ground
- [ ] Every `REVIEW REQUIRED` note has a named owner and a date
- [ ] Zero `UNVERIFIED` checks, or each explicitly accepted
- [ ] Diagrams render **and** describe the real system
- [ ] Services map back to the Stage 1.3 capabilities
- [ ] Architecture board approval

---

## Stage 2.2 · Transformation Roadmap and Work Breakdown

### What this stage does

Produces the plan for getting from the current system to the target **without breaking the business on the way** — what order to migrate in, how old and new coexist meanwhile, and how to roll back if a step fails.

**It also produces the work breakdown.** The wave definitions are not just a sequence: each wave carries its scope, its dependencies and its key deliverables, and that is the structure everything below it hangs off.

| Level | What it is | Produced by | Sizing signal attached |
|---|---|---|---|
| **L1 · Wave** | A group of capabilities delivered together, with a stated scope, dependencies and key deliverables | **this stage** | scope, dependencies, deliverables |
| **L2 · Epic** | A whole workstream inside a wave — weeks of work | Stage 3.1 | **complexity**: simple / standard / complex |
| **L3 · Story group** | A cluster of related stories inside an epic | Stage 3.1 | **estimated story count** (a range, N–M) |
| **L4 · Story** | One self-contained, implementable specification | Stage 3.1 | sizing rationale |

L1 is what you estimate the proposition from (Stage 2.3). L2–L4 are implementation planning and belong to [Stage 3.1](#stage-31--the-implementation-backlog) — building them requires an approved roadmap, and building them *before* the roadmap is signed off produces a backlog you then have to redo.

### Step 1 — Run

```
/transformation-roadmap
```

Three human-gated steps: **clarifying questions** → **a short wave-level plan you must confirm** → **document generation**.

**Have these answers ready — no agent can infer them:**
- Migration constraints and any fixed deadline
- **Team topology** — how many teams, and what each owns
- **Risk appetite** — tolerance for a single switch-over versus running old and new in parallel
- Anything out of scope

It produces nine planning documents — the overall plan, roadmap, wave definitions, transition architecture, coexistence strategy, sequencing, contract evolution, temporary integrations, and rollback strategy — plus `transformation-summary.json`, the machine-readable wave list (scope, dependencies, key deliverables per wave) that Stage 3.1 consumes to build the backlog.

**The migration strategy shapes the breakdown.** Gradual replacement, a phased cut-over, or old and new running in parallel produce genuinely different waves, different deliverables and therefore a different backlog downstream. That decision is made here, with the client — the agent asks, it does not choose.

### Step 2–3 — Validate / fix

No dedicated validator. The human review below is the real gate.

### Practical advice

- **The rollback strategy is the part to actually read.** Walk through one wave's rollback out loud with the delivery team. If it cannot be described in plain steps, it does not exist.
- **Reconcile the wave lists now.** The waves defined here should match the waves from Stage 1.3. The next stage will surface any divergence, but catching it here is cheaper.
- **Coexistence is where real projects fail.** Check that every integration found in Phase 1 has an answer for the period when both systems are live.
- **Bring the PM in properly.** Sequencing is a delivery decision as much as a technical one.

### ✅ Gate 2.2 checklist
- [ ] Wave sequencing is executable by the **actual** team, not a theoretical one
- [ ] Wave definitions reconcile with the capability map from Stage 1.3
- [ ] **Every wave has a stated scope and key deliverables** — not just a name and an order
- [ ] Every capability from Stage 1.3 appears in exactly one wave
- [ ] The chosen migration strategy is written down and the waves reflect it
- [ ] Rollback strategy is genuinely executable — you talked one through end to end
- [ ] Coexistence strategy addresses every known integration
- [ ] Contract evolution covers every external consumer
- [ ] All nine documents present, plus `transformation-summary.json`
- [ ] PM confirms deliverability; Architecture confirms sequencing

---

## Stage 2.3 · Estimation and Proposition 🟪 HUMAN DECISION — agent-assisted

### What the pipeline estimates, and what stays yours

`/transformation-roadmap` does not stop at the roadmap. Once `transformation-agent` has written `transformation-summary.json`, it **automatically chains `team-estimation-agent`**, which builds a single Work Breakdown Structure from the confirmed waves and then staffs and estimates that same WBS three ways:

| Option | What it optimizes for |
|---|---|
| **Cost-Optimized** | The lowest defensible cost, accepting a longer calendar |
| **Time-Optimized** | The shortest calendar, accepting a larger, more senior team |
| **Safe & Realistic** | The baseline you would actually commit to |

All three are estimated with **PERT three-point estimation** (optimistic / most likely / pessimistic) against formal consulting grade bands (A3–F2), with Gen-AI acceleration stated as an explicit assumption rather than baked in silently. It counts **only your delivery team's headcount** — customer-side SME time is tracked separately, because the customer's own staff time is not part of your estimate.

Outputs land in `target-state/transformation/`: `wbs.md`, one document per option, `team-estimate-comparison.md`, and `team-estimate-options-summary.json`. The `generate-estimate-excel` skill renders `team-estimate-rate-calculator.xlsx` from that JSON and then verifies every figure in the workbook against it.

> **Cost figures need a rate card.** Without a blended day-rate card **per grade band** somewhere in the knowledge base, the agent produces person-day and calendar-day estimates only — no currency figures — and it will tell you so rather than inventing rates.

**What stays yours** is the part that makes it a proposition rather than a spreadsheet:

| The agent supplies | You still have to |
|---|---|
| A WBS and three staffed, PERT-estimated options | **Calibrate against your own delivery history** — the bands are a model, not your team |
| Person-days and calendar-days per option | Decide which option you are actually proposing, and why |
| Cost figures, when a rate card exists | Own the commercial number and its margin |
| Explicit Gen-AI acceleration assumptions | Decide whether you believe them for *this* client and stack |
| A risk register with severity | Turn high-severity items into a **visible** contingency line, not silent padding |

> The other time-based figures in the asset sit in the **risk register** — remediation effort and "quick wins". Those describe *risk fixes*, not the migration itself. Do not fold them into the delivery estimate without saying so.

**You are estimating from the wave-level breakdown, not from stories.** The epic-and-story backlog is built at the start of Phase 3, after this gate — so the proposition estimate is a **range grounded in wave scope and capability complexity**, and it tightens once each wave's backlog exists. Say that out loud in the proposition rather than implying story-level precision you do not yet have.

The method below is how to sanity-check the agent's numbers against your own history — do it before you put any of them in front of a client.

### Recommended method

1. **Fix a unit** — story points or ideal-days, whichever your organization already uses, and a nominal size for one story.
2. **Count the countable things per wave.** From the wave definition and the capability map: capabilities in scope, key deliverables, integrations that need a coexistence answer, entities marked `Refactor` or `Retire`, screens to rebuild. These are your volume drivers.
3. **Calibrate against your own history**, per complexity band:

   | Complexity | Typical content | Your baseline |
   |---|---|---|
   | `simple` | Operational, deployment, monitoring — no business logic | ___ per capability |
   | `standard` | Contract changes, decoupling, integration migration | ___ per capability |
   | `complex` | Domain extraction, capability rebuild, multi-service work | ___ per capability |

4. **Roll up.** Volume × band baseline → wave → programme. Add the technical enablers — foundation, infrastructure, coexistence plumbing — as their own line; they carry no capability and are the most commonly forgotten.
5. **Widen the range for later waves.** They carry more unknowns. Say so explicitly rather than pretending to false precision.
6. **Load the risk register.** Take the high-severity items from Phase 1 and add contingency as a visible line item, not as silent padding.
7. **Re-baseline per wave as you go.** When Stage 3.1 produces a wave's epics and stories, replace that wave's estimate with the bottom-up roll-up — story count × band baseline — and tell the client the range narrowed and why.

### Practical advice

- **Estimate the whole breakdown, including technical enablers.** Infrastructure work with no BRD behind it is real work.
- **A demo is not an estimate.** If you ran [Stage 2.0](#stage-20--the-demo-track--optional-run-in-parallel-), resist extrapolating its velocity across the programme — the demo deliberately skipped the hard parts.
- **Show the assumptions with the number.** An estimate without its exclusions is a number someone will hold you to out of context.
- **Deferred items are not free.** Anything marked `Defer` or `REVIEW REQUIRED` at Gate 2.1 must be either estimated or explicitly excluded in writing.
- **Later waves deserve a range, not a point.** Precision you do not have is a promise you cannot keep.

### ✅ Gate 2.3 checklist — PROPOSITION SIGN-OFF, ends Phase 2

**The estimate**
- [ ] Every wave has an estimate, including technical enablers
- [ ] Calibrated on **your** delivery history, not the complexity labels alone
- [ ] Deferred items estimated or explicitly excluded
- [ ] Contingency is a visible line item
- [ ] Assumptions, exclusions, and the fact that this is a wave-level range are written down

**The proposition bundle you present**
- [ ] Target-state architecture (Gate 2.1 — **READY**)
- [ ] Phased roadmap with rollback and the wave-level work breakdown (Gate 2.2)
- [ ] Estimates with assumptions and contingency (Gate 2.3)
- [ ] Risk register from Phase 1 attached
- [ ] 🎬 The demo, if you built one — shown, not described
- [ ] 🌐 **Site published** — this is what you actually walk the client through
- [ ] **Client / steering group approval to proceed**

---

# Part IV — Phase 3 · Implementation

> **Purpose in one line:** break the approved plan into epics and stories, then turn each story into reviewed, merged code.

**Deliverable:** an implementation backlog, working software, and specifications kept in step with it.
**Leads:** Engineering, with PM and product on the backlog.

Phase 3 has two distinct halves. **Stage 3.1 is agent-based** — it turns the approved wave-level work breakdown into epics and stories. **Stages 3.2–3.4 are not**: they drive an **SDD (Spec-Driven Development) framework** through ordinary commands, so every step stays inspectable and repeatable. Those commands are written against the SDD workflow rather than any one product — OpenSpec is what the pilot used, but another SDD framework can take its place.

### Gate 3.1 is a hand-off point, not only a checkpoint

Stage 3.1's output — an engineering-ready backlog of epics and stories — is where this asset's job ends and building begins. **You have more than one way to build from it:**

| Option | What it means | Review |
|---|---|---|
| **Stages 3.2–3.4 in this manual** | The SDD loop below: one story at a time, spec → build → close, driven by an operator | Human code review per story ([Gate 3.2](#-gate-32-checklist--per-story-covering-steps-3234)) |
| **The Software Factory asset** | A separate, tested asset that consumes this backlog and takes **automated implementation** from there | Governed by that asset, not by this manual |
| **An ordinary delivery team** | The backlog is plain Markdown and a Jira-ready CSV — no tooling of ours required to consume it | Whatever the team already does |

The stages below document the first option, because it is the one this toolkit ships. **Choosing one of the others does not invalidate anything upstream** — the backlog is the same artifact either way, which is the point of stopping at a backlog rather than at code. What changes is who or what implements it, and which review regime applies.

## Agents in this phase

| # | Agent | What it does | Writes to |
|---|---|---|---|
| **3.1 — Implementation backlog** | | | |
| 25 | `epic-backlog-agent` | Writes one epic per invocation from a pre-prepared brief. Deliberately narrow and fast | one epic file |
| 26 | `story-intent-agent` | Refines an epic into self-contained story specifications | story files |
| 27 | `backlog-validator` | Grades epics and stories on five dimensions | `backlog/validation*` |
| — | `add-features-analyst` | `/add-features` — a **read-only** scan for duplicates, overlaps and contradictions before any backlog edit | nothing (reports only) |
| **3.2–3.4 — Build** | | | |
| — | *(none — SDD commands)* | Spec, build and close, one story at a time | your repo + the spec store |

## The four steps

| Step | Command | What it does |
|---|---|---|
| **3.1 Backlog** | `/create-epic-backlog` · `/story-intent` | Turns each approved wave into epics, then epics into stories. Runs **once per wave**, not once per story |
| **3.2 Spec** | `/new-story-spec` | Picks an unblocked story, creates a branch, turns the story into a formal specification, **checks the spec covers every part of the story**, pushes, opens a merge request |
| **3.3 Build** | `/new-story-impl` | Implements every task in the specification, verifies completion, commits, pushes. Optionally runs a code review with automatic fixes first |
| **3.4 Close** | `/archive-implemented` | Updates the master specifications, archives the change, marks the story done, merges, deletes the branch |

Steps 3.2–3.4 repeat per story; step 3.1 repeats per wave.

## Decide first: which repository does Phase 3 happen in?

This catches people out, because the answer is often *not* the repository you have been working in. Decide it **before Stage 3.1**, so the backlog is generated where it will be worked.

| Situation | Where to build |
|---|---|
| Modernizing in place — same language and platform | Continue in the existing repository |
| Re-platforming onto a new technology | **A new repository.** Copy the `target-state/` folder across — architecture and transformation plan — together with the agents the implementation commands need. The old repository keeps the current-state knowledge; the new one carries the plan and the code |

Generate the backlog *after* that move, in the repository where the code will live. Every story then arrives in `Draft` status, in the right place, ready to work through.

---

---

## Stage 3.1 · The Implementation Backlog

### What this stage does

Takes one approved wave from the transformation work breakdown and refines it into the two levels engineering actually works from: **epics** (L2) and **stories** (L4), with story groups (L3) in between.

This is where the plan stops being a plan. It sits in Phase 3 rather than Phase 2 because it is implementation planning: it needs the roadmap signed off first, it is done wave by wave as delivery approaches, and its output is consumed by the build commands directly below it — not by the proposition.

> **Open-questions gate.** Gated on `/resolve-open-questions brd`. If you cleared that register back in
> Stage 1.4 this is a formality; if not, clear it now.

### Step 1a — Generate epics

```
/create-epic-backlog
```

**First it proposes, then it writes.** The proposal shows: what it read · the waves · a table of proposed epics with complexity · **coverage gaps** (deliverables with no matching BRD) · cross-wave dependencies · open questions. **Nothing is written until you approve.**

Then, wave by wave, it writes the wave overview and generates all epics in that wave in parallel, and finally produces `epics.csv` — a spreadsheet ready to import into Jira.

**Epic size is enforced.** An epic must be a real workstream — a capability transformation, a domain extraction, a contract migration, a platform change. It must *not* be a single script, config change, or deployment task; the agent refuses briefs that are too small rather than writing a trivial epic.

**It takes a scope, not just a command.** You can steer it in prose — *"epics for wave 1"* — and if you are running the [demo track](#stage-20--the-demo-track--optional-run-in-parallel-) the scope is an argument, not a sentence: `/create-epic-backlog demo` writes into `backlog/demo/` and reads the matching `architecture/demo/` and `transformation/demo/`. The demo backlog is a separate run from the programme backlog, never a subset of it.

> **Open-questions gate — the highest-leverage checkpoint in this whole feature.** Run
> `/resolve-open-questions epics` before this step. One unresolved epic-level question, left open here,
> fans out into every story the epic splits into — clearing it now is cheaper than clearing it eight
> times over in Stage 3.2.

### Step 1b — Generate stories

```
/story-intent wave-00
```

Also proposes first: it shows a proposed story split per epic and waits for approval, then writes an approved plan file per epic, then generates the stories to match it exactly.

**Stories are specifications, not tickets.** Each contains requirement intents, precise `WHEN…THEN…` statements, test scenarios, and data contracts. They are deliberately *not* sprint tasks and *not* implementation instructions.

Every story arrives in `Draft` status — ready for step 3.2 to pick up.

**You do not have to generate every epic's stories up front.** `/story-intent` works per epic, so `/story-intent wave-00/epic-01` is a normal way to run it — generate the first epic, build it, then generate the next with what you learned. `/story-intent` on its own lists every epic that has no stories yet, and `/validate-backlog` does not require them: none of its twenty checks asks whether an epic has stories. What you cannot do is half-generate one epic — the command reconciles what it wrote against that epic's approved plan and re-spawns until they match.

**Adding scope later is `/add-features`, not a re-run.** It scans the whole backlog for duplicates and contradictions first, writes those findings, asks you about each, then delegates new epic/story files to the same agents this stage uses before editing indexes itself — and it only ever touches stories still in `Draft`. Anything `Active` or beyond is locked and reported as a follow-up for a human to decide.

### Step 2–3 — Validate and fix

```
/validate-backlog            # add --fix, then re-validate
```

Grades epics and stories together out of 100 across five weighted dimensions.

#### What the backlog validator checks

| Dimension | Points | What it checks |
|---|---|---|
| **Epic completeness** | 25 | Mandatory sections present · acceptance criteria that are actually testable · story-split signals usable by the next step · placeholders left behind · traceability links that resolve |
| **Story completeness** | 25 | Mandatory sections · story identity consistent between the file, its heading and the plan · `WHEN… THEN…` coverage of the stated behaviour · Gherkin scenario quality · placeholders · traceability links |
| **Dependency integrity** | 20 | Epic dependencies declared in **both** directions · cross-wave dependencies pointing forwards, never backwards · **no cycles** · the plan file agreeing with the stories that exist · story dependency chains intact |
| **Cross-item coherence** | 15 | Wave README in sync with its epics · **scope overlap between epics** · story count against the approved plan (this is the **drift** flag) · business capabilities named consistently · technical decisions not contradicting each other between items |
| **Traceability and source alignment** | 15 | Every epic traces to a BRD · alignment with the architecture documents · **every capability in the map addressed by some epic** · gap and risk IDs from Phase 1 resolving to real entries |

> Unlike the architecture completeness check, this validator gives a **score only, with no hard verdict.** You decide. Treat critical and high findings as blocking by convention.

### Practical advice

- **Generate one wave at a time.** This is the most valuable habit in the stage. Asking for the whole programme in one pass produces epics that overlap and contradict each other across waves, which you then have to find and repair — the validator finds the contradictions afterwards, but repairing them costs more than avoiding them. Scoping the request to a single wave keeps each run focused and the output materially better. Waves are independent enough that different people can generate different ones in parallel.
- **Do not run ahead of delivery.** Refining wave 4 while wave 1 is being built wastes the work: what you learn building wave 1 changes wave 4's split.
- **Re-baseline the estimate.** Once a wave's stories exist, replace that wave's Stage 2.3 range with a bottom-up roll-up and tell the client the number moved.
- **The epic proposal is the last cheap moment to restructure.** Changing the epic breakdown after stories exist means regenerating stories too. Read that table properly.
- **Chase every coverage gap.** A deliverable with no BRD behind it means either a missing BRD or scope nobody has agreed. Both matter.
- **For small later changes, use Update Mode.** Describe the change and let it touch only the affected epics — never regenerate the whole backlog. This is also the path for a late-arriving requirement the client only thought of once they saw the demo.
- **Get a tech lead to read five stories at random.** If they cannot start work from one, the split is too vague.
- **Check the dependency graph has no cycles.** Two stories that block each other stall the build immediately.

### ✅ Gate 3.1 checklist — per wave
- [ ] Every coverage gap reviewed — each accepted with a reason or actioned
- [ ] Cross-wave dependencies match the roadmap sequencing
- [ ] Every capability in this wave is addressed by at least one epic
- [ ] Complexity ratings look right
- [ ] Story count per epic matches its approved plan; drift flags reviewed
- [ ] A tech lead confirms stories are independently implementable
- [ ] Story dependencies form a clean graph with no cycles
- [ ] Every open question answered or owned
- [ ] Grade **B or better**, zero critical and zero high findings
- [ ] `epics.csv` imports into Jira cleanly
- [ ] Wave estimate re-baselined against the actual story count
- [ ] **PM, product and tech lead approve**

---

## Stages 3.2–3.4 · Build, story by story

### Story lifecycle

Each story carries a status that acts as a resume point — re-running picks up where it stopped rather than repeating work:

```
Draft / Active → Generating Spec → In Progress → Ready For Review → Ready for Validation → Done
      │                 │               │                 │                    │
   backlog        new-story-spec   new-story-impl   new-story-impl     archive-implemented
```

Only **unblocked** stories are eligible: status `Draft` or `Active`, and every story it depends on already `Done`. Do not hand-pick a blocked story — the dependency order exists for a reason.

### Prerequisites

- Your SDD framework installed and initialized in the repository
- Start on the main branch with no uncommitted changes
- Optionally, the GitLab command-line tool for automatic merge requests (otherwise it prints a link)
- **Recommended, once:** run `/recommend-tooling` after [Stage 2.1](#stage-21--target-state-architecture) is approved and before your first `/new-story-spec`. It reads the confirmed target-state architecture and proposes verified Claude Code skills, MCP servers, and CLI tools matched to your actual stack. Installing the ones that fit gives the implementation agents framework-idiomatic patterns and structural tools instead of plain-text search-and-edit — code quality goes up and token spend per story goes down, because the agent reaches for a precise tool call instead of re-reading files to find what a dedicated tool would return directly. Every community recommendation (first-party vendor tools are exempt) must clear a hard bar — **≥2000 GitHub stars, pushed within 6 months, not archived** — or it lands in "below the bar" with its measured star count rather than being dropped silently. Output is split strictly by scope, re-derived from the architecture every run with no accumulating catalog: `knowledge-base/target-state/project-tooling.md` (**commit this** — architecture-derived, zero host facts) and `.claude/tooling/host-setup.md` (**gitignored**, outside the knowledge base — this machine's install state).

> **Open-questions gate — scoped to this one story.** If `/resolve-open-questions stories` has left a
> blocking question open **for this specific story**, `new-story-spec` stops before creating a branch.
> An unresolved question elsewhere in the backlog never blocks this story — the check is per story on
> purpose, so one hard question does not freeze the whole team. Fix it with
> `/resolve-open-questions stories --interactive` to answer in conversation, or fill the register in by
> hand, then `/resolve-open-questions stories --story <path> --apply` and retry.

### Show the user interface before you build it

For anything with a significant front end, get a **clickable mockup** in front of stakeholders before writing implementation stories — that is what [Stage 2.0, the demo track](#stage-20--the-demo-track--optional-run-in-parallel-) produces, and it is worth doing even if you never demo anything.

The part that matters here is the standing instruction: keep the generated HTML screens in the repository (`ui-mockup/`) and tell the implementation agents, once, *before implementing any flow, find the matching screen in that folder and match it.* It measurably improves the generated front-end code, because the agent works from a concrete target instead of a written description.

Agents will occasionally forget to consult the mockups. When a spec ignores them, say so and have it redo the task breakdown.

### Practical advice

- **Review the task breakdown, not just the prose.** When the specification comes back, the most important part to read is the list of tasks it intends to carry out. That is where you catch a missing verification step, a skipped integration-test run, or an ignored mockup — and it is far cheaper to correct there than after the code exists. Standing requirements ("every story includes a verification step and runs the integration tests") are worth stating once and enforcing every time.
- **Do not accept "that test was already broken."** A recurring failure mode is the agent reporting that a couple of tests fail but that it did not touch them. Sometimes true, sometimes not. Check before believing it — a green run you did not verify is not a green run.
- **Parallelize at the story level.** Stories are self-contained by design, so several engineers can work at once: each takes either a story assigned to them or any unblocked one from the backlog. The dependency graph does the coordination — if a story is unblocked, it is safe to start.
- **The merge request review is a real code review.** The automation writes code; a human still approves it. Treat it exactly as you would any other contribution.
- **Use `--with-review` on complex or security-sensitive stories.** It costs more and takes longer, and it is worth it there and not everywhere.
- **Do not skip the archive step.** It is what keeps the specifications in step with the code. Skipping it leaves documentation that drifts, which is the problem this whole exercise exists to fix.
- **Republish the site periodically** so the backlog view reflects what is now `Done`.

### ✅ Gate 3.2 checklist — per story, covering steps 3.2–3.4
- [ ] Generated specification genuinely reflects the story's intent, not just its headings
- [ ] All tasks complete
- [ ] **Merge request reviewed and approved by a human**
- [ ] Tests pass
- [ ] `/archive-implemented` run — specs updated, story `Done`, branch merged and deleted

**Then:** pick the next unblocked story and repeat.

---

## Change requests · evolving the live system in place

### What this stage does

One feature, behaviour change or refactor on the system you already run, with no migration. It needs `/knowledge-extraction` (Stage 1.1) and nothing later: no capability split, BRDs, target state or backlog. The change gets its own folder, `knowledge-base/changes/<id>/`, and its stories run through the same three implementation commands as a migration story. Use `/add-features` instead when a migration backlog exists and the request belongs in it. The runbook, with a worked example per change type, is [`change-requests.md`](change-requests.md).

### Step 1 — Propose

```
/propose-change "Round totals half-up"
```

An impact agent locates the change in the knowledge base, confirms every location in the live code, lists the behaviours it touches (each `preserve`, `change`, `add` or `remove`), rates their test coverage and plans characterization tests for what is uncovered. It then **stops at the impact checkpoint**. A story-writing agent produces the change stories only after you approve.

### Step 2 — Build

```
/new-story-spec knowledge-base/changes/<id>/stories/story-01-<slug>.md
/new-story-impl changes/<id>/story-01-<slug>
/archive-implemented
```

`/new-story-impl` pins current behaviour first: the characterization tests are written and must pass on the **unmodified** code, and are committed as `test: characterize <area>` before any behaviour changes. A **Scope drift** warning lists files in the diff that the impact report did not declare; it does not block.

### Step 3 — Refresh the knowledge base

When the last story of a change is archived, `/archive-implemented` step 8.5 updates the extraction files the change made stale and writes `knowledge-base/changes/<id>/refresh.json`. A failed refresh never blocks the archive; it leaves `status: pending`, and `/fix-knowledge-extraction --change <id>` retries it.

`/validate-backlog --changes` checks a change's impact report and stories with two deterministic scripts and no agent.

### Practical advice

- **Read the "What to check" list, not just the table.** It names the places the analysis is most likely to be wrong. The checkpoint is cheap to correct and expensive to skip.
- **Do not weaken a failing pinning test.** If a pinning test fails on unmodified code, the impact analysis is wrong. Re-analyse with `/propose-change --id <slug>`, which keeps every story that is no longer `Draft`.
- **Treat `sizing: programme` as a signal.** More than 3 capabilities or 40 files is bigger than one change; split it.
- **Refactors allow no exceptions.** Every pinning test must stay green.

### ✅ Impact checkpoint checklist
- [ ] Every behaviour the change touches is listed, with the right disposition (`preserve` / `change` / `add` / `remove`)
- [ ] Dependents are plausible (and `dependencySource: grep` has been read as possibly incomplete)
- [ ] No behaviour is rated better covered than its tests deserve
- [ ] Any `breaking` contract has a consumer plan
- [ ] Blocking open questions are answered or owned
- [ ] Pinning tests pass on unmodified code before the change is made

**Then:** `/archive-implemented` per story; the last one refreshes the knowledge base.


---

# Part V — Reference

## 5.1 The published site 🌐

```
/publish-knowledge-base
```

Turns everything in `knowledge-base/` into a self-contained static website at `knowledge-base/site/index.html`. Copy the folder anywhere that serves files — as a site it needs no server and no database of its own.

| Section | Audience | Content |
|---|---|---|
| Product view | Product, business stakeholders | Capabilities, features, APIs, data |
| Architecture view | Architects, engineers | Structure, modules, dependencies, risks |

**When to publish**

| Moment | Why |
|---|---|
| After Gate 1.1 | First tangible output — shows the system is genuinely understood |
| Before the Gate 1.3 workshop | Stakeholders browse capabilities instead of opening files |
| While building a demo (§2.0) | The site explains the plan; the demo shows the result |
| At Gate 2.3 | **The proposition itself** — what you walk the client through |
| During Phase 3 | Keeps the backlog view current as stories complete |

Re-publishing is always safe: the site's structure is frozen and only the data behind it is regenerated.

**You can shape it.** The command takes direction like any other: ask for a particular section, an extra menu item, or a different arrangement of the material. What a client wants to see, and in what order, differs from engagement to engagement — tailor it rather than accepting the default arrangement every time.

**Publish deliberately, not automatically.** Because publishing is what stakeholders actually look at, it is also your control over *when* they see something. Finish a stage, review it, then publish — rather than exposing half-finished analysis and spending the next meeting explaining it.

### Ask the site questions 💬

```
/chat-serve
```

Builds a retrieval index over `knowledge-base/` and serves the site **together with a chat endpoint**, as one process, so the widget that ships with the site scaffold can answer questions about the knowledge base. Publish first — the widget is part of the site, not a separate page.

This changes what a stakeholder can do with the site: instead of hunting for the right document, they ask *"which capabilities touch billing?"* and get an answer grounded in the extracted material. It is a Node application rather than an agent, configured through `.env`.

**Publishing already did most of the work.** `/publish-knowledge-base` builds the search index (`chat-index.sqlite`) and copies the backend into `knowledge-base/chat-widget/`, so whoever receives the folder can start it with `cd knowledge-base && ./chat-widget/run.sh` — no plugin and no Claude Code session needed. One process then serves both the site and the chat API, so the widget talks to it same-origin with no configuration.

> ⚠️ **This is the one part of the asset that is not just files.** Everything else the toolkit produces is Markdown, JSON and static HTML you can email or drop on a shared drive. The chat is different, and it is worth being explicit about what it costs you:
>
> | | Static site alone | With the chat backend running |
> |---|---|---|
> | **Hosting** | Anything that serves files — SharePoint, Pages, a shared drive | A host that can run a **long-lived process** |
> | **Dependencies** | None | **Docker** (or Node), which builds a native SQLite module on first run |
> | **Storage** | None | A local SQLite index alongside the site |
> | **Network** | None inbound | An **inbound port**, plus outbound calls to the model API |
> | **Credentials** | None | An API key or gateway token the host must hold |
>
> **SharePoint and a shared drive cannot do the right-hand column.** If that is where the site lives, the widget will be present but inert — it reports "Can't reach the chat backend" rather than breaking the page.

> **Decide who is allowed to reach it.** A chat endpoint is an inbound service holding a model credential and an index of the client's system. Do not hand out a chat URL without answering that question first.

## 5.2 SME input — when you need a human expert

Agents reconstruct what the code *does*. They cannot know what the business *intends*, what is deliberately unused, or what lives outside the repository.

> For **who** you need from the customer side, how to run SME sessions, and what a sign-off has to contain, see **§1.5 Working with the customer**. The table below is the gate-by-gate summary.

| Gate | What only a human can supply | How it gets in |
|---|---|---|
| **1.0** | Missing material — database, rule exports, documentation | Put it in the repository |
| **1.1** | Answers to **source gaps**; confirmation the inventory is complete | Supply the artifact → re-run that agent → re-validate |
| **1.2** | Business grouping and wave sequencing judgement | Feedback loop until you approve |
| **1.3** | Business validation of the BRDs | Workshop → `/fix-brd` → re-validate |
| **2.1** | The six architecture decisions; whether dispositions make sense | Answered at the prompt; dispositions reviewed by hand |
| **2.2** | Timeline, team topology, risk appetite | Clarifying questions before the plan |
| **2.0** (demo) | Which flows to demo; reactions to the clickable mockup | Client picks the flows; feedback routed back into BRDs and architecture |
| **2.3** | **Every estimation number** — the asset supplies none | Your delivery history |
| **3.1** | Accepting or actioning coverage gaps; story implementability | Proposal feedback; tech lead review |

**Standing practice:** after every validation run, collect every "requires stakeholder input" entry, every `REVIEW REQUIRED` note, and every **source gap** into one list. That list is the agenda for your next SME session. Never let a hard gate pass with unowned items on it.

## 5.3 Cost tracking

Every session's tokens, cost, model, and duration are computed on demand from Claude Code's own
transcripts — no setup needed. The plugin's `SessionStart` hook refreshes an untracked, per-machine
ledger at the start of every session; a session's own tokens land in that ledger at the *next* session
start, not immediately.

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py --report          # readable table
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py --report --json   # machine-readable
```

`--report` also rewrites the team-visible `.claude/logs/summary.jsonl` in the target repo, if that
repo's maintainers choose to track it — `/archive-implemented` already does this at its final step
once a story merges to `main`.

Agents run on a mid-tier model, except the epic writer which runs on the fastest tier because its instructions are fully prepared in advance.

**In practice the mid-tier model does around 90% of the work**, and it handles it well. Control the model by hand and step up to the most capable one for a narrow class of problem: **fitting a late-discovered requirement into an existing backlog.** The typical case is the client asking for something that was never in the original story breakdown — writing that story correctly means finding everything it depends on and everything it disturbs, which is exactly the judgement worth paying more for. Bulk generation gains nothing from it.

**On budgeting.** Extraction dominates the cost, and it scales with how much code there is. As a reference point, a codebase of over a million lines was comfortably affordable, and the team that ran it over-estimated what they would need — they set aside roughly twice what they actually spent. Budget generously and expect to come in under; do not let cost anxiety push you into skipping the fix loop, which is where the quality comes from.

### Optional: live telemetry with OpenObserve

The stats ledger above is after-the-fact. If you also want to *watch* a session — metrics, logs and traces from Claude Code as they happen — run OpenObserve locally in Docker. It is optional, per-machine, and nothing in the pipeline depends on it. This setup ships in the toolkit repo itself (`compose.openobserve.yaml`, `.env.openobserve.example`); it is not copied into a target repo by `/plugin-init`, so this section is for toolkit maintainers: run step 1 from a clone of the toolkit repository.

**1. Start the service.** Needs Docker.

```bash
cp .env.openobserve.example .env.openobserve    # then set a strong ZO_ROOT_USER_PASSWORD
chmod 600 .env.openobserve
docker compose --env-file .env.openobserve -f compose.openobserve.yaml up -d
curl --fail http://localhost:5080/healthz
```

Open <http://localhost:5080> and sign in with the email and password from `.env.openobserve`. It listens on `127.0.0.1:5080` only; state lives in the git-ignored `openobserve/` folder, with 180-day retention. The root credentials are applied **only on first run** — editing `.env.openobserve` later does not change a user already stored in `openobserve/`.

**2. Point Claude Code at it.** First choose *where* the settings live, because Claude Code reads some telemetry variables from some files only. It deliberately **ignores the exporter variables in a repository's `.claude/settings.json` and `.claude/settings.local.json`** (Claude Code v2.1.282 or later), so a cloned repository cannot switch telemetry on, choose where it goes, or capture content.

| File | Applies to | In git? | Telemetry variables it can carry |
|---|---|---|---|
| `~/.claude/settings.json` | **Every project** on this machine, this user | No (outside any repo) | **All of them** — this is where the exporter block below belongs |
| `./.claude/settings.local.json` | **This repository only**, this user | No — git-ignored | Labels and timings only (`OTEL_RESOURCE_ATTRIBUTES`, the `*_EXPORT_INTERVAL` values) and *off* switches (an exporter set to `none`, a content flag set to `0`). Exporter, endpoint, header and content variables are dropped |
| `./.claude/settings.json` | This repository, **everyone who clones it** | Yes — committed | Same restriction as above — and never put a token here |

Precedence for the keys a file may set is per key, highest first: `./.claude/settings.local.json` → `./.claude/settings.json` → `~/.claude/settings.json`. An *off* value in a repo file overrides the same variable in your user file, so a repository can opt itself **out** of export but never in. Claude Code logs a warning for each dropped variable (visible with `claude --debug`); `/status` or `claude doctor` list the names it ignored, never the values. Settings are read when Claude Code starts, so **restart it after any change** — a running session keeps the old values.

**Recommended split:** put the exporter block below in `~/.claude/settings.json` once. If you want streams from different repositories told apart, add `"OTEL_RESOURCE_ATTRIBUTES": "project.name=<repo>,deployment.environment=local"` (your own project label) to that repository's git-ignored `./.claude/settings.local.json`; the user-level block deliberately carries no `project.name`, so unrelated repositories are not mislabelled.

Generate the HTTP Basic token, then add the keys below to the `env` object of `~/.claude/settings.json`:

```bash
printf '%s' 'your-email:your-password' | base64
```

```json
{
  "CLAUDE_CODE_ENABLE_TELEMETRY": "1",
  "CLAUDE_CODE_ENHANCED_TELEMETRY_BETA": "1",
  "OTEL_METRICS_EXPORTER": "otlp",
  "OTEL_LOGS_EXPORTER": "otlp",
  "OTEL_TRACES_EXPORTER": "otlp",
  "OTEL_EXPORTER_OTLP_PROTOCOL": "http/protobuf",
  "OTEL_EXPORTER_OTLP_ENDPOINT": "http://localhost:5080/api/default",
  "OTEL_EXPORTER_OTLP_HEADERS": "Authorization=Basic <base64-token>,stream-name=claude_code_modernization_cli",
  "OTEL_RESOURCE_ATTRIBUTES": "deployment.environment=local"
}
```

**Content capture is off in this block, on purpose.** By default only metadata is exported: token counts, costs, durations, tool names and prompt lengths. To also store the text of prompts, replies, tool arguments and tool output, add the four flags below to the same `env` object — only on a machine and engagement where copying that text into a second location is acceptable:

```json
{
  "OTEL_LOG_USER_PROMPTS": "1",
  "OTEL_LOG_ASSISTANT_RESPONSES": "1",
  "OTEL_LOG_TOOL_DETAILS": "1",
  "OTEL_LOG_TOOL_CONTENT": "1"
}
```

These capture source code, credentials and personal data in plaintext, and because `~/.claude/settings.json` is user-level they apply to **every repository you open**. Run `chmod 600 ~/.claude/settings.json`; keep the `openobserve/` folder on an encrypted disk with restricted permissions. The token is the OpenObserve root login, so for anything beyond a local trial create a dedicated low-privilege ingest-only OpenObserve user (or service account) and build the token from that instead.

What each parameter does:

| Variable | What it controls | Notes |
|---|---|---|
| `CLAUDE_CODE_ENABLE_TELEMETRY` | Master switch for all export | Off by default. `1` on, `0` off. Nothing below works without it |
| `CLAUDE_CODE_ENHANCED_TELEMETRY_BETA` | Also enables **traces** (spans) | Needed *in addition* to the switch above. Without it you get metrics and logs only |
| `OTEL_METRICS_EXPORTER`<br>`OTEL_LOGS_EXPORTER`<br>`OTEL_TRACES_EXPORTER` | Where each signal is sent | `otlp` (to a collector such as OpenObserve), `console` (print locally), `none` (drop). Metrics also accept `prometheus` |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | Wire format | `grpc`, `http/json` or `http/protobuf`. Claude Code has **no default**, so it must be set. OpenObserve's API port speaks HTTP, hence `http/protobuf` |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Base URL of the receiver, all signals | For OpenObserve: `http://localhost:5080/api/<organization>`. The SDK appends `/v1/metrics`, `/v1/logs`, `/v1/traces`. The organization must exist — `default` out of the box |
| `OTEL_EXPORTER_OTLP_HEADERS` | Authentication and routing | `Authorization=Basic <base64(email:password)>` signs in as the OpenObserve user. `stream-name=…` is OpenObserve-specific and names the stream the data lands in |
| `OTEL_LOG_USER_PROMPTS` | Whether the **text of your prompts** is exported | Default: only the prompt's length. Appears in `user_prompt` events and the `claude_code.interaction` span |
| `OTEL_LOG_ASSISTANT_RESPONSES` | Whether the **text of Claude's replies** is exported | If unset, follows `OTEL_LOG_USER_PROMPTS` (so redacted by default; enabling prompts also enables replies unless you set this to `0`) |
| `OTEL_LOG_TOOL_DETAILS` | Tool **arguments**: Bash commands, file paths, URLs, MCP/skill/agent names | Default: omitted. Needed for the `tool_parameters` / `tool_input` fields on `tool_result` events |
| `OTEL_LOG_TOOL_CONTENT` | Tool **output**: file contents read, Bash output, WebFetch/search results | Goes into trace spans, so it needs tracing on. Truncated per attribute (60 KB at v2.1.282) |
| `OTEL_METRIC_EXPORT_INTERVAL`<br>`OTEL_LOGS_EXPORT_INTERVAL`<br>`OTEL_TRACES_EXPORT_INTERVAL` | How often each batch is sent, in ms | Defaults at v2.1.282: 60000 / 5000 / 5000. Lower values show data sooner at the cost of more requests |
| `OTEL_RESOURCE_ATTRIBUTES` | Extra `key=value` labels on every metric and event | Comma-separated; values may not contain spaces, quotes, commas or semicolons. Settable per repository |

Optional and not in the example: `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` / `OTEL_EXPORTER_OTLP_TRACES_HEADERS` send traces somewhere else (the endpoint is used **as written**, so it must end in `/v1/traces`; the headers are merged with the generic ones). `OTEL_SERVICE_NAME` and `OTEL_LOG_LEVEL` are not documented by Claude Code — the service name is reported as `claude-code` — so do not rely on either; for export problems use `claude --debug-file <path>` instead.

**3. Check it works.** Restart Claude Code, submit a prompt and run at least one tool. In OpenObserve look for the `claude_code.session.count` and `claude_code.token.usage` metrics, the `claude_code_modernization_cli` log stream (`user_prompt`, `assistant_response`, `tool_result` events) and, under Traces, the `claude_code.interaction` spans (the `stream-name` header is applied to the trace stream too, but this has not been checked against a live instance). Logs and traces arrive in batches within seconds; metrics take up to a minute. If nothing appears, run `claude --debug` and look for `[3P telemetry]` errors.

**Stop or disable.** `docker compose --env-file .env.openobserve -f compose.openobserve.yaml down` stops the service and keeps the data. To stop exporting for this checkout only, set `"CLAUDE_CODE_ENABLE_TELEMETRY": "0"` in `./.claude/settings.local.json`; to stop it for every repository, set it to `0` in `~/.claude/settings.json`. Restart Claude Code either way.

## 5.4 Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Extraction grade C or below | Missing source material — usually the database | Supply it, re-run affected agents |
| A folder is missing its files | An agent failed silently | The command normally re-runs it; otherwise re-run that agent alone |
| Rule-engine mapping missing | Either there is no rule engine (correct — the index says so) or the agent missed it | If the system is rules-table driven, re-run with the table export present |
| Architecture scores A but feels thin | The form validator only checks form | Run the completeness validator — this is exactly what it catches |
| Grade capped at B with `UNVERIFIED` | A check's tool was unavailable | Fix the tooling and re-validate; the score is not trustworthy until it runs |
| AI discovery is slow, or a "degraded mode" warning appeared before it | graphify was not found or its graph was unreadable (directory-based clusters and whole files), graphify's Python interpreter or tree-sitter could not be used (whole files instead of call-chain slices), or the graph was stale | Install graphify (`uv tool install graphifyy`) and re-run extraction; the warning block names the exact code and its fix (table above). For the missing-graphify, interpreter and tree-sitter causes recall is not reduced, only speed; a stale graph (`GRAPH_STALE`) may miss code added since, and `CLUSTER_FALLBACK` makes those clusters shallower |
| AI tracers ask for permission to read files outside the project | The code slices live in the system temp directory (`cap-ai-slices-*`), outside the working directory | Allow reads there, or run extraction in a permission mode that allows it; if a slice still cannot be read the tracers fall back to reading the source files directly (and note it in the run's gaps) |
| AI coverage FAILED, or "coverage not measured" for `ai/` in the quality report | CHECK-13 found AI code the `ai/` folder does not describe, or `ai/sweep.json` is missing (a knowledge base extracted before the sweep existed) | Re-run `ai-discovery-agent`: `/fix-knowledge-extraction` routes the `ai/` finding to it, or run `/knowledge-extraction` again. "Not measured" clears once `sweep.json` exists |
| A high grade but a folder feels shallow, or the completeness report says "not scored" / "insufficient sample" | The structural checks pass thin output; the folder had too few checkable claims or entities to score | Treat "not measured" and "not scored" as unknown, not as good. Run `/completeness-report` once the grade is roughly B, and re-run the thin folder's agent with a directive naming what is missing |
| NOT-READY despite a high score | One item with no decision, or one folder never read | Resolve it, or record an explicit `Defer` **with an owner**. Do not proceed |
| Wave lists disagree between stages | The stages diverged | The epic backlog surfaces this in its proposal — reconcile before approving |
| Story count far off the estimate | The split diverged from the epic's signal | Accept with a reason, or re-split |
| Implementation command refuses to run | Not on the main branch, or uncommitted changes | Commit or stash, switch to main |
| A stage stops with "blocking open question" | An `/resolve-open-questions` register for that scope has an unanswered blocking question | Answer it either way — `/resolve-open-questions <scope> --interactive` to be walked through it, or fill in the `**Answer:**` block in the register by hand (or mark `DEFER`/`NOT-BLOCKING`) — then `/resolve-open-questions <scope> --apply` and retry. Unlike the implementation commands above, this one runs from whatever branch you are on |
| A question comes back `Deferred`, escalated to architecture | A `target-architecture` answer is never patched into the architecture documents automatically — that would desync `target-state-summary.json` from its prose | `--apply` offers to hand it to `/brainstorm-target target-architecture --from-open-questions <scope> --ids <ids>`, which reads the register and argues the decision out against the extraction evidence. The ADR that comes out does **not** close the question: record an answer citing it (`--interactive --ids <ids>`), `--apply`, then re-run `/target-state-architecture` |
| `open-questions-cli.py check` prints "malformed register" | The register JSON is corrupt or hand-edited | Never edit `open-questions*.json` by hand — regenerate it with `/resolve-open-questions <scope>` |
| The host gate itself is broken and `/plugin-init` cannot fix it | A bug in the gate, not a missing tool | Start Claude Code with `MODERNIZATION_CLI_SKIP_HOST_GATE=1` in its environment to bypass every host check, and report the problem. Remove it once fixed — it disables the gate entirely |

## 5.5 Where everything lands

```
knowledge-base/
  extraction/               ← PHASE 1 · one folder per agent
    repository/ architecture/ functional/ data-model/ data-flow/
    integrations/ ui-ux/ business-logic-rules/ security/
    runtime-operations/ ai/ business-intent/ risk-gap/
    knowledge-graph/ extraction-quality/
    open-questions.md · open-questions.json          ← GATE · extraction scope
  capabilities/             ← PHASE 1.3 · the capability and wave map
  business-capabilities/    ← PHASE 1.4 · a BRD per capability  🟩
    open-questions.md · open-questions.json          ← GATE · brd scope
  target-state/
    architecture/           ← PHASE 2.1 · target design + validations
      <track>/                 ← optional scoped variant, e.g. demo/  🎬
    transformation/         ← PHASE 2.2 · nine roadmap documents
                               + transformation-summary.json  ← L1 · THE WBS
      <track>/                 ← optional scoped variant
    backlog/                ← PHASE 3.1 · THE IMPLEMENTATION BACKLOG
      plan.md · epics.csv                              ← L2, Jira import
      open-questions-epics.md · .json                  ← GATE · epics scope
      open-questions-stories.md · .json                ← GATE · stories scope
      wave-NN/epic-MM-<name>.md                        ← L2
      wave-NN/epic-MM-<name>/stories/story-NN-*.md     ← L3–L4
      <track>/                 ← optional scoped variant, same layout inside
  research/                 ← /research · cited research notes  🎬 scoping input
  demo/                     ← 🎬 STAGE 2.0 · demo overview, findings, flow descriptions
                               (flat — takes no <track>; one demo per repo)
  design-guide.md           ← 🎬 /design-guide · the existing app's look and feel
  site/                     ← 🌐 THE PUBLISHED WEBSITE
ui-mockup/                  ← 🎬 STAGE 2.0 · design system + HTML screens
<sdd-framework>/            ← PHASE 3 · specifications and archive
```

Naming is strict because validators rely on it: waves, epics, and stories are always zero-padded (`wave-00`, `epic-01`, `story-02`).

The `<track>` segment is the demo track's whole mechanism: pass `demo` to a stage and it reads and writes inside that segment instead of the flat root. Only those three `target-state/` folders take one — see [Stage 2.0](#stage-20--the-demo-track--optional-run-in-parallel-).

## 5.6 Quick reference card

```
╔═ PHASE 1 · CURRENT STATE ══════════════════ 18 agents ══╗
   What exists today, written down in business language

0   HOST READY /plugin-init          (once per machine, then after every update)
    GATE 0    → required tools present · marker written

1.0 SETUP      install · BUILD THE SOURCE TREE  (completeness check)
               supporting sources · /parse-docx every Word doc
    GATE 1.0 → it builds · supporting sources in · gaps listed

1.1 EXTRACT    /knowledge-extraction                14 agents, 5 phases
    loop   →   /fix-knowledge-extraction  →  re-validate, until grade ≈ B
    then   →   /completeness-report  →  /fix-knowledge-extraction again
    human  →   feature / entity / SCREEN counts vs. your own knowledge
               spot-check HIGH rules · read the source-gap list
    GATE 1.1 → grade ≥ B · zero criticals · gaps owned
               🌐 publish the site

    oq     →   /resolve-open-questions extraction  → gates 1.3 & 2.1

1.3 SPLIT      /capability-split          → say "approve"              ★
    direct →   feed the CLIENT'S VOCABULARY in · ask for DEMOABLE WAVES
               "wave 0 is scaffolding; from wave 1 on, every wave ends in
                something we can demo — name it and its business outcome"
    human  →   all capabilities present · wave 0 truly foundational
    GATE 1.2 → Product Owner + Architect approve

1.4 BRDs 🟩    /export-for-alignment '<capability>'   (one per capability)
    loop   →   /validate-brd → /fix-brd → /fix-brd-readiness → re-validate
    human  →   READABILITY TEST: non-technical reader, unaided
    oq     →   /resolve-open-questions brd  → gates 2.1 & 3.1
    GATE 1.3 → grade ≥ B · Product + Architecture sign-off
               🌐 publish before the workshop

╔═ PHASE 2 · TARGET STATE & PROPOSITION ══════ 5 agents ══╗
   No agent here reads source code — knowledge base only

2.0 DEMO 🎬 OPTIONAL, PARALLEL — show it, don't describe it
    1 scope →  /research  ← STATE THE BUDGET: weeks, engineers, stack
               "propose 2–4 flows that fit, ranked by value"
    2 human →  CONFIRM THE FLOW SET WITH THE CLIENT, then amend the note
    3 plan  →  /demo-plan <scope prose> --design-guide
               = /demo-init (flow APPROVAL GATE) → architecture/demo/
                 → /demo-flows → /design-guide
    4 mockup→  screen inventory + design guide → HTML screens → ui-mockup/
    5 plan  →  /transformation-roadmap demo  →  /create-epic-backlog demo
               /resolve-open-questions epics demo  →  /validate-backlog demo
    6 stories→ /story-intent demo/wave-01/epic-01   ONE EPIC AT A TIME
               (you do not need stories for every epic before you build)
    7 build →  /new-story-spec <path in backlog/demo/> → /new-story-impl
    8 revise→  /add-features "<change>"   Draft-only · it ASKS which track
    9 show  →  /publish-knowledge-base demo
    human  →   feedback goes BACK into BRDs / architecture / backlog
    note   →   NO track for: /capability-split · /export-for-alignment
               /demo-init · /demo-flows · /design-guide  — all shared/flat

2.1 ARCH       /target-state-architecture   (6 decisions → confirm plan)
    loop   →   /validate-architecture               watch UNVERIFIED
               /validate-architecture-completeness  → must be READY     ★
    human  →   read receipt · dispositions sensible · owners on gaps
    GATE 2.1 → READY verdict + board approval    ← ONLY HARD STOP

2.2 ROADMAP    /transformation-roadmap       → confirm plan
    + WBS      waves with scope, deliverables, sequencing        L1
    human  →   rollback walked through out loud · waves reconcile
    GATE 2.2 → PM confirms deliverable · Architecture confirms sequence

2.3 ESTIMATE 🟪 HUMAN STEP — the asset supplies NO effort numbers
    inputs →   wave scope + deliverables · capability complexity · risks
    method →   unit → count per wave → calibrate → roll up → widen → risk
    note   →   a WAVE-LEVEL RANGE; it tightens per wave at 3.1
    GATE 2.3 → PROPOSITION SIGN-OFF
               architecture + roadmap/WBS + estimates + risks (+ demo)
               🌐 publish — the site IS the proposition

╔═ PHASE 3 · IMPLEMENTATION ═══ 3 agents, then commands ══╗
   Decide the target repo BEFORE 3.1 — re-platforming means a new one

3.1 BACKLOG    /create-epic-backlog         → approve proposal   L2–L3
    oq     →   /resolve-open-questions epics   → gates 3.1's story-intent step  ★
    per wave   /story-intent <wave>         → approve split      L4
    loop   →   /validate-backlog [--fix] → re-validate
    human  →   coverage gaps actioned · tech lead reads 5 stories
    GATE 3.1 → grade ≥ B · zero critical/high · no dependency cycles
               re-baseline the wave estimate against real story counts

    tool   →   (once) /recommend-tooling → stack-matched skills/CLI,
               more code quality, fewer tokens — before 3.2

3.2 SPEC       /new-story-spec [story]      → branch + merge request
    oq     →   gated per-story on /resolve-open-questions stories
    human  →   read the TASK BREAKDOWN · did it consult ui-mockup/ ?
3.3 BUILD      /new-story-impl <branch> [--with-review]
    human  →   REAL code review on the merge request
3.4 CLOSE      /archive-implemented         → merged · story Done
    GATE 3.2 → per story; then take the next unblocked one
               fresh session between stages — do not let it compact

╔═ ANY TIME ═══════════════════════════════════════════════╗
    🌐 /publish-knowledge-base      the site everyone reads
       /validate-mermaid            check diagrams
       /frontend-slides:frontend-slides   3rd-party — deck from knowledge-base/*.md
       python3 ${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py --report    costs
```

★ = the two gates where human attention pays back most.

## 5.7 Decks and presentations from the knowledge base

### The progress-report deck structure

```
/progress-report
```

Builds a **slide-by-slide structure** for a stakeholder progress deck out of everything the knowledge base holds so far, writing it to `knowledge-base/progress-report/`. It follows a fixed agenda — scope and approach recap, key codebase findings, the suggested target architecture, the demo flows, demo vs. final architecture, and the functional mockup — and proposes extra sections where they strengthen the story.

It runs in five phases (deck plan → per-section knowledge mapping → parallel section research → trim and merge → parallel detailed slide generation), with **an approval gate after the deck plan** so you shape the agenda before any slide is written.

It produces a *structure*, not a `.pptx`. Pair it with the slide tooling below, or hand the structure to whoever builds the deck.

> `progress-reporter.md` is the canonical description of the agenda, but the command does **not** invoke it — `/progress-report` spawns its own section and slide agents. When the two disagree, the command is what runs.

### Slide decks (frontend-slides)


[`frontend-slides`](https://github.com/zarazhangrui/frontend-slides) is a **third-party skill, not bundled with this plugin** — install it separately with `/plugin marketplace add https://github.com/zarazhangrui/frontend-slides` then `/plugin install frontend-slides@frontend-slides`. It turns a content outline, or an existing `.pptx`, into a single self-contained HTML slide deck (16:9, no external dependencies), picking a visual style from generated previews rather than asking you to describe one in prose.

Point it at any Markdown under `knowledge-base/` as the content brief — extraction findings, a capability BRD, a target-state architecture document — and let it drive the style selection:

```
/frontend-slides:frontend-slides Build a deck from knowledge-base/extraction/architecture/architecture.md
```

Once you have picked a style and the HTML deck is generated, the skill's bundled scripts can deploy it to a shareable URL (`scripts/deploy.sh`, via Vercel) or export it to PDF (`scripts/export-pdf.sh`, via Playwright) — ask the skill to deploy or export rather than running those directly.


## 5.8 Skill index

**Skills are shared policy, not commands you type** — a gate, a retry rule, or a verification step written once and invoked by every command that needs it, rather than restated in each. Two are exceptions, marked below.

| Skill | What it does | Invoked by |
|---|---|---|
| `check-prerequisites` | The mandatory upstream gate. Halts a command when the stage it depends on has not produced what it needs | Step 0 of every command that consumes an earlier stage |
| `check-open-questions` | Halts a command while a **blocking** open question in its scope is unanswered | Step 0.5, immediately after `check-prerequisites` |
| `reconcile` | Checks what an agent *declared* it would write against what it actually wrote, and applies the shared retry-cap policy | After every agent spawn |
| `contract` | Whole-pipeline diagnostics: schema conformance, declared-vs-actual outputs and orphans, manifest staleness, graph lint, pipeline status, and the execution-traceability ledger (`trace status` / `trace run` show each agent run's `model=` and `requested=`; `--git`, `--versions` and `--all` add the git state and tool versions it started under) | You or an agent, when the single-stage gate is too narrow |
| `graphify-source-graph` | Builds and verifies the source-code-only graph, rebuilding it when stale or poisoned. **Never call `graphify` directly** | `/completeness-report` |
| `generate-estimate-excel` | Renders the rate-calculator workbook from the estimate JSON, then verifies every figure in it against that input | After `team-estimation-agent` |
| `brainstorm-target` | **You type this one.** Adversarial, evidence-led pressure-testing of a target-state decision, recorded as a decision brief plus ADRs. Use it *before* stage 2.1 — and when you want to challenge what it already produced | You |
| `user-manual` | **Maintainer-only.** Edits this manual and its site as a pair. Nothing to act on in a target repository | A maintainer of the toolkit |

Stage 3 additionally uses the five `openspec-*` skills (`propose`, `apply`, `sync-specs`, `archive-change`, `explore`) that `openspec init` generates in the target repository. This plugin does not bundle its own copies.

> **You rarely invoke a skill by name.** If a command halts with a prerequisite or open-questions message, that is a skill doing its job — read the output rather than working around it.

---

# Part VI — Technical Documentation

> **Purpose in one line:** the technical reference for the **asset itself** — how it installs, how it is configured, how it is built, and what it needs to run.

Everything before this part describes how to *run an engagement*. This part describes the software. It is the section to read before installing the asset, reviewing it, or listing it in an asset catalog (§6.6).

## 6.1 Installation and deployment

The asset is a **Claude Code plugin** (`modernization-cli-cap`) — it is enabled against the codebase
you want to modernize, not copied into it, and there is nothing to deploy to a server.

```
/plugin install modernization-cli-cap
```

or, for local development against a checkout of the toolkit repo:

```bash
claude --plugin-dir /path/to/modernization-cli/.claude
```

| Property | Behaviour |
|---|---|
| **What travels with the plugin** | Everything under the toolkit repo's `.claude/` — agents, commands, skills, scripts, site templates and schemas, a `docs/` subfolder for the two docs (`artifact-manifest.md`, `contract.md`) that plugin content links to, and a `user-docs/` subfolder holding this manual and the other operator-facing docs |
| **What never travels with it** | Runtime artifacts in the target repo (`knowledge-base/`, `.claude/agent-memory/`, `.claude/logs/summary.jsonl`) — those are the target repo's own state |
| **Updating** | `/plugin update modernization-cli-cap` (or pulling the marketplace's latest pinned commit) — nothing to re-run against the target repository, except `/plugin-init` again if you want the local doc copy refreshed. `/whats-new` prints what the installed version changed (latest release by default; `/whats-new all` for the full history, `/whats-new X.Y.Z` for one release) |
| **Migration note** | A target repo previously installed into by the retired `install-kb-agents.py` copy-installer carries **project-level** `.claude/agents/`, `.claude/commands/`, etc. Those take precedence over the plugin and silently shadow it; delete them once (see `.claude/user-docs/installation.md` in the toolkit repo) before enabling the plugin. Run `/plugin-init` afterward — its Step 0 renames orphaned bare-named `.claude/agent-memory/` directories left over from that install to the plugin-namespaced form |

**Prerequisites**

| Component | Needed for | If absent |
|---|---|---|
| **Claude Code** | Everything — it is the execution environment (another agent harness is possible; see §6.5) | Nothing runs |
| **Python 3** | The pipeline's helper scripts (schema validation, the prerequisite gate, the stats collector). Standard library only, no third-party packages | Those checks cannot run |
| **git** | Normal repository work; the implementation commands branch and merge | Phase 3 cannot run |
| Node.js + `npx` | Mermaid diagram validation, and `validate-site.mjs` for the published site (`ajv`, which auto-installs — `npm ci --ignore-scripts` — the first time the plugin loads, no manual step) | Diagram checks report `UNVERIFIED` instead of passing |
| `pandoc` (+ `python-docx`) | `/parse-docx` | Word documents cannot be converted; `/parse-docx` installs pandoc itself if it is missing |
| `openspec` on `PATH`, with an initialized `openspec/` project root | Phase 3 build commands (`openspec init` also generates the `opsx:*` commands and `openspec-*` skills those commands invoke — this plugin does not bundle its own copies) | Stages 3.2–3.4 cannot run |
| `graphify` on `PATH` (`uv tool install graphifyy`) | The required completeness-report check in Stage 1.1–1.2 (built and verified only through the plugin's `graphify-source-graph` skill — never invoked directly) | `/completeness-report` cannot run, and Gate 1.1 needs a recorded exception |
| `docker` (or Node.js) | The optional knowledge-base **chat backend** (`/chat-serve`). The first run builds the image — it compiles a native SQLite module and downloads the embedding model | The site still publishes and works; the chat widget stays inert |
| `glab` | Opening merge requests automatically | The command prints a link instead |

There is no build step and no package to publish. The pipeline itself runs no service — **with one exception**: the knowledge-base chat backend (`/chat-serve`) is a long-lived process with its own Docker/Node dependency and a local SQLite index. It is optional, it is started deliberately, and nothing in the pipeline depends on it (§5.1).

## 6.2 Configuration model

Configuration lives in three layers, all of them plain text.

| Layer | Where | What it controls |
|---|---|---|
| **Behaviour** | `.claude/agents/**/*.md`, `.claude/commands/*.md`, `.claude/skills/**/SKILL.md` | The prompts themselves. **The configuration *is* the instruction text** — changing behaviour means editing Markdown, not code |
| **Stats refresh** | `.claude/hooks/hooks.json` — a `SessionStart` hook running `${CLAUDE_PLUGIN_ROOT}/scripts/collect-stats.py --refresh` on every session start | Keeps the untracked per-machine token/cost ledger current; see §5.3 |
| **Per-project facts** | `knowledge-base/extraction/project-profile.json` | Written during extraction and read by the downstream extraction agents and validators (§ [the project profile](#the-project-profile--your-single-biggest-quality-lever)). This is where a specific codebase's conventions are recorded |

A plugin's `.claude/settings.json` only supports the `agent` and `subagentStatusLine` keys — this
toolkit's copy carries neither; it holds only this repo's own dev-local settings, which have no
effect when the plugin is enabled elsewhere.

**Agent model tiers** are set per agent in frontmatter:

| Tier | Used by |
|---|---|
| `sonnet` | The default — all extraction, BRD, architecture, transformation, estimation, story, demo, design-guide, progress-report, and add-features agents |
| `opus` | `knowledge-base-research-agent` only — open-ended multi-source synthesis |
| `haiku` | `epic-backlog-agent` only — spawned in bulk, one per epic, and cost-sensitive |

**No credentials are configured anywhere.** The asset holds no secrets, connects to no database, and calls no service other than the model API through Claude Code.

## 6.3 Architecture and technical description

**Two file types do all the work.** There is no application, no build system and no test suite — the deliverables are Markdown definitions and a few Python and Node helper scripts.

| Type | Location | Role |
|---|---|---|
| **Commands** | `.claude/commands/*.md` | Orchestration. Each file is the instruction set Claude executes when you type `/<name>` — which agents to spawn, in what order, with what inputs |
| **Agents** | `.claude/agents/**/*.md` | The work. Each has a model tier, a tool allowlist and a detailed task prompt, and writes structured output |

**Execution model.** A command runs in the foreground and spawns agents; independent agents run in parallel (nine at once in extraction Phase 2, up to ten per batch in Phase 2b), dependent ones in sequence. After each phase the command verifies on disk that every agent produced its files and re-runs any that failed silently. Everything runs **locally, on one machine** — there is no server, no queue and no shared state between operators beyond the repository itself.

**The contract between stages** is JSON. Each stage writes a `summary.json` that the next stage reads in preference to the prose; the authoritative source is `${CLAUDE_PLUGIN_ROOT}/contract/v1/phase-graph.json`. `${CLAUDE_PLUGIN_ROOT}/docs/artifact-manifest.md` is a generated rendering of that graph (plus authored prose in `manifest-prose.md`) — edit the graph first, then run `render-manifest.py --write` to regenerate the manifest; a `PreToolUse` hook blocks direct edits to it.

**Composition**, as shipped by the plugin:

| Element | Count |
|---|---|
| Agent definitions | 37 |
| Slash commands | 35 |
| Skills | 8 (`check-prerequisites`, `check-open-questions`, `reconcile`, `contract`, `graphify-source-graph`, `generate-estimate-excel`, `brainstorm-target`, `user-manual`) |
| Quality gates | 10 |
| Helper scripts | 22 in `${CLAUDE_PLUGIN_ROOT}/scripts/`, plus the chat-widget Node app |

**Telemetry.** A `SessionStart` hook (`.claude/hooks/hooks.json`) refreshes an untracked, per-machine token/cost ledger on every session start by reading Claude Code's own transcripts — no event-time capture, nothing to lose if a session ends abnormally. `collect-stats.py --report` summarizes it as a table or JSON, and rewrites the target repo's tracked `.claude/logs/summary.jsonl` if that repo chooses to track it (§5.3). The ledger itself stays local to each machine.

**Site publishing.** `/publish-knowledge-base` copies a frozen scaffold from `.claude/site-templates/` and regenerates only the data files behind it; `.claude/site-contract.json` plus `.claude/site-schemas/` define what those files must contain, and `validate-site.mjs` enforces it.

## 6.4 Source repository and documentation

**Source repository:** `https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/modernization-cli.git`

| Path | Contents |
|---|---|
| `.claude/.claude-plugin/plugin.json` | The plugin manifest — the entry point Claude Code reads to discover components |
| `README.md` | Front door: what it is, install, pipeline order |
| `CLAUDE.md` | Working instructions for agents operating on this repository |
| `.claude/agents/` | 37 agent definitions, grouped by pipeline area |
| `.claude/commands/` | Slash commands |
| `.claude/scripts/` | Schema validation, the prerequisite gate, and the stats collector, plus the site validator |
| `.claude/site-templates/`, `.claude/site-schemas/`, `.claude/site-contract.json` | The frozen published-site scaffold and its contract |
| `.claude/skills/` | Skills, including the one that maintains this manual |
| `.claude/docs/` | Reference docs linked from plugin content (`artifact-manifest.md`, `contract.md`) — inside the plugin root because a plugin cannot reach `../` paths outside it |
| `.claude/user-docs/` | This manual and the other operator-facing docs, listed below. Also inside the plugin root, for the same reason — and so `/plugin-init` can copy them into any installed target repo at `.claude/docs/<plugin-name>/` |
| `docs/` | Maintainer-only notes not shipped anywhere: gap-tracking (`docs/gaps/`) and internal agent/schema audits |

| Document | Purpose |
|---|---|
| [`user-manual.md`](user-manual.md) | This manual — the operating guide for an engagement, plus this technical part |
| [`modernization.md`](modernization.md) | The full slash-command reference |
| [`agentic-modernization-overview.md`](agentic-modernization-overview.md) | The method, the agent swarm and the business case |
| [`.claude/docs/artifact-manifest.md`](../docs/artifact-manifest.md) | The shared artifact contract — canonical paths, filenames and JSON schemas. **Generated** from `phase-graph.json`; edit that first |
| [`installation.md`](installation.md) | Plugin-install reference — marketplace source, requirements, and the migration note for repos still carrying the old copy-installed payload |
| [`usage-stats.md`](usage-stats.md) | Telemetry and cost aggregation |

All six documents above (except `artifact-manifest.md`, which stays in `.claude/docs/`) ship inside the
plugin and can be copied into any installed target repo by running `/plugin-init`, which places them at
`.claude/docs/<plugin-name>/` — run it once after install and again after each `/plugin update`.

The manual is published as a self-contained page at `.claude/user-docs/user-manual.html` — no server required, and shareable as a single file.

## 6.5 Supported environments

| Dimension | Support |
|---|---|
| **Operating system** | Windows, macOS and Linux — wherever Claude Code itself runs. All helper scripts are pure Python or Node, no POSIX-only shell scripts remain |
| **Execution environment** | Claude Code — CLI, desktop app, web, or IDE extension. **Other agent harnesses are possible** but are not covered here |
| **Models** | Claude Sonnet and Claude Opus |
| **Language runtimes** | Python 3 required. Node.js optional, for diagram and site validation (its one dependency auto-installs at plugin load) |
| **Target codebase** | **Any language, framework or platform the model supports.** The toolkit imposes no limit of its own — the agents are stack-neutral and take project specifics from the project profile rather than assuming them — so the practical ceiling is how well the model reads that language, not the asset |
| **Target repository** | Any git repository, with the plugin enabled against it — no pre-existing directory or file layout required |
| **Network** | Outbound access to the model API only. No inbound ports, no server, no database, no shared infrastructure — **except when the optional chat backend is running**, which listens on a local port and keeps a SQLite index beside the site (§5.1) |
| **Scale** | Exercised on a codebase of **over a million lines**. Cost scales with codebase size; extraction dominates it (§5.3) |
| **Data residency** | All generated artifacts stay in the target repository. Source code is sent to the model API during Phase 1 extraction only — Phase 2 and the Phase 3 planning stage read the knowledge base, not the code |

**Degradation is explicit, not silent.** Where optional tooling is missing the affected check reports `UNVERIFIED` or `SKIPPED` rather than passing quietly — see §5.4.

## 6.6 Catalog entry

The fields an asset-catalog entry needs, answered from the sections above.

| Field | Entry |
|---|---|
| **Installation model** | Distributed as a Claude Code plugin (`modernization-cli-cap`), enabled from the internal marketplace against a target repository. No build, no packaging, no copy step. Updates are pulled via `/plugin update`, not re-run (§6.1) |
| **Detailed information link** | `https://assets.engine.capgemini.com/local-assets/ernd-eastern-europe-gec/rnd-hub/modernization-cli.git` — with `README.md` as the front door and `.claude/user-docs/user-manual.html` as the shareable manual (§6.4) |
| **Technology description** | A Claude Code agent toolkit: 37 agent definitions, 35 commands and 8 shared skills written as Markdown prompts, with Python helpers for schema validation, prerequisite gating, and telemetry, and a Node helper for diagram and site validation. No application runtime (§6.3) |
| **Deployment approach** | Runs locally on the operator's machine against a checked-out repository. The only outbound dependency is the model API, and output is plain Markdown and JSON committed to the target repository. Nothing is hosted — **unless you choose to run the optional knowledge-base chat backend**, which is a service with its own hosting, dependency and credential requirements (§6.5) |
| **Availability information** | Internal Capgemini asset, distributed by repository access. **Owner to confirm** the licensing terms and the audience cleared to request access before this entry is published |

> **Two facts a catalog entry must not overstate.** The asset produces analysis and plans, not a migrated system: it does not rewrite the codebase itself — its own Phase 3 builds story by story behind a human review gate, and full automation means handing the backlog to the **Software Factory** asset — and while it *does* produce a work breakdown and three staffing/cost options, it does not own the commercial number you put in front of a client (§2.3). Both are named in §0.3 under "where it stops".

---

<sub>Deeper reference for practitioners: [`modernization.md`](modernization.md) (full command syntax) · [`agentic-modernization-overview.md`](agentic-modernization-overview.md) (method and business case) · [`artifact-manifest.md`](../docs/artifact-manifest.md) (file-level contract between stages).</sub>

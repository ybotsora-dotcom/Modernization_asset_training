# Choosing a Modernization Strategy

This guide helps an engagement lead decide what kind of modernization they are running, and which toolkit path fits. It is short on purpose: pick a row in the [decision guide](#decision-guide), then follow the link.

Every path below is labelled **Supported** (it ships and works today) or **Planned** (designed, not yet built). See [Status labels](#status-labels).

## The strategy spectrum

The seven common modernization strategies, from least to most invasive. The toolkit does not force one of them; it gives you the evidence and the work items for whichever you choose.

| Strategy | What changes | Typical drivers | Main risk |
|---|---|---|---|
| **Retain** | Nothing; the system stays as is | Works well enough, low business value to change | Drift and rising maintenance cost go unnoticed |
| **Retire** | The system or capability is switched off | Redundant, unused or replaced by another product | A hidden consumer breaks when it goes |
| **Rehost** | The same system moves to new infrastructure (lift and shift) | Data-centre exit, cost, hardware end of life | Moves the problems along with the system |
| **Replatform** | Runtime or platform changes with minimal code change (managed database, newer runtime) | Unsupported platform, operational burden | Subtle behaviour differences on the new platform |
| **Refactor / Re-architect** | Internal structure changes; behaviour stays the same | Technical debt, testability, preparing for new features | Silent behaviour change without tests pinning it |
| **Rebuild / Replace** | The capability is rewritten on a new stack | End-of-life technology, unmaintainable code, new product direction | Cost, schedule, and losing undocumented business rules |
| **Repurchase** | A commercial product replaces the capability | Commodity function, vendor offers it as SaaS | Fit gaps and data migration |

## The two axes the toolkit uses

The toolkit does not model seven strategies. It models two questions.

- **Direction.** Are you moving to a new stack or platform (**migrate**), or staying on the current one (**evolve**)?
- **Scale.** Is this a planned **programme** (waves, a roadmap, estimates), or a single **change** requested one at a time?

Every strategy above lands on one of the four combinations. Retain, Rehost and Replatform need little from the toolkit beyond the extraction. Rebuild/Replace and Repurchase are migrate work. Refactor and most feature work are evolve work.

## Decision guide

| Situation | Strategy | Toolkit path | Status |
|---|---|---|---|
| Full rewrite to a new stack | migrate / programme | `/capability-split` through `/story-intent`, then the implementation commands | Supported |
| Move one subsystem out (strangler) | migrate / programme, mixed per-capability treatment | same chain | Supported |
| Add a feature, change a behaviour or refactor a module in the live system | evolve / change | `/propose-change` | Supported |
| Planned multi-quarter improvement on the current stack | evolve / programme | follow-up design, not built yet | Planned |
| A feature for a system that is mid-migration | migrate / programme | `/add-features` | Supported |

Two quick tests settle most cases:

- **Is there a migration backlog?** If yes and the request fits it, use `/add-features`. If no, and the request is about the live system, use `/propose-change`.
- **Does the request fit one change?** If `/propose-change` reports `sizing: programme` (more than 3 capabilities or more than 40 impacted files), the request is bigger than one change: split it, or treat it as a programme.

The runbook for the change path is [`change-requests.md`](change-requests.md).

## Mixing strategies

A real engagement is rarely one strategy. Two mechanisms let them coexist in one repository.

**Per-capability treatment.** In the migration chain, the target-state summary records a `treatment` for each capability: `Retain`, `Refactor`, `Replace` or `Retire`. A capability marked `Retain` is simply left out of the build; one marked `Replace` is rebuilt. This is how a strangler migration expresses "move these, keep those".

**Two work roots, side by side.** The two paths write to different places and do not overwrite each other.

| Root | Written by | Holds |
|---|---|---|
| `knowledge-base/target-state/backlog/` | `/create-epic-backlog`, `/story-intent`, `/add-features` | Migration epics and stories |
| `knowledge-base/changes/<id>/` | `/propose-change` | One change request: `impact.json`, `impact.md`, `stories/`, `refresh.json` |

`/new-story-spec`, `/new-story-impl` and `/archive-implemented` accept stories from either root. A story from `knowledge-base/changes/` gets branch `changes/<id>/story-NN-<slug>`; a migration story keeps its existing branch name.

**Collisions.** If a migration backlog exists, `/propose-change` checks for open (not Done) migration stories that touch the same capability or files, and lists them in `backlogCollisions[]` of the impact report. This is a warning only. Read it at the impact checkpoint and decide whether to sequence the change after those stories.

## Status labels

Each path in this guide is marked **Supported** or **Planned**, so the guide never promises a path before it exists.

- **Supported** - the commands exist and are covered by the command reference.
- **Planned** - designed but not available. The evolve / programme path (a planned multi-quarter roadmap on the current stack) is Planned. Until it ships, split the work into single changes with `/propose-change`, or run the migration chain with `Retain` and `Refactor` treatments.

# Modernization CLI — Command Reference

End-to-end flow for analyzing a legacy codebase and producing a migration plan ready for engineering execution.

Commands ship as part of the `modernization-cli-cap` Claude Code plugin and are reachable as
`/modernization-cli-cap:<command>`; the bare `/<command>` form below continues to work unless a local
project command of the same name exists. This document lives in this repo only — it is not copied to
target roots.

---

## Phase 0 — Host Readiness

### `/plugin-init [--reconsider]`

Required first step. Every other command and skill refuses to run until it has passed on this
machine for the installed plugin version. Seven steps (0–6): **0** — Bash/Python preflight (stops early on
failure); **1** — probe the host (read-only) for every required and optional tool; **2** — ask about
the optional tools (Git hosting CLI, OpenSpec, Docker, pandoc; Defer and Skip on the last three state what will be missing, so choosing one is your confirmation) via one `AskUserQuestion` call; **3** — copy the
operator docs from `${CLAUDE_PLUGIN_ROOT}/user-docs/` into `.claude/docs/<plugin-name>/`; **4** —
advisory `.gitignore` checks for the marker and the tracked ledgers; **5** — write the marker only if
everything required passed; **6** — report a host table, marker status, docs copied, and `.gitignore`
findings.

`--reconsider` re-asks about decisions remembered from an earlier run (skipped OpenSpec/Docker/pandoc, the Git
hosting choice). The marker lives at `.claude/tooling/host-check.json` — gitignored, keyed to this
machine and the installed plugin version, so a plugin update or a different machine invalidates it
and every gated command/skill blocks again until you re-run `/plugin-init`. It never installs
anything, only tells you what to install and how.

---

## Full Flow Overview

```
1. /knowledge-extraction          → extract and analyze the codebase
   └─ (optional) /completeness-report        → score extraction against deterministic code facts
   └─ (optional) /fix-knowledge-extraction  → fix quality issues if score is low
   └─ /resolve-open-questions extraction     → gate: clear blocking extraction-scope open questions
2. /capability-split              → plan wave/capability groupings and write summary.json
3. /export-for-alignment          → generate BRDs (one capability, or all in one batched run)
   └─ (optional) /validate-brd    → score BRD quality and internal consistency
   └─ (optional) /fix-brd         → apply corrections from validate-brd report
   └─ (optional) /fix-brd-readiness → strip implementation coupling so BRDs can drive stories on a new stack
   └─ /resolve-open-questions brd            → gate: clear blocking BRD-scope open questions
4. /target-state-architecture     → define the target platform and architecture
   └─ (optional) /validate-architecture  → score architecture docs for formatting and consistency
   └─ (optional) /validate-architecture-completeness → gate on coverage vs. the extraction inventory
5. /transformation-roadmap        → produce phased migration plan + team composition/estimate options
6. /create-epic-backlog           → generate wave-organized epic backlog from the plan
   └─ /resolve-open-questions epics          → gate: clear blocking epic-scope open questions before /story-intent
7. /story-intent                  → generate story specifications per epic or wave
   └─ (optional) /validate-backlog → score backlog for completeness and dependency integrity
   └─ /resolve-open-questions stories        → gate: clear blocking story-scope open questions before /new-story-spec
   └─ (recommended, once) /recommend-tooling → equip the coding session with stack-matched skills/CLI tools before /new-story-spec
8. /publish-knowledge-base        → build the static HTML knowledge base site (run anytime)
```

`/resolve-open-questions` is not optional in the same sense as the other `(optional)` sub-steps: once a
scope's register exists, its blocking questions gate the next stage automatically (Step 0.5 in that
stage's command). Before a register exists, every gate exits 0 — an existing backlog that never runs
this command is completely unaffected. See [`/resolve-open-questions`](#resolve-open-questions-scope-track---apply---interactive)
below.

**The demo track** runs the same stages 4–7 at a smaller scope, under a `demo` track segment, so it
never overwrites the programme artifacts. It branches off step 1 — but only its architecture/flows/mockup
half is actually free of everything else; its **backlog** half needs the programme's `/capability-split`
and `/export-for-alignment` too, so start those early if you already know a demo backlog is coming:

```
1. /knowledge-extraction
   ├─ (start early if you'll want a demo backlog) /capability-split → /export-for-alignment
   │
   └─ /research <goal + budget>      → propose 2–4 demo flows that fit the time and team you have
      └─ CONFIRM THE FLOW SET WITH THE CLIENT, then amend the note
      └─ /demo-plan <scope> --design-guide      ← needs step 1 only, runs while the above is in flight
         = /demo-init (flow approval gate) → architecture/demo/ → /demo-flows → /design-guide
         └─ /publish-knowledge-base demo (optional)
         └─ /transformation-roadmap demo   → /create-epic-backlog demo   ← needs capability-split + BRDs by now
            └─ /resolve-open-questions epics demo   → /validate-backlog demo
            └─ /story-intent demo/wave-01/epic-01   ← one epic at a time, as you build
               └─ /new-story-spec <path in backlog/demo/> → /new-story-impl → /archive-implemented
                  └─ /add-features "<change>"       ← revise demo scope mid-build (Draft-only)
```

Why the split: `/demo-plan` spawns `target-state-architecture-agent` **directly**, so it clears no
prerequisite gate and reads `knowledge-base/extraction/` alone — the demo architecture, flow
descriptions and design guide genuinely need nothing but step 1. The backlog half is different.
`capability-split` and `business-capability-brd` are the two pipeline stages that are *not*
track-aware, so the gate resolves them to their flat programme paths: `/create-epic-backlog demo`
requires `knowledge-base/capabilities/`, and `/story-intent demo/…` requires that **and** the BRDs
under `knowledge-base/business-capabilities/`. `/create-epic-backlog` also builds its epic briefs out
of the `capability-summary.json` files that `/export-for-alignment` writes, so this is missing input,
not just a formality — and neither stage is quick: capability-split needs your review of the wave
grouping, and BRDs are generated and validated one capability at a time. Starting them alongside
`/research` (rather than after `/demo-plan` finishes) means they're usually ready by the time you reach
`/transformation-roadmap demo`, instead of becoming a wait you discover only when the backlog gate fails.

One asymmetry to know about even on this sequencing: creating the demo architecture through `/demo-plan`
skips the gate, but *regenerating* it with `/target-state-architecture demo` runs it — and so demands
capability split and BRDs regardless of when you started them.

See [Side Track — The Demo](#side-track--the-demo) for the walkthrough, and
[The optional `<track>` segment](#the-optional--segment) for how the arguments differ from the
programme run. Capability split and BRDs take **no** track — they are shared by both.

Utilities available at any stage: `/research`, `/propose-change` (the evolve-in-place path, needs extraction only), `/demo-plan` (`/demo-init`, `/demo-flows`, `/design-guide`), `/add-features`, `/progress-report`, `/validate-mermaid`, `/parse-docx`, `/recommend-tooling`, and the third-party `frontend-slides` skill. Of these, `/recommend-tooling` is worth calling out: it's not just "available," it's **recommended once, right before Phase 8 implementation begins** — see the note in its own entry below.

---

## Cross-Cutting — Open Questions Gate

### `/resolve-open-questions [scope] [track] [--apply] [--interactive]`

Harvests, canonicalizes, and resolves open questions and unmarked assumptions for one scope of the
knowledge base before they reach the next pipeline stage — the fix for open questions accumulating
silently (a story's `### Open Questions` is discarded before `/new-story-spec` generates its
specification, and an unmarked `### Assumptions` bullet is silently promoted to fact). Runs the
`open-questions-agent` (SCAN, the default) or `open-questions-applier` (APPLY, `--apply`).

**Modes:**
- **SCAN** (default) — deterministically harvests raw items (`open-questions-cli.py harvest`, exact
  `file:line`, no LLM), then runs `open-questions-agent` to canonicalize/dedupe/classify them and write
  a batched review register — a Markdown document with 2–4 proposals per question (exactly one
  recommended) for a human or client SME to answer, plus the machine-readable JSON the gate reads. It then
  reports the count (`Blocking: N of M`) and **offers two ways to answer**: interactively, right there, or
  by opening the register in an editor. Neither is a fallback — a short register is faster in conversation,
  a long one is better read in full.
- **INTERACTIVE** (`--interactive`) — the same answering pass over a register that already exists, with no
  harvest and no agent run, so a session interrupted yesterday can be picked up today. Presents each
  unanswered question's proposals as choices, three at a time, grouped by owner role, and writes your
  choice into the register Markdown. It never writes the JSON: answering is not applying, and the gate
  stays closed until `--apply` has actually promoted the decision into the artifacts.
- **APPLY** (`--apply`) — parses the register's filled-in `**Answer:**` blocks (`open-questions-cli.py
  parse` — a script owns this, never the model) and runs `open-questions-applier` in parallel, one
  instance per epic/capability/extraction-folder, to promote each answer into the artifact section that
  survives downstream truncation, leaving a `[Resolved OQ-NNNN …]` pointer behind. Branches off **whatever
  branch you are on** into `backlog/resolve-oq-<scope>[-<track>]` — no required branch, and no `git pull`
  or any other remote call. Only the files it is about to patch need to be clean (derived from the answers'
  own occurrences); unrelated work in flight is reported and left alone, and the commit stages an explicit
  path list rather than `git add -A`. The Draft-only rule for story files is unchanged.

**Args:**
- `[scope]` — `extraction`, `brd`, `epics`, `stories`, or `changes`. **Omit it and the command asks**, listing each
  scope with its register's current state (`register exists — N of M blocking still open`, or `no register
  yet`).
- `[track]` — second positional, `epics`/`stories` only (matches `/validate-backlog`'s convention). Asked
  for as well, when the scope supports a track and at least one track directory exists. It scopes **what
  gets scanned**, not only where the register is written: a tracked run reads that track's backlog and
  architecture and nothing else, and a flat run excludes every track. On `extraction`/`brd` it is an
  error, not a no-op.
- `--change <id>` — required with the `changes` scope and rejected with every other scope: names the
  `knowledge-base/changes/<id>/` directory. `changes` is not track-scoped.
- `--interactive` — answer an existing register in conversation instead of in an editor.
- `--ids OQ-NNNN,…` — restrict `--interactive` to a named set of questions.
- `--wave wave-NN` / `--epic <NN|slug>` / `--story <path>` — narrow either mode to one slice.
- `--blocking-only` / `--all` — override the scope's default Markdown render mode (`blocking-only` for
  `stories`, `all` for the other three) — controls the fill-in surface only, never what the JSON stores.
- `--dry-run` — SCAN only: preview without writing.

**The gate:** once a scope's register exists, `open-questions-cli.py check` (via the
`check-open-questions` skill) runs as Step 0.5 in the commands below and halts them if a **blocking**
question is still `Open`/`Needs-Clarification`/`Deferred` in the requested slice. **Before any register
exists, the gate always exits 0** — an existing backlog that never runs this command behaves exactly as
it did before this feature shipped.

| Scope | Gates | Notes |
|---|---|---|
| `extraction` | `/capability-split`, `/target-state-architecture` | |
| `brd` | `/target-state-architecture`, `/create-epic-backlog` | |
| `epics` | `/story-intent` | Highest-leverage checkpoint — stops one epic question fanning out into every story that epic splits into. |
| `stories` | `/new-story-spec` | Scoped **per story** (`--story <path>`) so one unresolved question elsewhere never deadlocks the whole backlog. |
| `changes` | `/new-story-spec` (change stories) | One register per change (`--change <id>`), scoped per story like `stories`. Harvests the change stories' Open Questions and Assumptions plus `impact.json`'s `openQuestions[]`. |

**Output:**
- `knowledge-base/extraction/open-questions.{md,json}`
- `knowledge-base/business-capabilities/open-questions.{md,json}`
- `knowledge-base/target-state/backlog/(<track>/)open-questions-epics.{md,json}`
- `knowledge-base/target-state/backlog/(<track>/)open-questions-stories.{md,json}`
- `knowledge-base/changes/<id>/open-questions-changes.{md,json}`

**Architecture escalations.** A `target-architecture` answer is never auto-patched — `--apply` records
`resolution.escalatedTo: "architecture"` and offers to hand the question straight to
`/brainstorm-target target-architecture --from-open-questions <scope> --ids <ids>`, which reads the
register and seeds its challenge queue from those questions' evidence and proposals. The resulting ADR does
not close the question by itself: record an answer citing it (`--interactive --ids <ids>` offers the
session's ADRs as the choices, or write `**Answer:** ADR <topic>/adr-NNN — <decision>` by hand), then
`--apply`. That closes the question as `Applied`, citing the ADR in the extraction/BRD/backlog artifacts. It
leaves the architecture documents alone until the next `/target-state-architecture` run.

**Git.** `--apply` never commits your unrelated work and never needs the register committed first. It stops
only when a file it is about to patch has uncommitted changes of its own. If an earlier `--apply` was
interrupted before committing, it recognises that run's leftover patches and offers to commit them first
(`open-questions-cli.py preflight` shows the same verdict without changing anything).

The Markdown is human-authoritative for answers; the JSON is written only by this command and is what
the gate reads. See [`docs/gaps/OPEN_QUESTIONS_RESOLUTION.md`](../../docs/gaps/OPEN_QUESTIONS_RESOLUTION.md)
for the full design.

---

## Phase 1 — Knowledge Extraction

### `/knowledge-extraction`

Runs the full extraction pipeline against the target repository. All output goes to `knowledge-base/extraction/`.

**Phases (run in order):**
| Phase | Agents | Output folder |
|-------|--------|---------------|
| 1 — Repository Foundation | `repository-intake-agent` | `extraction/repository/` + `extraction/project-profile.json` |
| 2 — Domain, Business Logic & Infrastructure Analysis (parallel, one batch of nine) | `architecture-discovery-agent`, `functional-discovery-agent`, `data-model-agent`, `data-flow-agent`, `integration-agent`, `ui-ux-discovery-agent`, `business-logic-rules-agent`, `security-governance-agent`, `runtime-operations-agent` | `extraction/<goal>/` |
| 2b — AI Discovery (clustered) | `ai-cluster-tracer-agent` (one per entry-point cluster, up to 10 per batch in parallel), then `ai-discovery-agent`; the scripts around them are described below | `extraction/ai/` |
| 3 — Business Intent & Risk (parallel) | `business-intent-agent`, `risk-gap-agent` | `extraction/<goal>/` |
| 4 — Synthesis | `knowledge-graph-curator` | `extraction/knowledge-graph/` |
| 5 — Quality Validation | `extraction-quality-agent` | `extraction/extraction-quality/` |

All nine Phase 2 agents depend only on Phase 1's output, so they fan out as a single batch (10 is a
ceiling, not a target — one slot is deliberately free, since AI discovery moved to Phase 2b). Phase 2b runs once Phase 2 is done, and Phase 3 runs after Phase 2b — both
`business-intent-agent` and `risk-gap-agent` read the database rule-engine event→handler mapping
`business-logic-rules/taskengine-inferred-mapping.md` produced in Phase 2 (when the codebase uses such
an engine).

**Phase 2b — clustered AI discovery.** Nothing extra is typed; the command runs these steps itself:

1. Clears any previous Phase 2b outputs (an old `partial.json` would otherwise be merged as if it were fresh).
2. `ai-sweep.py` writes `extraction/ai/sweep.json`, the deterministic list of AI-related code and config.
3. If `graphify` is installed, builds its source-code graph (the `graphify-source-graph` skill).
4. `ai-cluster-plan.py` groups the sweep hits into clusters by entry point (controller, listener, job, CLI) using that call graph; code reached from many entry points goes to a shared `platform` cluster (split by directory when it grows past 25 seeds or 60 files) so it is traced once; test files are never entry points, and hits no entry point reaches are grouped by directory. It writes `extraction/ai/clusters/manifest.json`.
5. `ai-slice.py` cuts each cluster's code down to the methods on its call chains, using graphify's own tree-sitter grammars (Java, Python, JavaScript/TypeScript/TSX, C# and Go; other languages are read whole). The slices are raw source, so they live in an owner-only folder in the operating system's temp directory (emptied at the start of each run), never under `knowledge-base/`.
6. Any **degraded-mode warning** is printed before the first tracer starts (see below).
7. Up to 10 `ai-cluster-tracer-agent`s run in parallel per batch (more clusters means more batches), each tracing one cluster and writing `extraction/ai/clusters/<cluster>/partial.json`, plus `extraction/ai/flows-<cluster>.md` and `extraction/ai/rag-<cluster>.md` when it traced a flow or a retrieval pipeline.
8. `ai-merge-clusters.py` validates every `partial.json` against [`ai-cluster-partial.v1`](schema-reference.md#ai-cluster-partialv1) and writes `extraction/ai/clusters/merged.json`. A cluster that fails validation is re-run (at most two more attempts, failed clusters only); one that still fails is recorded as a `CLUSTER_FALLBACK` warning and traced by `ai-discovery-agent` instead.
9. `ai-discovery-agent` consolidates: it reads `merged.json`, adds the inventory (providers, models, tools, guardrails, observability, engineering harness), documentation findings, risks and cross-references, and writes `extraction/ai/summary.json`. If no clusters were found, or no `merged.json` exists, it traces everything itself exactly as before.

No new host tool is required. graphify makes the step faster and its absence only slows it: without graphify, or with an unreadable call graph, the step still runs with directory-based clusters and whole-file reads; if only graphify's Python interpreter or its tree-sitter grammars are unavailable, clusters stay entry-point based and tracers read whole files. Either way it says so.

**Degraded-mode warnings.** When something makes Phase 2b slower or less precise, the command prints one block **before** any tracer starts — so you can cancel, fix and re-run — and repeats it in the closing summary. Each entry has a code, an impact and a fix; `info` entries are printed once and `low` entries are folded into one line. The codes:

| Code | Severity | Meaning | What to do |
|---|---|---|---|
| `GRAPHIFY_MISSING` | high | graphify is not installed (not on `PATH`), so there is no call graph and no tree-sitter grammars | Install graphify (uv tool install graphifyy), then re-run knowledge extraction. |
| `GRAPH_UNAVAILABLE` | high | graphify is installed but its call graph could not be read | Rebuild the source graph (graphify-source-graph with --refresh), then re-run knowledge extraction. |
| `GRAPHIFY_INTERPRETER_NOT_FOUND` | high | graphify's Python interpreter could not be located, so slicing is off | Install graphify with uv (uv tool install graphifyy) or put its launcher on PATH, then re-run knowledge extraction. |
| `TREE_SITTER_IMPORT_FAILED` | high | graphify's interpreter was found but tree-sitter would not load there | Reinstall graphify (uv tool install --reinstall graphifyy), then re-run knowledge extraction. |
| `GRAPH_STALE` | medium | the call graph was built at a different commit, or files referenced by clusters have changed since | Rebuild the source graph (graphify-source-graph with --refresh), then re-run knowledge extraction. |
| `ENTRY_POINTS_NOT_FOUND` | medium | no entry points were recognised in the call graph | No action needed unless the repository does have entry points; then widen the planner's entry-point pattern. |
| `NO_GRAMMAR_FOR_LANGUAGE` | medium | some AI-relevant files are in a language the slicer has no grammar rule for | Add the language to the slicer's table (one row and one test fixture). |
| `PARSE_ERRORS` | low | some files could not be parsed cleanly | None required; fix the syntax errors if they are unexpected. |
| `UNSLICEABLE_LINES` | low | some chain lines sit outside any function or method the slicer recognises | None required. |
| `SLICER_FAILED` | medium | the slicer stopped unexpectedly | Re-run; if it repeats, report the detail shown with this warning. |
| `CLUSTER_FALLBACK` | high | a cluster failed after retries and was handed to `ai-discovery-agent` | Re-run knowledge extraction; if it repeats, inspect the cluster's partial.json errors. |
| `UNVALIDATED_LANGUAGE` | info | slicing used a language other than Java; only Java has been validated against a benchmark | None required. |

Outputs, all under `knowledge-base/extraction/ai/`: `clusters/manifest.json` (clusters, seeds, read sets and the degradations above), `clusters/merged.json`, `clusters/<cluster>/partial.json`, `flows-<cluster>.md`, `rag-<cluster>.md`, then the usual `index.md`, area files and `summary.json` from `ai-discovery-agent`.

Each agent produces `index.md`, per-domain `.md` files (max 500 lines each), and `summary.json`.
`repository-intake-agent` additionally produces `extraction/project-profile.json` — a schema-validated,
stack-neutral "what kind of project is this" file that later agents read instead of hardcoding a
stack-specific anchor. It is required: the Phase 1 gate hard-stops before Phase 2 if it is missing or
schema-invalid (see [`contract.md`](../docs/contract.md)).

**Extraction methodology (applies across the domain and business agents):**
- **Multi-tier source coverage** — `business-logic-rules-agent`, `data-flow-agent`, and `functional-discovery-agent` treat SQL **stored procedures, functions, views, and triggers** as first-class logic, data-flow, and feature sources, not just application code. Reporting/query procedures with no controller or UI are cataloged as features in their own right. Extraction never treats a single artifact (a rules spreadsheet, a config export, or the service layer alone) as the complete source.
- **Binding evidence-based confidence** — a rule, flow, or feature earns `HIGH` confidence only when its implementing body (method, stored procedure/function, or trigger) has actually been read; anything inferred from a name, heading, or export column alone is `MEDIUM` at best, and an implementation absent from the repository is recorded as an explicit **source gap** rather than a low-confidence guess.
- **Rule-engine awareness** — where a codebase dispatches business operations through a database-resident rule engine, `business-intent-agent` and `risk-gap-agent` consume the inferred event→handler mapping as the authoritative operation list and gap source, mapping the pattern to whatever engine the codebase uses.

Completes with a quality score and grade from `extraction-quality/summary.json`.

`ai-discovery-agent` traces call graphs and records flow steps, RAG stages with their real constants, prompts and configuration keys; the repository's own docs (`project-profile.json` `docs.sources`) guide it but never count as evidence. The quality gate runs fifteen checks, including CHECK-13 (AI coverage, via `check-ai-output.py` against `sweep.json`), CHECK-14 (a `confirmed` claim backed only by documentation) and CHECK-15 (boilerplate inventory tables and lists). A folder score is capped by measured coverage — `min(deduction score, 100 × coverage)` — and where coverage cannot be measured the report says "not measured" rather than implying completeness.

---

### `/fix-knowledge-extraction` _(optional)_

**Run only if** the quality report from Phase 5 shows criticals or warnings that need resolution.

Reads `extraction-quality/summary.json` and `extraction-quality/index.md`, triages every open issue, then:
1. Applies **direct edits** for stale text, wrong values, or inapplicable schema fields.
2. **Re-runs extraction agents** for folders where content is missing, incomplete, or requires re-analysis.
3. Re-runs `extraction-quality-agent` after all fixes.
4. Reports a before/after quality score comparison.

If `/completeness-report` has been run, its findings are folded into the fix pass. The command does **not** re-run the completeness agent, so afterwards the completeness score and missing-item counts are stale; the closing report says so. Re-run `/completeness-report` to refresh them.

If the quality report already shows `criticalCount == 0` and `warningCount == 0`, this command exits immediately — nothing to fix.

**`--change <id> [--diff-base <ref>]`** — refresh the extraction files that a landed [change request](change-requests.md) made stale. Findings come from `knowledge-base/changes/<id>/impact.json` (`kbRefreshTargets[]`) instead of the quality report. With `--diff-base <ref>`, extraction files that cite any file the diff modified are added as extra findings. The default is a direct edit of the anchored sections, with an `<!-- updated-by: change <id> -->` provenance marker on each. The quality re-run is skipped unless an agent re-run happened. The command writes `knowledge-base/changes/<id>/refresh.json` (`status: done | pending`) and does not commit; `/archive-implemented` step 8.5 calls it automatically when the last story of a change is archived, and you re-run it by hand to retry a `pending` refresh.

---

### `/completeness-report` _(optional)_

Compares the extraction artifacts against **deterministic code facts** rather than the extraction's own
internal consistency — the check `extraction-quality-agent` cannot do. It builds (or reuses) a
source-code-only knowledge graph via `graphify` and its wrapper skill (`graphify-source-graph`), then runs
`completeness-report-agent` to classify every checkable claim as `TOTALLY_WRONG`, `INACCURATE`,
`UNSUPPORTED`, or `HUMAN-REVIEW`, and to list entities the graph found that no extraction folder mentions.
Each folder is `scored`, `accuracy-only` (claims verified, but the graph has no entities to measure coverage
against), `not-scored` (no claims checked) or `insufficient-sample` (fewer than `min(10, available)` claims
checked); only scored folders enter the overall score, and a folder with nothing to check is never shown as 100.
`accuracy-only` is typical for folders that document rules, flows, configuration or risks rather than classes:
their accuracy is reported beside the overall score, never blended into it. Source references written as
Markdown links (`[File.java#method](../../../src/.../File.java)`) are verified by `check-evidence-links.py`:
the file must exist, a `#symbol` must be in it (graph first, then the file text) and an `#L12-L40` range must
fit inside it. That proves a citation points at real code, not that the description beside it is true. Coverage counts an entity as covered only when it is *described*, not merely
mentioned; `ai/` entities come from `ai/sweep.json`, and the report adds an `ai.md` file.

**Prerequisite**: `graphify` CLI on `PATH` (`uv tool install graphifyy`). The plugin owns all graph scoping
(source code only — never `knowledge-base/` or `.claude/`) and rebuild/staleness verification via the
`graphify-source-graph` skill; do not run `graphify` commands manually.

Scoring is ratio-based per domain — `accuracy_score` from wrong/inaccurate/unsupported/review counts
weighted `1.00`/`0.35`/`0.15`/`0.05` against total claims checked, `coverage_score` from missing-entity
ratio — combined `0.65 × accuracy + 0.35 × coverage`, then weighted across domains (`knowledge-graph/` ×
1.5, `repository/`/`architecture/`/`business-intent/`/`ui-ux/` × 1.2, all others × 1.0).

Writes `knowledge-base/extraction/completeness-report/{index.md,summary.json,wrong-statements/<folder>.md,missing-items/<folder>.md}`.
Feeds `/fix-knowledge-extraction`, which incorporates its findings alongside the quality report's.

Add `graphify-out/` to the target repo's `.gitignore` — it is a build artifact, not knowledge-base content.

---

## Phase 2 — Capability Split

### `/capability-split`

Plans the modernization wave and capability structure from extraction outputs. Run after knowledge extraction completes and before generating BRDs.

Invokes `capability-split-agent`. The agent reads all available extraction output, proposes wave/capability groupings with business intents, iterates on your feedback, and writes the approved split to `knowledge-base/capabilities/`:
- `index.md` — overview, capability map, and per-wave descriptions (condensed to a TOC if > 500 lines)
- `summary.json` — machine-readable split consumed by `/export-for-alignment`, `/create-epic-backlog`, and `/target-state-architecture`
- `wave-N.md` — per-wave detail files (written when `index.md` would exceed 500 lines)

Say **approve** when satisfied with the proposal to write the files.

**Ask for demoable waves if you need them.** The agent's wave-assignment rules optimise risk and
dependency order — Wave 0 foundation enablers, then high-risk capabilities, then their dependents — and
say nothing about what a stakeholder can watch. If each delivery wave has to end in something showable,
state that in the feedback loop before approving; there is no argument for it. Wave 0 is exempt:
scaffolding has no clear business value by design. For example:

```
Wave 0 is scaffolding — infrastructure, security, test coverage, observability — and does not need to
be demoable. From Wave 1 onward, every wave must end in something we can demo to the client: a
user-facing flow through UI, business rules and data, not an internal enabler. For each of those
waves, name what we would show at the end of it and which business outcome it proves. Where an
enabler is needed for a wave's demo, put it in that wave rather than deferring it.
```

`summary.json` is the capability→wave map every later stage reads, so wave shape decided here
propagates into the architecture, the roadmap and the backlog. Re-shaping waves after epics exist
means re-running this command and re-deriving the backlog.

**No `<track>` argument.** One capability split per repository, shared by the programme and any demo
track — see [The optional `<track>` segment](#the-optional--segment).

---

## Phase 3 — Business Alignment

### `/export-for-alignment [capability | all]`

Generates a Business Requirements Document (BRD) for a specific capability, or for every capability in
one batched run.

Naming a capability keeps the single-capability path, invoking `business-capability-brd-agent` once.
Naming none reads `knowledge-base/capabilities/summary.json`, presents the full capability list, and
offers to fan out — one `business-capability-brd-agent` per capability, spawned in batches of up to
**10** per message (a ceiling, not a target: a longer list splits into further batches of at most 10),
all launching simultaneously within a batch. Each brief names both output paths below literally, so the
per-capability retry accounting and reconcile resolve to the right item rather than pooling across the
batch.

Output goes to a per-capability subfolder under `knowledge-base/business-capabilities/`:
- `<slug>/BRD-<slug>.md` — full narrative BRD
- `<slug>/capability-summary.json` — structured JSON summary (domain, business objective, rules, gaps, risks, modernization opportunities)

If no capability is provided, the command will prompt with the full list and offer the batched run.

---

## Phase 3.5 — BRD Validation _(optional)_

Run after generating BRDs to validate quality before downstream planning work consumes them.

### `/validate-brd [brd-slug]`

Validates all BRDs (or a single named BRD) for internal quality across 5 scored dimensions: capability/wave alignment, structure completeness, requirement clarity, acceptance criteria quality, and deduplication/conflict detection. Invokes `brd-validator` in VALIDATE mode.

**Optional argument:** a single BRD slug (e.g., `brd-issue-tracking`) to restrict the check to one BRD.

**Output:**
- `knowledge-base/business-capabilities/validation.md` — full narrative report with per-BRD scorecards (0–100 per dimension)
- `knowledge-base/business-capabilities/validation-summary.json` — machine-readable scorecard

---

### `/fix-brd [issues or brd-slug]` _(optional)_

Applies corrections to BRDs based on the last validation report or explicit instructions. Invokes `brd-validator` in FIX mode.

**Optional argument:** specific issues or a BRD slug to restrict fixes (e.g., `brd-issue-tracking` or `"brd-time-tracking duplicates SCM workflow"`). Omit to apply all findings from the last report.

---

### `/fix-brd-readiness [brd-slug]` _(optional)_

Fixes a BRD **in place** so it is ready to drive tech-stack-independent user stories for a re-platform/migration. Distinct from `/fix-brd` (which applies validation-report corrections): this command strips implementation coupling and content that does not belong in a business document — named technologies as requirements, physical-schema-as-requirements, prescriptive "how to build it" risk mitigations, undefined developer jargon, and scattered inline provenance. It **rewords, relocates, or demotes** existing content only — it never adds requirements or re-verifies accuracy (that is the validators' job). Self-contained command (no agent); produces no report.

**Optional argument:** a BRD slug, several slugs, or `all`. Omit to pick interactively from the available BRDs.

**Output:** edits the selected `<slug>/BRD-<slug>.md` files in place and prints a per-BRD list of what changed. No file is persisted.

---

## Phase 4 — Target Architecture

### `/target-state-architecture [track]`

Generates the Target-State Architecture Document from the current knowledge base plus user-supplied direction.

**Optional argument**: a `[track]` name (e.g. `demo`) writes into `architecture/<track>/` instead of the flat root — see [The optional `<track>` segment](#the-optional--segment).

**Required inputs** (command will ask for any missing):
- Target platform and hosting (AWS / Azure / GCP / on-prem; Kubernetes, serverless, PaaS)
- Technology stack (backend language/framework, frontend)
- Architecture style (microservices, modular monolith, serverless, event-driven, hybrid)
- Migration strategy preference and constraints
- Primary drivers and out-of-scope items

Invokes `target-state-architecture-agent`. Output goes to `knowledge-base/target-state/architecture/`, or `knowledge-base/target-state/architecture/<track>/` when a track was named.

---

### `/validate-architecture` _(optional)_

Validates the target-state architecture document set for **formatting**: file completeness, frontmatter, placeholder text, Mermaid diagram syntax, and cross-document consistency. Invokes `architecture-validator` in VALIDATE mode.

Checks whose tool or input is unavailable (Mermaid CLI can't run, `architectureDecisions` absent from `summary.json`, etc.) are reported as `UNVERIFIED`, not scored as a silent pass — a document set with any `UNVERIFIED` dimension cannot be graded above B.

This validator does **not** check whether the architecture is substantively complete against the extraction — see `/validate-architecture-completeness` below for that.

Pass `--fix` to apply corrections from the last validation report (runs in FIX mode).

**Output:**
- `knowledge-base/target-state/architecture/validation.md` — scored report
- `knowledge-base/target-state/architecture/validation-summary.json` — machine-readable scorecard

Written into the validated track's directory — the flat root by default, or `architecture/<track>/` when a track was named.

---

### `/validate-architecture-completeness` _(optional)_

Deep **coverage** pass, complementary to `/validate-architecture`. Reconciles the target-state architecture against the knowledge-base extraction inventory — every entity in `extraction/data-model/summary.json` and every feature-area/module in `extraction/functional/summary.json` must have a traceable Retain/Refactor/Retire/Defer disposition. Also gates on whether every `extraction/*` folder was actually read (calling out `extraction/ui-ux/` by name — the most common frontend blind spot), checks that load-bearing design made it into `target-state-summary.json` (not Markdown-only), and audits that the creator's Phase 2 plan gate (`.plan.md`) was recorded. Invokes `architecture-completeness-validator` in VALIDATE mode.

Produces a hard **READY / NOT-READY** verdict independent of the numeric score: any single unmapped entity, unmapped feature-area, or unread extraction folder forces NOT-READY, with an explicit instruction not to run `/create-epic-backlog` until the gap is resolved.

Pass `--fix` to add explicit `Defer` dispositions or `REVIEW REQUIRED` stubs for unmapped items from the last report (runs in FIX mode). It never invents target architecture design.

**Output:**
- `knowledge-base/target-state/architecture/completeness-validation.md` — scored report with full unmapped-entity/feature tables and the verdict
- `knowledge-base/target-state/architecture/completeness-validation-summary.json` — machine-readable scorecard

Written into the validated track's directory — the flat root by default, or `architecture/<track>/` when a track was named.

---

## Phase 5 — Transformation Planning

### `/transformation-roadmap [track]`

Generates the phased migration plan, then automatically chains team composition and effort/cost estimation. Invokes `transformation-agent`, followed by `team-estimation-agent`.

**Optional argument**: a `[track]` name (e.g. `demo`) writes into `transformation/<track>/` and reads the matching `architecture/<track>/` — see [The optional `<track>` segment](#the-optional--segment).

**Step 1 — `transformation-agent`:**
1. Reads knowledge base artifacts and asks clarifying questions
2. Presents a high-level transition plan for confirmation
3. Generates full transformation documents to `knowledge-base/target-state/transformation/` — or `transformation/<track>/` when a track was named — (nine planning docs + `transformation-summary.json`)

It validates every Mermaid diagram before writing and verifies all artifacts exist before reporting done. The `/create-epic-backlog` command depends on these transformation documents (it reads `transformation-summary.json` as the structured wave source).

**Step 2 — `team-estimation-agent`** (runs automatically once `transformation-summary.json` is written):
1. Builds a single Work Breakdown Structure (WBS) from the confirmed roadmap
2. Staffs and estimates that WBS three times — Cost-Optimized, Time-Optimized, and Safe & Realistic — using PERT three-point estimation and formal consulting grade bands (A3–F2), separating the delivery team from customer-side SME involvement

---

## Phase 6 — Epic Backlog

### `/create-epic-backlog [track]`

Generates a wave-organized epic backlog from approved transformation plans and BRDs.

**Optional argument**: a `[track]` name (e.g. `demo`) writes into `backlog/<track>/` and reads the matching transformation and architecture tracks — see [The optional `<track>` segment](#the-optional--segment). Mode detection is scoped to the resolved root, so a tracked run never inspects the flat backlog.

**Modes:**
- **Generation Mode** (no epic files exist) — discovers sources, proposes wave/epic structure for
  approval, then writes every wave README first (command only, no agents — `wave-<N>/` is the parent
  directory of the epic files), then spawns every epic across every wave.
- **Update Mode** (epic files already exist) — targeted updates to affected waves/epics only.

Output at `knowledge-base/target-state/backlog/` (or `backlog/<track>/`):
```
plan.md
epics.csv
wave-00/
  README.md
  epic-01-<name>.md
  ...
wave-01/
  ...
```

Epic agents use `model: haiku`. **All epics across all waves are spawned in parallel**, batched up to
**10 epics per message** (a ceiling, not a wave boundary). Batch boundaries cut across the flat epic
list from `plan.md` and ignore wave boundaries — a batch may span several waves, and one wave's epics
may land in several batches. After every batch, a per-batch check confirms each epic in that batch has a
file, retrying failures up to twice; once every wave's epics are spawned, one global exact-count check
confirms every epic in `plan.md` has exactly one file across every wave.

---

## Phase 7 — Story Intent

### `/story-intent [wave | epic | path]`

Generates structured story intent documents for approved epics. Input can be a wave number, epic file path, epic slug, or multiple values.

**Modes:**
- If any epic is missing a `STORIES-PLAN.md` → **Proposal Phase** first (proposes story splits for approval), then Generation Phase.
- If all epics already have `STORIES-PLAN.md` → **Generation Phase** only.

Spawns one `story-intent-agent` per epic, running in parallel.

**Generate incrementally — the epic is the unit.** You do not need stories for every epic before
implementation starts. `/story-intent wave-01/epic-01` does one epic; with no arguments the command
lists every epic that has no stories yet (across every track present) and asks which to process. A
backlog with ungenerated epics is a valid state: `/validate-backlog` has no check requiring stories to
exist, and `/new-story-spec` simply sees fewer candidates. What is *not* supported is half-generating a
single epic — the command reconciles the files it wrote against that epic's `STORIES-PLAN.md` and
re-spawns until they match.

Generating just ahead of the build is usually better: stories written after the client has seen working
software are better stories, and the feedback lands in stories still in `Draft`, where
[`/add-features`](#add-features) can act on it.

Output alongside each epic file:
```
wave-NN/
  epic-MM-<name>/
    stories/
      STORIES-PLAN.md
      story-01-<slug>.md
      story-02-<slug>.md
```

---

### `/validate-backlog` _(optional)_

Validates the modernization backlog — all epics and their stories — for structural completeness, acceptance criteria quality, dependency integrity, and cross-item consistency. Invokes `backlog-validator` in VALIDATE mode.

Pass `--fix` to apply corrections from the last validation report (runs in FIX mode).

**Output:**
- `knowledge-base/target-state/backlog/validation.md` — scored report
- `knowledge-base/target-state/backlog/validation-summary.json` — machine-readable scorecard

Written into the validated backlog root — the flat root by default, or `backlog/<track>/` when a track was named.

**`--changes [<id>]`** — validate [change stories](change-requests.md) instead of the migration backlog. Without `<id>`, every directory under `knowledge-base/changes/`. This mode runs no agent and writes no report: for each change it runs two deterministic checkers (`check-change-impact.py` on `impact.json`, `check-change-story.py` on the stories) and shows their output, then a one-line total. The migration-backlog prerequisite does not apply. Positional track/wave values and `--fix` are rejected with `--changes`. To fix a FAILED change, re-run `/propose-change --id <slug> "<intent>"` (re-analyse keeps non-Draft stories).

---

## Phase 8 — Implementation

These commands drive individual backlog stories from `knowledge-base/target-state/backlog/**/stories/story-*.md` (produced by `/story-intent`) through to a merged implementation, using [OpenSpec](https://github.com/Fission-AI/OpenSpec) as the spec-driven implementation backend. They require the `openspec` CLI on `PATH` and an initialized `openspec/` project root in the target repo, plus `glab` (GitLab CLI) for merge request automation — both are optional; commands print a manual fallback URL/instructions when unavailable.

**Before the first `/new-story-spec`, run [`/recommend-tooling`](#recommend-tooling---revalidate-on-host) once.** It reads the confirmed target-state architecture and proposes verified Claude Code skills, plugins, MCP servers, and CLI tools matched to the actual target stack. Installing the ones that fit gives the implementation agents framework-idiomatic patterns and structural tools (e.g. an LSP-backed code-intelligence server, a stack-specific test-runner skill) instead of plain-text search/edit — this tends to raise the quality of the generated code and lowers token usage per story, since the agent reaches for a precise tool call instead of reading and re-reading files to find what a dedicated tool would return directly.

### `/new-story-spec [story-path]`

Picks an unblocked backlog story (or uses the path given), creates a feature branch, generates an OpenSpec proposal (`proposal.md`, `specs/`, `design.md`, `tasks.md`) grounded in the story content via `opsx:propose`, validates every story section is reflected in the generated artifacts, then pushes the branch and opens a GitLab merge request.

**Output:** a pushed feature branch with `openspec/changes/<change-name>/` populated, story status set to `Generating Spec`.

Story discovery also globs `knowledge-base/changes/*/stories/story-*.md`; the picker labels each story with its root (`backlog` or `change <id>`). For a change story (one with `**Story Kind:** change`), the branch is `changes/<id>/story-NN-<slug>`, and the characterization plan becomes task group 1, "Pin current behaviour".

---

### `/new-story-impl <branch-name> [--with-review]`

Checks out a story's branch and implements every task in its OpenSpec change via `opsx:apply`, validates all tasks completed, commits the implementation, and pushes. With `--with-review`, runs `/code-review --fix` before the final push. Resumable — re-running picks up from the story's current status instead of repeating completed phases.

**Output:** implementation committed and pushed on the story branch, story status advanced to `Ready for Validation`.

For a change story the implementation runs in two passes: first only the pinning tests (task group 1), which must pass on the unmodified code and are committed as `test: characterize <area>`; then the remaining tasks. If a pinning test fails on unmodified code the command stops and points back to `/propose-change`. After the tasks, a preservation check re-runs the suite, and a **Scope drift** warning lists files in the diff that `impact.json` did not declare (warning only).

---

### `/archive-implemented [branch-name]`

Finds an approved/ready merge request (or accepts a branch name directly), syncs the change's delta specs into the main OpenSpec specs via `opsx:sync`, archives the change via `opsx:archive`, sets the story status to `Done`, then squash-merges the branch into `main` and deletes the source branch (remote + local).

**Output:** change archived under `openspec/changes/archive/YYYY-MM-DD-<change-name>/`, story status `Done`, branch merged and deleted.

For a change story, step 8.5 refreshes the knowledge base once every story of the change is Done (otherwise it reports the refresh as deferred): it runs `/fix-knowledge-extraction --change <id> --diff-base origin/main`, writes `knowledge-base/changes/<id>/refresh.json`, and commits it with the archive. A failed refresh never blocks the archive; it leaves `status: pending`.

---

## Change Requests — Evolve in Place

For changes to the live system on its current stack, with no migration. This path needs `/knowledge-extraction` only. Choosing between it, `/add-features` and the migration chain: [`modernization-strategies.md`](modernization-strategies.md). The runbook: [`change-requests.md`](change-requests.md).

```
/knowledge-extraction → /propose-change → /new-story-spec → /new-story-impl → /archive-implemented
```

### `/propose-change "<intent>" [--type feature|behaviour-change|refactor] [--id <slug>]`

Proposes one in-place change: a feature, a behaviour change or a refactor. Analyses the change's impact on the existing code, gates on a human review of that impact, then writes change stories that `/new-story-spec`, `/new-story-impl` and `/archive-implemented` run unchanged.

**Args:**
- `"<intent>"` — the change request, in quotes. Asked for if absent.
- `--type` — skips classification (still shown for confirmation). A mixed request is split into one story per type, refactor first.
- `--id <slug>` — overrides the slug part of the change id (`YYYY-MM-DD-<slug>`).

**Steps:**
1. Prerequisite check (`change-impact`): extraction only; no capabilities, BRDs, target state or backlog.
2. Classify the change type and mint the change id. If the id exists, choose **Re-analyse** (overwrites `impact.*`, keeps every story that is no longer Draft) or **New id**.
3. If `graphify` is on `PATH`, build or reuse the source graph; otherwise dependents come from grep.
4. Spawn `change-impact-agent`, then re-check its `impact.json` with `check-change-impact.py`.
5. **Impact checkpoint:** shows the summary table and "What to check" list, plus type conflicts, `sizing: programme` warnings, blocking open questions and backlog collisions. Choose **Approve**, **Correct scope** (re-runs the analysis, at most 2 times) or **Cancel**.
6. Spawn `change-story-agent` to write the stories, then verify them with `check-change-story.py` and reconcile both producers.

**Output** (under `knowledge-base/changes/<id>/`):
- `impact.json` (schema [`change-impact.v1`](schema-reference.md#change-impactv1)) and `impact.md`
- `stories/story-NN-<slug>.md`: change stories, in the same shape as migration stories plus Current/Target Behaviour, Behaviour Preservation and a Characterization Plan
- `refresh.json`: written later, at archive time
- `open-questions-changes.{md,json}`: written by `/resolve-open-questions changes --change <id>`

---

## Side Track — The Demo

A demo is not a separate pipeline. It is the same stages 4–7 run at a smaller scope under a `demo`
track, plus three commands that exist only for it.

**Prerequisites differ by half.** Steps 1–4 below — research, `/demo-plan`, the design guide and the
mockup — need [`/knowledge-extraction`](#knowledge-extraction) and nothing else; `/demo-plan` spawns
`target-state-architecture-agent` directly and so clears no gate. Steps 5–8, the backlog half, also
need the programme's [`/capability-split`](#capability-split) and — from `/story-intent` on — its
[`/export-for-alignment`](#export-for-alignment-capability) BRDs, because those two stages are not
track-aware and their gates resolve to the flat paths. Neither is quick — capability-split needs your
review of the wave grouping, and BRDs are validated one capability at a time — so if you already know
you'll want a demo backlog, start them alongside step 1 rather than waiting until step 5's gate forces
the issue.

| # | Step | Command | Notes |
|---|---|---|---|
| 1 | **Scope it against a budget** | [`/research`](#research-question) | State the goal, the audience, and what you may spend — weeks, engineers, stack. Ask for 2–4 flows that fit, ranked by value, with dependencies and what each does *not* prove |
| 2 | **Confirm with the client** | — human step | Take the proposed flows to the client. If the agreed set differs materially, amend or re-run `/research` so the note the agents read matches what was agreed |
| 3 | **Plan the demo** | [`/demo-plan`](#demo-plan-scope-prose---design-guide) | Chains `/demo-init` (five scope dimensions + **the flow approval gate**) → `architecture/demo/` → `/demo-flows`, plus `/design-guide` with `--design-guide`. Idempotent by step |
| 4 | **Mockup** | — plus a design tool | Screen inventory for the approved flows + `design-guide.md` → clickable HTML screens. Keep them in `ui-mockup/` and tell the implementation agents to match them |
| 5 | **Roadmap and epics** | `/transformation-roadmap demo` → `/create-epic-backlog demo` → `/resolve-open-questions epics demo` → `/validate-backlog demo` | Reads the `demo` track of every stage that *has* one. **`/create-epic-backlog demo` additionally requires the flat `/capability-split`** — untracked, so it gates on `knowledge-base/capabilities/` and builds epic briefs from `capability-summary.json` |
| 6 | **Stories, incrementally** | `/story-intent demo/wave-01/epic-01` | One epic at a time as you build — see [`/story-intent`](#story-intent-wave--epic--path). Ungenerated epics are a valid state. **Requires the flat capability split *and* BRDs** — the strictest gate in the demo chain |
| 7 | **Build** | `/new-story-spec <path in backlog/demo/>` → `/new-story-impl` → `/archive-implemented` | The track becomes the branch's first segment. The open-questions gate is per story |
| 8 | **Revise scope mid-build** | [`/add-features`](#add-features) | Draft-only, scans for duplicates first, and asks which track. Not a re-run of `/create-epic-backlog` |
| 9 | **Show it** | `/publish-knowledge-base demo` | One track per publish |

Two things that surprise people:

- **The flow list is the only machine-enforced gate in the demo chain.** `/demo-init` prints the
  proposed flows and stops; `/demo-flows`, `/design-guide` and the mockup step have no gate of their own.
- **Capability split and BRDs are shared, not scoped — which makes them prerequisites, not optional.**
  A demo has no BRDs or capability map of its own; it reads the programme's, so the flat artifacts must
  exist before the backlog half will run. Only the `/demo-plan` half is free of them. See
  [What takes no track at all](#the-optional--segment).

---

## Utility Commands

### `/research [question]`

Launches `knowledge-base-research-agent` to produce a deep, cited research investigation grounded in `knowledge-base/`. Useful at any point. It is also an **optional upstream input to `/demo-plan`**: a note that ranks flows by value or maps their dependencies (e.g. "list flows from BRDs deliverable in 2 weeks, highest customer value, show dependencies") is read by `demo-init-planner` as evidence for flow selection — but `/demo-init`'s approval gate, not the note, decides the final flow set. `transformation-agent` reads these notes the same way for wave sequencing.

Always asks clarifying questions first (goal, audience, scope, supporting documents, claims to validate) — it never proceeds on a narrow, unconfirmed assumption.

**Output:** `knowledge-base/research/<slug>.md` — cited Markdown note with confidence-graded findings, a claim-validation table, and an explicit gaps section.

---

### `/demo-plan [scope prose] [--design-guide]`

End-to-end demo planning. Delegates to the steps below rather than duplicating them, so each stage
stays individually re-runnable:

1. `/demo-init` — scope collection + the demo-flow approval gate (the only gate in the run)
2. the demo-scoped target-state architecture — spawns `target-state-architecture-agent` into
   `target-state/architecture/demo/`, pre-filling its Required Input from the approved `demo-findings.json`.
   **Skipped if that root already exists.**
3. `/demo-flows` — one business-description document per approved flow
4. `/design-guide` — only with `--design-guide`

Idempotent by step: re-running after an architecture change skips step 2 and regenerates only the flow docs.

**No prerequisite gate.** Because step 2 spawns the agent directly instead of invoking
[`/target-state-architecture`](#target-state-architecture-track), this command needs only
`/knowledge-extraction` — no capability split, no BRDs. Regenerating the same output with
`/target-state-architecture demo` *does* run the gate and will demand both.

**Output:** `knowledge-base/demo/**` + `knowledge-base/target-state/architecture/demo/` (+ `design-guide.md` with the flag). This is what populates the site's two Demo pages and the index Demo block.

---

### `/demo-init [scope prose]`

Runs `demo-init-planner` against `knowledge-base/`. Collects five scope dimensions first — target domains,
target stack, audience, timeline, out-of-scope — asking only for what you did not already provide, and passes
the paths of any `knowledge-base/research/` notes to the agent as evidence. Then prints the proposed
`demoFlows[]` as a table and **stops for approval**; on feedback it patches both `demo-findings.json` and
§4 of `demo-overview.md` and re-displays.

**Output:** `knowledge-base/demo/demo-overview.md` + `knowledge-base/demo/demo-findings.json`.

---

### `/demo-flows [flow-ids]`

Spawns one `demo-flow-describer` per flow, all in parallel; with no arguments it covers every flow in
`demoFlows[]`. Gates first on `demo-findings.json` and on a resolvable architecture root
(`target-state/architecture/demo/` if present, else the flat root) — naming the exact command to run if
either is missing — and reconciles written files against the requested flow set afterwards, re-spawning any
stragglers.

**Output:** `knowledge-base/demo/business-flow/flow-<NN>-<slug>.md` — presenter-ready, zero technical detail, with every screen labelled *evolved from migrated …* or *new screen — no legacy equivalent* (+ a mandatory `New because:` line).

---

### `/design-guide [ui-path hint]`

Runs `design-guide-extractor` over the existing UI source to produce a technology-agnostic style guide —
colour palette, type scale, spacing, shape/elevation, component visual patterns, accessibility notes, and a
full design-tokens table. No dependency on the demo chain; runnable at any time.

**Output:** `knowledge-base/design-guide.md`.

---

### `/recommend-tooling [--revalidate-on-host]`

Runs `skill-recommender` against `knowledge-base/target-state/architecture/` to propose verified Claude Code skills, plugins, MCP servers, and CLI tools matched to the target stack — install commands only, never installs anything itself. Every community candidate (first-party vendor tools are exempt) must clear a hard quality bar — **≥2000 GitHub stars, pushed within the last 6 months, not archived** — measured live via `gh api`/the GitHub API; candidates that don't clear it are listed with their measured star count rather than silently dropped. Writes two files split strictly by scope, re-derived from the architecture on every run (no accumulating catalog, no template ever copied into the target repo): a committed, project-scoped deliverable, and a gitignored, host-scoped file — the latter also carries a fixed, stack-independent set of terminal ergonomics tools (`ast-grep`, `ripgrep`, `jq`, …) read straight from the plugin every run. `--revalidate-on-host` re-checks the host file's CLI claims against the current machine without rewriting the project file.

**Run this once, right before [Phase 8 — Implementation](#phase-8--implementation).** It needs nothing beyond a confirmed `/target-state-architecture`, so the earliest useful point is right after that stage, and the latest sensible point is immediately before the first `/new-story-spec`. Installing the skills/MCP servers/CLI tools it proposes — framework-idiomatic patterns, an LSP-backed code-intelligence server, structural editors — gives implementation agents precise tool calls in place of brittle plain-text search-and-edit, which tends to both **raise the quality of the generated code** (idiomatic to the actual framework, not guessed) and **lower token usage per story** (fewer exploratory reads to find something a dedicated tool would answer in one call).

**Output:** `knowledge-base/target-state/project-tooling.md` (committed — every row derived from the target architecture and its ADRs, zero host/machine facts, re-derived fresh each run) and `.claude/tooling/host-setup.md` (gitignored, deliberately outside `knowledge-base/` — this machine's install state plus the stack-independent CLI ergonomics list, regenerate on demand rather than trusting a stale commit).

---

### `/add-features <description>`

Adds a described piece of new functionality to an existing wave-structured backlog. Delegates the read-only backlog scan to the `add-features-analyst` subagent, which writes schema-governed findings (duplicates, overlaps, contradictions, affected epics/waves, editability map, placement recommendation) rather than only returning a message; resolves ambiguities with you from those findings; then delegates new epic/story authoring to `epic-backlog-agent`/`story-intent-agent` (the same producers `/create-epic-backlog` and `/story-intent` use) and applies index/aggregate edits itself, all on a new branch.

**Hard rule:** only stories with `**Status:** Draft` may be modified — every other status is locked. New stories are always born `Draft`.

Requires a clean working tree on `main`. Creates branch `backlog/add-<slug>`, commits, and optionally pushes + opens a merge request via `glab`.

**Track selection is asked, not passed.** The command resolves the backlog root itself; when more than
one track is present it asks which one the feature belongs to before scanning, so it can never scan one
track and write to another. There is no positional track argument.

**This is how demo scope changes mid-build.** The client sees the first flow and asks for something
adjacent — that is an `/add-features` run against the `demo` track, not a re-run of
`/create-epic-backlog`, which would regenerate epics you are already implementing. The Draft-only rule
is what makes it safe: anything already `Active` or beyond is reported as a follow-up rather than
edited.

**Output:** `add-features-findings.md` + `add-features-findings.json` (the scan, at the backlog root — overwritten per run, per-feature history lives in git on the run's own branch); new/edited story and epic files under the resolved `target-state/backlog/` root (or `<track>/`), plus updated index files (`plan.md`, `epics.csv`, wave `README.md`, `STORIES-PLAN.md`).

---

### `/progress-report`

Generates a slide-by-slide progress-report deck structure for stakeholder presentations, covering scope/approach recap, codebase findings, target architecture, demo flows, and demo-vs-final architecture. Works in 5 phases (deck planning → per-section knowledge mapping → parallel section research → trim/merge → parallel detailed slide generation), with an approval gate after the deck plan. Both fan-out phases (per-section, per-slide) reconcile their own output by exact count against the plan before moving on — a bespoke check, since the ad-hoc agents this command spawns are not a registered `producer` the `reconcile` skill can target.

**Output:** `knowledge-base/progress-report/` — `plan.json`, `sections/section-<NN>.json` + `section-<NN>-slides.json`, `deck-plan-merged.json`, `slides/slide-<NN>.md`, and the final assembled `deck-structure.md`.

---

### `frontend-slides` _(third-party skill)_

Not part of this plugin — turns any `knowledge-base/` Markdown into a self-contained HTML slide
deck. See the [user manual](user-manual.md#presentations-from-the-knowledge-base-frontend-slides)
for setup and usage.

---

### `/publish-knowledge-base [track]`

Builds or updates the static HTML knowledge base site from all files in `knowledge-base/`. Can be run at any stage.

**Optional argument**: a `[track]` name selects which target-state track the site renders. The site shows **one track per publish** — its data schemas are structurally singular. With no argument the publisher resolves the track itself (`end-state`, else flat, else the single track present) and asks if several exist with no obvious default.

Invokes `knowledge-base-publisher`. Output at `knowledge-base/site/index.html`.

The site serves two audiences: Product Team (capabilities, features, APIs, data) and Architecture Team (structure, modules, dependencies, risks). When extraction found AI components it also shows an **AI** navigation group — AI Overview, Agents & Flows, Prompts, Retrieval (RAG), Engineering Harness — with prompt source links pinned to the analysed commit; the group is hidden otherwise.

---

### `/validate-mermaid [file]`

Validates all Mermaid code blocks in the specified file, or all `knowledge-base/*.md` files if no argument given. Fixes draw.io incompatibilities in-place and reports syntax errors.

---

### `/parse-docx [file]`

Converts a Word `.docx` file to Markdown. Use before knowledge extraction when source material is in Word format. Installs `pandoc` automatically if absent.

Supports track-changes (accepts/rejects) and uses `python-docx` for accurate table and image extraction. Output is a `.md` file alongside the source document.

---

## Diagnostics

Nothing in this section gates a pipeline stage, writes to `knowledge-base/`, or starts a tracked
execution — so it is always safe to run, including in the middle of a long pipeline command. A non-zero
exit is a finding to act on, not a halt.

`/contract` and `/reconcile` are strictly read-only. The one exception is **`/collect-stats`**, which
writes its own two ledgers and nothing else: `report` (its default) rewrites the git-tracked
`.claude/logs/summary.jsonl`, `refresh` rewrites the per-machine ledger, and `sanitize` rewrites both
in place.

You will not find these in the phase list above because they report *on* the pipeline rather than
advancing it. They are the answer to "did that stage actually produce what it claimed?" and "which
run wrote this file?".

### `/contract <verb>`

Whole-pipeline contract diagnostics. The verbs, in rough order of everyday usefulness:

| Verb | Answers |
|---|---|
| `status` | What state is every stage in (`not-started` / `partial` / `done`), and what can I run right now? |
| `validate [stage-id \| --all]` | Is the output that exists actually **schema-valid**, not merely present? Stricter than the Step-0 gate. |
| `reconcile [stage-id \| --all]` | Did a stage write everything it declared — and is anything under `knowledge-base/` **orphaned** (declared by no stage)? |
| `trace status [--open] [--files] [--prompt] [--git] [--versions] [--all]` | Execution history, newest first: one block per command run with its agent runs nested underneath. Each agent run shows the `model=` its agent file declares and the `requested=` override the spawn passed, when recorded. `--open` shows runs that started but never finished. `--files` adds the files each agent run produced; `--prompt` adds the prompt that invoked the run. `--git` adds the branch, commit and dirty/clean state it started in; `--versions` adds the toolkit and Claude Code versions. `--all` turns on every annotation (everything except `--files`). |
| `trace run <RUN_ID> [--files] [--prompt] [--git] [--versions] [--all]` | One command execution's full tree. Takes the same opt-ins as `trace status`, with the same defaults — a bare `trace run` shows none of them. |
| `trace artifact <path>` | For one `knowledge-base/` file: which run produced the current copy, what it consumed, and what consumed it. |
| `list` | Every valid stage id — run this instead of guessing a spelling. |
| `lint` | Is the phase graph itself internally consistent? Maintainer-facing. |
| `levels` | Which stages have no dependency between them, i.e. what may legitimately run concurrently. Maintainer-facing. |
| `manifest` | Is the committed artifact manifest still what the graph renders to? Maintainer-facing. |
| `drift` | Has the published site's schema drifted from the contract schema it derives from? Maintainer-facing; **never** a publish gate. |

Add `--track <name>` when the run in question used a track, and `--json` (**before** the verb) for
machine-readable output. Invoked bare, it asks which verb you meant rather than guessing.

**Start with `/contract status`** if you are unsure where an engagement stands, and
`/contract trace status --open` if a command seems to have died midway.

### `/reconcile <agent-name>`

The same reconciliation check as `/contract reconcile`, scoped to one producing agent and carrying the
standard retry policy (2 retries, 3 attempts total). Commands invoke this automatically after every
agent spawn, so you rarely need it by hand — reach for it when you want to re-check one agent's output
after editing something underneath it.

### `/collect-stats [report|refresh|sanitize]`

Token and cost figures for this repo. `report` (the default) refreshes, rewrites
`.claude/logs/summary.jsonl`, and prints a table; `refresh` updates the per-machine ledger silently;
`sanitize` resets every `session_name` in both files to its git branch. **The one command in this
section that writes** — to those two ledgers only, never to `knowledge-base/`. See
[`usage-stats.md`](usage-stats.md) for what is tracked, what stays local, and the privacy
trade-offs of committing the report.

### `/whats-new [all|X.Y.Z]`

Shows the plugin's changelog from inside a session: the latest release by default, `all` for the whole
file, or one version. Strictly read-only. The release process copies the repo-root `CHANGELOG.md` into
the plugin root, which is what makes it readable after install.

---

## Output Folder Map

For the authoritative per-stage contract (exact filenames, JSON schema locations, and consumers), see [`artifact-manifest.md`](../docs/artifact-manifest.md) — generated from `phase-graph.json`, so it stays current with the pipeline.

```
knowledge-base/
  extraction/
    repository/             ← Phase 1
    project-profile.json    ← Phase 1
    architecture/           ← Phase 2
    functional/             ← Phase 2
    data-model/             ← Phase 2
    data-flow/              ← Phase 2
    integrations/           ← Phase 2
    ui-ux/                  ← Phase 2
    business-intent/        ← Phase 3
    business-logic-rules/   ← Phase 2
    security/               ← Phase 2
    runtime-operations/     ← Phase 2
    risk-gap/               ← Phase 3
    knowledge-graph/        ← Phase 4
    extraction-quality/     ← Phase 5
    completeness-report/    ← /completeness-report (optional)
      wrong-statements/<folder>.md
      missing-items/<folder>.md
  changes/                  ← /propose-change (one folder per change request)
    <id>/
      impact.json
      impact.md
      stories/story-NN-<slug>.md
      refresh.json          ← written at archive time
      open-questions-changes.{md,json}
  capabilities/             ← /capability-split
    index.md
    summary.json
    wave-N.md               ← (when index.md > 500 lines)
  business-capabilities/    ← /export-for-alignment
    <slug>/                 ← one subfolder per capability
      BRD-<slug>.md         ← /export-for-alignment
      capability-summary.json ← /export-for-alignment
    validation.md           ← /validate-brd
    validation-summary.json ← /validate-brd
  target-state/
    architecture/           ← /target-state-architecture
      <track>/              ← optional: one subfolder per track (e.g. demo/, end-state/)
      .plan.md              ← /target-state-architecture (Phase 2 plan-gate record)
      validation.md         ← /validate-architecture
      validation-summary.json ← /validate-architecture
      completeness-validation.md ← /validate-architecture-completeness
      completeness-validation-summary.json ← /validate-architecture-completeness
    project-tooling.md       ← /recommend-tooling (committed — architecture-derived, re-derived every run)
    transformation/         ← transformation-agent + team-estimation-agent
      <track>/              ← optional: one subfolder per track
    backlog/                ← /create-epic-backlog + /story-intent
      <track>/              ← optional: one subfolder per track
      validation.md         ← /validate-backlog
      validation-summary.json ← /validate-backlog
  research/                 ← /research
    <slug>.md               ← one cited research note per question
  demo/                     ← /demo-init + /demo-flows (both chained by /demo-plan) — deliberately flat, no <track>
    demo-overview.md
    demo-findings.json
    business-flow/flow-<NN>-<slug>.md
  design-guide.md           ← /design-guide
  progress-report/          ← /progress-report
    plan.json
    sections/section-<NN>.json, section-<NN>-slides.json
    deck-plan-merged.json
    slides/slide-<NN>.md
    deck-structure.md       ← final assembled deck outline
  site/                     ← /publish-knowledge-base
```

`/recommend-tooling`'s other output, `.claude/tooling/host-setup.md`, is deliberately **not** in the tree
above — it lives outside `knowledge-base/` entirely, is gitignored, and describes only this machine's
install state (never a team fact).

### The optional `<track>` segment

The three `target-state/` folders each accept an optional `<track>` segment so a scoped variant — typically
a **demo** — can be generated without overwriting the full programme artifacts. Pass a track name as the
command's optional positional argument:

```
/target-state-architecture demo     → knowledge-base/target-state/architecture/demo/
/transformation-roadmap demo        → knowledge-base/target-state/transformation/demo/
/create-epic-backlog demo           → knowledge-base/target-state/backlog/demo/
/validate-architecture demo         → validates the demo architecture track
/publish-knowledge-base demo        → site renders the demo track
/story-intent demo/wave-00          → a PATH PREFIX, not a separate argument
/validate-backlog demo wave-01      → track FIRST, then wave
/resolve-open-questions epics demo  → scope first, then track
```

**The argument shape is not uniform.** Most commands take the track as a bare first positional, but
three do not — and one asks instead of taking it at all:

| Programme run (the default) | Demo track | Shape |
|---|---|---|
| `/target-state-architecture` | `/target-state-architecture demo` | bare positional |
| `/validate-architecture` · `/validate-architecture-completeness` | `… demo` | bare positional |
| `/transformation-roadmap` | `/transformation-roadmap demo` | bare positional |
| `/create-epic-backlog` | `/create-epic-backlog demo` | bare positional |
| `/publish-knowledge-base` | `/publish-knowledge-base demo` | bare positional |
| `/story-intent wave-01` | `/story-intent demo/wave-01` | **path prefix** |
| `/validate-backlog wave-01` | `/validate-backlog demo wave-01` | **second positional**, track first |
| `/resolve-open-questions epics` | `/resolve-open-questions epics demo` | **second positional**, after the scope |
| `/add-features "…"` | `/add-features "…"` | **asked interactively**, never passed |
| `/new-story-spec <path>` | `/new-story-spec <path under backlog/demo/>` | **derived** from the path |

**What takes no track at all.** These are shared by the programme and every track, and passing one is
either ignored or rejected:

| Command | Why |
|---|---|
| `/capability-split` | One capability→wave map per repository |
| `/export-for-alignment`, `/validate-brd` | One BRD set per capability — a demo reads the programme's |
| `/resolve-open-questions extraction`, `… brd` | `open-questions-cli.py` exits 2 on `--track` for these scopes |
| `/demo-init`, `/demo-flows` | `knowledge-base/demo/` is flat — one demo per repository |
| `/design-guide` | `knowledge-base/design-guide.md` is flat — one style guide per repository |
| `/research` | Notes are named per question, not per track |

Capabilities and BRDs describe **the system**, which does not change because you are demoing part of
it — hence no demo-scoped variant of either. The consequence is easy to miss: because there is no
demo-scoped variant, the gates for `/create-epic-backlog` and `/story-intent` fall back to the **flat**
ones, so a demo backlog cannot be built until the programme has produced them. `/demo-plan` is the only
part of the demo chain that is exempt.

**The default is flat** — omit the argument and every command behaves exactly as before. Rules:

- A track propagates for the whole run: a stage invoked with a track reads *and* writes that track,
  including when it reads another stage's artifacts.
- The layout **inside** a track is identical to the flat layout — same filenames, same JSON schemas. A
  track changes the path only, never the contract.
- Story branches carry the track as their first segment (`demo/wave-00/epic-01-…/story-01-…`), so branches
  stay unambiguous across tracks. `/new-story-spec`, `/new-story-impl`, and `/archive-implemented` derive
  paths segment-count-agnostically.
- The site renders **one track per publish** — its data schemas are structurally singular. Publishing a
  different track is a separate run.

See [`artifact-manifest.md`](../docs/artifact-manifest.md) for the authoritative convention.

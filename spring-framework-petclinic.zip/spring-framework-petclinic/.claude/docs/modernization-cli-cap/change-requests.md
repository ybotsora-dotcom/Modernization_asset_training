# Change Requests: Evolving the Live System In Place

A task-oriented runbook for `/propose-change`: one feature, behaviour change or refactor on the system you already run, without migrating it.

## When to use it

Use it when the request is **one change against the live system, on the current stack**. Three types are supported:

| Type | Meaning | Example |
|---|---|---|
| `feature` | A new capability; existing behaviour stays | "Add a CSV export of invoice totals" |
| `behaviour-change` | An existing behaviour works differently | "Round totals half-up" |
| `refactor` | Internal structure changes; no observable behaviour changes | "Extract rounding into one helper" |

Use something else when:

- **There is a migration backlog and the request belongs in it.** Use `/add-features`; it edits Draft stories on that backlog.
- **You are moving to a new stack.** Use the migration chain, starting at `/capability-split`.
- **The request is a planned programme.** If `/propose-change` reports `sizing: programme`, see [Troubleshooting](#troubleshooting).

For the full comparison, see [`modernization-strategies.md`](modernization-strategies.md).

## Prerequisites

- `/knowledge-extraction` has completed. This is the only pipeline stage required: no capability split, BRDs, target state or backlog.
- `openspec init` has been run in the repository, because the implementation commands drive OpenSpec.
- `graphify` on `PATH` is **optional**. With it, dependents of the code you change come from a dependency graph. Without it they come from grep, the impact report records `dependencySource: grep`, and reach may be incomplete. Read the dependents list with that in mind.

## Walkthrough

Each example shows the same path: `/propose-change`, the impact checkpoint, the files written, then `/new-story-spec`, `/new-story-impl` and `/archive-implemented`.

Change ids look like `YYYY-MM-DD-<slug>`. The slug comes from the intent, or from `--id`.

### Feature: "Add a CSV export of invoice totals"

```
/propose-change "Add a CSV export of invoice totals"
```

The command confirms the type (`feature`), runs the impact analysis, and shows a checkpoint table like this:

| | |
|---|---|
| Change | `2026-10-14-add-csv-export` - feature - sizing change |
| Code | 2 direct, 4 dependent files (dependencies from graphify) |
| Behaviours | 2 preserve - 0 change - 1 add - 0 remove |
| Coverage | 1 covered - 1 partial - 1 none |
| Characterization | 1 item |
| Contracts | 1 compatible - 0 breaking |
| Type conflicts | 0 |
| Open questions | 1 (0 blocking) |

Approve it. The command then writes:

```
knowledge-base/changes/2026-10-14-add-csv-export/
  impact.json
  impact.md
  stories/
    story-01-invoice-csv-export.md      Change Type: feature   Blocked By: none
```

The story has one characterization item (the partially covered invoice-total calculation the export reads), so it is a single story. Before /new-story-spec, commit the change folder to main (`git add knowledge-base/changes/<id>/ && git commit -m "docs: propose change <id>"`); the command does not commit, and untracked story files would make the next `git pull origin main` abort. Then:

```
/new-story-spec knowledge-base/changes/2026-10-14-add-csv-export/stories/story-01-invoice-csv-export.md
/new-story-impl changes/2026-10-14-add-csv-export/story-01-invoice-csv-export
/archive-implemented
```

`/new-story-impl` makes two commits before the usual implementation commit: first `test: characterize invoice totals` (the pinning tests, passing on unmodified code), then the change itself. After the last story is archived, the knowledge base is refreshed and `knowledge-base/changes/<id>/refresh.json` is written.

### Behaviour change: "Round totals half-up"

```
/propose-change "Round totals half-up" --type behaviour-change
```

The impact report lists the current rounding behaviour with disposition `change`, recording both `before` ("banker's rounding") and `after` ("half-up"). Behaviours that depend on totals but must not move are `preserve`. If the rounding is not covered by tests, characterization items pin it first.

The story file is `story-01-half-up-rounding.md`. Its **Target Behaviour** section names every existing test that intentionally changes (for example `tests/test_totals.py::test_rounds_to_even changes: now half-up`). That naming is what lets the preservation check tell an intended change from a regression.

### Refactor: "Extract rounding into one helper"

```
/propose-change "Extract rounding into one helper" --type refactor
```

A refactor may contain only `preserve` behaviours. If the analysis finds one that must change, it is listed under `typeConflicts[]`, and the checkpoint offers to reclassify the change as a behaviour change or split it into a refactor story plus a behaviour-change story (refactor first; the second is `Blocked By` the first).

When there are many things to pin (more than 5 characterization items) or no test harness exists yet for the layer, the command writes a separate leading story:

```
stories/
  story-01-characterize-totals.md       Blocked By: none
  story-02-extract-rounding-helper.md   Blocked By: story-01
```

A change with a breaking contract whose consumers need migrating is split into an *expand* story and a later *contract* story, in the same way.

## Reading the impact report

`impact.md` is what the checkpoint shows; `impact.json` (schema `change-impact.v1`) is the same data in machine form.

**Dispositions.** Each touched behaviour is one of: `preserve` (must work exactly as today), `change` (before and after recorded), `add`, or `remove`.

**Coverage.** For each behaviour, `covered` means a test asserts exactly this behaviour; `partial` means a test runs the code but does not assert it or misses a branch; `none` means no test. Only real test files are listed.

**Confidence.** Every code reference and behaviour carries one of three levels:

| Level | Meaning |
|---|---|
| `confirmed-in-code` | The analysis read the code and the `file:line` was checked to exist |
| `kb-only` | The knowledge base says so, but it was not found in code |
| `inferred` | Neither; reasoning only. Every `inferred` item becomes an open question |

**Contract verdicts.** Each touched API, database schema, event, file or UI contract is `compatible` or `breaking`. A breaking verdict implies an expand/contract split.

**Type conflicts.** A refactor that contains a non-`preserve` behaviour (see above).

**What to correct at the checkpoint.** The report ends with a "What to check" list: the places where you are most likely to know something the analysis does not. Look for:

- Missing dependents (especially when `dependencySource: grep`).
- A behaviour marked `preserve` that you know is changing, or the reverse.
- A contract marked `compatible` that an external consumer would see as breaking.
- Coverage rated higher than the tests deserve.

Choose **Correct scope** and describe what was missed or over-counted. The analysis re-runs with your corrections, at most twice; after that the only options are Approve or Cancel.

## Characterization tests explained

A **characterization test** pins what the code does today, whether or not that is what it should do. It exists so that after your change you can prove what did not change.

**Why pin first, on unmodified code.** `/new-story-impl` runs in two passes. Pass 1 writes only the pinning tests (task group 1, "Pin current behaviour") and runs the suite. They must pass against the unmodified code, and are committed as `test: characterize <area>`. Only then does pass 2 change anything. The separate commit lets a reviewer see that the pinned tests were green before any behaviour moved.

**Intentional changes.** A test that pins a behaviour the story deliberately changes will fail after pass 2. The story's **Target Behaviour** names such tests, and they are updated in the same task. After implementation, a preservation check re-runs the suite: every pinning test must be green except the ones Target Behaviour named, which must have been updated.

**Refactors allow no exceptions.** A refactor story names no intentionally changing tests, so every pinning test must stay green.

## Keeping the knowledge base current

After a change lands, the extraction files that described the old behaviour are stale. `/archive-implemented` step 8.5 refreshes them.

- **Last story does it.** The refresh runs only when every story under `knowledge-base/changes/<id>/stories/` is Done. Until then the output says "Knowledge-base refresh deferred". The last story to be archived does the work.
- **How.** It calls `/fix-knowledge-extraction --change <id> --diff-base origin/main`, which reads `kbRefreshTargets[]` from `impact.json`, adds extraction files that cite any file the merged diff touched, and applies the refresh. The default is a direct edit of the anchored sections; it escalates to an agent re-run only when the change is `sizing: programme` or touches a breaking data-model or integration contract.
- **Provenance markers.** Each edited extraction section gets `<!-- updated-by: change <id> -->`, so you can see what a change touched.
- **`refresh.json`.** Written to `knowledge-base/changes/<id>/refresh.json`, it records each target, the action (`direct-edit`, `agent-rerun` or `skipped`), and an overall `status` of `done` or `pending`. It is committed with the archive commit.
- **Failure does not block the archive.** The code is already merged. A failed refresh leaves `status: pending`, and you retry with:

```
/fix-knowledge-extraction --change <id>
```

A standalone retry does not commit; commit the result yourself.

## Troubleshooting

**A pinning test fails on unmodified code.** `/new-story-impl` stops after pass 1. Either the test is wrong or current behaviour is not what the impact analysis said; both mean `impact.json` is wrong. Do not weaken the test. Re-analyse with `/propose-change --id <slug> "<intent>"`, choose **Re-analyse**, and correct the scope.

**The change is flagged `sizing: programme`.** It touches more than 3 capabilities or more than 40 files. Split the intent into smaller changes, or accept the warning and continue knowingly. Planned multi-quarter work on the current stack is a [Planned path](modernization-strategies.md#status-labels).

**Scope drift warning.** After implementation, the files in the diff are compared with `codeImpact[]`. Files outside the declared impact are listed under **Scope drift** in the final output and the merge request description. It does not block: impact analysis is a forecast, not a fence. Check whether the extra files are a real dependency the analysis missed, and if so, correct `impact.json`.

**Refresh left `pending`.** Run `/fix-knowledge-extraction --change <id>`, review the result, and commit it. `refresh.json` shows which targets were `skipped`.

**A story is locked when you re-analyse.** Re-running `/propose-change` on an existing id offers **Re-analyse** (overwrites `impact.*`) or **New id**. On re-analyse, every story that is no longer Draft is locked and left untouched; only Draft stories are rewritten.

**Validate a change.** `/validate-backlog --changes [<id>]` runs two deterministic checkers (impact invariants and change-story structure) without any agent, and prints OK or FAILED per change.
